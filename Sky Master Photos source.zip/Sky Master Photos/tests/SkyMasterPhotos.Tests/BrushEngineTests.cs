using Avalonia;
using Avalonia.Media;
using SkyMasterPhotos.Core;
using Xunit;

namespace SkyMasterPhotos.Tests;

/// <summary>The lazy-block brush engine, pen pressure and the optimized blur kernels.</summary>
public class BrushEngineTests
{
    static Document Photo(int w = 300, int h = 200)
    {
        var d = Document.CreateBlank(w, h, "t", Colors.White);
        var px = new uint[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                px[y * w + x] = 0xFF000000u | (uint)((x * 7) & 255) << 16 | (uint)((y * 5) & 255) << 8 | (uint)((x ^ y) & 255);
        d.Layers[0].SetPixels(px, w, h);
        d.ActiveLayer = d.Layers[0];
        d.RenderAll();
        return d;
    }

    static int Painted(uint[] a, uint[] b) => a.Zip(b).Count(p => p.First != p.Second);

    [Fact]
    public void Stroke_across_many_blocks_undoes_exactly()
    {
        var d = Photo();
        var l = d.ActiveLayer;
        var before = (uint[])l.Pixels.Clone();
        var s = new StrokeSession(d, l, StrokeKind.Paint, new BrushSettings { Size = 50, Hardness = 0.5 }, 0xFFFF0000, new Vector());
        for (int i = 0; i <= 20; i++) d.Render(s.MoveTo(new Point(5 + i * 14, 10 + i * 9)));
        s.Commit("Brush");
        Assert.True(Painted(before, l.Pixels) > 3000);
        d.Undo();
        Assert.Equal(before, l.Pixels);
        d.Redo();
        Assert.True(Painted(before, l.Pixels) > 3000);
    }

    [Fact]
    public void Cancel_restores_the_original_pixels()
    {
        var d = Photo();
        var l = d.ActiveLayer;
        var before = (uint[])l.Pixels.Clone();
        var s = new StrokeSession(d, l, StrokeKind.Erase, new BrushSettings { Size = 40 }, 0, new Vector());
        d.Render(s.MoveTo(new Point(20, 20)));
        d.Render(s.MoveTo(new Point(280, 180)));
        Assert.NotEqual(before, l.Pixels);
        s.Cancel();
        Assert.Equal(before, l.Pixels);
    }

    [Fact]
    public void Stroke_never_builds_past_its_opacity_when_crossing_itself()
    {
        var d = Photo();
        var l = d.ActiveLayer;
        var orig = l.Pixels[100 * 300 + 150];
        var s = new StrokeSession(d, l, StrokeKind.Paint, new BrushSettings { Size = 30, Hardness = 1, Opacity = 0.5 }, 0xFF000000, new Vector());
        for (int k = 0; k < 6; k++) { d.Render(s.MoveTo(new Point(100, 100))); d.Render(s.MoveTo(new Point(200, 100))); }
        uint p = l.Pixels[100 * 300 + 150];
        // half-way between the original and black, however often the stroke went over it
        Assert.InRange((int)Px.R(p), (int)(Px.R(orig) * 0.5) - 2, (int)(Px.R(orig) * 0.5) + 2);
    }

    [Fact]
    public void Clone_reads_the_original_even_where_the_stroke_already_painted()
    {
        var d = Photo();
        var l = d.ActiveLayer;
        var before = (uint[])l.Pixels.Clone();
        // source 100 px to the left; the stroke runs left to right through its own source area
        var s = new StrokeSession(d, l, StrokeKind.Clone, new BrushSettings { Size = 20, Hardness = 1 }, 0, new Vector(-100, 0));
        for (int x = 110; x <= 290; x += 4) d.Render(s.MoveTo(new Point(x, 100)));
        s.Commit("Clone");
        // the pixel at 250 must show the ORIGINAL pixel from 150, not the already-cloned one
        Assert.Equal(before[100 * 300 + 150], l.Pixels[100 * 300 + 250]);
    }

    [Fact]
    public void Light_pen_pressure_paints_a_thinner_line()
    {
        int Width(float pressure)
        {
            var d = Photo();
            var l = d.ActiveLayer;
            var before = (uint[])l.Pixels.Clone();
            var s = new StrokeSession(d, l, StrokeKind.Paint, new BrushSettings { Size = 40, Hardness = 1, PressureSize = true }, 0xFFFF0000, new Vector());
            s.MoveTo(new Point(50, 100), pressure);
            s.MoveTo(new Point(250, 100), pressure);
            int n = 0;
            for (int y = 0; y < 200; y++) if (l.Pixels[y * 300 + 150] != before[y * 300 + 150]) n++;
            return n;
        }
        int full = Width(1f), light = Width(0.25f);
        Assert.InRange(full, 36, 44);
        Assert.InRange(light, 8, 13);
    }

    [Fact]
    public void Pressure_can_be_ignored()
    {
        var d = Photo();
        var l = d.ActiveLayer;
        var before = (uint[])l.Pixels.Clone();
        var s = new StrokeSession(d, l, StrokeKind.Paint, new BrushSettings { Size = 40, Hardness = 1, PressureSize = false }, 0xFFFF0000, new Vector());
        s.MoveTo(new Point(50, 100), 0.1f);
        s.MoveTo(new Point(250, 100), 0.1f);
        int n = 0;
        for (int y = 0; y < 200; y++) if (l.Pixels[y * 300 + 150] != before[y * 300 + 150]) n++;
        Assert.InRange(n, 36, 44);
    }

    [Fact]
    public void Big_brushes_paint_the_same_as_small_ones_scaled()
    {
        // the >40 000 px dab path runs rows in parallel: it must give a clean, symmetric disc
        var d = Photo(800, 800);
        var l = d.ActiveLayer;
        var s = new StrokeSession(d, l, StrokeKind.Paint, new BrushSettings { Size = 500, Hardness = 1 }, 0xFF00FF00, new Vector());
        d.Render(s.MoveTo(new Point(400, 400)));
        Assert.Equal(0xFF00FF00u, l.Pixels[400 * 800 + 400]);
        Assert.Equal(0xFF00FF00u, l.Pixels[400 * 800 + 160]);
        Assert.Equal(0xFF00FF00u, l.Pixels[160 * 800 + 400]);
        Assert.NotEqual(0xFF00FF00u, l.Pixels[400 * 800 + 140]);
        Assert.NotEqual(0xFF00FF00u, l.Pixels[140 * 800 + 400]);
    }

    [Fact]
    public void Optimized_blurs_match_a_simple_reference()
    {
        int w = 150, h = 90;
        var src = new uint[w * h];
        var rnd = new Random(7);
        for (int i = 0; i < src.Length; i++) src[i] = (uint)rnd.Next() | 0xFF000000u;
        // box blur (strip-based vertical pass) vs a naive clamp-to-edge box filter
        int r = 3;
        var fast = Filters.BoxBlur(src, w, h, r);
        for (int y = 0; y < h; y += 7)
            for (int x = 0; x < w; x += 5)
            {
                double sr = 0;
                // separable: horizontal then vertical, both clamped (same as the engine)
                for (int dy = -r; dy <= r; dy++)
                {
                    int yy = Math.Clamp(y + dy, 0, h - 1);
                    double row = 0;
                    for (int dx = -r; dx <= r; dx++) row += Px.R(src[yy * w + Math.Clamp(x + dx, 0, w - 1)]);
                    sr += row / (2 * r + 1);
                }
                sr /= 2 * r + 1;
                Assert.InRange(Px.R(fast[y * w + x]), (int)sr - 1, (int)sr + 1);
            }
        // motion blur with precomputed taps: a horizontal blur of a vertical edge
        var edge = new uint[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) edge[y * w + x] = x < 75 ? 0xFF000000u : 0xFFFFFFFFu;
        var mb = Filters.MotionBlur(edge, w, h, 0, 10);
        Assert.Equal(0xFF000000u, mb[45 * w + 50]);
        Assert.Equal(0xFFFFFFFFu, mb[45 * w + 100]);
        Assert.InRange(Px.R(mb[45 * w + 75]), 115, 140);
    }
}

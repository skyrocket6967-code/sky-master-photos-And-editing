using Avalonia.Media;
using SkyMasterPhotos.Core;
using Xunit;

namespace SkyMasterPhotos.Tests;

/// <summary>Layer styles rendered for a dirty rect must match the full-layer render exactly.</summary>
public class LayerStyleRegionTests
{
    // the feather blur uses float running sums: a different work area can round a channel by one level
    static bool Close(uint a, uint b)
    {
        for (int s = 0; s < 32; s += 8) if (Math.Abs((int)((a >> s) & 255) - (int)((b >> s) & 255)) > 1) return false;
        return true;
    }

    static uint[] Shapes(int w, int h)
    {
        var px = new uint[w * h];
        var rnd = new Random(3);
        for (int k = 0; k < 14; k++)
        {
            int cx = rnd.Next(w), cy = rnd.Next(h), r = rnd.Next(5, 40);
            uint col = 0xFF000000u | (uint)rnd.Next(0xFFFFFF);
            uint a = (uint)rnd.Next(80, 256) << 24;
            for (int y = Math.Max(0, cy - r); y < Math.Min(h, cy + r); y++)
                for (int x = Math.Max(0, cx - r); x < Math.Min(w, cx + r); x++)
                    if ((x - cx) * (x - cx) + (y - cy) * (y - cy) < r * r) px[y * w + x] = (col & 0xFFFFFF) | a;
        }
        return px;
    }

    public static IEnumerable<object[]> Styles()
    {
        yield return new object[] { new LayerStyle { Shadow = true, Size = 8, Distance = 8 } };
        yield return new object[] { new LayerStyle { Shadow = true, Size = 3, Distance = 60, Angle = -40 } };
        yield return new object[] { new LayerStyle { OuterGlow = true, Size = 25 } };
        yield return new object[] { new LayerStyle { InnerGlow = true, Bevel = true, Size = 12 } };
        yield return new object[] { new LayerStyle { Stroke = true, Size = 6 } };
        yield return new object[] { new LayerStyle { Shadow = true, OuterGlow = true, InnerGlow = true, Bevel = true, Stroke = true, Size = 17, Distance = 23, Angle = 200 } };
    }

    [Theory]
    [MemberData(nameof(Styles))]
    public void Region_render_matches_full_render(LayerStyle style)
    {
        int w = 260, h = 190;
        var px = Shapes(w, h);
        var mask = new uint[w * h];
        for (int i = 0; i < mask.Length; i++) mask[i] = Masks.Gray((byte)(i % w * 255 / w));
        foreach (var m in new[] { null, mask })
        {
            var full = style.Render(px, m, w, h, 0.8);
            foreach (var r in new[] { new Int32Rect(0, 0, 40, 40), new Int32Rect(100, 70, 50, 30), new Int32Rect(230, 160, 40, 40), new Int32Rect(-10, 90, 60, 20), new Int32Rect(0, 0, w, h) })
            {
                var part = style.Render(px, m, w, h, 0.8, r, new uint[w * h]);
                var rr = RectUtil.Clip(r, w, h);
                for (int y = rr.Y; y < rr.Y + rr.Height; y++)
                    for (int x = rr.X; x < rr.X + rr.Width; x++)
                        Assert.True(Close(full[y * w + x], part[y * w + x]), $"{style} rect {r} differs at {x},{y}: {full[y * w + x]:X8} vs {part[y * w + x]:X8}");
            }
        }
    }

    [Fact]
    public void Painting_on_a_styled_layer_composites_like_a_full_render()
    {
        var d = Document.CreateBlank(300, 200, "t", Colors.White);
        var l = new Layer("Shape", 300, 200, Shapes(300, 200)) { Style = new LayerStyle { Shadow = true, Stroke = true, Size = 10, Distance = 12 } };
        d.Layers.Insert(0, l);
        d.ActiveLayer = l;
        d.RenderAll();
        var s = new StrokeSession(d, l, StrokeKind.Paint, new BrushSettings { Size = 20, Hardness = 1 }, 0xFFFF0000, new Avalonia.Vector());
        for (int x = 40; x <= 260; x += 6) d.Render(s.MoveTo(new Avalonia.Point(x, 100)));   // partial composites only
        var incremental = (uint[])d.Flat.Clone();
        d.RenderAll();
        for (int i = 0; i < incremental.Length; i++)
            Assert.True(Close(d.Flat[i], incremental[i]), $"pixel {i % 300},{i / 300}: {incremental[i]:X8} after painting vs {d.Flat[i]:X8} after a full render");
    }
}

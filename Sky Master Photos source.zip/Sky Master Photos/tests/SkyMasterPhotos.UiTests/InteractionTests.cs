using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Headless.XUnit;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Media;
using Avalonia.LogicalTree;
using Avalonia.VisualTree;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Tools;
using SkyMasterPhotos.UI;
using Xunit;

namespace SkyMasterPhotos.UiTests;

public class InteractionTests
{
    [AvaloniaFact]
    public void Brush_keys_change_size_colors_and_opacity()
    {
        using var ui = new Ui();
        ui.OpenImage();
        ui.Key(Key.B);
        double size = ui.W.Ctl.CurrentBrush.Size;
        ui.Key(Key.OemCloseBrackets);
        Assert.True(ui.W.Ctl.CurrentBrush.Size > size);
        ui.Key(Key.OemOpenBrackets);
        ui.Key(Key.OemOpenBrackets);
        Assert.True(ui.W.Ctl.CurrentBrush.Size < size);
        ui.Key(Key.D);
        Assert.Equal(Colors.Black, ui.W.Fg);
        ui.Key(Key.X);
        Assert.Equal(Colors.White, ui.W.Fg);
        ui.Key(Key.D5);
        Assert.Equal(0.5, ui.W.Ctl.CurrentBrush.Opacity, 3);
        ui.Key(Key.D0);
        Assert.Equal(1, ui.W.Ctl.CurrentBrush.Opacity, 3);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Space_drag_pans_and_tab_hides_panels()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.B);
        var pan = ui.Doc.Pan;
        ui.W.KeyPress(Key.Space, RawInputModifiers.None, PhysicalKey.Space, " ");
        ui.Pump();
        uint before = ui.DocPixel(200, 150);
        ui.Drag(ui.At(100, 100), ui.At(180, 140));
        ui.W.KeyRelease(Key.Space, RawInputModifiers.None, PhysicalKey.Space, " ");
        ui.Pump();
        Assert.NotEqual(pan, ui.Doc.Pan);
        Assert.Equal(before, ui.DocPixel(200, 150));   // panning must not paint
        double w = ui.W.Canvas.Bounds.Width;
        ui.Key(Key.Tab);
        ui.Pump(3);
        Assert.True(ui.W.Canvas.Bounds.Width > w);
        ui.Key(Key.Tab);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Delete_clears_selection_and_alt_backspace_fills()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);
        ui.W.Ctl.Tool = Tool.MarqueeRect;
        ui.Drag(ui.At(100, 100), ui.At(200, 200));
        ui.Key(Key.D);   // black / white
        ui.Key(Key.Back, RawInputModifiers.Alt);
        Assert.Equal(0xFF000000u, ui.Doc.Layers[0].Pixels[150 * 400 + 150]);
        ui.Key(Key.Delete);
        Assert.Equal(0u, ui.Doc.Layers[0].Pixels[150 * 400 + 150] >> 24);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Copy_paste_makes_a_new_layer()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.W.Ctl.Tool = Tool.MarqueeRect;
        ui.Drag(ui.At(50, 50), ui.At(150, 120));
        ui.Key(Key.C, RawInputModifiers.Control);
        ui.Key(Key.V, RawInputModifiers.Control);
        Assert.Equal(2, ui.Doc.Layers.Count);
        Assert.Equal("Pasted", ui.Doc.Layers[0].Name);
        ui.Key(Key.J, RawInputModifiers.Control | RawInputModifiers.Shift);   // layer via cut
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Shapes_lasso_polygon_and_wand()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);
        foreach (var t in new[] { Tool.ShapeRect, Tool.ShapeEllipse, Tool.ShapeLine })
        {
            ui.W.Ctl.Tool = t;
            ui.Drag(ui.At(50, 50), ui.At(250, 200));
        }
        Assert.True(ui.Doc.Layers.Count >= 2);
        ui.W.Ctl.Tool = Tool.Lasso;
        ui.Drag(ui.At(60, 60), ui.At(200, 180), steps: 20);
        ui.Key(Key.D, RawInputModifiers.Control);
        ui.W.Ctl.Tool = Tool.PolyLasso;
        ui.Click(ui.At(50, 50)); ui.Click(ui.At(200, 60)); ui.Click(ui.At(120, 200));
        ui.Click(ui.At(50, 50));   // back on the first point closes it
        Assert.True(ui.Doc.HasSelection);
        ui.Key(Key.D, RawInputModifiers.Control);
        ui.W.Ctl.Tool = Tool.MagicWand;
        ui.Click(ui.At(20, 20));
        Assert.True(ui.Doc.HasSelection);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Clone_stamp_needs_a_source_then_paints()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.W.Ctl.Tool = Tool.Clone;
        uint before = ui.DocPixel(300, 150);
        ui.Drag(ui.At(280, 150), ui.At(320, 150));   // no source yet: nothing happens
        Assert.Equal(before, ui.DocPixel(300, 150));
        ui.Click(ui.At(30, 30), RawInputModifiers.Alt);
        ui.Drag(ui.At(280, 150), ui.At(320, 150));
        Assert.NotEqual(before, ui.DocPixel(300, 150));
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Free_transform_handles_scale_the_layer()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);
        ui.W.Ctl.Tool = Tool.Brush;
        ui.W.Ctl.CurrentBrush.Size = 30;
        ui.Drag(ui.At(150, 150), ui.At(250, 150));
        ui.Key(Key.T, RawInputModifiers.Control);
        Assert.NotNull(ui.W.Ctl.Xf);
        var c = ui.W.Ctl.Xf.Corners();
        ui.Drag(ui.At(c[2].X, c[2].Y), ui.At(c[2].X + 60, c[2].Y + 40));   // bottom-right handle
        ui.Key(Key.Enter);
        Assert.Null(ui.W.Ctl.Xf);
        ui.Key(Key.Z, RawInputModifiers.Control);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Layer_panel_eye_lock_and_history_clicks()
    {
        using var ui = new Ui();
        ui.OpenImage(300, 200);
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);
        ui.Pump(3);
        var eye = ui.W.LayerList.GetVisualDescendants().OfType<Button>().First(b => ToolTip.GetTip(b) as string == "Show / hide");
        var layer = (Layer)eye.Tag;
        eye.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        Assert.False(layer.Visible);
        var lockBtn = ui.W.LayerList.GetVisualDescendants().OfType<Button>().First(b => ToolTip.GetTip(b) as string == "Lock / unlock");
        lockBtn.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
        Assert.True(((Layer)lockBtn.Tag).Locked);
        // a locked layer refuses to be painted
        ui.Doc.ActiveLayer = (Layer)lockBtn.Tag;
        ui.W.Ctl.Tool = Tool.Brush;
        var px = (uint[])ui.Doc.ActiveLayer.Pixels.Clone();
        ui.Drag(ui.At(50, 100), ui.At(250, 100));
        Assert.Equal(px, ui.Doc.ActiveLayer.Pixels);
        // history panel: jump back to the first step
        ui.W.HistoryList.SelectedIndex = 0;
        ui.Pump(3);
        Assert.Single(ui.Doc.Layers);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Tabs_switch_documents_and_close_asks_about_unsaved_work()
    {
        using var ui = new Ui();
        var a = ui.OpenImage(300, 200, "a.png");
        var b = ui.OpenImage(320, 240, "b.png");
        Assert.Same(b, ui.Doc);
        var tabs = ui.W.TabsHost.Children.OfType<Border>().ToList();
        Assert.Equal(2, tabs.Count);
        var p = tabs[0].TranslatePoint(new Point(20, tabs[0].Bounds.Height / 2), ui.W).Value;
        ui.Click(p);
        Assert.Same(a, ui.Doc);
        // paint so it's unsaved, then close: the save prompt appears; "cancel" keeps it open
        ui.W.Ctl.Tool = Tool.Brush;
        ui.Drag(ui.At(20, 20), ui.At(200, 100));
        Assert.True(a.IsDirty);
        int prompts = 0;
        SkyDialog.TestResponder = _ => { prompts++; return null; };
        SkyDialog.TestResponder = d => { prompts++; d.Close(); return null; };
        ui.Key(Key.W, RawInputModifiers.Control);
        Assert.Equal(1, prompts);
        Assert.Contains(a, ui.W.Docs);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Dropping_a_file_adds_it_as_a_layer()
    {
        using var ui = new Ui();
        ui.OpenImage(300, 200);
        var dir = Path.Combine(Path.GetTempPath(), "smp-uitests-files");
        var file = Path.Combine(dir, "drop.png");
        ImageIO.SaveImage(file, Enumerable.Repeat(0xFF00FF00u, 50 * 40).ToArray(), 50, 40);
        ui.W.PlaceFile(file, false);
        ui.Pump(3);
        Assert.Equal(2, ui.Doc.Layers.Count);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Undo_and_redo_many_times_stays_consistent()
    {
        using var ui = new Ui();
        ui.OpenImage(300, 200);
        ui.W.Ctl.Tool = Tool.Brush;
        var states = new List<uint[]> { (uint[])ui.Doc.Flat.Clone() };
        for (int i = 0; i < 8; i++)
        {
            ui.Drag(ui.At(20 + i * 30, 20), ui.At(20 + i * 30, 180));
            states.Add((uint[])ui.Doc.Flat.Clone());
        }
        for (int i = 7; i >= 0; i--) { ui.Key(Key.Z, RawInputModifiers.Control); Assert.Equal(states[i], ui.Doc.Flat); }
        for (int i = 1; i <= 8; i++) { ui.Key(Key.Y, RawInputModifiers.Control); Assert.Equal(states[i], ui.Doc.Flat); }
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Preferences_window_changes_settings()
    {
        using var ui = new Ui();
        ui.OpenImage();
        bool before = AppStore.Settings.ShowGrid;
        string title = null;
        SkyDialog.TestResponder = d =>
        {
            title = d.Title;
            var grid = d.GetVisualDescendants().OfType<CheckBox>().First(c => c.Content as string == "Show grid");
            grid.IsChecked = !grid.IsChecked;
            return true;
        };
        ui.Key(Key.K, RawInputModifiers.Control);
        Assert.Equal("Preferences", title);
        Assert.Equal(!before, AppStore.Settings.ShowGrid);
        AppStore.Settings.ShowGrid = false;
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Grid_draws_lines_on_the_canvas()
    {
        using var ui = new Ui();
        var d = ui.OpenImage(400, 300);
        ui.W.Canvas.ZoomAt(new Point(ui.W.Canvas.Bounds.Width / 2, ui.W.Canvas.Bounds.Height / 2), 1);
        ui.W.Canvas.CenterOn(new Point(200, 150));
        var off = ui.ScreenPixel(100, 120);
        AppStore.Settings.GridSize = 50;
        ui.Key(Key.OemQuotes, RawInputModifiers.Control);
        Assert.True(AppStore.Settings.ShowGrid);
        var on = ui.ScreenPixel(100, 120);   // x = 100 is a grid line
        Assert.NotEqual(off, on);
        ui.Key(Key.OemQuotes, RawInputModifiers.Control);
        Assert.False(AppStore.Settings.ShowGrid);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Hidden_task_bar_is_really_gone_and_stays_hidden()
    {
        using var ui = new Ui();
        ui.OpenImage();
        Assert.True(ui.W.TaskBar.IsVisible);
        var item = MenuSweepTests.Leaves(ui.W.MainMenu, "").First(l => l.path.EndsWith("Show / hide task bar")).item;
        item.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
        ui.Pump();
        Assert.False(ui.W.TaskBar.IsVisible);
        ui.OpenImage(200, 100, "second.png");   // switching documents rebuilds the bar
        Assert.False(ui.W.TaskBar.IsVisible);
        ui.AssertNoErrors();
    }
}

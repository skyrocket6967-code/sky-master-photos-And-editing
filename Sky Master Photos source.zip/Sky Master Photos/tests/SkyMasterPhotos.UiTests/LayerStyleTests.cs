using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Headless.XUnit;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.VisualTree;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Tools;
using SkyMasterPhotos.UI;
using Xunit;
using Xunit.Abstractions;

namespace SkyMasterPhotos.UiTests;

public class LayerStyleTests
{
    readonly ITestOutputHelper _out;
    public LayerStyleTests(ITestOutputHelper o) => _out = o;

    [AvaloniaFact]
    public void Layer_style_dialog_applies_shadow_and_stroke()
    {
        using var ui = new Ui();
        ui.OpenImage(300, 200);
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);   // transparent layer
        ui.W.Ctl.Tool = Tool.Brush;
        ui.W.Ctl.CurrentBrush.Size = 40;
        ui.Drag(ui.At(80, 100), ui.At(220, 100));
        var before = (uint[])ui.Doc.Flat.Clone();
        var layer = ui.Doc.ActiveLayer;
        string seen = null;
        SkyDialog.TestResponder = d =>
        {
            var boxes = d.GetVisualDescendants().OfType<CheckBox>().ToList();
            seen = string.Join(", ", boxes.Select(b => b.Content));
            boxes.First(b => b.Content as string == "Drop shadow").IsChecked = true;
            boxes.First(b => b.Content as string == "Stroke").IsChecked = true;
            ui.Pump(2);
            d.DefaultButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));   // press Apply like a user
            return null;
        };
        var item = MenuSweepTests.Leaves(ui.W.MainMenu, "").First(l => l.path.EndsWith("Layer style…")).item;
        item.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
        ui.Pump(5);
        _out.WriteLine("checkboxes: " + seen);
        _out.WriteLine("style: " + layer.Style);
        Assert.NotNull(layer.Style);
        Assert.True(layer.Style.Enabled, "style not enabled");
        int changed = before.Zip(ui.Doc.Flat).Count(p => p.First != p.Second);
        _out.WriteLine("changed pixels: " + changed);
        Assert.True(changed > 500, $"only {changed} pixels changed");
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Layer_style_checkboxes_respond_to_mouse_clicks()
    {
        using var ui = new Ui();
        ui.OpenImage(300, 200);
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);
        ui.W.Ctl.Tool = Tool.Brush;
        ui.W.Ctl.CurrentBrush.Size = 40;
        ui.Drag(ui.At(80, 100), ui.At(220, 100));
        var layer = ui.Doc.ActiveLayer;
        string report = "";
        SkyDialog.TestResponder = d =>
        {
            ui.Pump(3);
            using (var frame = d.CaptureRenderedFrame()) frame.Save(Path.Combine(Path.GetTempPath(), "smp-layerstyle-dialog.png"));
            report += $"dialog {d.Bounds.Width}x{d.Bounds.Height}; ";
            foreach (var name in new[] { "Drop shadow", "Stroke" })
            {
                var box = d.GetVisualDescendants().OfType<CheckBox>().First(b => b.Content as string == name);
                // click the middle of the checkbox's text, like a user would
                var p = box.TranslatePoint(new Point(box.Bounds.Width * 0.6, box.Bounds.Height / 2), d).Value;
                d.MouseDown(p, MouseButton.Left);
                d.MouseUp(p, MouseButton.Left);
                ui.Pump(2);
                report += $"{name} at {p} -> {box.IsChecked}; ";
            }
            var apply = d.DefaultButton;
            var ap = apply.TranslatePoint(new Point(apply.Bounds.Width / 2, apply.Bounds.Height / 2), d).Value;
            report += $"apply at {ap}; ";
            d.MouseDown(ap, MouseButton.Left);
            d.MouseUp(ap, MouseButton.Left);
            ui.Pump(2);
            return null;
        };
        var item = MenuSweepTests.Leaves(ui.W.MainMenu, "").First(l => l.path.EndsWith("Layer style…")).item;
        item.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
        ui.Pump(5);
        _out.WriteLine(report);
        _out.WriteLine("style: " + layer.Style);
        Assert.True(layer.Style?.Enabled == true, report);
        ui.AssertNoErrors();
    }
}

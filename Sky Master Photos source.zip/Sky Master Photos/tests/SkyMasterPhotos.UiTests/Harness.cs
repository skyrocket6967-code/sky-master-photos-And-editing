using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Headless;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Threading;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.UI;

[assembly: Avalonia.Headless.AvaloniaTestApplication(typeof(SkyMasterPhotos.UiTests.TestApp))]

namespace SkyMasterPhotos.UiTests;

public class TestApp
{
    public static AppBuilder BuildAvaloniaApp() => AppBuilder.Configure<App>()
        .UseSkia()
        .UseHeadless(new AvaloniaHeadlessPlatformOptions { UseHeadlessDrawing = false });
}

static class Init
{
    /// <summary>Never touch the real settings / recent files: the app's data folder goes to a scratch dir.</summary>
    [ModuleInitializer]
    internal static void Run()
    {
        var dir = Path.Combine(Path.GetTempPath(), "smp-uitests-" + Environment.ProcessId);
        Directory.CreateDirectory(dir);
        Environment.SetEnvironmentVariable("SKY_MASTER_PHOTOS_DATA", dir);
    }
}

/// <summary>The real main window, headless, with keyboard / mouse helpers.</summary>
public sealed class Ui : IDisposable
{
    public readonly MainWindow W;
    public readonly List<Exception> Errors = new();
    void OnError(Exception e) { lock (Errors) Errors.Add(e); }

    public Ui(int width = 1400, int height = 900)
    {
        App.ErrorLogged += OnError;
        // settings are global: every test starts from the defaults
        var st = AppStore.Settings;
        st.ShowGrid = false; st.PixelGrid = true; st.GridSize = 50; st.GpuFilters = true;
        SkyDialog.TestResponder = _ => false;   // any unexpected dialog: cancel it
        W = new MainWindow { Width = width, Height = height };
        App.MainWin = W;
        W.Show();
        Pump(5);
    }

    public Document Doc => W.ActiveDoc;

    public void Pump(int frames = 3)
    {
        for (int i = 0; i < frames; i++)
        {
            Dispatcher.UIThread.RunJobs();
            AvaloniaHeadlessPlatform.ForceRenderTimerTick();
        }
        Dispatcher.UIThread.RunJobs();
    }

    public void Key(Key k, RawInputModifiers m = RawInputModifiers.None)
    {
        W.KeyPress(k, m, PhysicalKey.None, null);
        W.KeyRelease(k, m, PhysicalKey.None, null);
        Pump();
    }

    public void Type(string text)
    {
        W.KeyTextInput(text);
        Pump();
    }

    /// <summary>Window coordinates of a document pixel.</summary>
    public Point At(double x, double y) => W.Canvas.TranslatePoint(W.Canvas.ToScreen(new Point(x, y)), W) ?? default;

    public void Click(Point p, RawInputModifiers m = RawInputModifiers.None, MouseButton b = MouseButton.Left)
    {
        W.MouseMove(p, m);
        W.MouseDown(p, b, m);
        W.MouseUp(p, b, m);
        Pump();
    }

    public void Drag(Point a, Point b, RawInputModifiers m = RawInputModifiers.None, int steps = 12)
    {
        W.MouseMove(a, m);
        W.MouseDown(a, MouseButton.Left, m);
        // real mice report the held button with every move
        for (int i = 1; i <= steps; i++) W.MouseMove(new Point(a.X + (b.X - a.X) * i / steps, a.Y + (b.Y - a.Y) * i / steps), m | RawInputModifiers.LeftMouseButton);
        W.MouseUp(b, MouseButton.Left, m);
        Pump();
    }

    /// <summary>Opens a generated image as a document (no file dialog).</summary>
    public Document OpenImage(int w = 400, int h = 300, string name = "test.png")
    {
        var px = new uint[w * h];
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                px[y * w + x] = 0xFF000000u | (uint)((x * 255 / w) << 16) | (uint)((y * 255 / h) << 8) | 0x40;
        var dir = Path.Combine(Path.GetTempPath(), "smp-uitests-files");
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, Guid.NewGuid().ToString("N")[..8] + "-" + name);
        ImageIO.SaveImage(path, px, w, h);
        W.OpenPath(path);
        Pump(4);
        return Doc;
    }

    public uint DocPixel(int x, int y) => Doc.Flat[y * Doc.Width + x];

    /// <summary>What the canvas actually shows at a document pixel (rendered frame).</summary>
    public Color ScreenPixel(double x, double y)
    {
        Pump(2);
        using var frame = W.CaptureRenderedFrame();
        var p = At(x, y);
        using var fb = frame.Lock();
        unsafe
        {
            int px = (int)p.X, py = (int)p.Y;
            byte* q = (byte*)fb.Address + py * fb.RowBytes + px * 4;
            bool rgba = fb.Format == Avalonia.Platform.PixelFormat.Rgba8888;
            return rgba ? Color.FromArgb(q[3], q[0], q[1], q[2]) : Color.FromArgb(q[3], q[2], q[1], q[0]);
        }
    }

    public void AssertNoErrors() => Xunit.Assert.True(Errors.Count == 0, "errors were logged:\n" + string.Join("\n\n", Errors));

    public void Dispose()
    {
        foreach (var d in W.Docs) d.IsDirty = false;
        SkyDialog.TestResponder = _ => false;
        W.Close();
        Pump(3);
        SkyDialog.TestResponder = null;
        App.ErrorLogged -= OnError;
    }
}

using Avalonia.Controls;
using Avalonia.Headless.XUnit;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.LogicalTree;
using SkyMasterPhotos.Tools;
using SkyMasterPhotos.UI;
using Xunit;

namespace SkyMasterPhotos.UiTests;

/// <summary>Runs every menu command in several document states and fails on any exception or logged error.</summary>
public class MenuSweepTests
{
    // commands that leave the app or touch the desktop outside the test
    static readonly string[] Skip = { "Exit", "Open app data folder" };

    static string HeaderText(MenuItem mi) => mi.Header switch
    {
        string s => s,
        Control c => c.GetLogicalDescendants().OfType<TextBlock>().FirstOrDefault()?.Text ?? c.ToString(),
        _ => mi.Header?.ToString() ?? "?",
    };

    internal static IEnumerable<(string path, MenuItem item)> Leaves(ItemsControl parent, string prefix)
    {
        foreach (var mi in parent.Items.OfType<MenuItem>())
        {
            string path = prefix + " ▸ " + HeaderText(mi);
            if (mi.Items.OfType<MenuItem>().Any())
                foreach (var leaf in Leaves(mi, path)) yield return leaf;
            else yield return (path, mi);
        }
    }

    static void Setup(Ui ui, bool selection, bool maskEdit)
    {
        foreach (var d in ui.W.Docs) d.IsDirty = false;
        foreach (var d in ui.W.Docs.ToList()) ui.W.CloseDoc(d);
        ui.OpenImage(240, 180);
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);
        ui.W.Ctl.Tool = Tool.Brush;
        ui.Drag(ui.At(30, 90), ui.At(210, 90));
        if (selection)
        {
            ui.W.Ctl.Tool = Tool.MarqueeRect;
            ui.Drag(ui.At(40, 40), ui.At(160, 130));
        }
        if (maskEdit)
        {
            var l = ui.Doc.ActiveLayer;
            l.SetMask(Enumerable.Repeat(Core.Masks.Gray(255), ui.Doc.Width * ui.Doc.Height).ToArray());
            l.EditMask = true;
        }
        ui.Pump();
    }

    void Sweep(bool apply, bool selection, bool maskEdit)
    {
        using var ui = new Ui();
        int dialogs = 0, changed = 0, ran = 0;
        SkyDialog.TestResponder = _ => { dialogs++; return apply; };
        var failures = new List<string>();
        var paths = Leaves(ui.W.MainMenu, "").Select(l => l.path).ToList();
        Assert.True(paths.Count > 80, $"only {paths.Count} menu commands found");
        foreach (var path in paths)
        {
            if (Skip.Any(s => path.EndsWith("▸ " + s))) continue;
            Setup(ui, selection, maskEdit);
            ui.Errors.Clear();
            // menus are rebuilt for some states: look the item up again in the current menu
            var item = Leaves(ui.W.MainMenu, "").FirstOrDefault(l => l.path == path).item;
            if (item == null) continue;
            int hist = ui.Doc?.History.Entries.Count ?? -1;
            var docBefore = ui.Doc;
            try
            {
                if (item.IsEnabled) { item.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent)); ran++; }
                ui.Pump(3);
            }
            catch (Exception ex) { failures.Add($"{path}: {ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}"); }
            foreach (var e in ui.Errors) failures.Add($"{path}: logged {e.GetType().Name}: {e.Message}\n{e.StackTrace}");
            if (ui.Doc != docBefore || (ui.Doc?.History.Entries.Count ?? -1) != hist) changed++;
            SkyDialog.TestResponder = _ => { dialogs++; return apply; };
        }
        Console.WriteLine($"sweep apply={apply} selection={selection} mask={maskEdit}: ran {ran} of {paths.Count}, {dialogs} dialogs, {changed} changed the document");
        Assert.True(ran > 80 && dialogs > 15 && changed > 30, $"the sweep didn't really run commands: ran {ran}, dialogs {dialogs}, changed {changed}");
        Assert.True(failures.Count == 0, $"{failures.Count} command(s) failed:\n\n" + string.Join("\n\n", failures));
    }

    [AvaloniaFact] public void Every_command_with_dialogs_cancelled() => Sweep(false, false, false);
    [AvaloniaFact] public void Every_command_with_dialogs_applied() => Sweep(true, false, false);
    [AvaloniaFact] public void Every_command_with_a_selection() => Sweep(true, true, false);
    [AvaloniaFact] public void Every_command_while_editing_a_mask() => Sweep(true, true, true);
}

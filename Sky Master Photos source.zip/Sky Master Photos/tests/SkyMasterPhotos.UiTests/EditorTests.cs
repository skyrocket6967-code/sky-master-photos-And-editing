using Avalonia;
using Avalonia.Headless;
using Avalonia.Headless.XUnit;
using Avalonia.Input;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Tools;
using Xunit;

namespace SkyMasterPhotos.UiTests;

public class EditorTests
{
    [AvaloniaFact]
    public void Starts_on_the_home_screen()
    {
        using var ui = new Ui();
        Assert.True(ui.W.HomeHost.IsVisible);
        Assert.False(ui.W.Editor.IsVisible);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Opening_an_image_shows_the_editor_with_one_layer()
    {
        using var ui = new Ui();
        var d = ui.OpenImage(400, 300);
        Assert.NotNull(d);
        Assert.True(ui.W.Editor.IsVisible);
        Assert.Single(d.Layers);
        Assert.Equal(400, d.Width);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Brush_drag_paints_and_undo_redo_work()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.B);
        Assert.Equal(Tool.Brush, ui.W.Ctl.Tool);
        uint before = ui.DocPixel(200, 150);
        ui.Drag(ui.At(100, 150), ui.At(300, 150));
        uint after = ui.DocPixel(200, 150);
        Assert.NotEqual(before, after);
        ui.Key(Key.Z, RawInputModifiers.Control);
        Assert.Equal(before, ui.DocPixel(200, 150));
        ui.Key(Key.Z, RawInputModifiers.Control | RawInputModifiers.Shift);
        Assert.Equal(after, ui.DocPixel(200, 150));
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Eraser_and_smoothing_paint_too()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.E);
        Assert.Equal(Tool.Eraser, ui.W.Ctl.Tool);
        ui.W.Ctl.CurrentBrush.Smoothing = 0.6;
        ui.Drag(ui.At(50, 50), ui.At(350, 250), steps: 30);
        Assert.True((ui.Doc.Layers[0].Pixels[150 * 400 + 200] >> 24) < 255, "the eraser should have made the middle transparent");
        ui.AssertNoErrors();
    }

    [AvaloniaTheory]
    [InlineData(Key.V, Tool.Move)]
    [InlineData(Key.M, Tool.MarqueeRect)]
    [InlineData(Key.L, Tool.Lasso)]
    [InlineData(Key.W, Tool.MagicWand)]
    [InlineData(Key.C, Tool.Crop)]
    [InlineData(Key.I, Tool.Eyedropper)]
    [InlineData(Key.B, Tool.Brush)]
    [InlineData(Key.E, Tool.Eraser)]
    [InlineData(Key.G, Tool.Gradient)]
    [InlineData(Key.T, Tool.Text)]
    [InlineData(Key.H, Tool.Hand)]
    [InlineData(Key.Z, Tool.Zoom)]
    public void Tool_shortcuts_pick_the_tool(Key key, Tool expected)
    {
        using var ui = new Ui();
        ui.OpenImage();
        ui.Key(key);
        Assert.Equal(ToolInfo.GroupOf(expected), ToolInfo.GroupOf(ui.W.Ctl.Tool));
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Marquee_selects_and_ctrl_d_deselects()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.M);
        ui.W.Ctl.Tool = Tool.MarqueeRect;
        ui.Drag(ui.At(50, 50), ui.At(200, 150));
        Assert.True(ui.Doc.HasSelection);
        var b = ui.Doc.SelectionBounds;
        Assert.InRange(b.Width, 140, 160);
        ui.Key(Key.D, RawInputModifiers.Control);
        Assert.False(ui.Doc.HasSelection);
        ui.Key(Key.A, RawInputModifiers.Control);
        Assert.True(ui.Doc.HasSelection);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Layer_shortcuts_add_duplicate_merge()
    {
        using var ui = new Ui();
        ui.OpenImage();
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);
        Assert.Equal(2, ui.Doc.Layers.Count);
        ui.Key(Key.J, RawInputModifiers.Control);
        Assert.Equal(3, ui.Doc.Layers.Count);
        ui.Key(Key.E, RawInputModifiers.Control);
        Assert.Equal(2, ui.Doc.Layers.Count);
        ui.Key(Key.E, RawInputModifiers.Control | RawInputModifiers.Shift);   // merge visible
        ui.Key(Key.Z, RawInputModifiers.Control);
        Assert.Equal(2, ui.Doc.Layers.Count);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Zoom_shortcuts_change_the_view()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.D1, RawInputModifiers.Control);
        Assert.Equal(1, ui.Doc.Zoom, 3);
        ui.Key(Key.OemPlus, RawInputModifiers.Control);
        Assert.True(ui.Doc.Zoom > 1);
        ui.Key(Key.OemMinus, RawInputModifiers.Control);
        ui.Key(Key.OemMinus, RawInputModifiers.Control);
        Assert.True(ui.Doc.Zoom < 1);
        ui.Key(Key.D0, RawInputModifiers.Control);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Text_tool_types_and_commits_a_text_layer()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.T);
        ui.Click(ui.At(60, 80));
        Assert.True(ui.W.Ctl.TextActive);
        ui.Type("Hello");
        ui.Key(Key.Enter, RawInputModifiers.Control);
        Assert.False(ui.W.Ctl.TextActive);
        Assert.Equal(2, ui.Doc.Layers.Count);
        Assert.True(ui.Doc.Layers[0].IsText);
        Assert.Equal("Hello", ui.Doc.Layers[0].Text.Text);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Free_transform_and_crop_apply_with_enter()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.T, RawInputModifiers.Control);
        Assert.NotNull(ui.W.Ctl.Xf);
        ui.Key(Key.Enter);
        Assert.Null(ui.W.Ctl.Xf);
        ui.Key(Key.C);
        ui.Drag(ui.At(20, 20), ui.At(220, 170));
        ui.Key(Key.Enter);
        Assert.InRange(ui.Doc.Width, 190, 210);
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Gradient_bucket_and_eyedropper_work()
    {
        using var ui = new Ui();
        ui.OpenImage(400, 300);
        ui.Key(Key.N, RawInputModifiers.Control | RawInputModifiers.Shift);
        ui.Key(Key.G);
        ui.W.Ctl.Tool = Tool.Gradient;
        ui.Drag(ui.At(10, 150), ui.At(390, 150));
        Assert.True((ui.Doc.Layers[0].Pixels[150 * 400 + 200] >> 24) > 0);
        ui.W.Ctl.Tool = Tool.Eyedropper;
        ui.Click(ui.At(390, 10));
        ui.W.Ctl.Tool = Tool.Bucket;
        ui.Click(ui.At(200, 150));
        ui.AssertNoErrors();
    }

    [AvaloniaTheory]
    [InlineData(1.0)]
    [InlineData(0.37)]
    [InlineData(3.0)]
    public void Canvas_shows_the_document_pixels(double zoom)
    {
        using var ui = new Ui();
        var d = ui.OpenImage(1200, 900);   // several GPU tiles
        ui.W.Ctl.Tool = Tool.Hand;          // no brush cursor drawn over the sampled pixels
        ui.W.MouseMove(new Point(2, 2));
        ui.W.Canvas.ZoomAt(new Point(ui.W.Canvas.Bounds.Width / 2, ui.W.Canvas.Bounds.Height / 2), zoom);
        ui.W.Canvas.CenterOn(new Point(600, 450));
        foreach (var (x, y) in new[] { (600, 450), (513, 450), (600, 511), (700, 520) })
        {
            uint want = d.Flat[y * d.Width + x];
            var got = ui.ScreenPixel(x + 0.5, y + 0.5);
            int dr = Math.Abs(got.R - (int)((want >> 16) & 255)), dg = Math.Abs(got.G - (int)((want >> 8) & 255)), db = Math.Abs(got.B - (int)(want & 255));
            Assert.True(dr <= 6 && dg <= 6 && db <= 6, $"at {x},{y} zoom {zoom}: screen {got} vs document {want:X8}");
        }
        ui.AssertNoErrors();
    }

    [AvaloniaFact]
    public void Painting_updates_the_canvas_on_screen()
    {
        using var ui = new Ui();
        ui.OpenImage(1200, 900);
        ui.W.Canvas.ZoomAt(new Point(ui.W.Canvas.Bounds.Width / 2, ui.W.Canvas.Bounds.Height / 2), 0.5);
        ui.W.Canvas.CenterOn(new Point(600, 450));
        ui.W.Ctl.Tool = Tool.Brush;
        ui.W.Ctl.CurrentBrush.Size = 60;
        ui.W.SetFg(Avalonia.Media.Colors.Red);
        ui.Drag(ui.At(400, 450), ui.At(800, 450));
        var got = ui.ScreenPixel(600, 450);
        Assert.True(got.R > 200 && got.G < 60 && got.B < 60, $"expected red on screen, got {got}");
        ui.AssertNoErrors();
    }
}

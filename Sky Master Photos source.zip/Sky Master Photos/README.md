# Sky Master Photos

A photo editor ("Sky Photo") for **Windows and Linux** (incl. Arch / CachyOS), built in C# on
.NET 10 with Avalonia and SkiaSharp. It opens and saves layered Adobe Photoshop files (.psd / .psb).
Version 2.0 is the cross-platform port; the last Windows-only WPF version is kept in `legacy\wpf-1.1.0`.

## What's new in 2.1

- **GPU canvas:** the photo lives on the graphics card in 512 px tiles. Only changed tiles are re-sent, and zooming out uses mipmaps.
  Measured on a 24 MP photo against 2.0:
  - painting while zoomed to fit: 17 → 80 fps
  - painting at 100%: 71 → 109 fps
  - zooming: 10 → 235 fps
  - panning: 12 → 237 fps
- **GPU filters:** Gaussian blur, motion blur and everything built on them (unsharp mask, glow, tilt-shift, shadows/highlights) run on the graphics card. They use their own context (Direct3D 11 via ANGLE / OpenGL), so they're 4–6× faster, and they fall back to the CPU automatically.
- **Faster everywhere:**
  - starting a stroke no longer copies the whole layer (24 ms → 0 ms)
  - blur kernels are cache-friendly (gaussian 576 → 351 ms on the CPU)
  - saving a `.skyphoto` project takes 2.2 s → 0.3 s
  - filter previews never pile up, and Apply reuses the finished preview
- **Brushes:**
  - every pointer sample is painted, so fast strokes stay round
  - pen pressure for size and/or flow (Windows Ink, Linux tablets)
  - stroke smoothing (lazy mouse)
- **New:** Edit ▸ Preferences (Ctrl+K), View ▸ Show grid (Ctrl+'), a pixel grid past 1000%, and GPU info in About.
- **Fixed:**
  - the Crop tool couldn't drag a new crop area on the default full-image box
  - the hidden task bar's invisible buttons could still be clicked
- **Tests:**
  - 219 engine tests
  - 44 end-to-end tests run the real window headless (`tests\SkyMasterPhotos.UiTests`): shortcuts, mouse drags, the canvas's drawn pixels, and every menu command in four document states
  - `tools\Bench` benchmarks the engine
  - hidden `--gputest` / `--perftest` flags check the GPU paths and frame times in the real window

## Linux (Arch / CachyOS and others)

`build.ps1` also produces `Output\Linux\sky-master-photos-<ver>-linux-x64.tar.gz` (everything bundled, no .NET needed):

```sh
tar xf sky-master-photos-2.0.0-linux-x64.tar.gz
cd sky-master-photos-2.0.0-linux-x64
makepkg -si          # Arch / CachyOS / Manjaro: a real pacman package (remove: sudo pacman -R sky-master-photos)
./install.sh         # any other distro, per user (~/.local); sudo ./install.sh for everyone
```

- Runs on X11, and on Wayland through XWayland (default on KDE Plasma / GNOME).
- Virtual machines (VirtualBox, VMware, QEMU) render on the CPU automatically; `SKY_SOFTWARE_RENDER=1/0` forces CPU / OpenGL.
- Settings, recent files, `selftest.log` and `crash.log` live in `~/.config/Sky Master Photos`.
- Packaging files (desktop entry, MIME type for `.skyphoto`, PKGBUILD, install scripts) are in `packaging\linux`.

## What's where

## Editing Upgrade

- Layer > Layer style adds editable Drop Shadow, Outer Glow, Inner Glow,
  Bevel & Emboss, and Stroke. Effects share size, angle, opacity and accent color
  controls. Use the foreground color button to change the glow/stroke color.
- Apply commits one undo step; Cancel restores the original style; Clear removes it.
- Save as `.skyphoto` to retain editable styles. PNG/JPEG exports include the effects.
  PSD export bakes native effects into each styled layer, preserving separate layers,
  but does not export editable Photoshop layer-effect descriptors.
- Select > Smooth removes isolated selection pixels; Border selects an outline;
  Reselect (Ctrl+Shift+D) restores the previous selection in the current document.
- Close All stops when a save prompt is canceled or a save fails.

### Project Layout

| Path | What it is |
|---|---|
| `Output\Sky Master Photos Setup.exe` | The installer. Run it or share it. Installs per-user, no admin needed. |
| `Output\App\Sky Master Photos.exe` | A portable copy of the app. Runs without installing. |
| `Output\Linux\*.tar.gz` | The Linux package (PKGBUILD + install.sh inside) |
| `packaging\linux` | Desktop entry, MIME type, PKGBUILD and install scripts for Linux |
| `src\SkyMasterPhotos` | The editor source. The engine is in `Core`, the PSD codec in `Core\Psd`. |
| `src\SkySetup` | The installer and uninstaller source (.NET Framework 4.8, built into Windows) |
| `tests\SkyMasterPhotos.Tests` | xUnit engine tests (219), including real Photoshop sample files |
| `tests\SkyMasterPhotos.UiTests` | 44 end-to-end tests: the real window, headless, driven by keys and mouse |
| `tools\Bench` | engine benchmark on a 24 MP photo (`dotnet run -c Release`) |
| `build.ps1` | Rebuilds everything: Windows app, uninstaller, payload and setup, plus the Linux tarball (`-SkipLinux` to skip) |

## Build and test

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1
dotnet test tests\SkyMasterPhotos.Tests -c Release
```

Optional independent PSD validation: set `SKY_PSD_PYTHON` to a Python with `pip install psd-tools`.
Every PSD the app writes is then re-read by psd-tools during the tests.

- Engine self-test: `"Sky Master Photos.exe" --selftest` writes `%AppData%\Sky Master Photos\selftest.log` (Linux: `~/.config/Sky Master Photos/selftest.log`).
- Layout check: `--snapshot out.png` renders the window to an image after start-up and exits.
- Silent install: `"Sky Master Photos Setup.exe" /S`
- Silent uninstall: `"Uninstall Sky Master Photos.exe" /S`

## Features

- **28 tools:** Move, Marquee, Lasso, Polygonal Lasso, Magic Wand, Crop, Eyedropper, **Spot Healing Brush**, Healing Brush, Brush, Pencil, Clone Stamp, Eraser, Gradient, Paint Bucket, Blur, Sharpen, Smudge, Dodge, Burn, Sponge, Type (re-editable), Rectangle, Ellipse, Line, Hand and Zoom, plus Free Transform.
- **Layers:**
  - layer masks you paint with any tool
  - **adjustment layers** (13 types, non-destructive)
  - clipping masks, fill opacity, groups and 23 blend modes
  - lock, merge and flatten
- **Content-Aware Fill** (Shift+F5) and a Spot Healing Brush that remove objects automatically.
- **Destructive adjustments and filters** with live preview. These are the classic Image ▸ Adjustments edits, plus 20 filters.
- **Files:**
  - opens PSD/PSB, PNG, JPG, BMP, GIF, TIFF, WebP and ICO (built-in decoders, the same on every OS)
  - saves `.skyphoto` projects and layered PSD
  - exports PNG, JPG, PSD, TIFF, BMP and GIF

## Photoshop (PSD) compatibility

The PSD reader and writer are implemented in-house from Adobe's file-format specification, in `Core\Psd`.
I evaluated existing libraries and none fit:
- Aspose.PSD has a commercial license.
- Magick.NET flattens most layer features and adds about 30 MB of native code.
- The Paint.NET PSD plugin depends on Paint.NET itself.

**Fully supported (open, edit and save back):**
- Layers, with order, names (Unicode and emoji), visibility, opacity, fill opacity and lock-all
- The 23 blend modes the app shares with Photoshop
- Layer masks: user masks, disabled masks and default colors
- Clipping masks
- Adjustment layers, editable and rendered live: Brightness/Contrast, Levels (composite channel), Curves (composite channel), Exposure, Vibrance, Hue/Saturation (master range), Color Balance (midtones), Black & White, Photo Filter, Invert, Posterize, Threshold and Gradient Map (two colors)
- 8/16/32-bit and RGB/Grayscale/CMYK/Lab/Indexed/Bitmap files open. 16/32-bit and non-RGB files are converted to 8-bit RGB.
- PSB (large document format), reading only
- The merged composite. Saved PSDs include it for apps that don't read layers.

**Partially supported:**
- **Text layers:** The text, font, size and color are imported and the text can be re-edited. If you don't edit it, the original Photoshop text data is written back, so it stays editable in Photoshop. Once edited in Sky Photo, it's saved to PSD as pixels.
- **Groups:** Groups are kept as a path on each layer, and group visibility and opacity are applied. Pass-through and other group blend modes are approximated. Empty groups are lost on save.
- **Smart Objects, shape layers, vector masks and fill layers:** These are shown using Photoshop's stored pixels. They're written back unchanged as long as the layer isn't edited. A solid color fill without pixel data is rendered.
- **Dissolve, Darker Color, Lighter Color and Hard Mix blend modes:** These are approximated for display. The original mode is saved back.
- **Adjustment details:** Levels and Curves edit only the composite (RGB) channel, Hue/Saturation only the master range, and Color Balance only the midtones.
- **Layers extending past the canvas:** They're cropped to the canvas.
- **Mask density and feather:** These settings are ignored.

**Preserved but not rendered (kept for Photoshop):**
- Layer effects (drop shadow, stroke and so on, marked "fx")
- Channel Mixer, Color Lookup and Selective Color adjustment layers
- Patterns, linked-layer data and layer comps

**Not supported:**
- Saving PSB, or 16/32-bit PSD. Saves are always 8-bit RGB PSD.
- Saving CMYK. CMYK files are converted to RGB on open.
- Alpha and spot channels
- Artboards, timeline and 3D data
- Rendering vector shapes and smart filters

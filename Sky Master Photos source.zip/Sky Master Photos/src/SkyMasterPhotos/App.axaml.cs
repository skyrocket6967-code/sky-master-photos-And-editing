using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Markup.Xaml;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Avalonia.Threading;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos;

public partial class App : Application
{
    public static string[] StartupFiles = Array.Empty<string>();
    public static bool SelfTest;
    /// <summary>--gputest: compare GPU filters with the CPU versions, log timings, exit.</summary>
    public static bool GpuTest;
    /// <summary>--perftest: paint and zoom on a big photo in the real window, log frame times, exit.</summary>
    public static bool PerfTest;
    /// <summary>--snapshot file.png: render the window to an image after start-up and exit (layout checks on other platforms).</summary>
    public static string SnapshotPath;
    public static MainWindow MainWin;

    /// <summary>The window that currently has focus (dialogs included) — for focus / keyboard helpers.</summary>
    public static TopLevel ActiveTopLevel
    {
        get
        {
            if (Current?.ApplicationLifetime is IClassicDesktopStyleApplicationLifetime d)
                return d.Windows.FirstOrDefault(w => w.IsActive) ?? (TopLevel)MainWin;
            return MainWin;
        }
    }

    public override void Initialize() => AvaloniaXamlLoader.Load(this);

    public override void OnFrameworkInitializationCompleted()
    {
        // engine pixels → on-screen images (layer thumbnails, navigator, recent files…)
        ImageHost.Create = MakeBitmap;
        Dispatcher.UIThread.UnhandledException += (_, e) =>
        {
            LogCrash(e.Exception);
            e.Handled = true;
            try { SkyDialog.Alert(MainWin, "Something went wrong", e.Exception.Message + "\n\nYour work is still open — saving a copy is recommended."); } catch { }
        };
        AppDomain.CurrentDomain.UnhandledException += (_, a) => LogCrash(a.ExceptionObject as Exception);
        TaskScheduler.UnobservedTaskException += (_, a) => { LogCrash(a.Exception); a.SetObserved(); };

        AppStore.Load();
        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            var args = desktop.Args ?? Array.Empty<string>();
            StartupFiles = args.Where((a, i) => !a.StartsWith("--") && (i == 0 || args[i - 1] != "--snapshot") && File.Exists(a)).ToArray();
            SelfTest = args.Contains("--selftest");
            GpuTest = args.Contains("--gputest");
            PerfTest = args.Contains("--perftest");
            int si = Array.IndexOf(args, "--snapshot");
            if (si >= 0 && si + 1 < args.Length) SnapshotPath = args[si + 1];
            desktop.ShutdownMode = ShutdownMode.OnMainWindowClose;
            MainWin = new MainWindow();
            desktop.MainWindow = MainWin;
        }
        base.OnFrameworkInitializationCompleted();
    }

    /// <summary>Straight-alpha BGRA pixels → an Avalonia bitmap.</summary>
    public static unsafe WriteableBitmap MakeBitmap(uint[] px, int w, int h)
    {
        var wb = new WriteableBitmap(new PixelSize(w, h), new Vector(96, 96), PixelFormat.Bgra8888, AlphaFormat.Unpremul);
        using var fb = wb.Lock();
        fixed (uint* src = px)
        {
            for (int y = 0; y < h; y++)
                Buffer.MemoryCopy(src + (long)y * w, (byte*)fb.Address + (long)y * fb.RowBytes, fb.RowBytes, w * 4L);
        }
        return wb;
    }

    /// <summary>Raised for every logged error (the automated UI tests fail on it).</summary>
    public static event Action<Exception> ErrorLogged;

    public static void LogCrash(Exception ex)
    {
        if (ex == null) return;
        ErrorLogged?.Invoke(ex);
        try
        {
            Directory.CreateDirectory(AppStore.Dir);
            File.AppendAllText(Path.Combine(AppStore.Dir, "errors.log"), $"[{DateTime.Now:u}] {ex}\n\n");
        }
        catch { }
    }
}

using System.Collections.Concurrent;
using Avalonia;
using Avalonia.OpenGL;
using Avalonia.Platform;
using Avalonia.Rendering.Composition;
using SkiaSharp;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

// ─────────────────────────────────────────────────────────────────────────────
//  GPU filters. A dedicated worker thread owns its own OpenGL context, created from
//  Avalonia's platform graphics (Direct3D 11 through ANGLE on Windows, OpenGL / GLES on
//  Linux), and a Skia GPU context on top of it. Being independent of window drawing it
//  keeps working while the window is covered or minimized. Jobs: upload, filter with a
//  GPU blur or an SkSL shader, read back; big images go in tiles with an apron.
//  No GPU, a failure or a timeout always just means "the CPU does it".
// ─────────────────────────────────────────────────────────────────────────────

public static class GpuCompute
{
    sealed class Job
    {
        public uint[] Src;
        public int W, H, Apron;
        public Func<SKImage, SKImageFilter> Filter;     // GPU image filter (blur …)
        public Func<SKImage, SKShader> Shader;          // or an SkSL shader reading the image
        public readonly TaskCompletionSource<uint[]> Done = new(TaskCreationOptions.RunContinuationsAsynchronously);
    }

    const int MaxTile = 4096;
    static readonly BlockingCollection<Job> Jobs = new();
    static readonly object InitLock = new();
    static Thread _worker;
    static volatile bool _ready, _failed;
    static readonly ManualResetEventSlim Started = new();

    /// <summary>The user can switch GPU filters off in Preferences.</summary>
    public static bool Enabled = true;
    /// <summary>Human-readable state for Preferences ("GPU filters: …").</summary>
    public static string Status { get; private set; } = "not started";
    public static bool Available => Enabled && EnsureStarted();

    static IGlContext _context;

    /// <summary>
    /// Connects the engine's GPU hooks. Call on the UI thread once the window is shown: the compositor
    /// hands out an OpenGL context that shares resources with the window's renderer (like OpenGlControlBase).
    /// </summary>
    public static async void Install(Avalonia.Rendering.Composition.Compositor compositor)
    {
        // any GPU problem must only ever mean "use the CPU", never a failed filter
        Filters.GpuGaussian = (src, w, h, sigma) => Safe(() => Gaussian(src, w, h, sigma));
        Filters.GpuMotion = (src, w, h, angle, dist) => Safe(() => Motion(src, w, h, angle, dist));
        if (!Enabled) { Status = "off"; return; }
        try
        {
            if (compositor == null) throw new NotSupportedException("no compositor");
            var feature = await compositor.TryGetRenderInterfaceFeature(typeof(IOpenGlTextureSharingRenderInterfaceContextFeature))
                as IOpenGlTextureSharingRenderInterfaceContextFeature;
            if (feature != null && feature.CanCreateSharedContext) _context = feature.CreateSharedContext();
            // ANGLE (Windows) shares through Direct3D instead: ask the platform graphics for a context of our own,
            // the same fallback Avalonia's OpenGlControlBase uses
            _context ??= PlatformContext() ?? throw new NotSupportedException("software rendering — no graphics card in use");
        }
        catch (Exception ex)
        {
            Status = "off — " + ex.Message;
            _failed = true;
            Started.Set();
            return;
        }
        // warm up in the background so the first filter doesn't pay for Skia's GPU setup
        if (Enabled) ThreadPool.QueueUserWorkItem(_ => EnsureStarted());
    }

    static uint[] Safe(Func<uint[]> f)
    {
        if (!Available) return null;
        try { return f(); }
        catch (Exception ex) { App.LogCrash(new Exception("GPU filter unavailable, using the CPU", ex)); return null; }
    }

    // ───────────────────────── worker thread with its own GL context ─────────────────────────

    static IGlContext PlatformContext()
    {
        // AvaloniaLocator.Current is hidden from the reference assemblies but public at run time
        var current = typeof(AvaloniaLocator).GetProperty("Current", System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Static)?.GetValue(null);
        var getService = current?.GetType().GetMethod("GetService", new[] { typeof(Type) });
        if (getService == null) return null;
        var factoryType = typeof(IGlContext).Assembly.GetType("Avalonia.OpenGL.IPlatformGraphicsOpenGlContextFactory");
        if (factoryType != null && getService.Invoke(current, new object[] { factoryType }) is object factory)
        {
            var create = factoryType.GetMethod("CreateContext");
            if (create?.Invoke(factory, new object[] { null }) is IGlContext ctx) return ctx;
        }
        return getService.Invoke(current, new object[] { typeof(IPlatformGraphics) }) is IPlatformGraphics pg ? pg.CreateContext() as IGlContext : null;
    }

    static bool EnsureStarted()
    {
        if (_ready) return true;
        if (_failed || _context == null) return false;
        lock (InitLock)
        {
            if (_worker == null)
            {
                _worker = new Thread(WorkerMain) { IsBackground = true, Name = "Sky GPU filters" };
                _worker.Start();
            }
        }
        Started.Wait(TimeSpan.FromSeconds(10));
        return _ready;
    }

    static void WorkerMain()
    {
        IGlContext gl = null;
        GRContext gr = null;
        try
        {
            gl = _context;
            using (gl.MakeCurrent())
            {
                var iface = gl.Version.Type == GlProfileType.OpenGLES
                    ? GRGlInterface.CreateGles(name => gl.GlInterface.GetProcAddress(name))
                    : GRGlInterface.CreateOpenGl(name => gl.GlInterface.GetProcAddress(name));
                gr = GRContext.CreateGl(iface) ?? throw new NotSupportedException("Skia couldn't create a GPU context");
            }
            string api = OperatingSystem.IsWindows() ? "Direct3D 11 via ANGLE" : gl.Version.Type == GlProfileType.OpenGLES ? "OpenGL ES" : "OpenGL";
            Status = $"on ({api} {gl.Version.Major}.{gl.Version.Minor})";
            _ready = true;
        }
        catch (Exception ex)
        {
            Status = "off — " + ex.Message;
            _failed = true;
            gl?.Dispose();
            Started.Set();
            return;
        }
        Started.Set();

        foreach (var job in Jobs.GetConsumingEnumerable())
        {
            try
            {
                using (gl.MakeCurrent()) job.Done.TrySetResult(Execute(gr, job));
            }
            catch (Exception ex)
            {
                App.LogCrash(new Exception("GPU filter failed, using the CPU instead", ex));
                job.Done.TrySetResult(null);
                // a lost device (driver reset …) shouldn't be retried every time
                if (gr.IsAbandoned) { _ready = false; _failed = true; Status = "off — the graphics driver reset"; break; }
            }
        }
    }

    static uint[] Run(Job job)
    {
        if (!Available || job.W <= 0 || job.H <= 0) return null;
        Jobs.Add(job);
        try { return job.Done.Task.Wait(TimeSpan.FromSeconds(30)) ? job.Done.Task.Result : null; }
        catch { return null; }
    }

    // ───────────────────────── filters ─────────────────────────

    public static uint[] Gaussian(uint[] src, int w, int h, double sigma) =>
        Run(new Job
        {
            Src = src, W = w, H = h, Apron = (int)Math.Ceiling(sigma * 3) + 2,
            Filter = _ => SKImageFilter.CreateBlur((float)sigma, (float)sigma, SKShaderTileMode.Clamp),
        });

    static readonly ConcurrentDictionary<int, SKRuntimeEffect> MotionShaders = new();

    public static uint[] Motion(uint[] src, int w, int h, double angleDeg, int distance)
    {
        if (distance > 400) return null;
        double a = angleDeg * Math.PI / 180;
        float dx = (float)Math.Cos(a), dy = (float)-Math.Sin(a);
        var effect = MotionShaders.GetOrAdd(distance, d =>
        {
            // average of 2d+1 premultiplied taps along the direction = the CPU's alpha-weighted mean
            // (SkiaSharp 2.88 / Skia m88 SkSL: sample(shader, coords))
            string sksl = $@"
uniform shader img;
uniform float2 dir;
half4 main(float2 p) {{
    half4 acc = half4(0);
    for (int k = -{d}; k <= {d}; k++) {{ acc += sample(img, p + dir * float(k)); }}
    return acc * {1.0 / (2 * d + 1):R};
}}";
            return SKRuntimeEffect.Create(sksl, out var errors) ?? throw new InvalidOperationException(errors);
        });
        return Run(new Job
        {
            Src = src, W = w, H = h, Apron = distance + 2,
            Shader = img =>
            {
                var u = new SKRuntimeEffectUniforms(effect) { ["dir"] = new[] { dx, dy } };
                var c = new SKRuntimeEffectChildren(effect) { ["img"] = img.ToShader(SKShaderTileMode.Clamp, SKShaderTileMode.Clamp) };
                return effect.ToShader(false, u, c);
            },
        });
    }

    /// <summary>Runs one job on the worker thread (its GL context is current).</summary>
    static unsafe uint[] Execute(GRContext gr, Job j)
    {
        var result = new uint[j.W * j.H];
        fixed (uint* srcP = j.Src)
        fixed (uint* dstP = result)
        {
            for (int ty = 0; ty < j.H; ty += MaxTile)
                for (int tx = 0; tx < j.W; tx += MaxTile)
                {
                    int iw = Math.Min(MaxTile, j.W - tx), ih = Math.Min(MaxTile, j.H - ty);
                    // the tile plus an apron of real neighbours so tile edges match the CPU result
                    int sx = Math.Max(0, tx - j.Apron), sy = Math.Max(0, ty - j.Apron);
                    int sw = Math.Min(j.W, tx + iw + j.Apron) - sx, sh = Math.Min(j.H, ty + ih + j.Apron) - sy;
                    var info = new SKImageInfo(sw, sh, SKColorType.Bgra8888, SKAlphaType.Unpremul);
                    using var raster = SKImage.FromPixelCopy(info, (nint)srcP + (nint)(((long)sy * j.W + sx) * 4), j.W * 4);
                    using var tex = raster.ToTextureImage(gr) ?? throw new InvalidOperationException("upload failed");
                    var premulInfo = new SKImageInfo(sw, sh, SKColorType.Bgra8888, SKAlphaType.Premul);
                    using var surf = SKSurface.Create(gr, false, premulInfo) ?? throw new InvalidOperationException("no GPU surface");
                    var c = surf.Canvas;
                    c.Clear(SKColors.Transparent);
                    if (j.Filter != null)
                    {
                        // image filters read their input as premultiplied: convert the straight-alpha upload with a
                        // plain draw first (otherwise semi-transparent pixels come out too bright)
                        using var pre = SKSurface.Create(gr, false, premulInfo) ?? throw new InvalidOperationException("no GPU surface");
                        pre.Canvas.Clear(SKColors.Transparent);
                        using (var copy = new SKPaint { BlendMode = SKBlendMode.Src }) pre.Canvas.DrawImage(tex, 0, 0, copy);
                        using var premul = pre.Snapshot();
                        using var f = j.Filter(premul);
                        using var paint = new SKPaint { ImageFilter = f, BlendMode = SKBlendMode.Src };
                        c.DrawImage(premul, 0, 0, paint);
                    }
                    else
                    {
                        using var shader = j.Shader(tex);
                        using var paint = new SKPaint { Shader = shader, BlendMode = SKBlendMode.Src };
                        c.DrawRect(new SKRect(0, 0, sw, sh), paint);
                    }
                    c.Flush();
                    // read the inner tile straight into the result (unpremultiplied, like the engine)
                    var outInfo = new SKImageInfo(iw, ih, SKColorType.Bgra8888, SKAlphaType.Unpremul);
                    if (!surf.ReadPixels(outInfo, (nint)dstP + (nint)(((long)ty * j.W + tx) * 4), j.W * 4, tx - sx, ty - sy))
                        throw new InvalidOperationException("readback failed");
                }
        }
        gr.PurgeUnlockedResources(false);   // don't keep hundreds of MB of tiles on the card between filters
        return result;
    }
}

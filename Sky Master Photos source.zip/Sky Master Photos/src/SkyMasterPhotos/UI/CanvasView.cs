using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;
using Avalonia.Threading;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Tools;

namespace SkyMasterPhotos.UI;

/// <summary>The zoomable, pannable document viewport.</summary>
public sealed class CanvasView : Control
{
    Document _doc;
    public ToolController Ctl;
    public event Action ViewChanged;
    public event Action<Point?> CursorMoved;

    Point? _mouse;
    readonly DispatcherTimer _ants;
    public double AntOffset { get; private set; }
    bool _panning, _captured;
    Point _panStart;
    Vector _panOrigin;
    Size _lastSize;
    static readonly ImageBrush CheckerBrush = UIx.Checker(8, false);

    // on-screen copy of the document composite: GPU tiles, updated per dirty rect
    readonly CanvasTiles _tiles = new();
    int _displayVersion = -1;
    // cached selection geometry
    SelectionPath _antsSource;
    Geometry _antsGeometry;

    static readonly double[] Steps = { 0.01, 0.02, 0.03, 0.05, 0.0667, 0.1, 0.125, 0.1667, 0.25, 0.3333, 0.5, 0.6667, 1, 1.5, 2, 3, 4, 5, 6, 8, 12, 16, 24, 32, 48, 64 };

    public CanvasView()
    {
        Focusable = true;
        ClipToBounds = true;
        _ants = new DispatcherTimer(TimeSpan.FromMilliseconds(110), DispatcherPriority.Render, (_, _) =>
        {
            if (_doc?.HasSelection == true || Ctl?.HasAntsPreview == true)
            {
                AntOffset = (AntOffset + 1) % 8;
                InvalidateVisual();
            }
        });
        _ants.Start();
        DragDrop.SetAllowDrop(this, true);
    }

    public Document Doc
    {
        get => _doc;
        set
        {
            if (_doc == value) return;
            if (_doc != null) { _doc.Rendered -= OnRendered; _doc.StructureChanged -= OnStructure; }
            _doc = value;
            _displayVersion = -1;
            if (_doc != null)
            {
                _doc.Rendered += OnRendered;
                _doc.StructureChanged += OnStructure;
                SyncDisplay(null);
                if (!_doc.ViewInitialized && Bounds.Width > 0) Fit();
            }
            InvalidateVisual();
            ViewChanged?.Invoke();
        }
    }

    void OnRendered(Int32Rect r) { SyncDisplay(r); InvalidateVisual(); }
    void OnStructure() { SyncDisplay(null); InvalidateVisual(); }

    /// <summary>Re-reads the changed part of the document composite into the GPU tiles.</summary>
    void SyncDisplay(Int32Rect? dirty)
    {
        var d = _doc;
        if (d?.Flat == null || d.Flat.Length != d.Width * d.Height) return;
        bool full = dirty == null || _displayVersion != d.DisplayVersion || _tiles.Width != d.Width || _tiles.Height != d.Height;
        _displayVersion = d.DisplayVersion;
        _tiles.Update(d.Flat, d.Width, d.Height, full ? null : dirty);
    }

    public double Zoom => _doc?.Zoom ?? 1;
    Vector Pan => _doc?.Pan ?? new Vector();

    public Matrix View => new(Zoom, 0, 0, Zoom, Pan.X, Pan.Y);
    public Point ToDoc(Point s) => new((s.X - Pan.X) / Zoom, (s.Y - Pan.Y) / Zoom);
    public Point ToScreen(Point d) => new(d.X * Zoom + Pan.X, d.Y * Zoom + Pan.Y);
    public Point? MouseScreen => _mouse;

    public void Fit()
    {
        if (_doc == null || Bounds.Width < 10 || Bounds.Height < 10) return;
        double z = Math.Min((Bounds.Width - 80) / _doc.Width, (Bounds.Height - 80) / _doc.Height);
        z = Math.Clamp(z, 0.01, 1.0 * Math.Max(1, Math.Floor(z)));
        if (z > 1) z = Math.Min(z, 4);
        SetView(z, new Vector((Bounds.Width - _doc.Width * z) / 2, (Bounds.Height - _doc.Height * z) / 2));
        _doc.ViewInitialized = true;
    }

    public void ActualPixels()
    {
        if (_doc == null) return;
        SetView(1, new Vector(Math.Round((Bounds.Width - _doc.Width) / 2), Math.Round((Bounds.Height - _doc.Height) / 2)));
    }

    void SetView(double z, Vector pan)
    {
        if (_doc == null) return;
        _doc.Zoom = z;
        _doc.Pan = pan;
        InvalidateVisual();
        ViewChanged?.Invoke();
    }

    public void ZoomAt(Point s, double nz)
    {
        if (_doc == null) return;
        nz = Math.Clamp(nz, 0.01, 64);
        var d = ToDoc(s);
        SetView(nz, new Vector(s.X - d.X * nz, s.Y - d.Y * nz));
    }

    public void ZoomStep(bool zoomIn, Point? at = null)
    {
        var p = at ?? new Point(Bounds.Width / 2, Bounds.Height / 2);
        double z = Zoom;
        double nz = zoomIn ? Steps.FirstOrDefault(s => s > z * 1.001, 64) : Steps.LastOrDefault(s => s < z / 1.001, 0.01);
        if (nz == 0) nz = zoomIn ? 64 : 0.01;
        ZoomAt(p, nz);
    }

    public void PanBy(Vector v) { if (_doc != null) SetView(Zoom, Pan + v); }

    /// <summary>Center the view on a document point (used by the navigator).</summary>
    public void CenterOn(Point d)
    {
        if (_doc == null) return;
        SetView(Zoom, new Vector(Bounds.Width / 2 - d.X * Zoom, Bounds.Height / 2 - d.Y * Zoom));
    }

    protected override void OnSizeChanged(SizeChangedEventArgs e)
    {
        base.OnSizeChanged(e);
        if (_doc != null && !_doc.ViewInitialized) Fit();
        else if (_doc != null && _lastSize.Width > 0)
        {
            // keep the image centered relative to the resize
            var d = new Vector((e.NewSize.Width - _lastSize.Width) / 2, (e.NewSize.Height - _lastSize.Height) / 2);
            SetView(Zoom, Pan + d);
        }
        _lastSize = e.NewSize;
        ViewChanged?.Invoke();
    }

    // ───────────────────────────── rendering ─────────────────────────────

    public override void Render(DrawingContext dc)
    {
        dc.DrawRectangle(Brushes.Transparent, null, new Rect(Bounds.Size));
        if (_doc == null) return;
        if (_displayVersion != _doc.DisplayVersion || _tiles.Width != _doc.Width || _tiles.Height != _doc.Height) SyncDisplay(null);
        double z = Zoom;
        var mode = z >= 2 ? BitmapInterpolationMode.None : z < 1 ? BitmapInterpolationMode.HighQuality : BitmapInterpolationMode.LowQuality;
        var rect = new Rect(Pan.X, Pan.Y, _doc.Width * z, _doc.Height * z);
        var docRect = new Rect(0, 0, _doc.Width, _doc.Height);

        // soft drop shadow
        for (int i = 1; i <= 4; i++)
        {
            var r = rect.Inflate(i * 3).Translate(new Vector(0, i * 1.5));
            dc.DrawRectangle(new SolidColorBrush(Color.FromArgb((byte)(26 - i * 5), 0, 0, 0)), null, r, i * 3, i * 3);
        }
        dc.DrawRectangle(CheckerBrush, null, rect);

        var xf = Ctl?.Xf;
        using (dc.PushRenderOptions(new RenderOptions { BitmapInterpolationMode = mode }))
        {
            if (xf != null)
            {
                if (xf.Below != null) dc.DrawImage(xf.Below, docRect, rect);
                var m = xf.M.ToAvalonia() * View;
                using (dc.PushTransform(m))
                using (dc.PushOpacity(xf.Layer.Opacity))
                    if (xf.Float != null) dc.DrawImage(xf.Float, docRect, docRect);
                if (xf.Above != null) dc.DrawImage(xf.Above, docRect, rect);
            }
            else dc.Custom(_tiles.CreateDrawOp(new Rect(Bounds.Size), View, z));
        }
        dc.DrawRectangle(null, new Pen(new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)), 1), Snap(rect));
        DrawGrids(dc, rect, z);

        // marching ants
        if (_doc.SelectionOutline is SelectionPath sp && !sp.IsEmpty)
        {
            var m = View;
            if (xf != null && xf.HadSelection) m = xf.M.ToAvalonia() * View;
            double scale = Math.Sqrt(Math.Abs(m.M11 * m.M22 - m.M12 * m.M21));
            using (dc.PushTransform(m))
                DrawAnts(dc, AntsGeometry(sp), 1.0 / scale);
        }

        Ctl?.DrawOverlay(dc, this);

        // brush cursor
        if (_mouse is Point mp && Ctl != null && ToolInfo.IsBrushLike(Ctl.Tool) && !Ctl.SpaceHeld && xf == null)
        {
            double r = Math.Max(1.5, Ctl.CurrentBrush.Size / 2 * z);
            dc.DrawEllipse(null, new Pen(new SolidColorBrush(Color.FromArgb(150, 0, 0, 0)), 2.5), mp, r, r);
            dc.DrawEllipse(null, new Pen(Brushes.White, 1.2), mp, r, r);
            if (r < 6 || Ctl.Tool is Tool.Clone or Tool.Heal)
            {
                var pen = new Pen(Brushes.White, 1);
                dc.DrawLine(pen, new Point(mp.X - 5, mp.Y), new Point(mp.X + 5, mp.Y));
                dc.DrawLine(pen, new Point(mp.X, mp.Y - 5), new Point(mp.X, mp.Y + 5));
            }
        }
    }

    static readonly Pen GridPen = new(new SolidColorBrush(Color.FromArgb(70, 120, 170, 255)), 1);
    static readonly Pen PixelGridPen = new(new SolidColorBrush(Color.FromArgb(38, 128, 128, 128)), 1);

    /// <summary>Optional layout grid (View ▸ Show grid) and a pixel grid when zoomed far in.</summary>
    void DrawGrids(DrawingContext dc, Rect rect, double z)
    {
        var vis = rect.Intersect(new Rect(Bounds.Size));
        if (vis.Width <= 0 || vis.Height <= 0) return;
        void Lines(double stepDoc, Pen pen)
        {
            double step = stepDoc * z;
            if (step < 6) return;
            var g = new StreamGeometry();
            using (var ctx = g.Open())
            {
                double x0 = rect.X + Math.Ceiling((vis.X - rect.X) / step) * step;
                for (double x = x0; x <= vis.Right; x += step) { double sx = Math.Round(x) + 0.5; ctx.BeginFigure(new Point(sx, vis.Y), false); ctx.LineTo(new Point(sx, vis.Bottom)); ctx.EndFigure(false); }
                double y0 = rect.Y + Math.Ceiling((vis.Y - rect.Y) / step) * step;
                for (double y = y0; y <= vis.Bottom; y += step) { double sy = Math.Round(y) + 0.5; ctx.BeginFigure(new Point(vis.X, sy), false); ctx.LineTo(new Point(vis.Right, sy)); ctx.EndFigure(false); }
            }
            dc.DrawGeometry(null, pen, g);
        }
        var st = AppStore.Settings;
        if (st.PixelGrid && z >= 10) Lines(1, PixelGridPen);
        if (st.ShowGrid) Lines(Math.Max(1, st.GridSize), GridPen);
    }

    Geometry AntsGeometry(SelectionPath sp)
    {
        if (ReferenceEquals(sp, _antsSource) && _antsGeometry != null) return _antsGeometry;
        var g = new StreamGeometry();
        using (var ctx = g.Open())
            foreach (var (a, b) in sp.Segments)
            {
                ctx.BeginFigure(a, false);
                ctx.LineTo(b);
                ctx.EndFigure(false);
            }
        _antsSource = sp;
        _antsGeometry = g;
        return g;
    }

    /// <summary>Converts a selection outline for drawing (used by tool previews too).</summary>
    public static Geometry ToGeometry(SelectionPath sp)
    {
        var g = new StreamGeometry();
        if (sp == null) return g;
        using (var ctx = g.Open())
            foreach (var (a, b) in sp.Segments)
            {
                ctx.BeginFigure(a, false);
                ctx.LineTo(b);
                ctx.EndFigure(false);
            }
        return g;
    }

    static Rect Snap(Rect r) => new(Math.Round(r.X) + 0.5, Math.Round(r.Y) + 0.5, Math.Max(0, Math.Round(r.Width) - 1), Math.Max(0, Math.Round(r.Height) - 1));

    public void DrawAnts(DrawingContext dc, Geometry g, double thickness)
    {
        var black = new Pen(Brushes.Black, thickness);
        var white = new Pen(Brushes.White, thickness, new DashStyle(new double[] { 4, 4 }, AntOffset), PenLineCap.Flat);
        dc.DrawGeometry(null, black, g);
        dc.DrawGeometry(null, white, g);
    }

    // ───────────────────────────── input ─────────────────────────────

    protected override void OnPointerPressed(PointerPressedEventArgs e)
    {
        base.OnPointerPressed(e);
        Focus();
        if (_doc == null) return;
        var pt = e.GetCurrentPoint(this);
        var s = pt.Position;
        var kind = pt.Properties.PointerUpdateKind;
        var mods = Keyboard.From(e.KeyModifiers);
        Keyboard.Update(e.KeyModifiers);
        bool left = kind == PointerUpdateKind.LeftButtonPressed, middle = kind == PointerUpdateKind.MiddleButtonPressed;
        if (middle || (left && (Ctl.SpaceHeld || (Ctl.Tool == Tool.Hand && Ctl.Xf == null))))
        {
            _panning = true;
            _panStart = s;
            _panOrigin = Pan;
            e.Pointer.Capture(this);
            _captured = true;
            UpdateCursor();
            e.Handled = true;
            return;
        }
        if (left && Ctl.Tool == Tool.Zoom && Ctl.Xf == null)
        {
            ZoomStep((mods & ModifierKeys.Alt) == 0, s);
            e.Handled = true;
            return;
        }
        if (left)
        {
            e.Pointer.Capture(this);
            _captured = true;
            Ctl.Pressure = PressureOf(pt, e.Pointer.Type);
            Ctl.MouseDown(s, ToDoc(s), mods, e.ClickCount);
            e.Handled = true;
        }
    }

    protected override void OnPointerMoved(PointerEventArgs e)
    {
        base.OnPointerMoved(e);
        var pt = e.GetCurrentPoint(this);
        var s = pt.Position;
        _mouse = s;
        if (_doc == null) return;
        if (_panning)
        {
            SetView(Zoom, _panOrigin + (s - _panStart));
            return;
        }
        Keyboard.Update(e.KeyModifiers);
        if (Ctl.Stroking && _captured && pt.Properties.IsLeftButtonPressed)
        {
            // every sample the system collected since the last event (high-rate mice and pens), so fast
            // strokes stay round instead of turning into straight segments
            var type = e.Pointer.Type;
            Ctl.StrokeSamples(e.GetIntermediatePoints(this).Select(p => (ToDoc(p.Position), PressureOf(p, type))));
        }
        else Ctl.MouseMove(s, ToDoc(s), Keyboard.From(e.KeyModifiers), pt.Properties.IsLeftButtonPressed && _captured);
        CursorMoved?.Invoke(ToDoc(s));
        UpdateCursor();
        InvalidateVisual();
    }

    /// <summary>Pen pressure (0–1); mice and touch paint at full pressure.</summary>
    static float PressureOf(PointerPoint p, PointerType type)
    {
        if (type != PointerType.Pen) return 1f;
        float pr = p.Properties.Pressure;
        return pr <= 0 ? 0.02f : Math.Min(1f, pr);
    }

    protected override void OnPointerReleased(PointerReleasedEventArgs e)
    {
        base.OnPointerReleased(e);
        if (_doc == null) return;
        var s = e.GetPosition(this);
        if (_panning)
        {
            if (e.InitialPressMouseButton is MouseButton.Middle or MouseButton.Left)
            {
                _panning = false;
                _captured = false;
                e.Pointer.Capture(null);
                UpdateCursor();
            }
            return;
        }
        if (e.InitialPressMouseButton == MouseButton.Left)
        {
            _captured = false;
            Ctl.MouseUp(s, ToDoc(s), Keyboard.From(e.KeyModifiers));
            e.Pointer.Capture(null);
            InvalidateVisual();
        }
    }

    protected override void OnPointerCaptureLost(PointerCaptureLostEventArgs e)
    {
        base.OnPointerCaptureLost(e);
        bool was = _captured;
        _captured = false;
        if (_panning) { _panning = false; UpdateCursor(); }
        if (was) Ctl?.CaptureLost();
    }

    protected override void OnPointerExited(PointerEventArgs e)
    {
        base.OnPointerExited(e);
        _mouse = null;
        CursorMoved?.Invoke(null);
        InvalidateVisual();
    }

    protected override void OnPointerWheelChanged(PointerWheelEventArgs e)
    {
        base.OnPointerWheelChanged(e);
        if (_doc == null) return;
        var s = e.GetPosition(this);
        var mods = Keyboard.From(e.KeyModifiers);
        // Avalonia reports wheel notches as 1.0 (touchpads: fractions); WPF used 120 per notch
        double dy = e.Delta.Y * 120, dx = e.Delta.X * 120;
        if ((mods & ModifierKeys.Shift) != 0) PanBy(new Vector((dy + dx) * 0.6, 0));
        else if (Math.Abs(dx) > Math.Abs(dy)) PanBy(new Vector(dx * 0.6, 0)); // two-finger sideways scroll
        else ZoomAt(s, Zoom * Math.Pow(1.0018, dy));
        e.Handled = true;
    }

    public void UpdateCursor()
    {
        if (Ctl == null) return;
        if (_panning) { Cursor = Cursors.SizeAll; return; }
        if (Ctl.SpaceHeld || (Ctl.Tool == Tool.Hand && Ctl.Xf == null)) { Cursor = Cursors.Hand; return; }
        Cursor = Ctl.CursorFor(_mouse);
    }
}

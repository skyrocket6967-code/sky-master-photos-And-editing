using System.Globalization;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Controls.Shapes;
using Avalonia.Threading;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

// ═══════════════════════════════ New document ═══════════════════════════════

public sealed class NewDocResult
{
    public string Name;
    public int Width, Height;
    public Color Background;
}

public static class NewDocumentDialog
{
    public record Preset(string Name, string Group, int W, int H);

    public static readonly Preset[] Presets =
    {
        new("Full HD", "Screen", 1920, 1080),
        new("4K UHD", "Screen", 3840, 2160),
        new("YouTube Thumbnail", "Social", 1280, 720),
        new("Instagram Post", "Social", 1080, 1080),
        new("Instagram Portrait", "Social", 1080, 1350),
        new("Story / Reel", "Social", 1080, 1920),
        new("X / Twitter Header", "Social", 1500, 500),
        new("Desktop Wallpaper", "Screen", 2560, 1440),
        new("A4 Print (300 ppi)", "Print", 2480, 3508),
        new("Photo 6×4 (300 ppi)", "Print", 1800, 1200),
        new("Icon 1024", "Design", 1024, 1024),
        new("Banner", "Design", 1200, 400),
    };

    public static Border PresetThumb(int w, int h, double box, bool highlight = false)
    {
        double s = box / Math.Max(w, h);
        var r = new Border
        {
            Width = Math.Max(10, w * s), Height = Math.Max(10, h * s), CornerRadius = new CornerRadius(4),
            Background = highlight ? UIx.R<Brush>("AccentGrad") : new LinearGradientBrush
            {
                StartPoint = new RelativePoint(0, 0, RelativeUnit.Relative), EndPoint = new RelativePoint(1, 1, RelativeUnit.Relative),
                GradientStops = { new GradientStop(Color.FromRgb(0x2B, 0x31, 0x3E), 0), new GradientStop(Color.FromRgb(0x1D, 0x21, 0x2A), 1) },
            },
            BorderBrush = UIx.R<Brush>("Line2"), BorderThickness = new Thickness(1),
            HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center,
        };
        return r;
    }

    public static NewDocResult Show(Window owner, Color fg, int? clipW = null, int? clipH = null)
    {
        var d = new SkyDialog(owner, "New document", "Pick a preset or set a custom size");
        NewDocResult result = null;

        var root = new Grid();
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(560) });
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(24) });
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(260) });

        var wrap = new WrapPanel { ItemWidth = 136, ItemHeight = 132 };
        var sc = new ScrollViewer { Content = wrap, Height = 420, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        root.Children.Add(sc);

        var right = new StackPanel();
        Grid.SetColumn(right, 2);
        root.Children.Add(right);

        TextBox name = new() { Text = "Untitled" }, wbox = new() { Text = "1920" }, hbox = new() { Text = "1080" };
        int bgIndex = 0;
        right.Children.Add(UIx.Label("Name", 12, "Text3"));
        name.Margin = new Thickness(0, 6, 0, 14);
        right.Children.Add(name);
        var sizeRow = new Grid();
        sizeRow.ColumnDefinitions.Add(new ColumnDefinition());
        sizeRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) });
        sizeRow.ColumnDefinitions.Add(new ColumnDefinition());
        var wcol = new StackPanel(); wcol.Children.Add(UIx.Label("Width (px)", 12, "Text3")); wbox.Margin = new Thickness(0, 6, 0, 0); wcol.Children.Add(wbox);
        var hcol = new StackPanel(); hcol.Children.Add(UIx.Label("Height (px)", 12, "Text3")); hbox.Margin = new Thickness(0, 6, 0, 0); hcol.Children.Add(hbox);
        Grid.SetColumn(hcol, 2);
        sizeRow.Children.Add(wcol); sizeRow.Children.Add(hcol);
        right.Children.Add(sizeRow);

        var preview = new Border { Height = 150, Margin = new Thickness(0, 18, 0, 0), CornerRadius = new CornerRadius(12), Background = UIx.R<Brush>("Bg0") };
        right.Children.Add(preview);
        var dims = UIx.Label("", 12, "Text3");
        dims.HorizontalAlignment = HorizontalAlignment.Center;
        dims.Margin = new Thickness(0, 8, 0, 0);
        right.Children.Add(dims);

        right.Children.Add(new Border { Height = 14 });
        right.Children.Add(UIx.Label("Background", 12, "Text3"));
        var bgSeg = UIx.SegGroup(new (object, string)[] { ("White", null), ("Black", null), ("Transparent", null), ("Color", "Foreground color") }, 0, i => bgIndex = i);
        bgSeg.Margin = new Thickness(0, 6, 0, 0);
        bgSeg.HorizontalAlignment = HorizontalAlignment.Left;
        right.Children.Add(bgSeg);

        void UpdatePreview()
        {
            if (int.TryParse(wbox.Text, out int w) && int.TryParse(hbox.Text, out int h) && w > 0 && h > 0)
            {
                preview.Child = PresetThumb(w, h, 120, true);
                dims.Text = $"{w} × {h} px  ·  {(w * (double)h / 1e6):0.0} MP";
            }
        }
        wbox.TextChanged += (_, _) => UpdatePreview();
        hbox.TextChanged += (_, _) => UpdatePreview();

        var cards = new List<ToggleButton>();
        void AddCard(string title, string sub, int w, int h)
        {
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Stretch };
            var thumbBox = new Border { Height = 70, Child = PresetThumb(w, h, 58) };
            sp.Children.Add(thumbBox);
            sp.Children.Add(new TextBlock { Text = title, Foreground = UIx.R<Brush>("Text"), FontSize = 12, FontWeight = FontWeights.SemiBold, TextAlignment = TextAlignment.Center, TextTrimming = TextTrimming.CharacterEllipsis, Margin = new Thickness(0, 6, 0, 0) });
            sp.Children.Add(new TextBlock { Text = sub, Foreground = UIx.R<Brush>("Text3"), FontSize = 11, TextAlignment = TextAlignment.Center });
            var tb = new ToggleButton { Content = sp, Style = UIx.R<Style>("Secondary"), Margin = new Thickness(0, 0, 10, 10), Padding = new Thickness(8, 10, 8, 10), HorizontalContentAlignment = HorizontalAlignment.Stretch };
            tb.Click += (_, _) =>
            {
                foreach (var c in cards) c.IsChecked = c == tb;
                wbox.Text = w.ToString(); hbox.Text = h.ToString();
                if (name.Text == "Untitled" || Presets.Any(p => p.Name == name.Text)) name.Text = title == "Clipboard" ? "Untitled" : title;
            };
            tb.DoubleTapped += (_, _) => d.DefaultButton?.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
            cards.Add(tb);
            wrap.Children.Add(tb);
        }
        if (clipW is int cw && clipH is int ch) AddCard("Clipboard", $"{cw} × {ch}", cw, ch);
        foreach (var p in Presets) AddCard(p.Name, $"{p.W} × {p.H}", p.W, p.H);
        if (cards.Count > 0) { cards[0].IsChecked = true; wbox.Text = (clipW ?? Presets[0].W).ToString(); hbox.Text = (clipH ?? Presets[0].H).ToString(); }
        UpdatePreview();

        d.Body = root;
        d.AddButton("Cancel", false, () => d.DialogResult = false);
        d.AddButton("Create", true, () =>
        {
            if (!int.TryParse(wbox.Text, out int w) || !int.TryParse(hbox.Text, out int h) || w < 1 || h < 1 || w > 20000 || h > 20000 || (long)w * h > 300_000_000)
            {
                SkyDialog.Alert(d, "Invalid size", "Width and height must be between 1 and 20000 pixels.");
                return;
            }
            var bg = bgIndex switch { 0 => Colors.White, 1 => Colors.Black, 2 => Colors.Transparent, _ => fg };
            result = new NewDocResult { Name = string.IsNullOrWhiteSpace(name.Text) ? "Untitled" : name.Text.Trim(), Width = w, Height = h, Background = bg };
            d.DialogResult = true;
        });
        return d.ShowDialog() == true ? result : null;
    }
}

// ═══════════════════════════════ Adjustment / filter dialog ═══════════════════════════════

public enum ParamKind { Slider, Check, Choice, Curve }

public sealed class AdjustParam
{
    public string Key, Label;
    public ParamKind Kind = ParamKind.Slider;
    public double Min, Max = 100, Def;
    public int Decimals;
    public string Suffix = "";
    public string[] Choices;

    public static AdjustParam S(string key, string label, double min, double max, double def, int decimals = 0, string suffix = "")
        => new() { Key = key, Label = label, Min = min, Max = max, Def = def, Decimals = decimals, Suffix = suffix };
    public static AdjustParam C(string key, string label, bool def) => new() { Key = key, Label = label, Kind = ParamKind.Check, Def = def ? 1 : 0 };
    public static AdjustParam Ch(string key, string label, int def, params string[] choices) => new() { Key = key, Label = label, Kind = ParamKind.Choice, Def = def, Choices = choices };
    public static AdjustParam Curve(string key) => new() { Key = key, Kind = ParamKind.Curve };
}

public sealed class AdjustContext
{
    public Dictionary<string, double> V = new();
    public CurvesEditor Curves;
    public double this[string k] => V.TryGetValue(k, out var v) ? v : 0;
    public bool B(string k) => this[k] >= 0.5;
}

public static class AdjustDialog
{
    static void BuildParams(StackPanel body, IList<AdjustParam> ps, AdjustContext ctx, Action schedule, List<Action> resets, uint[] histSrc, IList<Point> curve)
    {
        foreach (var p in ps)
        {
            switch (p.Kind)
            {
                case ParamKind.Slider:
                {
                    var (row, s) = UIx.SliderRow(p.Label, p.Min, p.Max, p.Def, v => { ctx.V[p.Key] = v; schedule(); }, p.Decimals, p.Suffix);
                    body.Children.Add(row);
                    resets.Add(() => s.Value = p.Def);
                    break;
                }
                case ParamKind.Check:
                {
                    var cb = new CheckBox { Content = p.Label, IsChecked = p.Def >= 0.5, Margin = new Thickness(0, 2, 0, 12) };
                    cb.Click += (_, _) => { ctx.V[p.Key] = cb.IsChecked == true ? 1 : 0; schedule(); };
                    body.Children.Add(cb);
                    resets.Add(() => { cb.IsChecked = p.Def >= 0.5; ctx.V[p.Key] = p.Def; });
                    break;
                }
                case ParamKind.Choice:
                {
                    if (!string.IsNullOrEmpty(p.Label)) body.Children.Add(new TextBlock { Text = p.Label, Foreground = UIx.R<Brush>("Text2"), FontSize = 12.5, Margin = new Thickness(0, 0, 0, 6) });
                    var wp = new WrapPanel { Margin = new Thickness(0, 0, 0, 12) };
                    var toggles = new List<ToggleButton>();
                    for (int i = 0; i < p.Choices.Length; i++)
                    {
                        int idx = i;
                        var t = new ToggleButton { Content = p.Choices[i], Style = UIx.R<Style>("Secondary"), Padding = new Thickness(10, 5, 10, 5), Margin = new Thickness(0, 0, 6, 6), IsChecked = i == (int)p.Def, FontSize = 12 };
                        t.Click += (_, _) => { foreach (var o in toggles) o.IsChecked = o == t; ctx.V[p.Key] = idx; schedule(); };
                        toggles.Add(t);
                        wp.Children.Add(t);
                    }
                    body.Children.Add(wp);
                    resets.Add(() => { for (int i = 0; i < toggles.Count; i++) toggles[i].IsChecked = i == (int)p.Def; ctx.V[p.Key] = p.Def; });
                    break;
                }
                case ParamKind.Curve:
                {
                    var ce = new CurvesEditor { Width = 340, Height = 300, Margin = new Thickness(0, 0, 0, 10), Histogram = histSrc != null ? Adjustments.LumaHistogram(histSrc) : null };
                    if (curve != null && curve.Count >= 2) { ce.Points.Clear(); ce.Points.AddRange(curve); }
                    ce.Changed += schedule;
                    ctx.Curves = ce;
                    body.Children.Add(ce);
                    body.Children.Add(new TextBlock { Text = "Click to add a point · drag to shape · right-click to remove", Foreground = UIx.R<Brush>("Text3"), FontSize = 11, Margin = new Thickness(0, 0, 0, 10) });
                    resets.Add(ce.Reset);
                    break;
                }
            }
        }
    }

    static void PlaceBeside(SkyDialog d, Window owner)
    {
        // keep live-preview dialogs off to the right so the canvas stays visible
        if (owner == null) return;
        double scale = owner.RenderScaling;
        int x = owner.Position.X + (int)((owner.Bounds.Width - d.Bounds.Width - 330) * scale);
        int y = owner.Position.Y + (int)(110 * scale);
        d.Position = new PixelPoint(Math.Max(owner.Position.X, x), y);
    }

    static (CheckBox preview, TextBlock status) Footer(SkyDialog d, List<Action> resets, Action schedule)
    {
        var status = UIx.Label("", 11.5, "Text3");
        var previewCb = new CheckBox { Content = "Preview", IsChecked = true };
        var left = new StackPanel { Orientation = Orientation.Horizontal };
        left.Children.Add(previewCb);
        var reset = new Button { Content = "Reset", Style = UIx.R<Style>("Ghost"), Margin = new Thickness(10, 0, 0, 0) };
        reset.Click += (_, _) => { foreach (var r in resets) r(); schedule(); };
        left.Children.Add(reset);
        status.Margin = new Thickness(10, 0, 0, 0);
        left.Children.Add(status);
        d.AddFooterLeft(left);
        return (previewCb, status);
    }

    /// <summary>
    /// Destructive adjustment / filter on the active layer's edit target (pixels or mask), with live preview.
    /// </summary>
    public static bool Show(Window owner, Document doc, string title, string subtitle, IList<AdjustParam> ps,
        Func<AdjustContext, uint[], int, int, uint[]> fn, string icon = "◑")
    {
        var layer = doc.ActiveLayer;
        if (layer == null) return false;
        var original = layer.Target;
        int w = layer.Width, h = layer.Height;
        var sel = doc.Selection;
        var before = doc.Capture();
        var ctx = new AdjustContext();
        foreach (var p in ps) ctx.V[p.Key] = p.Def;

        var d = new SkyDialog(owner, layer.EditMask ? title + " (mask)" : title, subtitle);
        d.WindowStartupLocation = WindowStartupLocation.Manual;
        var body = new StackPanel { Width = 340 };
        bool preview = true;
        // one render at a time: slider moves only bump the version; the worker loop renders the newest
        // settings when it's free (no pile-up of full-size renders), and Apply reuses a finished preview
        int version = 0, doneVersion = -1, taskVersion = -1;
        uint[] doneResult = null;
        Task<uint[]> task = null;
        var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(45) };
        var resets = new List<Action>();
        void Schedule() { version++; timer.Stop(); timer.Start(); }
        BuildParams(body, ps, ctx, Schedule, resets, original, null);
        var (previewCb, status) = Footer(d, resets, Schedule);
        previewCb.Click += (_, _) => { preview = previewCb.IsChecked == true; Schedule(); };
        Task<uint[]> Render() { var snap = new AdjustContext { V = new Dictionary<string, double>(ctx.V), Curves = ctx.Curves }; return Task.Run(() => Filters.Masked(original, fn(snap, original, w, h), sel)); }

        async void Pump()
        {
            if (task != null) return;   // the running render loops round to the newest settings
            if (!preview) { layer.SetTarget(original, false); doc.RenderAll(); status.Text = ""; return; }
            try
            {
                while (preview && doneVersion != version && d.IsVisible)
                {
                    int my = version;
                    status.Text = "Rendering…";
                    taskVersion = my;
                    task = Render();
                    uint[] res;
                    try { res = await task; }
                    catch (Exception ex) { status.Text = "Error: " + ex.Message; return; }
                    finally { task = null; taskVersion = -1; }
                    doneVersion = my;
                    doneResult = res;
                    if (!d.IsVisible || !preview) return;
                    layer.SetTarget(res);
                    doc.RenderAll();
                }
                status.Text = "";
            }
            catch (Exception ex) { App.LogCrash(ex); }
        }
        timer.Tick += (_, _) => { timer.Stop(); Pump(); };

        bool ok = false;
        d.Body = body;
        d.AddButton("Cancel", false, () => d.DialogResult = false);
        d.AddButton("Apply", true, () => { ok = true; d.DialogResult = true; });
        d.Opened += (_, _) => { PlaceBeside(d, owner); Schedule(); };
        d.ShowDialog();
        timer.Stop();

        if (ok)
        {
            // the preview usually already holds the exact result; otherwise finish it without freezing the window
            uint[] res = doneVersion == version ? doneResult : null;
            if (res == null)
            {
                Mouse.OverrideCursor = Cursors.Wait;
                try { res = UiWait.Wait(taskVersion == version && task != null ? task : Render()); }
                finally { Mouse.OverrideCursor = null; }
            }
            layer.SetTarget(res);
            doc.RenderAll();
            layer.RefreshThumbnail();
            doc.RefreshThumbnail();
            doc.Record(title.TrimEnd('…', '.') + (layer.EditMask ? " (mask)" : ""), before, icon);
            return true;
        }
        layer.SetTarget(original, false);
        doc.RenderAll();
        return false;
    }

    /// <summary>Edit a non-destructive adjustment layer; the composite updates live.</summary>
    public static bool ShowLayer(Window owner, Document doc, Layer layer, string subtitle, IList<AdjustParam> ps,
        Func<AdjustContext, AdjustmentSpec> build, IList<Point> curve, bool isNew)
    {
        var originalSpec = layer.Adjustment;
        var before = doc.Capture();
        var ctx = new AdjustContext();
        foreach (var p in ps) ctx.V[p.Key] = p.Def;
        var d = new SkyDialog(owner, originalSpec.Title, subtitle ?? "Adjustment layer — non-destructive, edit any time");
        d.WindowStartupLocation = WindowStartupLocation.Manual;
        var body = new StackPanel { Width = 340 };
        var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(30) };
        var resets = new List<Action>();
        bool preview = true;
        void Schedule() { timer.Stop(); timer.Start(); }
        BuildParams(body, ps, ctx, Schedule, resets, doc.Flat, curve);
        var (previewCb, status) = Footer(d, resets, Schedule);
        previewCb.Click += (_, _) => { preview = previewCb.IsChecked == true; Schedule(); };
        timer.Tick += (_, _) =>
        {
            timer.Stop();
            layer.Adjustment = preview ? build(ctx) : originalSpec;
            bool vis = layer.Visible;
            if (!preview) layer.Visible = false;
            doc.RenderAll();
            layer.Visible = vis;
        };
        bool ok = false;
        d.Body = body;
        d.AddButton("Cancel", false, () => d.DialogResult = false);
        d.AddButton(isNew ? "Create" : "Apply", true, () => { ok = true; d.DialogResult = true; });
        d.Opened += (_, _) => { PlaceBeside(d, owner); Schedule(); };
        d.ShowDialog();
        timer.Stop();
        if (ok)
        {
            layer.Adjustment = build(ctx);
            doc.RenderAll();
            doc.RefreshThumbnail();
            doc.Record(isNew ? $"New {layer.Adjustment.Title} Layer" : $"Edit {layer.Adjustment.Title}", before, "◑");
            return true;
        }
        layer.Adjustment = originalSpec;
        doc.RenderAll();
        return false;
    }
}
// ═══════════════════════════════ Image size ═══════════════════════════════

public static class ImageSizeDialog
{
    public static (int w, int h)? Show(Window owner, int w0, int h0, string title = "Image size", string subtitle = "Resample every layer")
    {
        var d = new SkyDialog(owner, title, subtitle);
        var sp = new StackPanel { Width = 340 };
        TextBox wb = new() { Text = w0.ToString() }, hb = new() { Text = h0.ToString() }, pb = new() { Text = "100" };
        var link = new ToggleButton { Content = new Ico("link", 16), Style = UIx.R<Style>("IconBtn"), IsChecked = true, ToolTip = "Keep proportions", Margin = new Thickness(8, 18, 8, 0) };
        var g = new Grid();
        g.ColumnDefinitions.Add(new ColumnDefinition());
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        g.ColumnDefinitions.Add(new ColumnDefinition());
        var c1 = new StackPanel(); c1.Children.Add(UIx.Label("Width (px)", 12, "Text3")); wb.Margin = new Thickness(0, 6, 0, 0); c1.Children.Add(wb);
        var c2 = new StackPanel(); c2.Children.Add(UIx.Label("Height (px)", 12, "Text3")); hb.Margin = new Thickness(0, 6, 0, 0); c2.Children.Add(hb);
        Grid.SetColumn(link, 1); Grid.SetColumn(c2, 2);
        g.Children.Add(c1); g.Children.Add(link); g.Children.Add(c2);
        sp.Children.Add(g);
        var pr = new StackPanel { Margin = new Thickness(0, 14, 0, 0) };
        pr.Children.Add(UIx.Label("Scale (%)", 12, "Text3"));
        pb.Margin = new Thickness(0, 6, 0, 0);
        pr.Children.Add(pb);
        sp.Children.Add(pr);
        var info = UIx.Label($"Current: {w0} × {h0} px", 12, "Text3");
        info.Margin = new Thickness(0, 14, 0, 0);
        sp.Children.Add(info);
        bool upd = false;
        wb.TextChanged += (_, _) =>
        {
            if (upd || !int.TryParse(wb.Text, out int w)) return;
            upd = true;
            if (link.IsChecked == true) hb.Text = Math.Max(1, (int)Math.Round(w * (double)h0 / w0)).ToString();
            pb.Text = (w * 100.0 / w0).ToString("0.#", CultureInfo.InvariantCulture);
            upd = false;
        };
        hb.TextChanged += (_, _) =>
        {
            if (upd || !int.TryParse(hb.Text, out int h)) return;
            upd = true;
            if (link.IsChecked == true) { wb.Text = Math.Max(1, (int)Math.Round(h * (double)w0 / h0)).ToString(); pb.Text = (h * 100.0 / h0).ToString("0.#", CultureInfo.InvariantCulture); }
            upd = false;
        };
        pb.TextChanged += (_, _) =>
        {
            if (upd || !double.TryParse(pb.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out double p) || p <= 0) return;
            upd = true;
            wb.Text = Math.Max(1, (int)Math.Round(w0 * p / 100)).ToString();
            hb.Text = Math.Max(1, (int)Math.Round(h0 * p / 100)).ToString();
            upd = false;
        };
        d.Body = sp;
        (int, int)? res = null;
        d.AddButton("Cancel", false, () => d.DialogResult = false);
        d.AddButton("Apply", true, () =>
        {
            if (int.TryParse(wb.Text, out int w) && int.TryParse(hb.Text, out int h) && w > 0 && h > 0 && w <= 20000 && h <= 20000) { res = (w, h); d.DialogResult = true; }
            else SkyDialog.Alert(d, "Invalid size", "Enter a size between 1 and 20000 pixels.");
        });
        return d.ShowDialog() == true ? res : null;
    }
}

// ═══════════════════════════════ Canvas size ═══════════════════════════════

public static class CanvasSizeDialog
{
    public static (int w, int h, int ax, int ay, int fill)? Show(Window owner, int w0, int h0)
    {
        var d = new SkyDialog(owner, "Canvas size", "Add or remove space around the image");
        var sp = new StackPanel { Width = 340 };
        TextBox wb = new() { Text = w0.ToString() }, hb = new() { Text = h0.ToString() };
        var g = new Grid();
        g.ColumnDefinitions.Add(new ColumnDefinition());
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) });
        g.ColumnDefinitions.Add(new ColumnDefinition());
        var c1 = new StackPanel(); c1.Children.Add(UIx.Label("Width (px)", 12, "Text3")); wb.Margin = new Thickness(0, 6, 0, 0); c1.Children.Add(wb);
        var c2 = new StackPanel(); c2.Children.Add(UIx.Label("Height (px)", 12, "Text3")); hb.Margin = new Thickness(0, 6, 0, 0); c2.Children.Add(hb);
        Grid.SetColumn(c2, 2);
        g.Children.Add(c1); g.Children.Add(c2);
        sp.Children.Add(g);

        sp.Children.Add(new TextBlock { Text = "Anchor", Foreground = UIx.R<Brush>("Text3"), FontSize = 12, Margin = new Thickness(0, 16, 0, 6) });
        int ax = 1, ay = 1;
        var grid = new UniformGrid { Rows = 3, Columns = 3, Width = 114, Height = 114, HorizontalAlignment = HorizontalAlignment.Left };
        var anchors = new List<ToggleButton>();
        for (int y = 0; y < 3; y++)
            for (int x = 0; x < 3; x++)
            {
                int xx = x, yy = y;
                var t = new ToggleButton { Style = UIx.R<Style>("Secondary"), Margin = new Thickness(2), Padding = new Thickness(0), IsChecked = x == 1 && y == 1, Content = new Ellipse { Width = 8, Height = 8, Fill = UIx.R<Brush>("Text2") } };
                t.Click += (_, _) => { foreach (var a in anchors) a.IsChecked = a == t; ax = xx; ay = yy; };
                anchors.Add(t);
                grid.Children.Add(t);
            }
        sp.Children.Add(grid);
        sp.Children.Add(new TextBlock { Text = "New area", Foreground = UIx.R<Brush>("Text3"), FontSize = 12, Margin = new Thickness(0, 16, 0, 6) });
        int fill = 0;
        var seg = UIx.SegGroup(new (object, string)[] { ("Transparent", null), ("Background color", null), ("White", null), ("Black", null) }, 0, i => fill = i);
        seg.HorizontalAlignment = HorizontalAlignment.Left;
        sp.Children.Add(seg);
        d.Body = sp;
        (int, int, int, int, int)? res = null;
        d.AddButton("Cancel", false, () => d.DialogResult = false);
        d.AddButton("Apply", true, () =>
        {
            if (int.TryParse(wb.Text, out int w) && int.TryParse(hb.Text, out int h) && w > 0 && h > 0 && w <= 20000 && h <= 20000) { res = (w, h, ax, ay, fill); d.DialogResult = true; }
            else SkyDialog.Alert(d, "Invalid size", "Enter a size between 1 and 20000 pixels.");
        });
        return d.ShowDialog() == true ? res : null;
    }
}

// ═══════════════════════════════ Export ═══════════════════════════════

public sealed class ExportOptions
{
    public string Format = "PNG";
    public int Quality = 92;
    public double Scale = 1;
}

public static class ExportDialog
{
    public static ExportOptions Show(Window owner, Document doc)
    {
        var d = new SkyDialog(owner, "Export", "Save a flattened copy of your image");
        var opt = new ExportOptions { Quality = AppStore.Settings.JpegQuality };
        var root = new Grid();
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(340) });
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(24) });
        root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(300) });

        var thumb = ImageHost.Make(ImageIO.MakeThumbPixels(doc.Flat, doc.Width, doc.Height, 680, out int tw, out int th), tw, th);
        var img = new Image { Source = thumb, Stretch = Stretch.Uniform, MaxHeight = 300 };
        RenderOptions.SetBitmapInterpolationMode(img, BitmapInterpolationMode.HighQuality);
        var pv = new Border { Background = UIx.Checker(8, true), CornerRadius = new CornerRadius(12), Padding = new Thickness(12), Child = img, Height = 320 };
        root.Children.Add(pv);

        var right = new StackPanel();
        Grid.SetColumn(right, 2);
        root.Children.Add(right);
        right.Children.Add(UIx.Label("Format", 12, "Text3"));
        var formats = new[] { "PNG", "JPG", "PSD", "TIFF", "BMP", "GIF" };
        Control qualityRow = null, scaleRow = null;
        TextBlock noteText = null;
        var dims = UIx.Label("", 12, "Text2");
        void UpdateDims() => dims.Text = $"{Math.Max(1, (int)Math.Round(doc.Width * opt.Scale))} × {Math.Max(1, (int)Math.Round(doc.Height * opt.Scale))} px";
        var seg = UIx.SegGroup(formats.Select(f => ((object)f, (string)null)), 0, i =>
        {
            opt.Format = formats[i];
            if (qualityRow != null) qualityRow.Visibility = opt.Format == "JPG" ? Visibility.Visible : Visibility.Collapsed;
            if (scaleRow != null) scaleRow.Visibility = opt.Format == "PSD" ? Visibility.Collapsed : Visibility.Visible;
            if (noteText != null) noteText.Text = opt.Format == "PSD" ? "PSD keeps every layer, mask, adjustment layer, blend mode and group — Photoshop opens it fully editable." : "Layers are flattened. JPG and BMP fill transparency with white. To keep layers, choose PSD or use File ▸ Save (.skyphoto).";
        });
        seg.Margin = new Thickness(0, 6, 0, 18);
        seg.HorizontalAlignment = HorizontalAlignment.Left;
        right.Children.Add(seg);
        var (qr, _) = UIx.SliderRow("Quality", 10, 100, opt.Quality, v => opt.Quality = (int)v, 0, "", 300);
        qualityRow = qr;
        qualityRow.Visibility = Visibility.Collapsed;
        right.Children.Add(qualityRow);
        var (sr, _) = UIx.SliderRow("Scale", 10, 400, 100, v => { opt.Scale = v / 100; UpdateDims(); }, 0, "%", 300);
        scaleRow = sr;
        right.Children.Add(sr);
        right.Children.Add(UIx.Label("Output size", 12, "Text3"));
        dims.Margin = new Thickness(0, 4, 0, 0);
        right.Children.Add(dims);
        UpdateDims();
        var note = noteText = new TextBlock { Text = "Layers are flattened. JPG and BMP fill transparency with white. To keep layers, choose PSD or use File ▸ Save (.skyphoto).", TextWrapping = TextWrapping.Wrap, Foreground = UIx.R<Brush>("Text3"), FontSize = 11.5, Margin = new Thickness(0, 18, 0, 0) };
        right.Children.Add(note);

        d.Body = root;
        bool ok = false;
        d.AddButton("Cancel", false, () => d.DialogResult = false);
        d.AddButton("Export…", true, () => { ok = true; d.DialogResult = true; });
        d.ShowDialog();
        if (ok) { AppStore.Settings.JpegQuality = opt.Quality; AppStore.SaveSettings(); }
        return ok ? opt : null;
    }
}

// ═══════════════════════════════ Help ═══════════════════════════════

public static class InfoDialogs
{
    public static void Shortcuts(Window owner)
    {
        var d = new SkyDialog(owner, "Keyboard shortcuts", "Work faster in Sky Photo");
        var items = new (string, string)[]
        {
            ("V", "Move"), ("M", "Marquee (Shift+M cycles)"), ("L", "Lasso"), ("W", "Magic Wand"), ("C", "Crop"), ("I", "Eyedropper"),
            ("J", "Spot Healing / Healing Brush"), ("B", "Brush / Pencil"), ("S", "Clone Stamp"), ("E", "Eraser"), ("G", "Gradient / Bucket"),
            ("R", "Blur / Sharpen / Smudge"), ("O", "Dodge / Burn / Sponge"), ("T", "Type"), ("U", "Shapes"), ("H / Space", "Hand"), ("Z", "Zoom"),
            ("[  ]", "Brush size"), ("Shift [  ]", "Brush hardness"), ("1 – 0", "Tool opacity"), ("X", "Swap colors"), ("D", "Default colors"),
            ("Ctrl Z", "Undo"), ("Ctrl Shift Z / Ctrl Y", "Redo"), ("Ctrl N / O / S", "New / Open / Save"), ("Ctrl Shift S", "Save as"),
            ("Ctrl Alt E", "Export"), ("Ctrl T", "Free transform"), ("Ctrl A / D", "Select all / Deselect"), ("Ctrl Shift I", "Invert selection"),
            ("Ctrl J", "Duplicate layer"), ("Ctrl Shift N", "New layer"), ("Ctrl E", "Merge down"), ("Ctrl Shift E", "Merge visible"), ("Ctrl G", "Put layer in a group"), ("Ctrl Alt G", "Clipping mask"), ("Shift F5", "Content-Aware Fill"), ("Shift click mask", "Disable mask"),
            ("Ctrl C / X / V", "Copy / Cut / Paste"), ("Delete", "Clear selection"), ("Alt Backspace", "Fill with foreground"),
            ("Ctrl L", "Levels"), ("Ctrl M", "Curves"), ("Ctrl U", "Hue / Saturation"), ("Ctrl B", "Color balance"), ("Ctrl I", "Invert"),
            ("Ctrl Shift U", "Desaturate"), ("Ctrl + / –", "Zoom in / out"), ("Ctrl 0", "Fit on screen"), ("Ctrl 1", "100%"), ("Tab", "Hide panels"),
        };
        var grid = new UniformGrid { Columns = 2, Width = 640 };
        foreach (var (k, a) in items)
        {
            var row = new DockPanel { Margin = new Thickness(0, 0, 18, 8) };
            var key = new Border { Background = UIx.R<Brush>("Bg3"), CornerRadius = new CornerRadius(6), Padding = new Thickness(8, 3, 8, 3), BorderBrush = UIx.R<Brush>("Line2"), BorderThickness = new Thickness(1), Child = new TextBlock { Text = k, FontSize = 11.5, Foreground = UIx.R<Brush>("Text") } };
            DockPanel.SetDock(key, Dock.Right);
            row.Children.Add(key);
            row.Children.Add(new TextBlock { Text = a, Foreground = UIx.R<Brush>("Text2"), FontSize = 12.5, VerticalAlignment = VerticalAlignment.Center });
            grid.Children.Add(row);
        }
        d.Body = new ScrollViewer { Content = grid, MaxHeight = 520, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        d.AddButton("Close", true, () => d.DialogResult = true);
        d.ShowDialog();
    }

    public static void About(Window owner)
    {
        var d = new SkyDialog(owner, "About");
        var sp = new StackPanel { Width = 380, HorizontalAlignment = HorizontalAlignment.Center };
        var logo = new Image { Source = UIx.Asset("logo.png"), Width = 88, Height = 88, Margin = new Thickness(0, 4, 0, 14) };
        sp.Children.Add(logo);
        sp.Children.Add(new TextBlock { Text = "Sky Master Photos", Style = UIx.R<Style>("H1"), HorizontalAlignment = HorizontalAlignment.Center, FontSize = 26 });
        sp.Children.Add(new TextBlock { Text = "Sky Photo editor · version " + (typeof(InfoDialogs).Assembly.GetName().Version?.ToString(3) ?? "2.0.0"), Foreground = UIx.R<Brush>("Text3"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 4, 0, 16) });
        sp.Children.Add(new TextBlock
        {
            Text = "A fast, GPU-accelerated layered photo editor with 28 tools, pen pressure, layer masks, adjustment layers, clipping masks, editable text, content-aware healing, 23 blend modes and full Photoshop PSD open/save — built in C# with Avalonia and Skia, for Windows and Linux.",
            TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center, Foreground = UIx.R<Brush>("Text2"), FontSize = 12.5, LineHeight = 19
        });
        sp.Children.Add(new TextBlock { Text = $"Canvas: {GpuInfo.Renderer}  ·  GPU filters: {(GpuCompute.Enabled ? GpuCompute.Status : "off")}", Foreground = UIx.R<Brush>("Text3"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 12, 0, 0), FontSize = 11.5, TextWrapping = TextWrapping.Wrap, TextAlignment = TextAlignment.Center });
        sp.Children.Add(new TextBlock { Text = "© 2026 Sky", Foreground = UIx.R<Brush>("Text3"), HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 16, 0, 0), FontSize = 11.5 });
        d.Body = sp;
        d.AddButton("Close", true, () => d.DialogResult = true);
        d.ShowDialog();
    }
}

using Avalonia;
using Avalonia.Media;
using Avalonia.Platform;
using Avalonia.Rendering.SceneGraph;
using Avalonia.Skia;
using SkiaSharp;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

// ─────────────────────────────────────────────────────────────────────────────
//  GPU canvas. The document composite is cut into 512 px tiles, each an immutable
//  Skia image. Skia keeps an uploaded texture per image on the GPU, so after the
//  first frame only tiles that actually changed are sent to the graphics card
//  (WPF / WriteableBitmap re-uploaded the whole photo on every brush dab).
//  Zoomed out, tiles are drawn with trilinear mipmaps; zoomed in, as crisp pixels.
//  Without a GPU (VMs, remote desktops) the very same code draws on the CPU.
// ─────────────────────────────────────────────────────────────────────────────

public sealed class CanvasTiles : IDisposable
{
    public const int Size = 512;
    const int Apron = 2;    // extra pixels around each tile so filtering doesn't seam at tile edges

    SKImage[] _tiles = Array.Empty<SKImage>();
    readonly List<SKImage> _retired = new();
    int _cols, _rows, _w, _h;
    readonly object _lock = new();

    public int Width => _w;
    public int Height => _h;

    /// <summary>Re-reads the tiles under the dirty rect (null = all) from the straight-alpha composite.</summary>
    public unsafe void Update(uint[] flat, int w, int h, Int32Rect? dirty)
    {
        if (flat == null || flat.Length < w * h) return;
        lock (_lock)
        {
            if (w != _w || h != _h)
            {
                _retired.AddRange(_tiles.Where(t => t != null));
                _w = w; _h = h;
                _cols = (w + Size - 1) / Size; _rows = (h + Size - 1) / Size;
                _tiles = new SKImage[_cols * _rows];
                dirty = null;
            }
            var r = dirty is Int32Rect d ? RectUtil.Clip(d, w, h) : new Int32Rect(0, 0, w, h);
            if (RectUtil.IsEmptyRect(r)) return;
            int c0 = Math.Max(0, (r.X - Apron) / Size), c1 = Math.Min(_cols - 1, (r.X + r.Width - 1 + Apron) / Size);
            int r0 = Math.Max(0, (r.Y - Apron) / Size), r1 = Math.Min(_rows - 1, (r.Y + r.Height - 1 + Apron) / Size);
            var fresh = new SKImage[(c1 - c0 + 1) * (r1 - r0 + 1)];
            fixed (uint* src = flat)
            {
                var basePtr = (IntPtr)src;
                Parallel.For(0, fresh.Length, k =>
                {
                    int ty = r0 + k / (c1 - c0 + 1), tx = c0 + k % (c1 - c0 + 1);
                    var (x, y, tw, th) = TileBounds(tx, ty);
                    // straight alpha straight out of the composite; Skia converts while uploading
                    var info = new SKImageInfo(tw, th, SKColorType.Bgra8888, SKAlphaType.Unpremul);
                    fresh[k] = SKImage.FromPixelCopy(info, (nint)basePtr + (nint)(((long)y * w + x) * 4), w * 4);
                });
            }
            for (int k = 0; k < fresh.Length; k++)
            {
                int ty = r0 + k / (c1 - c0 + 1), tx = c0 + k % (c1 - c0 + 1);
                int i = ty * _cols + tx;
                if (_tiles[i] != null) _retired.Add(_tiles[i]);
                _tiles[i] = fresh[k];
            }
        }
    }

    /// <summary>Pixel bounds of a tile image including its apron.</summary>
    (int x, int y, int w, int h) TileBounds(int tx, int ty)
    {
        int x0 = Math.Max(0, tx * Size - Apron), y0 = Math.Max(0, ty * Size - Apron);
        int x1 = Math.Min(_w, (tx + 1) * Size + Apron), y1 = Math.Min(_h, (ty + 1) * Size + Apron);
        return (x0, y0, x1 - x0, y1 - y0);
    }

    /// <summary>Snapshot for one frame; the draw operation owns the images retired before it.</summary>
    public TileDrawOp CreateDrawOp(Rect bounds, Matrix view, double zoom)
    {
        lock (_lock)
        {
            var tiles = new TileRef[_tiles.Length];
            for (int ty = 0; ty < _rows; ty++)
                for (int tx = 0; tx < _cols; tx++)
                {
                    var (x, y, _, _) = TileBounds(tx, ty);
                    int sx = tx * Size, sy = ty * Size;
                    tiles[ty * _cols + tx] = new TileRef(_tiles[ty * _cols + tx], x, y,
                        SKRect.Create(sx - x, sy - y, Math.Min(Size, _w - sx), Math.Min(Size, _h - sy)), new SKRect(sx, sy, Math.Min(_w, sx + Size), Math.Min(_h, sy + Size)));
                }
            var retired = _retired.ToArray();
            _retired.Clear();
            return new TileDrawOp(bounds, tiles, view, zoom, retired, (long)_w * _h);
        }
    }

    public void Dispose()
    {
        lock (_lock)
        {
            // images may still be referenced by a frame in flight; the GC finalizes them safely
            _tiles = Array.Empty<SKImage>();
            _retired.Clear();
            _w = _h = 0;
        }
    }

    public readonly record struct TileRef(SKImage Image, int ImageX, int ImageY, SKRect Src, SKRect Dst);
}

/// <summary>Draws the document tiles with Skia on the render thread (GPU when available).</summary>
public sealed class TileDrawOp : ICustomDrawOperation
{
    readonly CanvasTiles.TileRef[] _tiles;
    readonly Matrix _view;
    readonly double _zoom;
    SKImage[] _retired;

    readonly long _docPixels;

    public TileDrawOp(Rect bounds, CanvasTiles.TileRef[] tiles, Matrix view, double zoom, SKImage[] retired, long docPixels)
    {
        _docPixels = docPixels;
        Bounds = bounds;
        _tiles = tiles;
        _view = view;
        _zoom = zoom;
        _retired = retired;
    }

    public Rect Bounds { get; }
    public bool HitTest(Point p) => false;
    public bool Equals(ICustomDrawOperation other) => false;

    public void Dispose()
    {
        // the previous frame has been replaced by now, so the tiles it used can go
        if (_retired == null) return;
        foreach (var i in _retired) i.Dispose();
        _retired = null;
    }

    public void Render(ImmediateDrawingContext context)
    {
        var lease = context.TryGetFeature<ISkiaSharpApiLeaseFeature>();
        if (lease == null) return;
        using var l = lease.Lease();
        var canvas = l.SkCanvas;
        GpuInfo.Report(l.GrContext);
        // keep every tile (with mipmaps) resident: evicted tiles would be re-uploaded each frame
        if (l.GrContext is GRContext gr)
        {
            long need = (long)(_docPixels * 4 * 1.4) + 256L * 1024 * 1024;
            if (gr.GetResourceCacheLimit() < need) gr.SetResourceCacheLimit(Math.Min(need, 3L * 1024 * 1024 * 1024));
        }

        // zoomed in: crisp pixels; 1-2×: bilinear; zoomed out: mipmapped (no shimmering / aliasing)
        var quality = _zoom >= 2 ? SKFilterQuality.None : _zoom >= 0.999 ? SKFilterQuality.Low : SKFilterQuality.Medium;
        using var paint = new SKPaint { IsAntialias = false, FilterQuality = quality };

        canvas.Save();
        canvas.ClipRect(new SKRect(0, 0, (float)Bounds.Width, (float)Bounds.Height));
        var m = new SKMatrix((float)_view.M11, (float)_view.M21, (float)_view.M31, (float)_view.M12, (float)_view.M22, (float)_view.M32, 0, 0, 1);
        canvas.Concat(ref m);
        // only tiles that are on screen
        var inv = _view.Invert();
        var vis = new Rect(0, 0, Bounds.Width, Bounds.Height).TransformToAABB(inv).Inflate(2);
        foreach (var t in _tiles)
        {
            if (t.Image == null) continue;
            if (t.Dst.Right < vis.X || t.Dst.Bottom < vis.Y || t.Dst.Left > vis.Right || t.Dst.Top > vis.Bottom) continue;
            canvas.DrawImage(t.Image, t.Src, t.Dst, paint);
        }
        canvas.Restore();
    }
}

/// <summary>What the canvas is drawing with — shown in Preferences and the About box.</summary>
public static class GpuInfo
{
    public static string Renderer { get; private set; } = "Starting…";
    public static bool IsGpu { get; private set; }
    public static event Action Changed;

    internal static void Report(GRContext gr)
    {
        bool gpu = gr != null;
        string name = !gpu ? "CPU (software rendering)"
            : gr.Backend switch
            {
                GRBackend.OpenGL when OperatingSystem.IsWindows() => "GPU — Direct3D 11 (via ANGLE)",
                GRBackend.OpenGL => "GPU — OpenGL",
                GRBackend.Vulkan => "GPU — Vulkan",
                GRBackend.Metal => "GPU — Metal",
                GRBackend.Direct3D => "GPU — Direct3D 12",
                _ => "GPU",
            };
        if (name == Renderer) return;
        Renderer = name;
        IsGpu = gpu;
        Avalonia.Threading.Dispatcher.UIThread.Post(() => Changed?.Invoke());
    }
}

using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

/// <summary>Edit ▸ Preferences: graphics card use, history, files and the canvas grid.</summary>
public static class Preferences
{
    public static void Show(Window owner, Action changed)
    {
        var st = AppStore.Settings;
        var d = new SkyDialog(owner, "Preferences", "Applies right away unless noted.");
        var body = new StackPanel { Width = 440, Spacing = 4 };

        TextBlock Section(string t) => new() { Text = t, Classes = { "PanelTitle" }, Margin = new Thickness(0, 14, 0, 6) };
        CheckBox Switch(string text, bool value, Action<bool> set, string tip = null)
        {
            var c = new CheckBox { Content = text, IsChecked = value, Margin = new Thickness(0, 2, 0, 2) };
            c.IsCheckedChanged += (_, _) => { set(c.IsChecked == true); changed?.Invoke(); };
            if (tip != null) ToolTip.SetTip(c, tip);
            return c;
        }
        TextBlock Note(string t) => new() { Text = t, Classes = { "Muted" }, FontSize = 11.5, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 4) };

        // ── graphics ──
        body.Children.Add(Section("GRAPHICS CARD"));
        var renderer = Note("");
        var filters = Note("");
        void Refresh()
        {
            renderer.Text = "Canvas drawn with: " + GpuInfo.Renderer;
            filters.Text = "GPU filters: " + (GpuCompute.Enabled ? GpuCompute.Status : "off (switched off here)");
        }
        Refresh();
        GpuInfo.Changed += Refresh;
        d.Closed += (_, _) => GpuInfo.Changed -= Refresh;
        body.Children.Add(Switch("Draw with the graphics card", st.GpuRendering, v => st.GpuRendering = v,
            "Smooth zooming, panning and painting on big photos. Takes effect after a restart."));
        body.Children.Add(renderer);
        body.Children.Add(Switch("Run heavy filters on the graphics card", st.GpuFilters, v => { st.GpuFilters = v; GpuCompute.Enabled = v; Refresh(); },
            "Gaussian blur, motion blur, unsharp mask, glow, tilt-shift … several times faster. Falls back to the CPU automatically."));
        body.Children.Add(filters);
        if (OperatingSystem.IsLinux())
            body.Children.Add(Note("In virtual machines the window is drawn on the CPU automatically (VM 3D drivers often show black windows). Start with SKY_SOFTWARE_RENDER=0 to force the GPU."));

        // ── editing ──
        body.Children.Add(Section("EDITING"));
        var (histRow, _) = UIx.SliderRow("History steps", 20, 300, st.HistoryLimit, v => { st.HistoryLimit = (int)v; History.MaxEntries = (int)v; }, 0, "", 420);
        body.Children.Add(histRow);
        body.Children.Add(Note("More steps use more memory on big photos."));

        // ── files ──
        body.Children.Add(Section("FILES"));
        var (jpgRow, _) = UIx.SliderRow("JPEG quality when saving", 50, 100, st.JpegQuality, v => st.JpegQuality = (int)v, 0, "", 420);
        body.Children.Add(jpgRow);

        // ── canvas ──
        body.Children.Add(Section("CANVAS"));
        body.Children.Add(Switch("Show grid", st.ShowGrid, v => st.ShowGrid = v));
        var (gridRow, _) = UIx.SliderRow("Grid spacing", 5, 500, st.GridSize, v => { st.GridSize = (int)v; changed?.Invoke(); }, 0, " px", 420);
        body.Children.Add(gridRow);
        body.Children.Add(Switch("Pixel grid when zoomed in past 1000%", st.PixelGrid, v => st.PixelGrid = v));

        d.Body = new ScrollViewer { Content = body, MaxHeight = 640, VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto };
        d.AddButton("Done", true, () => d.DialogResult = true);
        d.ShowDialog();
        AppStore.SaveSettings();
        changed?.Invoke();
    }
}

using System.Diagnostics;
using System.Text;
using Avalonia;
using Avalonia.Media;
using Avalonia.Rendering.Composition;
using Avalonia.Threading;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Tools;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos;

// Hidden diagnostics:  --gputest  (GPU filters vs CPU)   --perftest  (frame times in the real window)
public partial class MainWindow
{
    static uint[] TestPhoto(int w, int h)
    {
        var p = new uint[w * h];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                int r = (x * 255 / w + y / 7) & 255, g = (y * 255 / h) & 255, b = ((x ^ y) * 3) & 255;
                uint a = (x / 300 + y / 300) % 5 == 0 ? 120u : 255u;   // some semi-transparent blocks
                p[y * w + x] = (a << 24) | (uint)(r << 16) | (uint)(g << 8) | (uint)b;
            }
        });
        return p;
    }

    static (int max, double mean) Diff(uint[] a, uint[] b)
    {
        int max = 0; long sum = 0;
        for (int i = 0; i < a.Length; i++)
        {
            uint x = a[i], y = b[i];
            if ((x >> 24) < 8 && (y >> 24) < 8) continue;   // colour of near-transparent pixels is meaningless
            for (int s = 0; s < 32; s += 8)
            {
                int d = Math.Abs((int)((x >> s) & 255) - (int)((y >> s) & 255));
                if (d > max) max = d;
                sum += d;
            }
        }
        return (max, sum / (a.Length * 4.0));
    }

    async void RunGpuTest()
    {
        try { await Task.Run(GpuTestBody); }
        catch (Exception ex)
        {
            File.WriteAllText(Path.Combine(AppStore.Dir, "gputest.log"), "CRASHED" + Environment.NewLine + ex);
            Environment.Exit(2);
        }
    }

    void GpuTestBody()
    {
        var log = new StringBuilder();
        log.AppendLine($"Sky Master Photos GPU test — {DateTime.Now}");
        bool avail = GpuCompute.Available;   // waits for the GPU worker to start
        log.AppendLine($"Renderer: {GpuInfo.Renderer}   GPU filters: {GpuCompute.Status}");
        int w = 6000, h = 4000;
        var src = TestPhoto(w, h);
        bool ok = true;
        void Case(string name, Func<uint[]> cpu, Func<uint[]> gpu, int tolerance)
        {
            var g0 = Filters.GpuGaussian; var m0 = Filters.GpuMotion;
            Filters.GpuGaussian = null; Filters.GpuMotion = null;
            var sw = Stopwatch.StartNew(); var c = cpu(); double tc = sw.Elapsed.TotalMilliseconds;
            Filters.GpuGaussian = g0; Filters.GpuMotion = m0;
            gpu();   // warm-up (shader compile, upload paths)
            sw.Restart(); var g = gpu(); double tg = sw.Elapsed.TotalMilliseconds;
            if (g == null) { log.AppendLine($"{name,-24} CPU {tc,7:F0} ms   GPU: not available (CPU fallback)"); return; }
            var (max, mean) = Diff(c, g);
            bool pass = mean < tolerance / 4.0;
            ok &= pass;
            log.AppendLine($"{name,-24} CPU {tc,7:F0} ms   GPU {tg,7:F0} ms   ×{tc / Math.Max(1, tg),4:F1}   diff max {max} mean {mean:F2}  {(pass ? "OK" : "TOO DIFFERENT")}");
        }
        Case("Gaussian blur r=20", () => Filters.GaussianBlur(src, w, h, 20), () => GpuCompute.Gaussian(src, w, h, 10), 8);
        Case("Gaussian blur r=80", () => Filters.GaussianBlur(src, w, h, 80), () => GpuCompute.Gaussian(src, w, h, 40), 8);
        Case("Motion blur 40px", () => Filters.MotionBlur(src, w, h, 25, 40), () => GpuCompute.Motion(src, w, h, 25, 40), 8);
        var big = TestPhoto(9000, 6000);   // bigger than one GPU tile: checks the tiling seams
        Case("Gaussian 54 MP (tiled)", () => Filters.GaussianBlur(big, 9000, 6000, 30), () => GpuCompute.Gaussian(big, 9000, 6000, 15), 8);
        log.Insert(0, (ok ? "ALL PASSED" : "SOME FAILED") + "\n");
        Directory.CreateDirectory(AppStore.Dir);
        File.WriteAllText(Path.Combine(AppStore.Dir, "gputest.log"), log.ToString());
        Environment.Exit(ok ? 0 : 1);
    }

    async void RunPerfTest()
    {
        var log = new StringBuilder();
        log.AppendLine($"Sky Master Photos perf test — {DateTime.Now}");
        log.AppendLine($"Renderer: {GpuInfo.Renderer}");
        int w = 6000, h = 4000;
        var d = new Document(w, h, "Perf", "New");
        var bg = new Layer("Background", w, h, TestPhoto(w, h));
        d.Layers.Add(bg);
        d.ActiveLayer = bg;
        d.RenderAll();
        AddDocument(d);
        var comp = ElementComposition.GetElementVisual(this)?.Compositor;
        async Task Frame()
        {
            Canvas.InvalidateVisual();
            if (comp != null) await comp.RequestCompositionBatchCommitAsync().Rendered;
            else await Task.Delay(16);
        }
        for (int i = 0; i < 10; i++) await Frame();

        async Task Measure(string name, int frames, Action<int> step)
        {
            var times = new List<double>();
            var sw = Stopwatch.StartNew();
            for (int i = 0; i < frames; i++)
            {
                double t0 = sw.Elapsed.TotalMilliseconds;
                step(i);
                await Frame();
                times.Add(sw.Elapsed.TotalMilliseconds - t0);
            }
            times.Sort();
            double avg = times.Average(), p95 = times[(int)(times.Count * 0.95)];
            log.AppendLine($"{name,-34} avg {avg,6:F1} ms ({1000 / avg,5:F0} fps)   95% under {p95,6:F1} ms");
        }

        Canvas.Fit();
        Ctl.Tool = Tool.Brush;
        Ctl.CurrentBrush.Size = 60;
        Point P(int i) => new(w / 2 + Math.Cos(i * 0.09) * (400 + i * 6), h / 2 + Math.Sin(i * 0.09) * (400 + i * 6));
        Ctl.MouseDown(Canvas.ToScreen(P(0)), P(0), ModifierKeys.None, 1);
        await Measure("brush, fit to screen", 150, i => Ctl.MouseMove(Canvas.ToScreen(P(i + 1)), P(i + 1), ModifierKeys.None, true));
        Ctl.MouseUp(Canvas.ToScreen(P(150)), P(150), ModifierKeys.None);
        Canvas.ActualPixels();
        Ctl.MouseDown(Canvas.ToScreen(P(0)), P(0), ModifierKeys.None, 1);
        await Measure("brush, 100%", 150, i => Ctl.MouseMove(Canvas.ToScreen(P(i + 1)), P(i + 1), ModifierKeys.None, true));
        Ctl.MouseUp(Canvas.ToScreen(P(150)), P(150), ModifierKeys.None);
        var c = new Point(Canvas.Bounds.Width / 2, Canvas.Bounds.Height / 2);
        await Measure("zoom in/out", 120, i => Canvas.ZoomAt(c, 0.05 * Math.Pow(1.04, i % 60 < 30 ? i % 60 : 60 - i % 60) * 4));
        await Measure("pan", 120, i => Canvas.PanBy(new Vector(i % 40 < 20 ? 25 : -25, 0)));

        foreach (var doc in Docs) doc.IsDirty = false;
        log.AppendLine($"Canvas drawn with: {GpuInfo.Renderer}");
        Directory.CreateDirectory(AppStore.Dir);
        File.WriteAllText(Path.Combine(AppStore.Dir, "perftest.log"), log.ToString());
        Environment.Exit(0);
    }
}

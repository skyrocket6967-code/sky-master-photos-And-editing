using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Avalonia.Media;

namespace SkyMasterPhotos.Core;

public sealed class RecentItem
{
    public string Path { get; set; }
    public DateTime LastOpened { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }

    [System.Text.Json.Serialization.JsonIgnore] public string Name => System.IO.Path.GetFileName(Path);
    [System.Text.Json.Serialization.JsonIgnore] public string Info => $"{Width} × {Height}  ·  {Ago(LastOpened)}";
    [System.Text.Json.Serialization.JsonIgnore] public IImage Thumb => AppStore.GetCachedThumb(Path);
    [System.Text.Json.Serialization.JsonIgnore] public string Kind => System.IO.Path.GetExtension(Path).TrimStart('.').ToUpperInvariant();

    static string Ago(DateTime t)
    {
        var d = DateTime.Now - t;
        if (d.TotalMinutes < 1) return "just now";
        if (d.TotalHours < 1) return $"{(int)d.TotalMinutes} min ago";
        if (d.TotalDays < 1) return $"{(int)d.TotalHours} h ago";
        if (d.TotalDays < 7) return $"{(int)d.TotalDays} d ago";
        return t.ToString("MMM d, yyyy");
    }
}

public sealed class AppSettings
{
    public bool ShowRulersHint { get; set; } = true;
    public string LastFolder { get; set; }
    public int JpegQuality { get; set; } = 92;
    public List<string> Swatches { get; set; }
    public double WindowWidth { get; set; } = 1600;
    public double WindowHeight { get; set; } = 960;
    public bool Maximized { get; set; } = true;
    /// <summary>Draw the window with the graphics card (needs a restart). Off = CPU rendering.</summary>
    public bool GpuRendering { get; set; } = true;
    /// <summary>Run heavy filters (blurs …) on the graphics card when there is one.</summary>
    public bool GpuFilters { get; set; } = true;
    public int HistoryLimit { get; set; } = 60;
    public bool ShowGrid { get; set; }
    public int GridSize { get; set; } = 50;
    public bool PixelGrid { get; set; } = true;
}

public static class AppStore
{
    /// <summary>Settings / recent files folder. SKY_MASTER_PHOTOS_DATA overrides it (the UI tests use a scratch folder).</summary>
    public static string Dir { get; } = Environment.GetEnvironmentVariable("SKY_MASTER_PHOTOS_DATA") is string d && d.Length > 0
        ? d : System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "Sky Master Photos");
    static string ThumbDir => System.IO.Path.Combine(Dir, "thumbs");
    static string RecentFile => System.IO.Path.Combine(Dir, "recent.json");
    static string SettingsFile => System.IO.Path.Combine(Dir, "settings.json");

    public static AppSettings Settings { get; private set; } = new();

    public static void Load()
    {
        try
        {
            Directory.CreateDirectory(ThumbDir);
            if (File.Exists(SettingsFile)) Settings = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(SettingsFile)) ?? new();
        }
        catch { Settings = new(); }
    }

    public static void SaveSettings()
    {
        try { Directory.CreateDirectory(Dir); File.WriteAllText(SettingsFile, JsonSerializer.Serialize(Settings, new JsonSerializerOptions { WriteIndented = true })); } catch { }
    }

    public static List<RecentItem> GetRecent()
    {
        try
        {
            if (!File.Exists(RecentFile)) return new();
            var list = JsonSerializer.Deserialize<List<RecentItem>>(File.ReadAllText(RecentFile)) ?? new();
            return list.Where(r => File.Exists(r.Path)).OrderByDescending(r => r.LastOpened).Take(24).ToList();
        }
        catch { return new(); }
    }

    public static void AddRecent(string path, int w, int h, uint[] flat)
    {
        try
        {
            Directory.CreateDirectory(ThumbDir);
            var list = GetRecent();
            list.RemoveAll(r => string.Equals(r.Path, path, StringComparison.OrdinalIgnoreCase));
            list.Insert(0, new RecentItem { Path = path, LastOpened = DateTime.Now, Width = w, Height = h });
            File.WriteAllText(RecentFile, JsonSerializer.Serialize(list.Take(24).ToList(), new JsonSerializerOptions { WriteIndented = true }));
            if (flat != null)
            {
                var t = ImageIO.MakeThumbPixels(flat, w, h, 360, out int tw, out int th);
                File.WriteAllBytes(ThumbPath(path), ImageIO.EncodePng(t, tw, th));
            }
        }
        catch { }
    }

    public static void RemoveRecent(string path)
    {
        try
        {
            var list = GetRecent();
            list.RemoveAll(r => string.Equals(r.Path, path, StringComparison.OrdinalIgnoreCase));
            File.WriteAllText(RecentFile, JsonSerializer.Serialize(list));
        }
        catch { }
    }

    static string ThumbPath(string path)
    {
        var hash = Convert.ToHexString(SHA1.HashData(Encoding.UTF8.GetBytes(path.ToLowerInvariant())));
        return System.IO.Path.Combine(ThumbDir, hash[..16] + ".png");
    }

    public static IImage GetCachedThumb(string path)
    {
        try
        {
            var tp = ThumbPath(path);
            if (File.Exists(tp))
            {
                var (px, w, h) = ImageIO.LoadPixels(new MemoryStream(File.ReadAllBytes(tp)));
                return ImageHost.Make(px, w, h);
            }
            return ImageIO.LoadThumbnail(path, 360);
        }
        catch { return null; }
    }
}

using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Avalonia;

namespace SkyMasterPhotos.Core;

public sealed class LayerState
{
    public Layer L;
    public uint[] Pixels;
    public uint[] Mask;
    public int W, H;
    public string Name;
    public bool Visible, Locked, MaskEnabled, Clipped;
    public double Opacity, Fill;
    public BlendMode Blend;
    public string Group;
    public AdjustmentSpec Adjustment;
    public TextSpec Text;
    public LayerStyle Style;
    public PsdLayerData Psd;
}

/// <summary>
/// A cheap snapshot of document structure. Pixel buffers are captured by reference: every in-place pixel
/// mutation is recorded as a <see cref="PixelPatch"/>, and every other change swaps in a new buffer, so a
/// linear undo walk always finds buffers in exactly the state the snapshot saw.
/// </summary>
public sealed class DocState
{
    public int W, H;
    public LayerState[] Layers;
    public int Active;
    public byte[] Sel;
    public Dictionary<string, GroupInfo> Groups;
}

public sealed class PixelPatch
{
    public Layer L;
    public bool IsMask;
    public Int32Rect R;
    public uint[] Before, After;

    public static uint[] Extract(uint[] src, int w, Int32Rect r)
    {
        var o = new uint[r.Width * r.Height];
        for (int y = 0; y < r.Height; y++) Array.Copy(src, (r.Y + y) * w + r.X, o, y * r.Width, r.Width);
        return o;
    }

    public static void Put(uint[] dst, int w, Int32Rect r, uint[] data)
    {
        for (int y = 0; y < r.Height; y++) Array.Copy(data, y * r.Width, dst, (r.Y + y) * w + r.X, r.Width);
    }
}

public sealed class HistoryEntry : INotifyPropertyChanged
{
    public string Name { get; init; }
    public string Icon { get; init; } = "•";
    public DocState Before;
    public DocState After;
    public PixelPatch Patch;

    bool _undone, _current;
    public bool IsUndone { get => _undone; set { if (_undone != value) { _undone = value; OnChanged(); } } }
    public bool IsCurrent { get => _current; set { if (_current != value) { _current = value; OnChanged(); } } }

    public event PropertyChangedEventHandler PropertyChanged;
    void OnChanged([CallerMemberName] string n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}

public sealed class History
{
    /// <summary>Undo steps kept (Preferences ▸ History steps).</summary>
    public static int MaxEntries = 80;
    public ObservableCollection<HistoryEntry> Entries { get; } = new();
    /// <summary>Number of entries currently applied (base entry included).</summary>
    public int Index { get; private set; }

    public History(string baseName)
    {
        Entries.Add(new HistoryEntry { Name = baseName, Icon = "★" });
        Index = 1;
        UpdateFlags();
    }

    public bool CanUndo => Index > 1;
    public bool CanRedo => Index < Entries.Count;

    public void Push(HistoryEntry e)
    {
        while (Entries.Count > Index) Entries.RemoveAt(Entries.Count - 1);
        Entries.Add(e);
        Index++;
        while (Entries.Count > MaxEntries) { Entries.RemoveAt(1); Index--; }
        UpdateFlags();
    }

    public HistoryEntry TakeUndo()
    {
        if (!CanUndo) return null;
        Index--;
        var e = Entries[Index];
        UpdateFlags();
        return e;
    }

    public HistoryEntry TakeRedo()
    {
        if (!CanRedo) return null;
        var e = Entries[Index];
        Index++;
        UpdateFlags();
        return e;
    }

    void UpdateFlags()
    {
        for (int i = 0; i < Entries.Count; i++)
        {
            Entries[i].IsUndone = i >= Index;
            Entries[i].IsCurrent = i == Index - 1;
        }
    }
}

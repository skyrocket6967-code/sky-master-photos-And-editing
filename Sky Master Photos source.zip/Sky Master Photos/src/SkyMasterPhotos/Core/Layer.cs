using System.ComponentModel;
using System.Runtime.CompilerServices;
using Avalonia;
using Avalonia.Media;

namespace SkyMasterPhotos.Core;

public enum BlendMode
{
    Normal, Darken, Multiply, ColorBurn, LinearBurn,
    Lighten, Screen, ColorDodge, LinearDodge,
    Overlay, SoftLight, HardLight, VividLight, LinearLight, PinLight,
    Difference, Exclusion, Subtract, Divide,
    Hue, Saturation, Color, Luminosity
}

public static class BlendModeInfo
{
    public static string Name(BlendMode m) => m switch
    {
        BlendMode.ColorBurn => "Color Burn",
        BlendMode.LinearBurn => "Linear Burn",
        BlendMode.ColorDodge => "Color Dodge",
        BlendMode.LinearDodge => "Linear Dodge (Add)",
        BlendMode.SoftLight => "Soft Light",
        BlendMode.HardLight => "Hard Light",
        BlendMode.VividLight => "Vivid Light",
        BlendMode.LinearLight => "Linear Light",
        BlendMode.PinLight => "Pin Light",
        _ => m.ToString()
    };

    /// <summary>Menu groups, separated like Photoshop's blend list.</summary>
    public static readonly BlendMode[][] Groups =
    {
        new[] { BlendMode.Normal },
        new[] { BlendMode.Darken, BlendMode.Multiply, BlendMode.ColorBurn, BlendMode.LinearBurn },
        new[] { BlendMode.Lighten, BlendMode.Screen, BlendMode.ColorDodge, BlendMode.LinearDodge },
        new[] { BlendMode.Overlay, BlendMode.SoftLight, BlendMode.HardLight, BlendMode.VividLight, BlendMode.LinearLight, BlendMode.PinLight },
        new[] { BlendMode.Difference, BlendMode.Exclusion, BlendMode.Subtract, BlendMode.Divide },
        new[] { BlendMode.Hue, BlendMode.Saturation, BlendMode.Color, BlendMode.Luminosity },
    };
}

public sealed class Layer : INotifyPropertyChanged
{
    static int _nextId;
    public int Id { get; } = Interlocked.Increment(ref _nextId);

    public int Width { get; private set; }
    public int Height { get; private set; }
    public uint[] Pixels { get; private set; }

    /// <summary>
    /// Optional layer mask, same size as the layer. Stored as opaque gray pixels (0xFFgggggg) so every
    /// painting tool and filter can edit it exactly like normal pixels. White reveals, black hides.
    /// </summary>
    public uint[] Mask { get; private set; }

    string _name;
    bool _visible = true;
    double _opacity = 1.0;
    double _fill = 1.0;
    BlendMode _blend = BlendMode.Normal;
    bool _locked;
    bool _maskEnabled = true;
    bool _clipped;
    bool _editMask;
    string _group = "";
    AdjustmentSpec _adjust;
    TextSpec _text;
    IImage _thumb, _maskThumb;
    bool _isActive;

    /// <summary>Photoshop data kept for lossless round-trips (raw tagged blocks, source hash).</summary>
    public PsdLayerData Psd { get => _psd; set { _psd = value; OnChanged(); OnChanged(nameof(IsAdjustmentLike)); OnChanged(nameof(AdjustIcon)); OnChanged(nameof(Info)); OnChanged(nameof(HasEffects)); } }
    PsdLayerData _psd;

    public Layer(string name, int w, int h, uint[] pixels = null)
    {
        _name = name;
        Width = w;
        Height = h;
        Pixels = pixels ?? new uint[w * h];
    }

    public string Name { get => _name; set { if (_name != value) { _name = value; OnChanged(); } } }
    public bool Visible { get => _visible; set { if (_visible != value) { _visible = value; OnChanged(); } } }
    public double Opacity { get => _opacity; set { value = Math.Clamp(value, 0, 1); if (_opacity != value) { _opacity = value; OnChanged(); OnChanged(nameof(OpacityPercent)); OnChanged(nameof(Info)); } } }
    /// <summary>Photoshop "Fill" opacity (affects content but not layer effects).</summary>
    public double Fill { get => _fill; set { value = Math.Clamp(value, 0, 1); if (_fill != value) { _fill = value; OnChanged(); OnChanged(nameof(Info)); } } }
    public int OpacityPercent => (int)Math.Round(_opacity * 100);
    public BlendMode Blend { get => _blend; set { if (_blend != value) { _blend = value; OnChanged(); OnChanged(nameof(BlendName)); OnChanged(nameof(Info)); } } }
    public string BlendName => BlendModeInfo.Name(_blend);
    public bool Locked { get => _locked; set { if (_locked != value) { _locked = value; OnChanged(); } } }
    public bool IsActive { get => _isActive; set { if (_isActive != value) { _isActive = value; OnChanged(); OnChanged(nameof(PixelTargetActive)); OnChanged(nameof(MaskTargetActive)); } } }
    /// <summary>For the layers panel: which thumbnail of the active layer gets the edit-target outline.</summary>
    public bool PixelTargetActive => _isActive && !EditMask;
    public bool MaskTargetActive => _isActive && EditMask;
    public IImage Thumbnail { get => _thumb; private set { _thumb = value; OnChanged(); } }
    public IImage MaskThumbnail { get => _maskThumb; private set { _maskThumb = value; OnChanged(); } }

    public bool HasMask => Mask != null;
    public bool MaskEnabled { get => _maskEnabled; set { if (_maskEnabled != value) { _maskEnabled = value; OnChanged(); OnChanged(nameof(Info)); } } }
    /// <summary>Clipped to the layer below (Photoshop clipping mask).</summary>
    public bool Clipped { get => _clipped; set { if (_clipped != value) { _clipped = value; OnChanged(); } } }
    /// <summary>UI edit target: true while painting on the mask instead of the pixels.</summary>
    public bool EditMask { get => _editMask && Mask != null; set { if (_editMask != value) { _editMask = value; OnChanged(); OnChanged(nameof(EditPixels)); OnChanged(nameof(PixelTargetActive)); OnChanged(nameof(MaskTargetActive)); } } }
    public bool EditPixels => !EditMask;
    /// <summary>Group path from Photoshop ("Outer/Inner"), empty when ungrouped.</summary>
    public string Group { get => _group; set { value ??= ""; if (_group != value) { _group = value; OnChanged(); OnChanged(nameof(Info)); OnChanged(nameof(GroupDepth)); } } }
    public int GroupDepth => string.IsNullOrEmpty(_group) ? 0 : _group.Count(c => c == '/') + 1;

    /// <summary>Non-destructive adjustment (the layer has no pixels of its own when set).</summary>
    public AdjustmentSpec Adjustment { get => _adjust; set { if (!ReferenceEquals(_adjust, value)) { _adjust = value; OnChanged(); OnChanged(nameof(IsAdjustment)); OnChanged(nameof(IsAdjustmentLike)); OnChanged(nameof(AdjustIcon)); OnChanged(nameof(Info)); } } }
    public bool IsAdjustment => _adjust != null;
    public string AdjustIcon => _adjust?.Icon ?? (_psd?.UnrenderedAdjustment == true ? "sliders" : "");
    /// <summary>Adjustment layers, including Photoshop adjustments that are preserved but not rendered.</summary>
    public bool IsAdjustmentLike => _adjust != null || _psd?.UnrenderedAdjustment == true;

    /// <summary>Editable text source (pixels hold the rendered text).</summary>
    public TextSpec Text { get => _text; set { if (!ReferenceEquals(_text, value)) { _text = value; OnChanged(); OnChanged(nameof(IsText)); OnChanged(nameof(Info)); } } }
    public bool IsText => _text != null;

    public LayerStyle Style { get; set; }
    public bool HasEffects => Style?.Enabled == true || Psd?.HasEffects == true;

    /// <summary>Subtitle shown under the layer name.</summary>
    public string Info
    {
        get
        {
            var parts = new List<string>();
            if (!string.IsNullOrEmpty(_group)) parts.Add(_group.Replace("/", " › "));
            if (_adjust != null) parts.Add(_adjust.Title);
            else if (_text != null) parts.Add("Text");
            else if (!string.IsNullOrEmpty(Psd?.KindLabel)) parts.Add(Psd.KindLabel);
            if (_blend != BlendMode.Normal) parts.Add(BlendName);
            parts.Add($"{OpacityPercent}%");
            if (Mask != null && !_maskEnabled) parts.Add("mask off");
            return string.Join("  ·  ", parts);
        }
    }

    public void NotifyInfo() { OnChanged(nameof(Info)); OnChanged(nameof(HasEffects)); }

    /// <summary>Replace the pixel buffer (used by whole-layer operations; old buffer stays referenced by history).</summary>
    public void SetPixels(uint[] pixels, int w, int h)
    {
        Pixels = pixels;
        Width = w;
        Height = h;
    }

    public void SetMask(uint[] mask)
    {
        bool had = Mask != null;
        Mask = mask;
        if (mask == null) _editMask = false;
        if (had != (mask != null)) { OnChanged(nameof(HasMask)); OnChanged(nameof(EditMask)); OnChanged(nameof(EditPixels)); OnChanged(nameof(PixelTargetActive)); OnChanged(nameof(MaskTargetActive)); OnChanged(nameof(Info)); }
    }

    /// <summary>The buffer tools should edit right now (mask or pixels).</summary>
    public uint[] Target => EditMask ? Mask : Pixels;

    uint[] _styleBuffer;
    /// <summary>Scratch buffer for the compositor's layer-style rendering (reused between frames).</summary>
    internal uint[] StyleBuffer(int w, int h)
    {
        if (_styleBuffer == null || _styleBuffer.Length != w * h) _styleBuffer = new uint[w * h];
        return _styleBuffer;
    }

    public void SetTarget(uint[] px, bool normalize = true)
    {
        if (EditMask) Mask = normalize ? Masks.Normalize(px) : px;
        else Pixels = px;
    }

    public static uint[] NewMask(int w, int h, byte value)
    {
        var m = new uint[w * h];
        Array.Fill(m, 0xFF000000u | (uint)value << 16 | (uint)value << 8 | value);
        return m;
    }

    public Layer CloneDeep(string name = null)
    {
        var l = new Layer(name ?? _name, Width, Height, (uint[])Pixels.Clone())
        {
            _visible = _visible,
            _opacity = _opacity,
            _fill = _fill,
            _blend = _blend,
            _clipped = _clipped,
            _maskEnabled = _maskEnabled,
            _group = _group,
            _adjust = _adjust,
            _text = _text,
            Style = Style,
            Mask = (uint[])Mask?.Clone(),
            Psd = Psd?.CloneForCopy(),
        };
        return l;
    }

    public void RefreshThumbnail(int max = 56)
    {
        Thumbnail = _adjust != null ? null : ThumbnailMaker.Make(Pixels, Width, Height, max, true);
        MaskThumbnail = Mask == null ? null : ThumbnailMaker.Make(Mask, Width, Height, max, false);
    }

    public event PropertyChangedEventHandler PropertyChanged;
    void OnChanged([CallerMemberName] string n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}

public static class Masks
{
    /// <summary>Force a buffer to opaque gray so it is a valid mask.</summary>
    public static uint[] Normalize(uint[] px)
    {
        var o = new uint[px.Length];
        Parallel.For(0, px.Length / 4096 + 1, c =>
        {
            int s = c * 4096, e = Math.Min(px.Length, s + 4096);
            for (int i = s; i < e; i++)
            {
                uint p = px[i];
                int a = (int)(p >> 24);
                int g = (int)((((p >> 16) & 255) * 77 + ((p >> 8) & 255) * 150 + (p & 255) * 29) >> 8);
                g = g * a / 255; // transparent areas of a pasted image become black
                o[i] = 0xFF000000u | (uint)g << 16 | (uint)g << 8 | (uint)g;
            }
        });
        return o;
    }

    public static uint Gray(byte v) => 0xFF000000u | (uint)v << 16 | (uint)v << 8 | v;

    public static byte Value(uint m) => (byte)(m & 255);

    public static uint[] FromSelection(byte[] sel, int w, int h)
    {
        var m = new uint[w * h];
        if (sel == null) { Array.Fill(m, 0xFFFFFFFF); return m; }
        for (int i = 0; i < m.Length; i++) m[i] = Gray(sel[i]);
        return m;
    }

    /// <summary>Most common edge value — what a mask "defaults" to outside its content.</summary>
    public static byte EdgeValue(uint[] m, int w, int h)
    {
        long sum = 0; int n = 0;
        for (int x = 0; x < w; x += Math.Max(1, w / 64)) { sum += Value(m[x]); sum += Value(m[(h - 1) * w + x]); n += 2; }
        for (int y = 0; y < h; y += Math.Max(1, h / 64)) { sum += Value(m[y * w]); sum += Value(m[y * w + w - 1]); n += 2; }
        return sum / Math.Max(1, n) >= 128 ? (byte)255 : (byte)0;
    }
}

public static class ThumbnailMaker
{
    /// <summary>Box-filtered downscale to an on-screen image, optionally over a checkerboard (null when running headless).</summary>
    public static IImage Make(uint[] px, int w, int h, int max, bool checker)
    {
        if (ImageHost.Create == null) return null;
        var (t, tw, th) = MakePixels(px, w, h, max, checker);
        return t == null ? null : ImageHost.Make(t, tw, th);
    }

    public static (uint[] px, int w, int h) MakePixels(uint[] px, int w, int h, int max, bool checker)
    {
        if (w <= 0 || h <= 0) return (null, 0, 0);
        double s = Math.Min(1.0, (double)max / Math.Max(w, h));
        int tw = Math.Max(1, (int)Math.Round(w * s)), th = Math.Max(1, (int)Math.Round(h * s));
        var outPx = new uint[tw * th];
        for (int ty = 0; ty < th; ty++)
        {
            int sy0 = ty * h / th, sy1 = Math.Max(sy0 + 1, (ty + 1) * h / th);
            for (int tx = 0; tx < tw; tx++)
            {
                int sx0 = tx * w / tw, sx1 = Math.Max(sx0 + 1, (tx + 1) * w / tw);
                // sample a sparse grid inside the box for speed
                int stepX = Math.Max(1, (sx1 - sx0) / 4), stepY = Math.Max(1, (sy1 - sy0) / 4);
                double ra = 0, rr = 0, rg = 0, rb = 0; int n = 0;
                for (int y = sy0; y < sy1; y += stepY)
                {
                    int row = y * w;
                    for (int x = sx0; x < sx1; x += stepX)
                    {
                        uint p = px[row + x];
                        double a = Px.A(p);
                        ra += a; rr += Px.R(p) * a; rg += Px.G(p) * a; rb += Px.B(p) * a; n++;
                    }
                }
                uint res = 0;
                if (ra > 0) res = Px.Pack(Px.Clamp(ra / n), Px.Clamp(rr / ra), Px.Clamp(rg / ra), Px.Clamp(rb / ra));
                if (checker)
                {
                    bool c = ((tx >> 2) + (ty >> 2) & 1) == 0;
                    uint bg = c ? 0xFFFFFFFFu : 0xFFCFD3DAu;
                    res = Px.Over(bg, res);
                }
                outPx[ty * tw + tx] = res;
            }
        }
        return (outPx, tw, th);
    }
}

using System.IO;
using System.IO.Compression;
using System.Text.Json;
using Avalonia;
using Avalonia.Media;
using SkiaSharp;

namespace SkyMasterPhotos.Core;

public static class ImageIO
{
    public const string ProjectExt = ".skyphoto";
    public static readonly string[] OpenExtensions = { ".skyphoto", ".psd", ".psb", ".png", ".jpg", ".jpeg", ".jfif", ".bmp", ".gif", ".tif", ".tiff", ".webp", ".ico" };
    public static readonly string[] ImageExtensions = { ".psd", ".psb", ".png", ".jpg", ".jpeg", ".jfif", ".bmp", ".gif", ".tif", ".tiff", ".webp", ".ico" };

    public static (uint[] px, int w, int h) LoadPixels(string path)
    {
        if (IsPsd(path))
        {
            var res = Psd.PsdReader.Read(path);
            res.Doc.RenderAll();
            return ((uint[])res.Doc.Flat.Clone(), res.Width, res.Height);
        }
        using var fs = File.OpenRead(path);
        return LoadPixels(fs);
    }

    /// <summary>Decodes PNG / JPEG / WebP / GIF / BMP / ICO (SkiaSharp) and TIFF (LibTiff.NET), honouring EXIF orientation.</summary>
    public static (uint[] px, int w, int h) LoadPixels(Stream s)
    {
        var bytes = ReadAll(s);
        if (IsTiff(bytes)) return Tiff.Read(bytes);
        using var data = SKData.CreateCopy(bytes);
        using var codec = SKCodec.Create(data) ?? throw new InvalidDataException("This file isn't an image format Sky Master Photos can read.");
        var info = new SKImageInfo(codec.Info.Width, codec.Info.Height, SKColorType.Bgra8888, SKAlphaType.Unpremul);
        var px = new uint[info.Width * info.Height];
        unsafe
        {
            fixed (uint* p = px)
            {
                var r = codec.GetPixels(info, (IntPtr)p);
                if (r is not (SKCodecResult.Success or SKCodecResult.IncompleteInput))
                    throw new InvalidDataException("Couldn't decode the image (" + r + ").");
            }
        }
        return Orient(px, info.Width, info.Height, codec.EncodedOrigin);
    }

    static byte[] ReadAll(Stream s)
    {
        if (s is MemoryStream ms && ms.Position == 0) return ms.ToArray();
        using var m = new MemoryStream();
        s.CopyTo(m);
        return m.ToArray();
    }

    static bool IsTiff(byte[] b) => b.Length > 4 && ((b[0] == 'I' && b[1] == 'I' && b[2] == 42 && b[3] == 0) || (b[0] == 'M' && b[1] == 'M' && b[2] == 0 && b[3] == 42));

    /// <summary>Applies an EXIF orientation to straight BGRA pixels.</summary>
    static (uint[] px, int w, int h) Orient(uint[] px, int w, int h, SKEncodedOrigin o)
    {
        if (o is SKEncodedOrigin.TopLeft or SKEncodedOrigin.Default) return (px, w, h);
        bool swap = o is SKEncodedOrigin.LeftTop or SKEncodedOrigin.RightTop or SKEncodedOrigin.RightBottom or SKEncodedOrigin.LeftBottom;
        int ow = swap ? h : w, oh = swap ? w : h;
        var dst = new uint[px.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                int dx, dy;
                switch (o)
                {
                    case SKEncodedOrigin.TopRight: dx = w - 1 - x; dy = y; break;          // mirror
                    case SKEncodedOrigin.BottomRight: dx = w - 1 - x; dy = h - 1 - y; break; // 180°
                    case SKEncodedOrigin.BottomLeft: dx = x; dy = h - 1 - y; break;        // flip
                    case SKEncodedOrigin.LeftTop: dx = y; dy = x; break;                   // transpose
                    case SKEncodedOrigin.RightTop: dx = h - 1 - y; dy = x; break;          // 90° cw
                    case SKEncodedOrigin.RightBottom: dx = h - 1 - y; dy = w - 1 - x; break; // transverse
                    default: dx = y; dy = w - 1 - x; break;                                // LeftBottom: 90° ccw
                }
                dst[dy * ow + dx] = px[y * w + x];
            }
        });
        return (dst, ow, oh);
    }

    static SKBitmap ToSkia(uint[] px, int w, int h)
    {
        var bmp = new SKBitmap(new SKImageInfo(w, h, SKColorType.Bgra8888, SKAlphaType.Unpremul));
        unsafe { fixed (uint* p = px) Buffer.MemoryCopy(p, (void*)bmp.GetPixels(), (long)w * h * 4, (long)w * h * 4); }
        return bmp;
    }

    static byte[] Encode(uint[] px, int w, int h, SKEncodedImageFormat fmt, int quality)
    {
        using var bmp = ToSkia(px, w, h);
        using var img = SKImage.FromBitmap(bmp);
        using var data = img.Encode(fmt, quality) ?? throw new IOException("Couldn't encode the image.");
        return data.ToArray();
    }

    public static void SaveImage(string path, uint[] px, int w, int h, int jpegQuality = 92)
    {
        string ext = Path.GetExtension(path).ToLowerInvariant();
        byte[] bytes = ext switch
        {
            ".jpg" or ".jpeg" or ".jfif" => Encode(Flatten(px, 0xFFFFFFFF), w, h, SKEncodedImageFormat.Jpeg, Math.Clamp(jpegQuality, 1, 100)),
            ".webp" => Encode(px, w, h, SKEncodedImageFormat.Webp, Math.Clamp(jpegQuality, 1, 100)),
            ".bmp" => Bmp.Write(px, w, h),
            ".tif" or ".tiff" => Tiff.Write(px, w, h),
            ".gif" => Gif.Write(px, w, h),
            _ => Encode(px, w, h, SKEncodedImageFormat.Png, 100),
        };
        string tmp = path + ".tmp";
        File.WriteAllBytes(tmp, bytes);
        File.Move(tmp, path, true);
    }

    static uint[] Flatten(uint[] px, uint bg)
    {
        var o = new uint[px.Length];
        Parallel.For(0, px.Length, i => o[i] = Px.Over(bg, px[i]));
        return o;
    }

    public static byte[] EncodePng(uint[] px, int w, int h) => Encode(px, w, h, SKEncodedImageFormat.Png, 100);

    /// <summary>PNG with a light zlib level: ~3× faster to write, a few percent bigger (project layers, clipboard).</summary>
    public static unsafe byte[] EncodePngFast(uint[] px, int w, int h)
    {
        fixed (uint* p = px)
        {
            using var pm = new SKPixmap(new SKImageInfo(w, h, SKColorType.Bgra8888, SKAlphaType.Unpremul), (IntPtr)p, w * 4);
            using var data = pm.Encode(new SKPngEncoderOptions(SKPngEncoderFilterFlags.Sub | SKPngEncoderFilterFlags.Up, 2))
                ?? throw new IOException("Couldn't encode the image.");
            return data.ToArray();
        }
    }

    /// <summary>Uncompressed 32-bit BMP (with alpha) — SkiaSharp has no BMP encoder.</summary>
    static class Bmp
    {
        public static byte[] Write(uint[] px, int w, int h)
        {
            int size = 14 + 40 + w * h * 4;
            var b = new byte[size];
            var s = new BinaryWriter(new MemoryStream(b));
            s.Write((byte)'B'); s.Write((byte)'M'); s.Write(size); s.Write(0); s.Write(54);
            s.Write(40); s.Write(w); s.Write(-h); s.Write((short)1); s.Write((short)32); s.Write(0); s.Write(w * h * 4); s.Write(2835); s.Write(2835); s.Write(0); s.Write(0);
            Buffer.BlockCopy(px, 0, b, 54, w * h * 4);   // BGRA little-endian = 0xAARRGGBB
            return b;
        }
    }

    /// <summary>TIFF through LibTiff.NET (8-bit RGBA, deflate).</summary>
    static class Tiff
    {
        public static (uint[] px, int w, int h) Read(byte[] bytes)
        {
            using var ms = new MemoryStream(bytes);
            using var t = BitMiracle.LibTiff.Classic.Tiff.ClientOpen("image", "r", ms, new BitMiracle.LibTiff.Classic.TiffStream())
                          ?? throw new InvalidDataException("Couldn't read the TIFF file.");
            int w = t.GetField(BitMiracle.LibTiff.Classic.TiffTag.IMAGEWIDTH)[0].ToInt();
            int h = t.GetField(BitMiracle.LibTiff.Classic.TiffTag.IMAGELENGTH)[0].ToInt();
            var raster = new int[w * h];
            if (!t.ReadRGBAImageOriented(w, h, raster, BitMiracle.LibTiff.Classic.Orientation.TOPLEFT))
                throw new InvalidDataException("Couldn't decode the TIFF image.");
            var px = new uint[w * h];
            Parallel.For(0, px.Length, i =>
            {
                int v = raster[i];
                px[i] = Px.Pack(BitMiracle.LibTiff.Classic.Tiff.GetA(v), BitMiracle.LibTiff.Classic.Tiff.GetR(v), BitMiracle.LibTiff.Classic.Tiff.GetG(v), BitMiracle.LibTiff.Classic.Tiff.GetB(v));
            });
            return (px, w, h);
        }

        public static byte[] Write(uint[] px, int w, int h)
        {
            using var ms = new MemoryStream();
            using (var t = BitMiracle.LibTiff.Classic.Tiff.ClientOpen("image", "w", ms, new BitMiracle.LibTiff.Classic.TiffStream()))
            {
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.IMAGEWIDTH, w);
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.IMAGELENGTH, h);
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.SAMPLESPERPIXEL, 4);
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.BITSPERSAMPLE, 8);
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.ORIENTATION, BitMiracle.LibTiff.Classic.Orientation.TOPLEFT);
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.PLANARCONFIG, BitMiracle.LibTiff.Classic.PlanarConfig.CONTIG);
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.PHOTOMETRIC, BitMiracle.LibTiff.Classic.Photometric.RGB);
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.EXTRASAMPLES, 1, new short[] { (short)BitMiracle.LibTiff.Classic.ExtraSample.UNASSALPHA });
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.COMPRESSION, BitMiracle.LibTiff.Classic.Compression.ADOBE_DEFLATE);
                t.SetField(BitMiracle.LibTiff.Classic.TiffTag.ROWSPERSTRIP, 64);
                var row = new byte[w * 4];
                for (int y = 0; y < h; y++)
                {
                    for (int x = 0; x < w; x++)
                    {
                        uint p = px[y * w + x];
                        row[x * 4] = (byte)(p >> 16); row[x * 4 + 1] = (byte)(p >> 8); row[x * 4 + 2] = (byte)p; row[x * 4 + 3] = (byte)(p >> 24);
                    }
                    t.WriteScanline(row, y);
                }
                t.WriteDirectory();
            }
            return ms.ToArray();
        }
    }

    /// <summary>Single-frame GIF (6×7×6 color cube + 1 transparent index, LZW) — SkiaSharp has no GIF encoder.</summary>
    static class Gif
    {
        public static byte[] Write(uint[] px, int w, int h)
        {
            // palette: 252 colors in a 6×7×6 cube, index 255 = transparent
            var pal = new byte[256 * 3];
            for (int r = 0; r < 6; r++) for (int g = 0; g < 7; g++) for (int b = 0; b < 6; b++)
                    {
                        int i = (r * 7 + g) * 6 + b;
                        pal[i * 3] = (byte)(r * 51); pal[i * 3 + 1] = (byte)(g * 255 / 6); pal[i * 3 + 2] = (byte)(b * 51);
                    }
            var idx = new byte[w * h];
            bool anyTransparent = false;
            for (int i = 0; i < idx.Length; i++)
            {
                uint p = px[i];
                if ((p >> 24) < 128) { idx[i] = 255; anyTransparent = true; continue; }
                int r = ((int)((p >> 16) & 255) * 5 + 127) / 255, g = ((int)((p >> 8) & 255) * 6 + 127) / 255, b = ((int)(p & 255) * 5 + 127) / 255;
                idx[i] = (byte)((r * 7 + g) * 6 + b);
            }
            using var ms = new MemoryStream();
            var o = new BinaryWriter(ms);
            o.Write("GIF89a"u8);
            o.Write((ushort)w); o.Write((ushort)h);
            o.Write((byte)0xF7); o.Write((byte)0); o.Write((byte)0);   // global table, 256 entries
            o.Write(pal);
            if (anyTransparent) { o.Write(new byte[] { 0x21, 0xF9, 4, 1, 0, 0, 255, 0 }); }
            o.Write((byte)0x2C); o.Write((ushort)0); o.Write((ushort)0); o.Write((ushort)w); o.Write((ushort)h); o.Write((byte)0);
            o.Write((byte)8);                                            // LZW minimum code size
            var lzw = Lzw(idx);
            for (int i = 0; i < lzw.Length; i += 255)
            {
                int n = Math.Min(255, lzw.Length - i);
                o.Write((byte)n); o.Write(lzw, i, n);
            }
            o.Write((byte)0); o.Write((byte)0x3B);
            return ms.ToArray();
        }

        static byte[] Lzw(byte[] data)
        {
            // classic GIF LZW (same code-size timing as the reference encoder): bump the width after emitting
            // a code once the next free code no longer fits; reset after a clear code
            const int clear = 256, end = 257;
            var dict = new Dictionary<int, int>();
            var outBytes = new List<byte>();
            int bitBuf = 0, bitCount = 0, codeSize = 9, maxCode = 511, next = 258;
            bool clearFlag = false;
            void Output(int code)
            {
                bitBuf |= code << bitCount; bitCount += codeSize;
                while (bitCount >= 8) { outBytes.Add((byte)bitBuf); bitBuf >>= 8; bitCount -= 8; }
                if (clearFlag) { codeSize = 9; maxCode = 511; clearFlag = false; }
                else if (next > maxCode) { codeSize++; maxCode = codeSize >= 12 ? 4096 : (1 << codeSize) - 1; if (codeSize > 12) codeSize = 12; }
            }
            Output(clear);
            int prefix = data.Length > 0 ? data[0] : 0;
            for (int i = 1; i < data.Length; i++)
            {
                int c = data[i], key = prefix << 8 | c;
                if (dict.TryGetValue(key, out int code)) { prefix = code; continue; }
                Output(prefix);
                if (next < 4096) dict[key] = next++;
                else { dict.Clear(); next = 258; clearFlag = true; Output(clear); }
                prefix = c;
            }
            Output(prefix);
            Output(end);
            if (bitCount > 0) outBytes.Add((byte)bitBuf);
            return outBytes.ToArray();
        }
    }

    // ───────────────────────────── project files ─────────────────────────────

    public static bool IsPsd(string path)
    {
        var e = Path.GetExtension(path).ToLowerInvariant();
        return e == ".psd" || e == ".psb";
    }

    sealed class ProjectManifest
    {
        public string App { get; set; } = "Sky Master Photos";
        public int Version { get; set; } = 2;
        public int Width { get; set; }
        public int Height { get; set; }
        public int Active { get; set; }
        public List<ProjectLayer> Layers { get; set; } = new();
        public List<ProjectGroup> Groups { get; set; }
        public List<ProjectBlock> PsdGlobal { get; set; }
        public List<ProjectResource> PsdResources { get; set; }
    }

    sealed class ProjectLayer
    {
        public string Name { get; set; }
        public bool Visible { get; set; }
        public bool Locked { get; set; }
        public double Opacity { get; set; }
        public double Fill { get; set; } = 1;
        public string Blend { get; set; }
        public string File { get; set; }
        public string MaskFile { get; set; }
        public bool MaskEnabled { get; set; } = true;
        public bool Clipped { get; set; }
        public string Group { get; set; }
        public ProjectAdjust Adjustment { get; set; }
        public ProjectText Text { get; set; }
        public LayerStyle Style { get; set; }
        public ProjectPsd Psd { get; set; }
    }

    sealed class ProjectAdjust
    {
        public string Kind { get; set; }
        public Dictionary<string, double> P { get; set; }
        public List<double[]> Curve { get; set; }
        public string C1 { get; set; }
        public string C2 { get; set; }
        public bool FromPsd { get; set; }
    }

    sealed class ProjectText
    {
        public string Text { get; set; }
        public string Font { get; set; }
        public double Size { get; set; }
        public bool Bold { get; set; }
        public bool Italic { get; set; }
        public string Color { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public bool FromPsd { get; set; }
    }

    sealed class ProjectPsd
    {
        public List<ProjectBlock> Blocks { get; set; }
        public ulong SourceHash { get; set; }
        public string KindLabel { get; set; }
        public bool Unrendered { get; set; }
        public string BlendKey { get; set; }
        public string BlendAtImport { get; set; }
    }

    sealed class ProjectBlock
    {
        public string Key { get; set; }
        public string Data { get; set; }
    }

    sealed class ProjectResource
    {
        public int Id { get; set; }
        public string Data { get; set; }
    }

    sealed class ProjectGroup
    {
        public string Path { get; set; }
        public string Name { get; set; }
        public bool Visible { get; set; }
        public double Opacity { get; set; }
        public string Blend { get; set; }
        public bool Open { get; set; }
        public List<ProjectBlock> Blocks { get; set; }
    }

    static string Hex(Color c) => $"#{c.A:X2}{c.R:X2}{c.G:X2}{c.B:X2}";
    static Color FromHex(string s) => Color.TryParse(s, out var c) ? c : Colors.Black;

    static List<ProjectBlock> Blocks(IEnumerable<PsdBlock> b) => b?.Select(x => new ProjectBlock { Key = x.Key, Data = Convert.ToBase64String(x.Data) }).ToList();
    static List<PsdBlock> Blocks(List<ProjectBlock> b) => b?.Select(x => new PsdBlock(x.Key, Convert.FromBase64String(x.Data))).ToList() ?? new();

    public static void SaveProject(Document doc, string path)
    {
        var man = new ProjectManifest { Width = doc.Width, Height = doc.Height, Active = doc.ActiveIndex };
        string tmp = path + ".tmp";
        using (var fs = File.Create(tmp))
        using (var zip = new ZipArchive(fs, ZipArchiveMode.Create))
        {
            // encode every layer and mask in parallel; PNG is already compressed, so the zip only stores it
            var images = new List<(string file, uint[] px)>();
            for (int i = 0; i < doc.Layers.Count; i++)
            {
                images.Add(($"layers/{i:D3}.png", doc.Layers[i].Pixels));
                if (doc.Layers[i].Mask != null) images.Add(($"layers/{i:D3}_mask.png", doc.Layers[i].Mask));
            }
            var encoded = new byte[images.Count][];
            Parallel.For(0, images.Count, k => encoded[k] = EncodePngFast(images[k].px, doc.Width, doc.Height));
            var byFile = new Dictionary<string, byte[]>();
            for (int k = 0; k < images.Count; k++) byFile[images[k].file] = encoded[k];
            void Png(string file, uint[] px)
            {
                var e = zip.CreateEntry(file, CompressionLevel.NoCompression);
                using var es = e.Open();
                var bytes = byFile[file];
                es.Write(bytes, 0, bytes.Length);
            }
            for (int i = 0; i < doc.Layers.Count; i++)
            {
                var l = doc.Layers[i];
                var pl = new ProjectLayer
                {
                    Name = l.Name, Visible = l.Visible, Locked = l.Locked, Opacity = l.Opacity, Fill = l.Fill, Blend = l.Blend.ToString(),
                    File = $"layers/{i:D3}.png", MaskEnabled = l.MaskEnabled, Clipped = l.Clipped, Group = l.Group, Style = l.Style,
                };
                Png(pl.File, l.Pixels);
                if (l.Mask != null) { pl.MaskFile = $"layers/{i:D3}_mask.png"; Png(pl.MaskFile, l.Mask); }
                if (l.Adjustment is AdjustmentSpec a)
                    pl.Adjustment = new ProjectAdjust
                    {
                        Kind = a.Kind, P = a.P.ToDictionary(k => k.Key, k => k.Value), Curve = a.Curve?.Select(p => new[] { p.X, p.Y }).ToList(),
                        C1 = Hex(a.C1), C2 = Hex(a.C2), FromPsd = l.Psd != null && ReferenceEquals(l.Psd.ImportedAdjustment, a)
                    };
                if (l.Text is TextSpec t)
                    pl.Text = new ProjectText
                    {
                        Text = t.Text, Font = t.Font, Size = t.Size, Bold = t.Bold, Italic = t.Italic, Color = Hex(t.Color), X = t.X, Y = t.Y,
                        FromPsd = l.Psd != null && ReferenceEquals(l.Psd.ImportedText, t)
                    };
                if (l.Psd is PsdLayerData p)
                    pl.Psd = new ProjectPsd
                    {
                        Blocks = Blocks(p.Blocks), SourceHash = p.SourceHash, KindLabel = p.KindLabel, Unrendered = p.UnrenderedAdjustment,
                        BlendKey = p.BlendKey, BlendAtImport = p.BlendAtImport.ToString()
                    };
                man.Layers.Add(pl);
            }
            if (doc.Groups.Count > 0)
                man.Groups = doc.Groups.Select(g => new ProjectGroup { Path = g.Key, Name = g.Value.Name, Visible = g.Value.Visible, Opacity = g.Value.Opacity, Blend = g.Value.BlendKey, Open = g.Value.Open, Blocks = Blocks(g.Value.Blocks) }).ToList();
            if (doc.PsdData != null)
            {
                man.PsdGlobal = Blocks(doc.PsdData.GlobalBlocks);
                man.PsdResources = doc.PsdData.Resources.Select(r => new ProjectResource { Id = r.id, Data = Convert.ToBase64String(r.data) }).ToList();
            }
            // composite thumbnail for the home screen
            var thumb = MakeThumbPixels(doc.Flat, doc.Width, doc.Height, 512, out int tw, out int th);
            var te = zip.CreateEntry("thumbnail.png", CompressionLevel.Fastest);
            using (var ts = te.Open()) { var b = EncodePng(thumb, tw, th); ts.Write(b, 0, b.Length); }
            var me = zip.CreateEntry("manifest.json");
            using (var ms = me.Open())
                JsonSerializer.Serialize(ms, man, new JsonSerializerOptions { WriteIndented = true });
        }
        File.Move(tmp, path, true);
    }

    public static Document LoadProject(string path)
    {
        using var fs = File.OpenRead(path);
        using var zip = new ZipArchive(fs, ZipArchiveMode.Read);
        ProjectManifest man;
        using (var ms = zip.GetEntry("manifest.json").Open()) man = JsonSerializer.Deserialize<ProjectManifest>(ms);
        var doc = new Document(man.Width, man.Height, Path.GetFileNameWithoutExtension(path), "Open");
        uint[] ReadPng(string file)
        {
            using var es = zip.GetEntry(file).Open();
            using var mem = new MemoryStream();
            es.CopyTo(mem);
            mem.Position = 0;
            var (p, w, h) = LoadPixels(mem);
            return (w == man.Width && h == man.Height) ? p : Transforms.Canvas(p, w, h, man.Width, man.Height, 0, 0, 0);
        }
        foreach (var pl in man.Layers)
        {
            var l = new Layer(pl.Name, man.Width, man.Height, ReadPng(pl.File))
            {
                Visible = pl.Visible,
                Locked = pl.Locked,
                Opacity = pl.Opacity,
                Fill = pl.Fill <= 0 && man.Version < 2 ? 1 : pl.Fill,
                Blend = Enum.TryParse<BlendMode>(pl.Blend, out var bm) ? bm : BlendMode.Normal,
                Clipped = pl.Clipped,
                Group = pl.Group ?? "",
                Style = pl.Style,
            };
            if (pl.MaskFile != null) l.SetMask(Masks.Normalize(ReadPng(pl.MaskFile)));
            l.MaskEnabled = pl.MaskEnabled;
            if (pl.Psd != null)
                l.Psd = new PsdLayerData
                {
                    Blocks = Blocks(pl.Psd.Blocks), SourceHash = pl.Psd.SourceHash, KindLabel = pl.Psd.KindLabel, UnrenderedAdjustment = pl.Psd.Unrendered,
                    BlendKey = pl.Psd.BlendKey, BlendAtImport = Enum.TryParse<BlendMode>(pl.Psd.BlendAtImport, out var bi) ? bi : BlendMode.Normal
                };
            if (pl.Adjustment != null)
            {
                var a = new AdjustmentSpec
                {
                    Kind = pl.Adjustment.Kind, P = pl.Adjustment.P ?? new(),
                    Curve = pl.Adjustment.Curve?.Select(c => new Point(c[0], c[1])).ToList(),
                    C1 = FromHex(pl.Adjustment.C1), C2 = FromHex(pl.Adjustment.C2)
                };
                l.Adjustment = a;
                if (pl.Adjustment.FromPsd && l.Psd != null) l.Psd.ImportedAdjustment = a;
            }
            if (pl.Text != null)
            {
                var t = new TextSpec { Text = pl.Text.Text, Font = pl.Text.Font, Size = pl.Text.Size, Bold = pl.Text.Bold, Italic = pl.Text.Italic, Color = FromHex(pl.Text.Color), X = pl.Text.X, Y = pl.Text.Y };
                l.Text = t;
                if (pl.Text.FromPsd && l.Psd != null) l.Psd.ImportedText = t;
            }
            doc.Layers.Add(l);
        }
        if (man.Groups != null)
            foreach (var g in man.Groups) doc.Groups[g.Path] = new GroupInfo(g.Name, g.Visible, g.Opacity, g.Blend, g.Open) { Blocks = Blocks(g.Blocks) };
        if (man.PsdGlobal != null || man.PsdResources != null)
            doc.PsdData = new PsdDocData
            {
                GlobalBlocks = Blocks(man.PsdGlobal),
                Resources = man.PsdResources?.Select(r => ((ushort)r.Id, Convert.FromBase64String(r.Data))).ToList() ?? new(),
            };
        if (doc.Layers.Count == 0) doc.Layers.Add(new Layer("Layer 1", man.Width, man.Height));
        doc.ActiveLayer = doc.Layers[Math.Clamp(man.Active, 0, doc.Layers.Count - 1)];
        doc.FilePath = path;
        return doc;
    }

    public static IImage LoadThumbnail(string path, int max)
    {
        var (px, w, h) = LoadThumbnailPixels(path, max);
        return px == null ? null : ImageHost.Make(px, w, h);
    }

    /// <summary>Small preview pixels for the home screen (embedded project thumbnail, PSD composite or a scaled decode).</summary>
    public static (uint[] px, int w, int h) LoadThumbnailPixels(string path, int max)
    {
        try
        {
            if (IsPsd(path))
            {
                var (px, w, h) = Psd.PsdReader.ReadComposite(path);
                if (px == null) return (null, 0, 0);
                var t = MakeThumbPixels(px, w, h, max, out int tw, out int th);
                return (t, tw, th);
            }
            if (Path.GetExtension(path).Equals(ProjectExt, StringComparison.OrdinalIgnoreCase))
            {
                using var fs = File.OpenRead(path);
                using var zip = new ZipArchive(fs, ZipArchiveMode.Read);
                var e = zip.GetEntry("thumbnail.png");
                if (e == null) return (null, 0, 0);
                using var es = e.Open();
                var (p, pw, ph) = LoadPixels(es);
                var t = MakeThumbPixels(p, pw, ph, max, out int tw, out int th);
                return (t, tw, th);
            }
            return DecodeScaled(File.ReadAllBytes(path), max);
        }
        catch { return (null, 0, 0); }
    }

    /// <summary>Fast downscaled decode (JPEG / WebP decode at 1/2–1/8 size directly), then an exact resize.</summary>
    static (uint[] px, int w, int h) DecodeScaled(byte[] bytes, int max)
    {
        if (IsTiff(bytes))
        {
            var (tp, tw0, th0) = Tiff.Read(bytes);
            var t = MakeThumbPixels(tp, tw0, th0, max, out int tw, out int th);
            return (t, tw, th);
        }
        using var data = SKData.CreateCopy(bytes);
        using var codec = SKCodec.Create(data);
        if (codec == null) return (null, 0, 0);
        float scale = Math.Min(1f, (float)max / Math.Max(codec.Info.Width, codec.Info.Height));
        var dims = codec.GetScaledDimensions(scale);
        var info = new SKImageInfo(dims.Width, dims.Height, SKColorType.Bgra8888, SKAlphaType.Unpremul);
        var px = new uint[info.Width * info.Height];
        SKCodecResult r;
        unsafe { fixed (uint* p = px) r = codec.GetPixels(info, (IntPtr)p); }
        if (r is not (SKCodecResult.Success or SKCodecResult.IncompleteInput))
        {
            var (fp, fw, fh) = LoadPixels(new MemoryStream(bytes));
            var t2 = MakeThumbPixels(fp, fw, fh, max, out int w2, out int h2);
            return (t2, w2, h2);
        }
        var (op, ow, oh) = Orient(px, info.Width, info.Height, codec.EncodedOrigin);
        var res = MakeThumbPixels(op, ow, oh, max, out int rw, out int rh);
        return (res, rw, rh);
    }

    public static uint[] MakeThumbPixels(uint[] px, int w, int h, int max, out int tw, out int th)
    {
        double s = Math.Min(1.0, (double)max / Math.Max(w, h));
        tw = Math.Max(1, (int)(w * s)); th = Math.Max(1, (int)(h * s));
        return Transforms.Resize(px, w, h, tw, th);
    }
}

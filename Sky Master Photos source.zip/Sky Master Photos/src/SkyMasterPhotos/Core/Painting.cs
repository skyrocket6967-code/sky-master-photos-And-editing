using Avalonia;

namespace SkyMasterPhotos.Core;

public enum StrokeKind { Paint, Pencil, Erase, Clone, Heal, SpotHeal, Blur, Sharpen, Smudge, Dodge, Burn, Sponge }

public sealed class BrushSettings
{
    public double Size = 40;
    public double Hardness = 0.75;
    public double Opacity = 1.0;
    public double Flow = 1.0;
    public double Spacing = 0.12;
    public double Strength = 0.5;   // for effect tools
    public bool SpongeSaturate = false;
    /// <summary>Pen pressure controls the brush size (tablets; a mouse always paints at full pressure).</summary>
    public bool PressureSize = true;
    /// <summary>Pen pressure controls the flow.</summary>
    public bool PressureOpacity = false;
    /// <summary>Stroke smoothing (lazy mouse), 0 = off … 1 = very smooth.</summary>
    public double Smoothing = 0;
}

/// <summary>
/// A single brush stroke. Coverage-based tools (paint, erase, clone) accumulate a stroke mask so a stroke
/// never builds past its opacity; effect tools (blur, dodge, smudge...) modify pixels dab by dab.
/// The original pixels and the coverage mask are kept per 64 px block, only where the brush has been,
/// so starting a stroke costs nothing even on a 50-megapixel layer.
/// </summary>
public sealed class StrokeSession
{
    const int TB = 64;   // block size of the lazy backup / coverage store

    readonly Document _doc;
    public readonly Layer Layer;
    readonly uint[][] _backupTiles;
    readonly ushort[][] _covTiles;
    readonly int _tilesX;
    readonly uint[] _px;
    readonly bool _isMask;
    readonly int _w, _h;
    readonly StrokeKind _kind;
    readonly BrushSettings _b;
    readonly uint _color;
    readonly byte[] _sel;
    readonly Vector _cloneOffset;
    uint[] _smudge;
    int _smudgeR;
    Point _last;
    float _lastPressure = 1;
    double _carry;
    bool _started;
    public Int32Rect Total { get; private set; } = Int32Rect.Empty;

    public StrokeSession(Document doc, Layer layer, StrokeKind kind, BrushSettings b, uint color, Vector cloneOffset)
    {
        _doc = doc;
        Layer = layer;
        _isMask = layer.EditMask;
        _px = layer.Target;
        // masks are grayscale: paint luminance, and the eraser paints black (hide)
        if (_isMask)
        {
            if (kind == StrokeKind.Erase) { kind = StrokeKind.Paint; color = 0xFF000000; }
            int g = Px.Clamp(Px.Luma(color));
            color = Masks.Gray((byte)g);
        }
        _kind = kind;
        _b = b;
        _color = color;
        _w = layer.Width;
        _h = layer.Height;
        _sel = doc.Selection;
        _cloneOffset = cloneOffset;
        _tilesX = (_w + TB - 1) / TB;
        int tiles = _tilesX * ((_h + TB - 1) / TB);
        _backupTiles = new uint[tiles][];
        if (IsCoverage) _covTiles = new ushort[tiles][];
    }

    bool IsCoverage => _kind is StrokeKind.Paint or StrokeKind.Pencil or StrokeKind.Erase or StrokeKind.Clone or StrokeKind.SpotHeal;

    double BaseRadius => Math.Max(0.5, _b.Size / 2);

    // ── lazy per-block storage ──

    /// <summary>Saves the original pixels of every block in rect before they are modified.</summary>
    void EnsureBackup(Int32Rect r)
    {
        int tx0 = r.X / TB, tx1 = (r.X + r.Width - 1) / TB, ty0 = r.Y / TB, ty1 = (r.Y + r.Height - 1) / TB;
        for (int ty = ty0; ty <= ty1; ty++)
            for (int tx = tx0; tx <= tx1; tx++)
            {
                int t = ty * _tilesX + tx;
                if (_backupTiles[t] != null) continue;
                var tile = new uint[TB * TB];
                int x0 = tx * TB, y0 = ty * TB, bw = Math.Min(TB, _w - x0), bh = Math.Min(TB, _h - y0);
                for (int y = 0; y < bh; y++) Array.Copy(_px, (y0 + y) * _w + x0, tile, y * TB, bw);
                _backupTiles[t] = tile;
                if (_covTiles != null) _covTiles[t] = new ushort[TB * TB];
            }
    }

    /// <summary>Original (pre-stroke) pixel.</summary>
    uint Orig(int x, int y)
    {
        var tile = _backupTiles[(y / TB) * _tilesX + x / TB];
        return tile == null ? _px[y * _w + x] : tile[(y % TB) * TB + x % TB];
    }

    ushort Cov(int x, int y)
    {
        var tile = _covTiles[(y / TB) * _tilesX + x / TB];
        return tile == null ? (ushort)0 : tile[(y % TB) * TB + x % TB];
    }

    /// <summary>Adds the stroke segment to p (pen pressure 0–1), returns the dirty rect in doc space.</summary>
    public Int32Rect MoveTo(Point p, float pressure = 1f)
    {
        pressure = Math.Clamp(pressure, 0.02f, 1f);
        if (!_started)
        {
            _started = true;
            _last = p;
            _lastPressure = pressure;
            if (_kind == StrokeKind.Smudge) InitSmudge(p);
            return Dab(p, pressure);
        }
        double size = _b.Size * (_b.PressureSize ? Math.Max(_lastPressure, pressure) : 1);
        double step = Math.Max(1, size * _b.Spacing);
        if (_kind == StrokeKind.Smudge) step = Math.Max(1, size * 0.08);
        Vector d = p - _last;   // (Avalonia: Point − Point is a Point)
        double len = d.Length;
        Int32Rect dirty = Int32Rect.Empty;
        if (len < 1e-6) return dirty;
        var dir = d / len;
        double t = step - _carry;
        while (t <= len)
        {
            var q = _last + dir * t;
            float pr = _lastPressure + (pressure - _lastPressure) * (float)(t / len);
            dirty = RectUtil.Union(dirty, Dab(q, pr));
            t += step;
        }
        _carry = len - (t - step);
        _last = p;
        _lastPressure = pressure;
        return dirty;
    }

    float DabAlpha(double dist, double r)
    {
        if (_kind == StrokeKind.Pencil) return dist <= r ? 1f : 0f;
        double d = dist / r;
        if (d >= 1) return 0;
        double h = Math.Clamp(_b.Hardness, 0, 0.99);
        if (d <= h) return 1;
        double t = (d - h) / (1 - h);
        return (float)(1 - t * t * (3 - 2 * t));
    }

    Int32Rect Dab(Point c, float pressure)
    {
        double radius = Math.Max(0.5, BaseRadius * (_b.PressureSize ? pressure : 1));
        double r = radius + 1;
        var rect = RectUtil.Clip(RectUtil.FromPoints(c.X - r, c.Y - r, c.X + r, c.Y + r), _w, _h);
        if (RectUtil.IsEmptyRect(rect)) return Int32Rect.Empty;
        Total = RectUtil.Union(Total, rect);
        EnsureBackup(rect);

        if (IsCoverage)
        {
            float flow = (float)(_kind == StrokeKind.Pencil ? 1 : _b.Flow) * (_b.PressureOpacity ? pressure : 1f);
            // big brushes: rows in parallel (blocks are already allocated, rows don't share pixels)
            void Row(int y)
            {
                double dy = y + 0.5 - c.Y;
                for (int x = rect.X; x < rect.X + rect.Width; x++)
                {
                    double dx = x + 0.5 - c.X;
                    float a = DabAlpha(Math.Sqrt(dx * dx + dy * dy), radius) * flow;
                    if (a <= 0) continue;
                    var tile = _covTiles[(y / TB) * _tilesX + x / TB];
                    int ti = (y % TB) * TB + x % TB;
                    int cov = tile[ti];
                    tile[ti] = (ushort)Math.Min(65535, cov + (65535 - cov) * a);
                }
            }
            if (rect.Width * rect.Height > 40_000) Parallel.For(rect.Y, rect.Y + rect.Height, Row);
            else for (int y = rect.Y; y < rect.Y + rect.Height; y++) Row(y);
            ApplyCoverage(rect);
            return rect;
        }

        ApplyEffect(c, rect, radius);
        return rect;
    }

    void ApplyCoverage(Int32Rect rect)
    {
        var px = _px;
        float op = (float)_b.Opacity;
        void Row(int y)
        {
            for (int x = rect.X; x < rect.X + rect.Width; x++)
            {
                int i = y * _w + x;
                int ti = (y % TB) * TB + x % TB, t = (y / TB) * _tilesX + x / TB;
                float m = _covTiles[t][ti] / 65535f * op;
                if (_sel != null) m *= _sel[i] / 255f;
                uint orig = _backupTiles[t][ti];
                if (m <= 0) { px[i] = orig; continue; }
                switch (_kind)
                {
                    case StrokeKind.Erase:
                        px[i] = Px.WithAlpha(orig, (int)(Px.A(orig) * (1 - m) + 0.5f));
                        break;
                    case StrokeKind.SpotHeal:
                        px[i] = Px.Over(orig, 0xFF1A1C22u, Math.Min(1f, m) * 0.6f);
                        break;
                    case StrokeKind.Clone:
                        int sx = (int)Math.Round(x + _cloneOffset.X), sy = (int)Math.Round(y + _cloneOffset.Y);
                        if (sx < 0 || sy < 0 || sx >= _w || sy >= _h) { px[i] = orig; break; }
                        px[i] = Px.Lerp(orig, Orig(sx, sy), m);
                        break;
                    default:
                        px[i] = Px.Over(orig, _color, m);
                        break;
                }
            }
        }
        if (rect.Width * rect.Height > 40_000) Parallel.For(rect.Y, rect.Y + rect.Height, Row);
        else for (int y = rect.Y; y < rect.Y + rect.Height; y++) Row(y);
    }

    void InitSmudge(Point c)
    {
        _smudgeR = (int)Math.Ceiling(BaseRadius);
        int d = _smudgeR * 2 + 1;
        _smudge = new uint[d * d];
        for (int y = 0; y < d; y++)
            for (int x = 0; x < d; x++)
            {
                int sx = Math.Clamp((int)c.X - _smudgeR + x, 0, _w - 1), sy = Math.Clamp((int)c.Y - _smudgeR + y, 0, _h - 1);
                _smudge[y * d + x] = _px[sy * _w + sx];
            }
    }

    void ApplyEffect(Point c, Int32Rect rect, double radius)
    {
        var px = _px;
        float k = (float)_b.Strength;
        uint[] src = null;
        if (_kind is StrokeKind.Blur or StrokeKind.Sharpen)
        {
            // snapshot the neighbourhood so the kernel reads unmodified pixels
            src = new uint[rect.Width * rect.Height];
            for (int y = 0; y < rect.Height; y++) Array.Copy(px, (rect.Y + y) * _w + rect.X, src, y * rect.Width, rect.Width);
        }

        // healing: match the mean color of the destination ring to the source
        double hr = 0, hg = 0, hb = 0;
        if (_kind == StrokeKind.Heal)
        {
            double sr = 0, sg = 0, sb = 0, dr = 0, dg = 0, db = 0; int n = 0;
            for (int y = rect.Y; y < rect.Y + rect.Height; y++)
                for (int x = rect.X; x < rect.X + rect.Width; x++)
                {
                    int sx = (int)Math.Round(x + _cloneOffset.X), sy = (int)Math.Round(y + _cloneOffset.Y);
                    if (sx < 0 || sy < 0 || sx >= _w || sy >= _h) continue;
                    uint s = Orig(sx, sy), d = px[y * _w + x];
                    sr += Px.R(s); sg += Px.G(s); sb += Px.B(s); dr += Px.R(d); dg += Px.G(d); db += Px.B(d); n++;
                }
            if (n > 0) { hr = (dr - sr) / n; hg = (dg - sg) / n; hb = (db - sb) / n; }
        }

        int sd = _smudgeR * 2 + 1;
        for (int y = rect.Y; y < rect.Y + rect.Height; y++)
        {
            for (int x = rect.X; x < rect.X + rect.Width; x++)
            {
                double dx = x + 0.5 - c.X, dy = y + 0.5 - c.Y;
                float a = DabAlpha(Math.Sqrt(dx * dx + dy * dy), radius);
                if (a <= 0) continue;
                int i = y * _w + x;
                if (_sel != null) a *= _sel[i] / 255f;
                if (a <= 0) continue;
                uint p = px[i];
                switch (_kind)
                {
                    case StrokeKind.Blur:
                    case StrokeKind.Sharpen:
                    {
                        int lx = x - rect.X, ly = y - rect.Y;
                        double sa = 0, sr = 0, sg = 0, sb = 0; int n = 0;
                        for (int ky = -1; ky <= 1; ky++)
                            for (int kx = -1; kx <= 1; kx++)
                            {
                                int xx = Math.Clamp(lx + kx, 0, rect.Width - 1), yy = Math.Clamp(ly + ky, 0, rect.Height - 1);
                                uint q = src[yy * rect.Width + xx];
                                double qa = Px.A(q);
                                sa += qa; sr += Px.R(q) * qa; sg += Px.G(q) * qa; sb += Px.B(q) * qa; n++;
                            }
                        if (sa <= 0) break;
                        uint avg = Px.Pack(Px.Clamp(sa / n), Px.Clamp(sr / sa), Px.Clamp(sg / sa), Px.Clamp(sb / sa));
                        if (_kind == StrokeKind.Blur) px[i] = Px.Lerp(p, avg, a * k);
                        else
                        {
                            double s = a * k * 1.2;
                            px[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) + (Px.R(p) - Px.R(avg)) * s), Px.Clamp(Px.G(p) + (Px.G(p) - Px.G(avg)) * s), Px.Clamp(Px.B(p) + (Px.B(p) - Px.B(avg)) * s));
                        }
                        break;
                    }
                    case StrokeKind.Smudge:
                    {
                        int bx = x - ((int)c.X - _smudgeR), by = y - ((int)c.Y - _smudgeR);
                        if (bx < 0 || by < 0 || bx >= sd || by >= sd) break;
                        int bi = by * sd + bx;
                        uint carried = _smudge[bi];
                        uint np = Px.Lerp(p, carried, a * k);
                        px[i] = np;
                        _smudge[bi] = Px.Lerp(carried, np, 0.2f + (1 - k) * 0.3f);
                        break;
                    }
                    case StrokeKind.Dodge:
                    {
                        double f = a * k * 0.25;
                        px[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) + (255 - Px.R(p)) * f), Px.Clamp(Px.G(p) + (255 - Px.G(p)) * f), Px.Clamp(Px.B(p) + (255 - Px.B(p)) * f));
                        break;
                    }
                    case StrokeKind.Burn:
                    {
                        double f = 1 - a * k * 0.25;
                        px[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) * f), Px.Clamp(Px.G(p) * f), Px.Clamp(Px.B(p) * f));
                        break;
                    }
                    case StrokeKind.Sponge:
                    {
                        double l = Px.Luma(p);
                        double f = (_b.SpongeSaturate ? 1 : -1) * a * k * 0.2;
                        px[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) + (Px.R(p) - l) * f), Px.Clamp(Px.G(p) + (Px.G(p) - l) * f), Px.Clamp(Px.B(p) + (Px.B(p) - l) * f));
                        break;
                    }
                    case StrokeKind.Heal:
                    {
                        int sx = (int)Math.Round(x + _cloneOffset.X), sy = (int)Math.Round(y + _cloneOffset.Y);
                        if (sx < 0 || sy < 0 || sx >= _w || sy >= _h) break;
                        uint s = Orig(sx, sy);
                        uint corrected = Px.Pack(Px.A(s), Px.Clamp(Px.R(s) + hr), Px.Clamp(Px.G(s) + hg), Px.Clamp(Px.B(s) + hb));
                        px[i] = Px.Lerp(p, corrected, a * 0.85f);
                        break;
                    }
                }
            }
        }
    }

    /// <summary>Finishes the stroke and records an undoable patch.</summary>
    public void Commit(string name)
    {
        if (RectUtil.IsEmptyRect(Total)) return;
        if (_kind == StrokeKind.SpotHeal) HealSpot();
        var before = ExtractOriginal(Total);
        var after = PixelPatch.Extract(_px, _w, Total);
        _doc.RecordPatch(_isMask ? name + " (mask)" : name, Layer, Total, before, after, "✎", _isMask);
        Layer.RefreshThumbnail();
        _doc.RefreshThumbnail();
    }

    /// <summary>Replace the painted area with content-aware fill (Spot Healing Brush).</summary>
    void HealSpot()
    {
        var mask = new byte[_w * _h];
        for (int y = Total.Y; y < Total.Y + Total.Height; y++)
            for (int x = Total.X; x < Total.X + Total.Width; x++)
            {
                int i = y * _w + x;
                int cv = Cov(x, y);
                if (cv > 0) mask[i] = (byte)Math.Min(255, cv / 128);
            }
        mask = SelectionOps.Grow(mask, _w, _h, 2);
        var original = FullOriginal();
        var healed = Inpaint.Fill(original, _w, _h, mask);
        var area = RectUtil.Clip(new Int32Rect(Total.X - 3, Total.Y - 3, Total.Width + 6, Total.Height + 6), _w, _h);
        for (int y = area.Y; y < area.Y + area.Height; y++)
            for (int x = area.X; x < area.X + area.Width; x++)
            {
                int i = y * _w + x;
                _px[i] = _sel == null ? healed[i] : Px.Lerp(original[i], healed[i], _sel[i] / 255f);
            }
        Total = area;
        _doc.Render(area);
    }

    public void Cancel()
    {
        if (!RectUtil.IsEmptyRect(Total))
        {
            var orig = ExtractOriginal(Total);
            for (int y = 0; y < Total.Height; y++) Array.Copy(orig, y * Total.Width, _px, (Total.Y + y) * _w + Total.X, Total.Width);
            _doc.Render(Total);
        }
    }

    /// <summary>The pre-stroke pixels of rect r, row by row.</summary>
    uint[] ExtractOriginal(Int32Rect r)
    {
        var res = new uint[r.Width * r.Height];
        for (int y = 0; y < r.Height; y++)
            for (int x = 0; x < r.Width; x++)
                res[y * r.Width + x] = Orig(r.X + x, r.Y + y);
        return res;
    }

    /// <summary>The whole layer as it was before the stroke (only needed by the spot healing brush).</summary>
    uint[] FullOriginal()
    {
        var res = (uint[])_px.Clone();
        for (int t = 0; t < _backupTiles.Length; t++)
        {
            var tile = _backupTiles[t];
            if (tile == null) continue;
            int x0 = (t % _tilesX) * TB, y0 = (t / _tilesX) * TB, bw = Math.Min(TB, _w - x0), bh = Math.Min(TB, _h - y0);
            for (int y = 0; y < bh; y++) Array.Copy(tile, y * TB, res, (y0 + y) * _w + x0, bw);
        }
        return res;
    }
}

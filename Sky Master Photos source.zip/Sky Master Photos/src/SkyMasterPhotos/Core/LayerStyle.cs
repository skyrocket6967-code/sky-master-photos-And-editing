namespace SkyMasterPhotos.Core;

public sealed record LayerStyle
{
    public bool Shadow { get; init; }
    public bool OuterGlow { get; init; }
    public bool InnerGlow { get; init; }
    public bool Bevel { get; init; }
    public bool Stroke { get; init; }
    public int Size { get; init; } = 8;
    public int Distance { get; init; } = 8;
    public double Angle { get; init; } = 135;
    public double Strength { get; init; } = 0.65;
    public uint Color { get; init; } = 0xFF70BFFF;
    public bool Enabled => Shadow || OuterGlow || InnerGlow || Bevel || Stroke;

    /// <summary>How far (px) an effect can land from the pixels that cause it.</summary>
    public int Reach => Math.Clamp(Size, 1, 100) * 2 + Math.Abs(Distance) + 4;

    public uint[] Render(uint[] pixels, uint[] mask, int w, int h, double fill) =>
        Render(pixels, mask, w, h, fill, new Int32Rect(0, 0, w, h), null);

    /// <summary>
    /// Renders the styled layer for <paramref name="region"/> only, into <paramref name="dst"/> (layer-sized, row-major;
    /// pixels outside the region are left alone). Effects only reach a limited distance, so a work area of the
    /// region plus that margin gives exactly the same pixels as rendering the whole layer — a brush dab on a
    /// styled layer costs a few hundred pixels' worth of work instead of the full photo.
    /// </summary>
    public uint[] Render(uint[] pixels, uint[] mask, int w, int h, double fill, Int32Rect region, uint[] dst)
    {
        int size = Math.Clamp(Size, 1, 100);
        double strength = Math.Clamp(Strength, 0, 1);
        dst ??= new uint[pixels.Length];
        region = RectUtil.Clip(region, w, h);
        if (RectUtil.IsEmptyRect(region)) return dst;
        // feather = 3 box passes of size/2 (reach 1.5 × size), grow and bevel reach size, the shadow is offset by Distance
        int margin = Reach;
        var c = RectUtil.Clip(new Int32Rect(region.X - margin, region.Y - margin, region.Width + 2 * margin, region.Height + 2 * margin), w, h);
        int cw = c.Width, ch = c.Height;
        var alpha = new byte[cw * ch];
        Parallel.For(0, ch, ly =>
        {
            int src = (c.Y + ly) * w + c.X, o = ly * cw;
            for (int lx = 0; lx < cw; lx++)
                alpha[o + lx] = (byte)(Px.A(pixels[src + lx]) * (mask == null ? 255 : mask[src + lx] & 255) / 255);
        });
        var soft = SelectionOps.Feather(alpha, cw, ch, size);
        var expanded = Stroke ? SelectionOps.Grow(alpha, cw, ch, size) : null;
        double radians = Angle * Math.PI / 180;
        int dx = (int)Math.Round(Math.Cos(radians) * Distance);
        int dy = (int)Math.Round(Math.Sin(radians) * Distance);
        int bx = (int)Math.Round(Math.Cos(radians) * size);
        int by = (int)Math.Round(Math.Sin(radians) * size);
        // global coordinates → work-area samples (outside the layer = transparent)
        double At(byte[] a, int x, int y)
        {
            if (x < 0 || y < 0 || x >= w || y >= h) return 0;
            int lx = x - c.X, ly = y - c.Y;
            return lx < 0 || ly < 0 || lx >= cw || ly >= ch ? 0 : a[ly * cw + lx] / 255.0;
        }
        Parallel.For(region.Y, region.Y + region.Height, y =>
        {
            for (int x = region.X; x < region.X + region.Width; x++)
            {
                int i = y * w + x, li = (y - c.Y) * cw + (x - c.X);
                uint p = 0;
                double a = alpha[li] / 255.0;
                if (Shadow) p = Over(p, 0xFF000000, At(soft, x - dx, y - dy) * strength);
                if (OuterGlow) p = Over(p, Color, soft[li] / 255.0 * strength * 2);
                if (Stroke) p = Over(p, Color, expanded[li] / 255.0 * strength);
                uint content = (pixels[i] & 0xFFFFFF) | ((uint)Math.Round(alpha[li] * Math.Clamp(fill, 0, 1)) << 24);
                p = Over(p, content, 1);
                if (InnerGlow) p = Over(p, Color, a * (1 - soft[li] / 255.0) * strength * 2);
                if (Bevel)
                {
                    double light = At(alpha, x + bx, y + by) - At(alpha, x - bx, y - by);
                    p = Over(p, light > 0 ? 0xFFFFFFFF : 0xFF000000, Math.Abs(light) * a * strength);
                }
                dst[i] = p;
            }
        });
        return dst;
    }

    static uint Over(uint dst, uint src, double amount)
    {
        double a = Px.A(src) / 255.0 * Math.Clamp(amount, 0, 1), b = Px.A(dst) / 255.0 * (1 - a), total = a + b;
        if (total <= 0) return 0;
        return Px.Pack((int)Math.Round(total * 255),
            (int)Math.Round((Px.R(src) * a + Px.R(dst) * b) / total),
            (int)Math.Round((Px.G(src) * a + Px.G(dst) * b) / total),
            (int)Math.Round((Px.B(src) * a + Px.B(dst) * b) / total));
    }
}

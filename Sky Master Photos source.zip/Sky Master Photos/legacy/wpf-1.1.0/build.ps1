# Builds Sky Master Photos and its installer.
#   Output\Sky Master Photos Setup.exe   – the installer to run / share
#   Output\App\Sky Master Photos.exe     – the standalone app (no install needed)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$src = Join-Path $root 'src'
$out = Join-Path $root 'Output'
$stage = Join-Path $root 'build\stage'
$pub = Join-Path $root 'build\publish'

function Step($t) { Write-Host "`n==> $t" -ForegroundColor Cyan }

if (-not (Test-Path "$src\Shared\app.ico")) { Step 'Generating icon'; & "$root\tools\make-icon.ps1" }

Step 'Publishing Sky Master Photos (self-contained, single file)'
Remove-Item $pub -Recurse -Force -ErrorAction SilentlyContinue
dotnet publish "$src\SkyMasterPhotos\SkyMasterPhotos.csproj" -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:DebugType=none -p:PublishReadyToRun=false -o $pub
if ($LASTEXITCODE -ne 0) { throw 'publish failed' }

Step 'Building uninstaller'
dotnet build "$src\SkySetup\SkySetup.csproj" -c Release -p:Uninstaller=true
if ($LASTEXITCODE -ne 0) { throw 'uninstaller build failed' }

Step 'Packing payload'
Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $stage | Out-Null
Copy-Item "$pub\SkyMasterPhotos.exe" "$stage\Sky Master Photos.exe"
Copy-Item "$src\SkySetup\bin\uninstall\net48\SkyUninstall.exe" "$stage\Uninstall Sky Master Photos.exe"
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = "$src\SkySetup\payload.zip"
Remove-Item $zip -ErrorAction SilentlyContinue
[System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $zip, [System.IO.Compression.CompressionLevel]::Optimal, $false)

Step 'Building installer'
dotnet build "$src\SkySetup\SkySetup.csproj" -c Release
if ($LASTEXITCODE -ne 0) { throw 'installer build failed' }

Step 'Collecting output'
New-Item -ItemType Directory -Force "$out\App" | Out-Null
Copy-Item "$src\SkySetup\bin\Release\net48\SkySetup.exe" "$out\Sky Master Photos Setup.exe" -Force
Copy-Item "$stage\Sky Master Photos.exe" "$out\App\Sky Master Photos.exe" -Force
Get-ChildItem $out -Recurse -File | ForEach-Object { '{0,-40} {1,8:N1} MB' -f $_.FullName.Substring($out.Length + 1), ($_.Length / 1MB) }
Write-Host "`nDone." -ForegroundColor Green

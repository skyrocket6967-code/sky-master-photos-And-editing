# Sky Master Photos

A native Windows photo editor ("Sky Photo") built in C# / WPF on .NET 10. It opens and saves
layered Adobe Photoshop files (.psd / .psb).

## What's where

## Editing Upgrade

- Layer > Layer style adds editable Drop Shadow, Outer Glow, Inner Glow,
  Bevel & Emboss, and Stroke. Effects share size, angle, opacity and accent color
  controls. Use the foreground color button to change the glow/stroke color.
- Apply commits one undo step; Cancel restores the original style; Clear removes it.
- Save as `.skyphoto` to retain editable styles. PNG/JPEG exports include the effects.
  PSD export bakes native effects into each styled layer, preserving separate layers,
  but does not export editable Photoshop layer-effect descriptors.
- Select > Smooth removes isolated selection pixels; Border selects an outline;
  Reselect (Ctrl+Shift+D) restores the previous selection in the current document.
- Close All stops when a save prompt is canceled or a save fails.

### Project Layout

| Path | What it is |
|---|---|
| `Output\Sky Master Photos Setup.exe` | The installer. Run it or share it. Installs per-user, no admin needed. |
| `Output\App\Sky Master Photos.exe` | A portable copy of the app. Runs without installing. |
| `src\SkyMasterPhotos` | The editor source. The engine is in `Core`, the PSD codec in `Core\Psd`. |
| `src\SkySetup` | The installer and uninstaller source (.NET Framework 4.8, built into Windows) |
| `tests\SkyMasterPhotos.Tests` | xUnit tests (205), including real Photoshop sample files |
| `build.ps1` | Rebuilds everything: app, uninstaller, payload and setup |

## Build and test

```powershell
powershell -ExecutionPolicy Bypass -File build.ps1
dotnet test tests\SkyMasterPhotos.Tests -c Release
```

Optional independent PSD validation: set `SKY_PSD_PYTHON` to a Python with `pip install psd-tools`.
Every PSD the app writes is then re-read by psd-tools during the tests.

- Engine self-test: `"Sky Master Photos.exe" --selftest` writes `%AppData%\Sky Master Photos\selftest.log`.
- Silent install: `"Sky Master Photos Setup.exe" /S`
- Silent uninstall: `"Uninstall Sky Master Photos.exe" /S`

## Features

- **28 tools:** Move, Marquee, Lasso, Polygonal Lasso, Magic Wand, Crop, Eyedropper, **Spot Healing Brush**, Healing Brush, Brush, Pencil, Clone Stamp, Eraser, Gradient, Paint Bucket, Blur, Sharpen, Smudge, Dodge, Burn, Sponge, Type (re-editable), Rectangle, Ellipse, Line, Hand and Zoom, plus Free Transform.
- **Layers:**
  - layer masks you paint with any tool
  - **adjustment layers** (13 types, non-destructive)
  - clipping masks, fill opacity, groups and 23 blend modes
  - lock, merge and flatten
- **Content-Aware Fill** (Shift+F5) and a Spot Healing Brush that remove objects automatically.
- **Destructive adjustments and filters** with live preview. These are the classic Image ▸ Adjustments edits, plus 20 filters.
- **Files:**
  - opens PSD/PSB, PNG, JPG, BMP, GIF, TIFF, WebP/HEIC (when Windows has the codecs) and ICO
  - saves `.skyphoto` projects and layered PSD
  - exports PNG, JPG, PSD, TIFF, BMP and GIF

## Photoshop (PSD) compatibility

The PSD reader and writer are implemented in-house from Adobe's file-format specification, in `Core\Psd`.
I evaluated existing libraries and none fit:
- Aspose.PSD has a commercial license.
- Magick.NET flattens most layer features and adds about 30 MB of native code.
- The Paint.NET PSD plugin depends on Paint.NET itself.

**Fully supported (open, edit and save back):**
- Layers, with order, names (Unicode and emoji), visibility, opacity, fill opacity and lock-all
- The 23 blend modes the app shares with Photoshop
- Layer masks: user masks, disabled masks and default colors
- Clipping masks
- Adjustment layers, editable and rendered live: Brightness/Contrast, Levels (composite channel), Curves (composite channel), Exposure, Vibrance, Hue/Saturation (master range), Color Balance (midtones), Black & White, Photo Filter, Invert, Posterize, Threshold and Gradient Map (two colors)
- 8/16/32-bit and RGB/Grayscale/CMYK/Lab/Indexed/Bitmap files open. 16/32-bit and non-RGB files are converted to 8-bit RGB.
- PSB (large document format), reading only
- The merged composite. Saved PSDs include it for apps that don't read layers.

**Partially supported:**
- **Text layers:** The text, font, size and color are imported and the text can be re-edited. If you don't edit it, the original Photoshop text data is written back, so it stays editable in Photoshop. Once edited in Sky Photo, it's saved to PSD as pixels.
- **Groups:** Groups are kept as a path on each layer, and group visibility and opacity are applied. Pass-through and other group blend modes are approximated. Empty groups are lost on save.
- **Smart Objects, shape layers, vector masks and fill layers:** These are shown using Photoshop's stored pixels. They're written back unchanged as long as the layer isn't edited. A solid color fill without pixel data is rendered.
- **Dissolve, Darker Color, Lighter Color and Hard Mix blend modes:** These are approximated for display. The original mode is saved back.
- **Adjustment details:** Levels and Curves edit only the composite (RGB) channel, Hue/Saturation only the master range, and Color Balance only the midtones.
- **Layers extending past the canvas:** They're cropped to the canvas.
- **Mask density and feather:** These settings are ignored.

**Preserved but not rendered (kept for Photoshop):**
- Layer effects (drop shadow, stroke and so on, marked "fx")
- Channel Mixer, Color Lookup and Selective Color adjustment layers
- Patterns, linked-layer data and layer comps

**Not supported:**
- Saving PSB, or 16/32-bit PSD. Saves are always 8-bit RGB PSD.
- Saving CMYK. CMYK files are converted to RGB on open.
- Alpha and spot channels
- Artboards, timeline and 3D data
- Rendering vector shapes and smart filters

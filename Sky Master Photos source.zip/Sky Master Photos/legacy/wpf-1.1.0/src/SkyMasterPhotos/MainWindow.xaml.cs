using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Tools;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos;

public partial class MainWindow : Window, IEditorHost
{
    public ObservableCollection<Document> Docs { get; } = new();
    Document _active;
    public ToolController Ctl { get; }
    readonly HomeView _home = new();
    Color _fg = Color.FromRgb(0x1E, 0x1E, 0x24), _bg = Colors.White;
    bool _editingBg;
    readonly DispatcherTimer _thumbTimer;
    readonly DispatcherTimer _toastTimer;
    bool _panelsHidden;

    public MainWindow()
    {
        InitializeComponent();
        Ctl = new ToolController(this) { Canvas = Canvas };
        Canvas.Ctl = Ctl;
        Ctl.ToolChanged += OnToolChanged;

        _home.NewDoc = () => NewDocument();
        _home.NewPreset = (w, h, n) => CreateDocument(w, h, n, Colors.White);
        _home.Open = () => OpenFiles();
        _home.OpenRecent = p => OpenPath(p);
        _home.ResumeDoc = d => { SwitchTo(d); ShowEditor(); };
        _home.Shortcuts = () => InfoDialogs.Shortcuts(this);
        _home.About = () => InfoDialogs.About(this);
        _home.OpenDocs = () => Docs;
        HomeHost.Content = _home;

        _thumbTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(320) };
        _thumbTimer.Tick += (_, _) => { _thumbTimer.Stop(); RefreshThumbsAndNavigator(); };
        _toastTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(2400) };
        _toastTimer.Tick += (_, _) => { _toastTimer.Stop(); ToastPanel.BeginAnimation(OpacityProperty, new DoubleAnimation(0, TimeSpan.FromMilliseconds(260))); };

        BuildMenu();
        BuildToolbar();
        BuildColorWell();
        BuildPanels();
        BuildTaskBar();

        Canvas.ViewChanged += OnViewChanged;
        Canvas.CursorMoved += OnCursorMoved;
        Picker.ColorChanged += c => { if (_editingBg) SetBg(c, false); else SetFg(c, false); };
        Picker.SetColor(_fg);

        PreviewKeyDown += OnPreviewKeyDown;
        PreviewKeyUp += OnPreviewKeyUp;
        Deactivated += (_, _) => { if (Ctl.SpaceHeld) { Ctl.SpaceHeld = false; Canvas.UpdateCursor(); } };
        StateChanged += (_, _) => UpdateChromeMargin();
        Loaded += OnLoaded;
        Closing += OnClosing;
        DragEnter += OnDragOver;
        DragOver += OnDragOver;
        DragLeave += (_, _) => DropOverlay.Visibility = Visibility.Collapsed;
        Drop += OnDrop;

        var s = AppStore.Settings;
        Width = Math.Max(MinWidth, s.WindowWidth);
        Height = Math.Max(MinHeight, s.WindowHeight);
        if (s.Maximized) WindowState = WindowState.Maximized;

        ShowHome();
        OnToolChanged();
        UpdateTitle();
    }

    void OnLoaded(object sender, RoutedEventArgs e)
    {
        UpdateChromeMargin();
        foreach (var f in App.StartupFiles) OpenPath(f);
        if (App.SelfTest) Dispatcher.BeginInvoke(new Action(RunSelfTest), DispatcherPriority.ApplicationIdle);
    }

    // ───────────────────────────── IEditorHost ─────────────────────────────

    public Document ActiveDoc => _active;
    public Color Fg => _fg;
    public Color Bg => _bg;
    public System.Windows.Controls.Canvas TextHost => TextLayer;

    public void SetFg(Color c) => SetFg(c, true);
    public void SetBg(Color c) => SetBg(c, true);

    void SetFg(Color c, bool updatePicker)
    {
        _fg = c;
        if (updatePicker && !_editingBg) Picker.SetColor(c);
        UpdateColorWell();
        Ctl.ApplyTextStyle();
    }

    void SetBg(Color c, bool updatePicker)
    {
        _bg = c;
        if (updatePicker && _editingBg) Picker.SetColor(c);
        UpdateColorWell();
    }

    public void Toast(string msg)
    {
        ToastText.Text = msg;
        ToastPanel.BeginAnimation(OpacityProperty, new DoubleAnimation(1, TimeSpan.FromMilliseconds(140)));
        _toastTimer.Stop();
        _toastTimer.Start();
    }

    public void OnToolStateChanged()
    {
        BuildOptions();
        Canvas.InvalidateVisual();
    }

    // ───────────────────────────── chrome ─────────────────────────────

    [DllImport("user32.dll")] static extern int GetSystemMetricsForDpi(int nIndex, uint dpi);

    void UpdateChromeMargin()
    {
        if (WindowState == WindowState.Maximized)
        {
            double m = 7;
            try
            {
                var dpi = VisualTreeHelper.GetDpi(this);
                uint d = (uint)(96 * dpi.DpiScaleX);
                int frame = GetSystemMetricsForDpi(32, d) + GetSystemMetricsForDpi(92, d);
                m = frame / dpi.DpiScaleX;
            }
            catch { }
            RootGrid.Margin = new Thickness(m);
            MaxIcon.Kind = "win-restore";
        }
        else
        {
            RootGrid.Margin = new Thickness(0);
            MaxIcon.Kind = "win-max";
        }
    }

    void OnMinClick(object s, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    void OnMaxClick(object s, RoutedEventArgs e) => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
    void OnCloseClick(object s, RoutedEventArgs e) => Close();
    void OnHomeClick(object s, RoutedEventArgs e) { if (HomeHost.Visibility == Visibility.Visible && _active != null) ShowEditor(); else ShowHome(); }
    void OnUndoClick(object s, RoutedEventArgs e) => Undo();
    void OnRedoClick(object s, RoutedEventArgs e) => Redo();
    void OnExportClick(object s, RoutedEventArgs e) => ExportDoc();
    void OnZoomInClick(object s, RoutedEventArgs e) => Canvas.ZoomStep(true);
    void OnZoomOutClick(object s, RoutedEventArgs e) => Canvas.ZoomStep(false);

    void OnClosing(object sender, CancelEventArgs e)
    {
        Ctl.FinishPending();
        foreach (var d in Docs.ToList())
        {
            if (!d.IsDirty) continue;
            SwitchTo(d);
            ShowEditor();
            var c = SkyDialog.AskSave(this, d.Title);
            if (c == SaveChoice.Cancel) { e.Cancel = true; return; }
            if (c == SaveChoice.Save && !SaveDoc(d, false)) { e.Cancel = true; return; }
        }
        var st = AppStore.Settings;
        st.Maximized = WindowState == WindowState.Maximized;
        if (WindowState == WindowState.Normal) { st.WindowWidth = Width; st.WindowHeight = Height; }
        AppStore.SaveSettings();
    }

    // ───────────────────────────── views ─────────────────────────────

    void ShowHome()
    {
        Ctl.FinishPending();
        _home.Refresh();
        HomeHost.Visibility = Visibility.Visible;
        Editor.Visibility = Visibility.Collapsed;
        ExportBtn.Visibility = Visibility.Collapsed;
        UndoBtn.Visibility = RedoBtn.Visibility = Visibility.Collapsed;
        UpdateTitle();
    }

    void ShowEditor()
    {
        HomeHost.Visibility = Visibility.Collapsed;
        Editor.Visibility = Visibility.Visible;
        ExportBtn.Visibility = _active != null ? Visibility.Visible : Visibility.Collapsed;
        UndoBtn.Visibility = RedoBtn.Visibility = Visibility.Visible;
        EmptyHint.Visibility = _active == null ? Visibility.Visible : Visibility.Collapsed;
        UpdateTitle();
        Canvas.Focus();
    }

    void UpdateTitle()
    {
        if (_active != null && Editor.Visibility == Visibility.Visible)
        {
            TitleText.Text = $"{_active.TabTitle}  ·  {_active.Width} × {_active.Height}  ·  {_active.ZoomText}";
            Title = $"{_active.Title} — Sky Master Photos";
        }
        else
        {
            TitleText.Text = "Sky Master Photos";
            Title = "Sky Master Photos";
        }
        UndoBtn.IsEnabled = _active?.History.CanUndo == true;
        RedoBtn.IsEnabled = _active?.History.CanRedo == true;
    }

    // ───────────────────────────── documents ─────────────────────────────

    void AddDocument(Document d)
    {
        Docs.Add(d);
        d.RefreshAllLayerThumbs();
        SwitchTo(d);
        ShowEditor();
    }

    void SwitchTo(Document d)
    {
        if (_active == d) { RebuildTabs(); return; }
        Ctl.FinishPending();
        if (_active != null)
        {
            _active.Rendered -= OnDocRendered;
            _active.StructureChanged -= OnDocStructure;
            _active.PropertyChanged -= OnDocProperty;
            _active.History.Entries.CollectionChanged -= OnHistoryChanged;
        }
        _active = d;
        if (d != null)
        {
            d.Rendered += OnDocRendered;
            d.StructureChanged += OnDocStructure;
            d.PropertyChanged += OnDocProperty;
            d.History.Entries.CollectionChanged += OnHistoryChanged;
        }
        Canvas.Doc = d;
        Ctl.OnDocumentSwitched();
        BindPanels();
        RebuildTabs();
        RefreshThumbsAndNavigator();
        RebuildTaskBar();
        EmptyHint.Visibility = d == null ? Visibility.Visible : Visibility.Collapsed;
        ExportBtn.Visibility = d != null && Editor.Visibility == Visibility.Visible ? Visibility.Visible : Visibility.Collapsed;
        UpdateStatus();
        UpdateTitle();
    }

    void OnDocRendered(Int32Rect r)
    {
        _thumbTimer.Stop();
        _thumbTimer.Start();
    }

    void OnDocStructure()
    {
        UpdateStatus();
        UpdateTitle();
        RebuildTaskBar();
        _thumbTimer.Stop();
        _thumbTimer.Start();
    }

    void OnDocProperty(object sender, PropertyChangedEventArgs e)
    {
        switch (e.PropertyName)
        {
            case nameof(Document.ActiveLayer): SyncLayerSelection(); break;
            case nameof(Document.TabTitle): UpdateTitle(); break;
            case nameof(Document.HasSelection): RebuildTaskBar(); break;
        }
    }

    void OnHistoryChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
    {
        UpdateTitle();
        SyncHistorySelection();
    }

    void CreateDocument(int w, int h, string name, Color bg)
    {
        var d = Document.CreateBlank(w, h, name, bg);
        AddDocument(d);
    }

    public void NewDocument()
    {
        int? cw = null, ch = null;
        try
        {
            if (Clipboard.ContainsImage())
            {
                var img = Clipboard.GetImage();
                if (img != null) { cw = img.PixelWidth; ch = img.PixelHeight; }
            }
        }
        catch { }
        var r = NewDocumentDialog.Show(this, _fg, cw, ch);
        if (r != null) CreateDocument(r.Width, r.Height, r.Name, r.Background);
    }

    public void OpenFiles()
    {
        var dlg = new OpenFileDialog { Filter = ImageIO.OpenFilter, Multiselect = true, Title = "Open" };
        if (!string.IsNullOrEmpty(AppStore.Settings.LastFolder) && Directory.Exists(AppStore.Settings.LastFolder)) dlg.InitialDirectory = AppStore.Settings.LastFolder;
        if (dlg.ShowDialog(this) != true) return;
        AppStore.Settings.LastFolder = Path.GetDirectoryName(dlg.FileNames[0]);
        foreach (var f in dlg.FileNames) OpenPath(f);
    }

    public void OpenPath(string path)
    {
        var existing = Docs.FirstOrDefault(d => string.Equals(d.FilePath, path, StringComparison.OrdinalIgnoreCase));
        if (existing != null) { SwitchTo(existing); ShowEditor(); return; }
        try
        {
            Mouse.OverrideCursor = Cursors.Wait;
            Document d;
            List<string> notes = null;
            if (ImageIO.IsPsd(path))
            {
                var res = Core.Psd.PsdReader.Read(path);
                d = res.Doc;
                d.FilePath = path;
                d.RenderAll();
                notes = res.Warnings;
            }
            else if (Path.GetExtension(path).Equals(ImageIO.ProjectExt, StringComparison.OrdinalIgnoreCase))
            {
                d = ImageIO.LoadProject(path);
                d.RenderAll();
            }
            else
            {
                var (px, w, h) = ImageIO.LoadPixels(path);
                d = new Document(w, h, Path.GetFileNameWithoutExtension(path), "Open");
                var layer = new Layer("Background", w, h, px);
                d.Layers.Add(layer);
                d.ActiveLayer = layer;
                d.FilePath = path;
                d.RenderAll();
            }
            d.Title = Path.GetFileName(path);
            d.IsDirty = false;
            if (notes != null) _importNotes[d] = notes;
            AddDocument(d);
            AppStore.AddRecent(path, d.Width, d.Height, d.Flat);
            if (notes != null && notes.Count > 0) Toast($"Photoshop file opened — {notes.Count} note{(notes.Count == 1 ? "" : "s")} (File ▸ Photoshop compatibility)");
            else if (notes != null) Toast($"Photoshop file opened — {d.Layers.Count} editable layers");
        }
        catch (Exception ex)
        {
            AppStore.RemoveRecent(path);
            SkyDialog.Alert(this, "Couldn't open file", $"{Path.GetFileName(path)}\n\n{ex.Message}");
            if (HomeHost.Visibility == Visibility.Visible) _home.Refresh();
        }
        finally { Mouse.OverrideCursor = null; }
    }

    /// <summary>Save as .skyphoto (layers kept) or flatten to an image format.</summary>
    public bool SaveDoc(Document d, bool saveAs)
    {
        if (d == null) return false;
        Ctl.FinishPending();
        string path = d.FilePath;
        bool isProject = path != null && (Path.GetExtension(path).Equals(ImageIO.ProjectExt, StringComparison.OrdinalIgnoreCase) || Path.GetExtension(path).Equals(".psd", StringComparison.OrdinalIgnoreCase));
        if (path != null && Path.GetExtension(path).Equals(".psb", StringComparison.OrdinalIgnoreCase)) { saveAs = true; }
        bool flatFormat = path != null && !isProject;
        if (saveAs || path == null)
        {
            var dlg = new SaveFileDialog
            {
                Filter = "Sky Photo project (*.skyphoto)|*.skyphoto|Photoshop document (*.psd)|*.psd|PNG image (*.png)|*.png|JPEG image (*.jpg)|*.jpg|TIFF image (*.tif)|*.tif|Bitmap (*.bmp)|*.bmp",
                FileName = Path.GetFileNameWithoutExtension(d.Title),
                Title = "Save as",
                AddExtension = true,
            };
            if (!string.IsNullOrEmpty(AppStore.Settings.LastFolder) && Directory.Exists(AppStore.Settings.LastFolder)) dlg.InitialDirectory = AppStore.Settings.LastFolder;
            if (dlg.ShowDialog(this) != true) return false;
            path = dlg.FileName;
            AppStore.Settings.LastFolder = Path.GetDirectoryName(path);
        }
        else if (flatFormat && d.Layers.Count > 1)
        {
            // saving a layered doc back over a flat image: offer the project format
            if (SkyDialog.Confirm(this, "Keep your layers?", $"“{Path.GetFileName(path)}” can't store layers. Save as a Sky Photo project instead to keep them editable?", "Save as project", "Flatten & save"))
                return SaveDoc(d, true);
        }
        try
        {
            Mouse.OverrideCursor = Cursors.Wait;
            if (Path.GetExtension(path).Equals(ImageIO.ProjectExt, StringComparison.OrdinalIgnoreCase)) ImageIO.SaveProject(d, path);
            else if (Path.GetExtension(path).Equals(".psd", StringComparison.OrdinalIgnoreCase))
            {
                if (d.Layers.Any(l => l.Style?.Enabled == true) && !SkyDialog.Confirm(this, "PSD layer styles",
                    "Effects will be baked into their individual layers. Save a .skyphoto project to keep styles editable.", "Save PSD")) return false;
                Core.Psd.PsdWriter.Save(d, path);
            }
            else ImageIO.SaveImage(path, d.Flat, d.Width, d.Height, AppStore.Settings.JpegQuality);
            d.FilePath = path;
            d.Title = Path.GetFileName(path);
            d.IsDirty = false;
            AppStore.AddRecent(path, d.Width, d.Height, d.Flat);
            Toast($"Saved {Path.GetFileName(path)}");
            RebuildTabs();
            return true;
        }
        catch (Exception ex)
        {
            SkyDialog.Alert(this, "Couldn't save", ex.Message);
            return false;
        }
        finally { Mouse.OverrideCursor = null; }
    }

    public void ExportDoc()
    {
        if (!RequireDoc()) return;
        Ctl.FinishPending();
        var d = _active;
        var opt = ExportDialog.Show(this, d);
        if (opt == null) return;
        string ext = opt.Format switch { "PSD" => ".psd", "JPG" => ".jpg", "TIFF" => ".tif", "BMP" => ".bmp", "GIF" => ".gif", _ => ".png" };
        var dlg = new SaveFileDialog
        {
            Filter = $"{opt.Format} image (*{ext})|*{ext}",
            FileName = Path.GetFileNameWithoutExtension(d.Title) + ext,
            Title = "Export",
            AddExtension = true,
        };
        if (!string.IsNullOrEmpty(AppStore.Settings.LastFolder) && Directory.Exists(AppStore.Settings.LastFolder)) dlg.InitialDirectory = AppStore.Settings.LastFolder;
        if (dlg.ShowDialog(this) != true) return;
        try
        {
            Mouse.OverrideCursor = Cursors.Wait;
            if (opt.Format == "PSD")
            {
                if (d.Layers.Any(l => l.Style?.Enabled == true) && !SkyDialog.Confirm(this, "PSD layer styles",
                    "Effects will be baked into their individual layers. Keep a .skyphoto project for editable styles.", "Export PSD")) return;
                Core.Psd.PsdWriter.Save(d, dlg.FileName);
                AppStore.Settings.LastFolder = Path.GetDirectoryName(dlg.FileName);
                Toast($"Exported layered PSD — {d.Layers.Count} layers");
                return;
            }
            var px = d.Flat;
            int w = d.Width, h = d.Height;
            if (Math.Abs(opt.Scale - 1) > 0.001)
            {
                int nw = Math.Max(1, (int)Math.Round(w * opt.Scale)), nh = Math.Max(1, (int)Math.Round(h * opt.Scale));
                px = Transforms.Resize(px, w, h, nw, nh);
                w = nw; h = nh;
            }
            ImageIO.SaveImage(dlg.FileName, px, w, h, opt.Quality);
            AppStore.Settings.LastFolder = Path.GetDirectoryName(dlg.FileName);
            AppStore.AddRecent(dlg.FileName, w, h, px);
            Toast($"Exported {Path.GetFileName(dlg.FileName)}");
        }
        catch (Exception ex) { SkyDialog.Alert(this, "Export failed", ex.Message); }
        finally { Mouse.OverrideCursor = null; }
    }

    public bool CloseDoc(Document d)
    {
        if (d == null) return true;
        if (d == _active) Ctl.FinishPending();
        if (d.IsDirty)
        {
            if (d != _active) SwitchTo(d);
            var c = SkyDialog.AskSave(this, d.Title);
            if (c == SaveChoice.Cancel) return false;
            if (c == SaveChoice.Save && !SaveDoc(d, false)) return false;
        }
        int idx = Docs.IndexOf(d);
        Docs.Remove(d);
        _importNotes.Remove(d);
        if (_active == d)
        {
            var next = Docs.Count == 0 ? null : Docs[Math.Clamp(idx, 0, Docs.Count - 1)];
            _active = null;
            SwitchTo(next);
            if (next == null) ShowHome();
        }
        else RebuildTabs();
        GC.Collect(1, GCCollectionMode.Optimized, false);
        return true;
    }

    bool RequireDoc()
    {
        if (_active != null) return true;
        Toast("Open or create a document first");
        return false;
    }

    // ───────────────────────────── tabs ─────────────────────────────

    void RebuildTabs()
    {
        TabsHost.Children.Clear();
        foreach (var d in Docs)
        {
            var doc = d;
            bool active = d == _active;
            var thumb = new Border { Width = 26, Height = 22, CornerRadius = new CornerRadius(5), Background = UIx.Checker(3, true), BorderBrush = UIx.R<Brush>("Line2"), BorderThickness = new Thickness(1) };
            var img = new Border { CornerRadius = new CornerRadius(5) };
            img.SetBinding(Border.BackgroundProperty, new Binding(nameof(Document.Thumbnail)) { Source = d, Converter = new FuncConverter(v => v is BitmapSource b ? new ImageBrush(b) { Stretch = Stretch.UniformToFill } : null) });
            thumb.Child = img;
            var title = new TextBlock { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(9, 0, 6, 0), FontSize = 12.5, MaxWidth = 220, TextTrimming = TextTrimming.CharacterEllipsis, Foreground = UIx.R<Brush>(active ? "Text" : "Text2") };
            title.SetBinding(TextBlock.TextProperty, new Binding(nameof(Document.TabTitle)) { Source = d });
            var close = new Button { Style = UIx.R<Style>("IconBtn"), Width = 22, Height = 22, Content = new Ico("close", 12), ToolTip = "Close" };
            close.Click += (_, _) => CloseDoc(doc);
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            sp.Children.Add(thumb); sp.Children.Add(title); sp.Children.Add(close);
            var tab = new Border
            {
                Child = sp,
                Padding = new Thickness(8, 6, 6, 6),
                Margin = new Thickness(0, 0, 4, 0),
                CornerRadius = new CornerRadius(10, 10, 0, 0),
                Background = UIx.R<Brush>(active ? "Bg2" : "Bg0"),
                BorderBrush = active ? UIx.R<Brush>("AccentGradH") : Brushes.Transparent,
                BorderThickness = new Thickness(0, 2, 0, 0),
                Cursor = Cursors.Hand,
                ToolTip = d.FilePath ?? d.Title,
            };
            tab.MouseLeftButtonDown += (_, _) => { SwitchTo(doc); ShowEditor(); };
            tab.MouseDown += (_, e) => { if (e.ChangedButton == MouseButton.Middle) CloseDoc(doc); };
            tab.MouseEnter += (_, _) => { if (doc != _active) tab.Background = UIx.R<Brush>("Bg1"); };
            tab.MouseLeave += (_, _) => { if (doc != _active) tab.Background = UIx.R<Brush>("Bg0"); };
            TabsHost.Children.Add(tab);
        }
        var plus = new Button { Style = UIx.R<Style>("IconBtn"), Content = new Ico("plus", 15), ToolTip = "New document (Ctrl+N)", Margin = new Thickness(4, 0, 0, 6), VerticalAlignment = VerticalAlignment.Center };
        plus.Click += (_, _) => NewDocument();
        TabsHost.Children.Add(plus);
    }

    // ───────────────────────────── thumbnails / status ─────────────────────────────

    void RefreshThumbsAndNavigator()
    {
        var d = _active;
        if (d == null) { NavImage.Source = null; Histo.Update(null); return; }
        d.RefreshThumbnail();
        d.ActiveLayer?.RefreshThumbnail();
        NavImage.Source = ThumbnailMaker.Make(d.Flat, d.Width, d.Height, 300, true);
        if (HistoPane.Visibility == Visibility.Visible) Histo.Update(d.Flat);
        UpdateNavRect();
    }

    void OnViewChanged()
    {
        UpdateNavRect();
        UpdateStatus();
        UpdateTitle();
        Ctl.PositionTextBox();
        Ctl.ApplyTextStyle();
    }

    void UpdateStatus()
    {
        var d = _active;
        if (d == null) { StatusZoom.Text = ""; StatusSize.Text = ""; return; }
        StatusZoom.Text = d.ZoomText;
        StatusSize.Text = $"{d.Width} × {d.Height} px  ·  {d.Layers.Count} layer{(d.Layers.Count == 1 ? "" : "s")}" + (d.HasSelection ? $"  ·  selection {d.SelectionBounds.Width} × {d.SelectionBounds.Height}" : "");
        NavZoom.Text = d.ZoomText;
        _navSync = true;
        NavSlider.Value = Math.Log(d.Zoom / 0.01) / Math.Log(6400);
        _navSync = false;
    }

    void OnCursorMoved(Point? p)
    {
        var d = _active;
        if (d == null || p == null) { StatusPos.Text = ""; StatusColor.Text = ""; StatusSwatch.Visibility = Visibility.Collapsed; return; }
        int x = (int)Math.Floor(p.Value.X), y = (int)Math.Floor(p.Value.Y);
        StatusPos.Text = $"X {x}   Y {y}";
        if (x >= 0 && y >= 0 && x < d.Width && y < d.Height)
        {
            uint c = d.Flat[y * d.Width + x];
            StatusColor.Text = Px.A(c) == 0 ? "transparent" : $"#{Px.R(c):X2}{Px.G(c):X2}{Px.B(c):X2}" + (Px.A(c) < 255 ? $"  {Px.A(c) * 100 / 255}%" : "");
            StatusSwatch.Background = new SolidColorBrush(Px.ToColor(c));
            StatusSwatch.Visibility = Visibility.Visible;
        }
        else { StatusColor.Text = ""; StatusSwatch.Visibility = Visibility.Collapsed; }
    }

    // ───────────────────────────── keyboard ─────────────────────────────

    void OnPreviewKeyDown(object sender, KeyEventArgs e)
    {
        var key = e.Key == Key.System ? e.SystemKey : e.Key;
        var mods = Keyboard.Modifiers;
        // keep Alt from activating the menu bar (Alt is a tool modifier)
        if (key is Key.LeftAlt or Key.RightAlt) { e.Handled = true; return; }
        if (Keyboard.FocusedElement is TextBox) return;
        if (Keyboard.FocusedElement is MenuItem) return;
        if (OwnedWindows.Count > 0) return;

        if (key == Key.Space)
        {
            if (!Ctl.SpaceHeld && _active != null && !Ctl.TextActive) { Ctl.SpaceHeld = true; Canvas.UpdateCursor(); }
            e.Handled = true;
            return;
        }
        if (HomeHost.Visibility == Visibility.Visible)
        {
            if (mods == ModifierKeys.Control && key == Key.N) { NewDocument(); e.Handled = true; }
            else if (mods == ModifierKeys.Control && key == Key.O) { OpenFiles(); e.Handled = true; }
            else if (mods == ModifierKeys.Control && key == Key.V) { Paste(); e.Handled = true; }
            return;
        }
        if (Ctl.KeyDown(key, mods)) { e.Handled = true; return; }
        if (HandleShortcut(key, mods, e.IsRepeat)) e.Handled = true;
    }

    void OnPreviewKeyUp(object sender, KeyEventArgs e)
    {
        var key = e.Key == Key.System ? e.SystemKey : e.Key;
        if (key is Key.LeftAlt or Key.RightAlt) { e.Handled = true; return; }
        if (key == Key.Space && Ctl.SpaceHeld)
        {
            Ctl.SpaceHeld = false;
            Canvas.UpdateCursor();
            e.Handled = true;
        }
    }

    bool HandleShortcut(Key key, ModifierKeys mods, bool repeat)
    {
        bool ctrl = (mods & ModifierKeys.Control) != 0, shift = (mods & ModifierKeys.Shift) != 0, alt = (mods & ModifierKeys.Alt) != 0;
        if (ctrl)
        {
            switch (key)
            {
                case Key.N when shift: NewLayer(); return true;
                case Key.N: NewDocument(); return true;
                case Key.O: OpenFiles(); return true;
                case Key.S: SaveDoc(_active, shift); return true;
                case Key.E when alt: ExportDoc(); return true;
                case Key.E when shift: MergeVisible(); return true;
                case Key.E: MergeDown(); return true;
                case Key.W: CloseDoc(_active); return true;
                case Key.Z when shift: Redo(); return true;
                case Key.Z: Undo(); return true;
                case Key.Y: Redo(); return true;
                case Key.A: SelectAll(); return true;
                case Key.D when shift: Reselect(); return true;
                case Key.D: Ctl.Deselect(); return true;
                case Key.I when shift: InvertSelection(); return true;
                case Key.I: QuickAdjust("Invert", Adjustments.Invert); return true;
                case Key.T: Ctl.BeginFreeTransform(); return true;
                case Key.G when alt: ToggleClipping(); return true;
                case Key.G when shift: UngroupActiveLayer(); return true;
                case Key.G: GroupActiveLayer(); return true;
                case Key.J when shift: LayerViaCut(); return true;
                case Key.J: LayerViaCopy(); return true;
                case Key.C when shift: Copy(true); return true;
                case Key.C: Copy(false); return true;
                case Key.X: Cut(); return true;
                case Key.V: Paste(); return true;
                case Key.L: AdjLevels(); return true;
                case Key.M: AdjCurves(); return true;
                case Key.U when shift: QuickAdjust("Desaturate", Adjustments.Desaturate); return true;
                case Key.U: AdjHueSat(); return true;
                case Key.B: AdjColorBalance(); return true;
                case Key.OemPlus:
                case Key.Add: Canvas.ZoomStep(true); return true;
                case Key.OemMinus:
                case Key.Subtract: Canvas.ZoomStep(false); return true;
                case Key.D0:
                case Key.NumPad0: Canvas.Fit(); return true;
                case Key.D1:
                case Key.NumPad1: Canvas.ActualPixels(); return true;
                case Key.Back: FillSelection(false); return true;
            }
            return false;
        }
        if (alt && key == Key.Back) { FillSelection(true); return true; }
        if (shift && key == Key.F5) { ContentAwareFill(); return true; }
        if (alt) return false;

        switch (key)
        {
            case Key.Tab: TogglePanels(); return true;
            case Key.Delete:
            case Key.Back: ClearSelection(); return true;
            case Key.X: { var t = _fg; SetFg(_bg); SetBg(t); return true; }
            case Key.D when !shift: SetFg(Colors.Black); SetBg(Colors.White); return true;
            case Key.OemOpenBrackets:
                if (shift) { var b = Ctl.CurrentBrush; b.Hardness = Math.Max(0, b.Hardness - 0.1); }
                else { var b = Ctl.CurrentBrush; b.Size = Math.Max(1, b.Size < 10 ? b.Size - 1 : b.Size < 50 ? b.Size - 5 : b.Size * 0.85); }
                BuildOptions(); Canvas.InvalidateVisual(); return true;
            case Key.OemCloseBrackets:
                if (shift) { var b = Ctl.CurrentBrush; b.Hardness = Math.Min(1, b.Hardness + 0.1); }
                else { var b = Ctl.CurrentBrush; b.Size = Math.Min(2500, b.Size < 10 ? b.Size + 1 : b.Size < 50 ? b.Size + 5 : b.Size * 1.18); }
                BuildOptions(); Canvas.InvalidateVisual(); return true;
        }
        if (key >= Key.D0 && key <= Key.D9 && ToolInfo.IsBrushLike(Ctl.Tool))
        {
            int n = key - Key.D0;
            Ctl.CurrentBrush.Opacity = n == 0 ? 1 : n / 10.0;
            Ctl.CurrentBrush.Strength = n == 0 ? 1 : n / 10.0;
            BuildOptions();
            Toast($"Opacity {(n == 0 ? 100 : n * 10)}%");
            return true;
        }
        var g = ToolInfo.Groups.FirstOrDefault(gr => gr.Key == key);
        if (g != null && !repeat)
        {
            if (shift && g.Tools.Length > 1)
            {
                int i = Array.IndexOf(g.Tools, g.Current);
                g.Current = g.Tools[(i + 1) % g.Tools.Length];
            }
            Ctl.Tool = g.Current;
            return true;
        }
        return false;
    }

    void TogglePanels()
    {
        _panelsHidden = !_panelsHidden;
        PanelColumn.Width = new GridLength(_panelsHidden ? 0 : 318);
        Canvas.InvalidateVisual();
    }

    // ───────────────────────────── drag & drop ─────────────────────────────

    void OnDragOver(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            e.Effects = DragDropEffects.Copy;
            DropText.Text = _active != null && Editor.Visibility == Visibility.Visible ? "Drop to add as a layer  ·  hold Ctrl to open separately" : "Drop to open";
            DropOverlay.Visibility = Visibility.Visible;
        }
        else if (!e.Data.GetDataPresent(typeof(Layer))) e.Effects = DragDropEffects.None;
        e.Handled = true;
    }

    void OnDrop(object sender, DragEventArgs e)
    {
        DropOverlay.Visibility = Visibility.Collapsed;
        if (e.Data.GetData(DataFormats.FileDrop) is not string[] files) return;
        bool asLayer = _active != null && Editor.Visibility == Visibility.Visible && (e.KeyStates & DragDropKeyStates.ControlKey) == 0;
        foreach (var f in files)
        {
            if (asLayer && !f.EndsWith(ImageIO.ProjectExt, StringComparison.OrdinalIgnoreCase)) PlaceFile(f, false);
            else OpenPath(f);
        }
        Activate();
    }
}

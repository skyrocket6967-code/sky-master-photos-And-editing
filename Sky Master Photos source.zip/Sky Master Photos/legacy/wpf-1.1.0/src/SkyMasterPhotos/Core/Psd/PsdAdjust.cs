using System.Windows;
using System.Windows.Media;

namespace SkyMasterPhotos.Core.Psd;

/// <summary>Maps Photoshop adjustment-layer blocks to <see cref="AdjustmentSpec"/> and back.</summary>
public static class PsdAdjust
{
    /// <summary>Adjustment keys we can render and edit.</summary>
    public static readonly HashSet<string> Supported = new() { "brit", "levl", "curv", "expA", "vibA", "hue2", "hue ", "blnc", "blwh", "phfl", "nvrt", "post", "thrs", "grdm" };

    /// <summary>Adjustment / fill keys we preserve but cannot render.</summary>
    public static readonly Dictionary<string, string> Unrendered = new()
    {
        ["mixr"] = "Channel Mixer", ["clrL"] = "Color Lookup", ["selc"] = "Selective Color",
    };

    public static bool IsAdjustmentKey(string k) => Supported.Contains(k) || Unrendered.ContainsKey(k) || k == "CgEd";

    static Dictionary<string, double> D(params (string, double)[] p) => AdjustmentSpec.D(p);

    /// <summary>Decode an adjustment block; <paramref name="all"/> gives sibling blocks (e.g. CgEd for brit).</summary>
    public static AdjustmentSpec Decode(string key, byte[] data, IList<PsdBlock> all)
    {
        var r = new BeReader(data);
        switch (key)
        {
            case "brit":
            {
                double b = r.I16(), c = r.I16();
                var cg = all.FirstOrDefault(x => x.Key == "CgEd");
                if (cg != null)
                {
                    try
                    {
                        var cr = new BeReader(cg.Data);
                        cr.U32();
                        var d = Descriptor.Read(cr);
                        b = d.Num("Brgh", b);
                        c = d.Num("Cntr", c);
                    }
                    catch { }
                }
                return new AdjustmentSpec { Kind = "brightness", P = D(("b", b), ("c", c)) };
            }
            case "levl":
            {
                r.U16();
                double ib = r.I16(), iw = r.I16(), ob = r.I16(), ow = r.I16(), g = r.I16() / 100.0;
                return new AdjustmentSpec { Kind = "levels", P = D(("ib", ib), ("iw", iw), ("g", g <= 0 ? 1 : g), ("ob", ob), ("ow", ow)) };
            }
            case "curv":
            {
                bool isMap = r.U8() != 0;
                ushort version = r.U16();
                uint map = r.U32();
                var pts = new List<Point>();
                if ((map & 1) != 0)
                {
                    if (isMap)
                    {
                        var lut = r.Bytes(256);
                        for (int i = 0; i < 256; i += 32) pts.Add(new Point(i, lut[i]));
                        pts.Add(new Point(255, lut[255]));
                    }
                    else
                    {
                        int n = r.U16();
                        for (int i = 0; i < n; i++) { double outV = r.U16(), inV = r.U16(); pts.Add(new Point(inV, outV)); }
                    }
                }
                if (pts.Count < 2) pts = new List<Point> { new(0, 0), new(255, 255) };
                return new AdjustmentSpec { Kind = "curves", Curve = pts };
            }
            case "expA":
            {
                r.U16();
                double e = r.F32(), o = r.F32(), g = r.F32();
                return new AdjustmentSpec { Kind = "exposure", P = D(("e", e), ("o", o), ("g", g <= 0 ? 1 : g)) };
            }
            case "vibA":
            {
                r.U32();
                var d = Descriptor.Read(r);
                return new AdjustmentSpec { Kind = "vibrance", P = D(("v", d.Num("vibrance")), ("s", d.Num("Strt"))) };
            }
            case "hue2":
            case "hue ":
            {
                r.U16();
                bool colorize = r.U8() != 0;
                r.U8();
                double ch = r.I16(), cs = r.I16(), cl = r.I16();
                double h = r.I16(), s = r.I16(), l = r.I16();
                return colorize
                    ? new AdjustmentSpec { Kind = "huesat", P = D(("h", ch), ("s", cs), ("l", cl), ("c", 1)) }
                    : new AdjustmentSpec { Kind = "huesat", P = D(("h", h), ("s", s), ("l", l), ("c", 0)) };
            }
            case "blnc":
            {
                r.Skip(6);
                double cr = r.I16(), mg = r.I16(), yb = r.I16();
                r.Skip(6);
                bool preserve = r.Pos < r.Length && r.U8() != 0;
                return new AdjustmentSpec { Kind = "colorbalance", P = D(("r", cr), ("g", mg), ("b", yb), ("p", preserve ? 1 : 0)) };
            }
            case "blwh":
            {
                r.U32();
                var d = Descriptor.Read(r);
                return new AdjustmentSpec
                {
                    Kind = "bw",
                    P = D(("r", d.Num("Rd  ", 40)), ("y", d.Num("Yllw", 60)), ("g", d.Num("Grn ", 40)), ("c", d.Num("Cyn ", 60)), ("b", d.Num("Bl  ", 20)), ("m", d.Num("Mgnt", 80)))
                };
            }
            case "phfl":
            {
                int ver = r.U16();
                Color c = Color.FromRgb(236, 138, 0);
                if (ver == 3)
                {
                    // XYZ (fixed 16.16) → approximate sRGB
                    double X = r.I32() / 65536.0 / 100, Y = r.I32() / 65536.0 / 100, Z = r.I32() / 65536.0 / 100;
                    c = XyzToRgb(X, Y, Z);
                }
                else
                {
                    int space = r.U16();
                    int a = r.U16(), b = r.U16(), cc = r.U16(); r.U16();
                    if (space == 0) c = Color.FromRgb((byte)(a / 257), (byte)(b / 257), (byte)(cc / 257));
                }
                double density = r.I32();
                bool preserve = r.U8() != 0;
                return new AdjustmentSpec { Kind = "photofilter", P = D(("d", density), ("l", preserve ? 1 : 0)), C1 = c };
            }
            case "nvrt": return new AdjustmentSpec { Kind = "invert" };
            case "post": return new AdjustmentSpec { Kind = "posterize", P = D(("l", Math.Max(2, (int)r.U16()))) };
            case "thrs": return new AdjustmentSpec { Kind = "threshold", P = D(("t", r.U16())) };
            case "grdm":
            {
                r.U16();
                bool reversed = r.U8() != 0;
                r.U8();
                r.Unicode();
                int n = r.U16();
                var stops = new List<(uint loc, Color c)>();
                for (int i = 0; i < n; i++)
                {
                    uint loc = r.U32(); r.U32();
                    int mode = r.U16();
                    int a = r.U16(), b = r.U16(), cc = r.U16(), d = r.U16();
                    r.U16();
                    var col = mode == 0 ? Color.FromRgb((byte)(a / 257), (byte)(b / 257), (byte)(cc / 257)) : mode == 8 ? Color.FromRgb((byte)(a / 39.2), (byte)(a / 39.2), (byte)(a / 39.2)) : Colors.Gray;
                    stops.Add((loc, col));
                }
                if (stops.Count == 0) return AdjustmentSpec.Default("gradientmap");
                stops.Sort((x, y) => x.loc.CompareTo(y.loc));
                var c1 = stops[0].c; var c2 = stops[^1].c;
                if (reversed) (c1, c2) = (c2, c1);
                return new AdjustmentSpec { Kind = "gradientmap", C1 = c1, C2 = c2 };
            }
        }
        return null;
    }

    static Color XyzToRgb(double x, double y, double z)
    {
        double r = 3.2406 * x - 1.5372 * y - 0.4986 * z, g = -0.9689 * x + 1.8758 * y + 0.0415 * z, b = 0.0557 * x - 0.2040 * y + 1.0570 * z;
        byte C(double v) { v = v <= 0.0031308 ? 12.92 * v : 1.055 * Math.Pow(Math.Max(0, v), 1 / 2.4) - 0.055; return (byte)Math.Clamp(Math.Round(v * 255), 0, 255); }
        return Color.FromRgb(C(r), C(g), C(b));
    }

    /// <summary>Encode a spec as Photoshop adjustment block(s).</summary>
    public static List<PsdBlock> Encode(AdjustmentSpec s)
    {
        var list = new List<PsdBlock>();
        var w = new BeWriter(256);
        short S(double v, int lo, int hi) => (short)Math.Clamp((int)Math.Round(v), lo, hi);
        switch (s.Kind)
        {
            case "brightness":
            {
                w.I16(S(s["b"], -150, 150)); w.I16(S(s["c"], -50, 100)); w.I16(127); w.U8(0); w.U8(0);
                list.Add(new("brit", w.ToArray()));
                var cw = new BeWriter(256);
                cw.U32(16);
                var d = new Descriptor();
                d["Vrsn"] = 1; d["Brgh"] = (int)Math.Round(s["b"]); d["Cntr"] = (int)Math.Round(s["c"]); d["means"] = 127;
                d["Lab "] = false; d["useLegacy"] = false; d["Auto"] = false;
                d.Write(cw);
                list.Add(new("CgEd", cw.ToArray()));
                return list;
            }
            case "levels":
            {
                w.U16(2);
                w.I16(S(s["ib"], 0, 253)); w.I16(S(s.P.ContainsKey("iw") ? s["iw"] : 255, 2, 255));
                w.I16(S(s["ob"], 0, 255)); w.I16(S(s.P.ContainsKey("ow") ? s["ow"] : 255, 0, 255));
                w.I16(S((s.P.ContainsKey("g") ? s["g"] : 1) * 100, 10, 999));
                for (int i = 1; i < 29; i++) { w.I16(0); w.I16(255); w.I16(0); w.I16(255); w.I16(100); }
                list.Add(new("levl", w.ToArray()));
                return list;
            }
            case "curves":
            {
                var pts = (s.Curve ?? new List<Point> { new(0, 0), new(255, 255) }).OrderBy(p => p.X).ToList();
                w.U8(0); w.U16(1); w.U32(1);
                w.U16(pts.Count);
                foreach (var p in pts) { w.U16(S(p.Y, 0, 255)); w.U16(S(p.X, 0, 255)); }
                list.Add(new("curv", w.ToArray()));
                return list;
            }
            case "exposure":
                w.U16(1); w.F32((float)s["e"]); w.F32((float)s["o"]); w.F32((float)(s.P.ContainsKey("g") ? s["g"] : 1));
                list.Add(new("expA", w.ToArray()));
                return list;
            case "vibrance":
            {
                w.U32(16);
                var d = new Descriptor();
                d["vibrance"] = (int)Math.Round(s["v"]);
                d["Strt"] = (int)Math.Round(s["s"]);
                d.Write(w);
                list.Add(new("vibA", w.ToArray()));
                return list;
            }
            case "huesat":
            {
                bool colorize = s.B("c");
                w.U16(2); w.U8(colorize ? 1 : 0); w.U8(0);
                if (colorize) { w.I16(S(s["h"], -180, 360)); w.I16(S(s["s"], 0, 100)); w.I16(S(s["l"], -100, 100)); w.I16(0); w.I16(0); w.I16(0); }
                else { w.I16(0); w.I16(25); w.I16(0); w.I16(S(s["h"], -180, 180)); w.I16(S(s["s"], -100, 100)); w.I16(S(s["l"], -100, 100)); }
                int[][] ranges = { new[] { 315, 345, 15, 45 }, new[] { 15, 45, 75, 105 }, new[] { 75, 105, 135, 165 }, new[] { 135, 165, 195, 225 }, new[] { 195, 225, 255, 285 }, new[] { 255, 285, 315, 345 } };
                foreach (var rg in ranges) { foreach (var v in rg) w.I16(v); w.I16(0); w.I16(0); w.I16(0); }
                list.Add(new("hue2", w.ToArray()));
                return list;
            }
            case "colorbalance":
                w.I16(0); w.I16(0); w.I16(0);
                w.I16(S(s["r"], -100, 100)); w.I16(S(s["g"], -100, 100)); w.I16(S(s["b"], -100, 100));
                w.I16(0); w.I16(0); w.I16(0);
                w.U8(!s.P.ContainsKey("p") || s.B("p") ? 1 : 0); w.U8(0);
                list.Add(new("blnc", w.ToArray()));
                return list;
            case "bw":
            {
                w.U32(16);
                var d = new Descriptor();
                d["Rd  "] = (int)Math.Round(s["r"]); d["Yllw"] = (int)Math.Round(s["y"]); d["Grn "] = (int)Math.Round(s["g"]);
                d["Cyn "] = (int)Math.Round(s["c"]); d["Bl  "] = (int)Math.Round(s["b"]); d["Mgnt"] = (int)Math.Round(s["m"]);
                d["useTint"] = false;
                var tint = new Descriptor { ClassId = "RGBC" };
                tint["Rd  "] = 225.0; tint["Grn "] = 211.0; tint["Bl  "] = 179.0;
                d["tintColor"] = tint;
                d["bwPresetKind"] = 1;
                d["blackAndWhitePresetFileName"] = "";
                d.Write(w);
                list.Add(new("blwh", w.ToArray()));
                return list;
            }
            case "photofilter":
                w.U16(2); w.U16(0);
                w.U16(s.C1.R * 257); w.U16(s.C1.G * 257); w.U16(s.C1.B * 257); w.U16(0);
                w.I32((int)Math.Round(s.P.ContainsKey("d") ? s["d"] : 25));
                w.U8(!s.P.ContainsKey("l") || s.B("l") ? 1 : 0); w.U8(0);
                list.Add(new("phfl", w.ToArray()));
                return list;
            case "invert":
                list.Add(new("nvrt", Array.Empty<byte>()));
                return list;
            case "posterize":
                w.U16(Math.Clamp((int)s["l"], 2, 255)); w.U16(0);
                list.Add(new("post", w.ToArray()));
                return list;
            case "threshold":
                w.U16(Math.Clamp((int)(s.P.ContainsKey("t") ? s["t"] : 128), 1, 255)); w.U16(0);
                list.Add(new("thrs", w.ToArray()));
                return list;
            case "gradientmap":
            {
                w.U16(1); w.U8(0); w.U8(0);
                w.Unicode("Custom");
                w.U16(2);
                foreach (var (loc, c) in new[] { (0u, s.C1), (4096u, s.C2) })
                {
                    w.U32(loc); w.U32(50);
                    w.U16(0); w.U16(c.R * 257); w.U16(c.G * 257); w.U16(c.B * 257); w.U16(0);
                    w.U16(0);
                }
                w.U16(2);
                foreach (var loc in new[] { 0u, 4096u }) { w.U32(loc); w.U32(50); w.U16(255); }
                w.U16(2); w.U16(4096); w.U16(32); w.U16(0); w.U32(0); w.U16(0); w.U16(0); w.U32(2048);
                w.U16(3);
                for (int i = 0; i < 4; i++) w.U16(0);
                for (int i = 0; i < 4; i++) w.U16(32768);
                w.U16(0);
                list.Add(new("grdm", w.ToArray()));
                return list;
            }
        }
        return list;
    }
}

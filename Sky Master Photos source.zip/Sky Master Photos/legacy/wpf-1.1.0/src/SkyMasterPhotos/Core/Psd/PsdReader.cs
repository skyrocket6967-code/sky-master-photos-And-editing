using System.IO;
using System.Windows;
using System.Windows.Media;

namespace SkyMasterPhotos.Core.Psd;

public sealed class PsdReadResult
{
    public Document Doc;
    /// <summary>Photoshop's own merged image (null if the file has none).</summary>
    public uint[] Composite;
    public int Width, Height, Depth, ColorMode, Version, Channels;
    public List<string> Warnings = new();
    public int LayerRecordCount;
}

/// <summary>
/// Reads Adobe Photoshop documents (.psd and .psb) into an editable <see cref="Document"/>.
/// Written against Adobe's "Photoshop File Formats Specification".
/// </summary>
public static class PsdReader
{
    sealed class MaskInfo
    {
        public int T, L, B, R, RT, RL, RB, RR;
        public byte Def = 255, RDef = 255;
        public byte Flags, RFlags;
        public bool HasReal;
    }

    sealed class Rec
    {
        public int Top, Left, Bottom, Right;
        public readonly List<(short id, long len)> Ch = new();
        public string Blend = "norm";
        public byte Opacity = 255, Clipping, Flags;
        public MaskInfo Mask;
        public string Name = "";
        public readonly List<PsdBlock> Blocks = new();
        public readonly Dictionary<short, byte[]> Planes = new();
        public int Width => Right - Left;
        public int Height => Bottom - Top;
        public PsdBlock Block(string key) => Blocks.FirstOrDefault(b => b.Key == key);
    }

    public static PsdReadResult Read(string path) => Read(File.ReadAllBytes(path), Path.GetFileName(path));

    /// <summary>Fast path for thumbnails: only the merged image.</summary>
    public static (uint[] px, int w, int h) ReadComposite(string path)
    {
        var res = Read(File.ReadAllBytes(path), Path.GetFileName(path), compositeOnly: true);
        return (res.Composite, res.Width, res.Height);
    }

    public static PsdReadResult Read(byte[] data, string title, bool compositeOnly = false)
    {
        var r = new BeReader(data);
        var res = new PsdReadResult();
        if (r.Sig() != "8BPS") throw new InvalidDataException("Not a Photoshop file (missing 8BPS signature).");
        int version = r.U16();
        if (version != 1 && version != 2) throw new InvalidDataException($"Unsupported PSD version {version}.");
        bool psb = version == 2;
        r.Skip(6);
        int channels = r.U16();
        int h = (int)r.U32(), w = (int)r.U32();
        int depth = r.U16();
        int mode = r.U16();
        res.Width = w; res.Height = h; res.Depth = depth; res.ColorMode = mode; res.Version = version; res.Channels = channels;
        if ((long)w * h > 400_000_000) throw new InvalidDataException($"Image is too large ({w} × {h}).");
        if (depth != 1 && depth != 8 && depth != 16 && depth != 32) throw new InvalidDataException($"Unsupported bit depth {depth}.");

        // color mode data (palette for indexed)
        var colorData = r.Bytes(r.U32());

        // image resources
        long resLen = r.U32();
        long resEnd = r.Pos + resLen;
        bool noRealMerged = false;
        var docData = new PsdDocData { SourceInfo = $"{PsdFormat.ModeName(mode)} {depth}-bit, {(psb ? "PSB" : "PSD")}" };
        while (r.Pos + 12 <= resEnd)
        {
            var sig = r.Sig();
            if (sig != "8BIM" && sig != "MeSa" && sig != "AgHg" && sig != "PHUT" && sig != "DCSR") break;
            ushort id = r.U16();
            r.Pascal(2);
            long size = r.U32();
            var payload = r.Bytes(Math.Min(size, resEnd - r.Pos));
            if ((size & 1) == 1 && r.Pos < resEnd) r.Skip(1);
            if (PsdFormat.SafeResources.Contains(id)) docData.Resources.Add((id, payload));
            if (id == 1057 && payload.Length >= 5 && payload[4] == 0) noRealMerged = true; // saved without "Maximize Compatibility"
            if (id == 1039 && mode == PsdFormat.ModeRgb) docData.Resources.Add((id, payload)); // ICC profile only valid for RGB sources
        }
        r.Pos = resEnd;

        // layer and mask information
        long lmLen = r.Len(psb);
        long lmEnd = r.Pos + lmLen;
        var records = new List<Rec>();
        bool mergedAlpha = false;
        if (!compositeOnly && lmLen > 0)
        {
            long liLen = r.Len(psb);
            long liEnd = r.Pos + liLen;
            if (liLen > 0)
            {
                records = ReadLayerInfo(r, liEnd, psb, depth, out mergedAlpha, res.Warnings);
                r.Pos = liEnd;
            }
            if (r.Pos + 4 <= lmEnd)
            {
                long gmLen = r.U32();
                r.Pos = Math.Min(lmEnd, r.Pos + gmLen);
            }
            // global additional layer information
            foreach (var blk in ReadBlocks(r, lmEnd, psb))
            {
                if ((blk.Key == "Lr16" || blk.Key == "Lr32" || blk.Key == "Layr") && records.Count == 0)
                {
                    var sub = new BeReader(blk.Data);
                    records = ReadLayerInfo(sub, blk.Data.Length, psb, depth, out mergedAlpha, res.Warnings);
                }
                else if (!PsdFormat.DroppedGlobals.Contains(blk.Key)) docData.GlobalBlocks.Add(blk);
            }
        }
        r.Pos = lmEnd;

        // merged image data
        uint[] composite = null;
        try
        {
            if (r.Pos + 2 <= r.Length) composite = ReadComposite(r, w, h, depth, mode, channels, psb, colorData, mergedAlpha || records.Count == 0);
        }
        catch (Exception ex) { res.Warnings.Add("Merged image unreadable: " + ex.Message); }
        if (noRealMerged && records.Count > 0) composite = null;
        res.Composite = composite;
        if (compositeOnly) return res;

        res.LayerRecordCount = records.Count;
        res.Doc = BuildDocument(records, w, h, depth, mode, composite, title, docData, res.Warnings);
        return res;
    }

    // ───────────────────────────── layer info ─────────────────────────────

    static List<Rec> ReadLayerInfo(BeReader r, long end, bool psb, int depth, out bool mergedAlpha, List<string> warnings)
    {
        int count = r.I16();
        mergedAlpha = count < 0;
        count = Math.Abs(count);
        var recs = new List<Rec>(count);
        for (int i = 0; i < count; i++) recs.Add(ReadRecord(r, psb));
        foreach (var rec in recs)
        {
            foreach (var (id, len) in rec.Ch)
            {
                if (len < 2) { r.Skip(len); continue; }
                long start = r.Pos;
                int comp = r.U16();
                int cw = rec.Width, ch = rec.Height;
                if (id == -2 && rec.Mask != null) { cw = rec.Mask.R - rec.Mask.L; ch = rec.Mask.B - rec.Mask.T; }
                if (id == -3 && rec.Mask != null) { cw = rec.Mask.RR - rec.Mask.RL; ch = rec.Mask.RB - rec.Mask.RT; }
                try
                {
                    if (cw > 0 && ch > 0)
                    {
                        var plane = Codec.Decode(r, comp, len - 2, cw, ch, depth, psb);
                        rec.Planes[id] = Codec.To8(plane, cw, ch, depth, id >= 0);
                    }
                }
                catch (Exception ex) { warnings.Add($"Layer “{rec.Name}” channel {id}: {ex.Message}"); }
                r.Pos = start + len;
            }
        }
        return recs;
    }

    static Rec ReadRecord(BeReader r, bool psb)
    {
        var rec = new Rec { Top = r.I32(), Left = r.I32(), Bottom = r.I32(), Right = r.I32() };
        int nch = r.U16();
        for (int i = 0; i < nch; i++) rec.Ch.Add((r.I16(), r.Len(psb)));
        var sig = r.Sig();
        if (sig != "8BIM") throw new InvalidDataException("Bad layer record signature.");
        rec.Blend = r.Sig();
        rec.Opacity = r.U8();
        rec.Clipping = r.U8();
        rec.Flags = r.U8();
        r.U8();
        long extraLen = r.U32();
        long extraEnd = r.Pos + extraLen;

        long maskLen = r.U32();
        if (maskLen > 0)
        {
            long ms = r.Pos;
            var m = new MaskInfo { T = r.I32(), L = r.I32(), B = r.I32(), R = r.I32(), Def = r.U8(), Flags = r.U8() };
            if (maskLen >= 36)
            {
                m.RFlags = r.U8(); m.RDef = r.U8();
                m.RT = r.I32(); m.RL = r.I32(); m.RB = r.I32(); m.RR = r.I32();
                m.HasReal = true;
            }
            rec.Mask = m;
            r.Pos = ms + maskLen;
        }
        long brLen = r.U32();
        r.Skip(brLen);
        rec.Name = r.Pascal(4);
        if (r.Pos < extraEnd) rec.Blocks.AddRange(ReadBlocks(r, extraEnd, psb));
        r.Pos = extraEnd;
        return rec;
    }

    /// <summary>Tagged blocks ("additional layer information"), tolerant of 1/2/4-byte padding variants.</summary>
    static List<PsdBlock> ReadBlocks(BeReader r, long end, bool psb)
    {
        var list = new List<PsdBlock>();
        while (r.Pos + 12 <= end)
        {
            var sig = r.PeekSig();
            if (sig != "8BIM" && sig != "8B64")
            {
                // realign over padding bytes
                bool found = false;
                for (int k = 1; k <= 3 && r.Pos + k + 4 <= end; k++)
                {
                    long save = r.Pos;
                    r.Pos += k;
                    var s2 = r.PeekSig();
                    if (s2 == "8BIM" || s2 == "8B64") { found = true; break; }
                    r.Pos = save;
                }
                if (!found) break;
            }
            r.Sig();
            var key = r.Sig();
            long len = psb && PsdFormat.BigKeys.Contains(key) ? (long)r.U64() : r.U32();
            if (len < 0 || r.Pos + len > end) break;
            list.Add(new PsdBlock(key, r.Bytes(len)));
        }
        return list;
    }

    // ───────────────────────────── composite ─────────────────────────────

    static uint[] ReadComposite(BeReader r, int w, int h, int depth, int mode, int channels, bool psb, byte[] palette, bool useAlpha)
    {
        int comp = r.U16();
        int bpp = Math.Max(1, depth / 8);
        int rowBytes = depth == 1 ? (w + 7) / 8 : w * bpp;
        var planes = new byte[channels][];
        if (comp == 1)
        {
            var counts = new int[channels * h];
            for (int i = 0; i < counts.Length; i++) counts[i] = psb ? (int)r.U32() : r.U16();
            for (int c = 0; c < channels; c++)
            {
                var plane = new byte[(long)rowBytes * h];
                for (int y = 0; y < h; y++) Codec.UnpackBits(r.Span(counts[c * h + y]), plane.AsSpan(y * rowBytes, rowBytes));
                planes[c] = plane;
            }
        }
        else if (comp == 0)
        {
            for (int c = 0; c < channels; c++) planes[c] = r.Bytes((long)rowBytes * h);
        }
        else
        {
            // ZIP-compressed merged data: one stream for all channels
            var plane = Codec.Decode(r, comp, r.Length - r.Pos, w, h * channels, depth, psb);
            for (int c = 0; c < channels; c++) { planes[c] = new byte[(long)rowBytes * h]; Array.Copy(plane, (long)c * rowBytes * h, planes[c], 0, planes[c].Length); }
        }
        var ch8 = planes.Select((p, i) => Codec.To8(p, w, h, depth, IsColorChannel(mode, i))).ToArray();
        int colorCount = ColorChannelCount(mode);
        byte[] alpha = useAlpha && channels > colorCount ? ch8[colorCount] : null;
        var px = new uint[w * h];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                int i = y * w + x;
                uint c = ToRgb(mode, ch8, i, palette);
                int a = alpha != null ? alpha[i] : 255;
                px[i] = (c & 0x00FFFFFF) | (uint)a << 24;
            }
        });
        return px;
    }

    static int ColorChannelCount(int mode) => mode switch
    {
        PsdFormat.ModeRgb => 3, PsdFormat.ModeCmyk => 4, PsdFormat.ModeLab => 3, _ => 1
    };

    static bool IsColorChannel(int mode, int index) => index < ColorChannelCount(mode);

    static uint ToRgb(int mode, byte[][] ch, int i, byte[] palette)
    {
        byte C(int k) => k < ch.Length && ch[k] != null ? ch[k][i] : (byte)0;
        switch (mode)
        {
            case PsdFormat.ModeRgb:
                return Px.Pack(255, C(0), C(1), C(2));
            case PsdFormat.ModeCmyk:
            {
                // PSD stores CMYK inverted (255 = no ink)
                int k = C(3);
                return Px.Pack(255, C(0) * k / 255, C(1) * k / 255, C(2) * k / 255);
            }
            case PsdFormat.ModeLab:
                return LabToRgb(C(0), C(1), C(2));
            case PsdFormat.ModeIndexed:
            {
                int idx = C(0);
                if (palette != null && palette.Length >= 768) return Px.Pack(255, palette[idx], palette[256 + idx], palette[512 + idx]);
                return Px.Pack(255, idx, idx, idx);
            }
            default:
            {
                int v = C(0);
                return Px.Pack(255, v, v, v);
            }
        }
    }

    static uint LabToRgb(byte L8, byte a8, byte b8)
    {
        double L = L8 * 100.0 / 255, a = a8 - 128, b = b8 - 128;
        double fy = (L + 16) / 116, fx = fy + a / 500, fz = fy - b / 200;
        double F(double t) => t > 6.0 / 29 ? t * t * t : 3 * (6.0 / 29) * (6.0 / 29) * (t - 4.0 / 29);
        double X = 0.95047 * F(fx), Y = F(fy), Z = 1.08883 * F(fz);
        double r = 3.2406 * X - 1.5372 * Y - 0.4986 * Z, g = -0.9689 * X + 1.8758 * Y + 0.0415 * Z, bl = 0.0557 * X - 0.2040 * Y + 1.0570 * Z;
        int G(double v) { v = v <= 0.0031308 ? 12.92 * v : 1.055 * Math.Pow(Math.Max(0, v), 1 / 2.4) - 0.055; return Px.Clamp(v * 255); }
        return Px.Pack(255, G(r), G(g), G(bl));
    }

    // ───────────────────────────── document ─────────────────────────────

    sealed class Frame
    {
        public readonly List<Layer> Layers = new();
        public readonly Dictionary<string, GroupInfo> Groups = new();
    }

    static Document BuildDocument(List<Rec> records, int w, int h, int depth, int mode, uint[] composite, string title, PsdDocData docData, List<string> warnings)
    {
        var doc = new Document(w, h, title, "Open");
        doc.PsdData = docData;
        var stack = new Stack<Frame>();
        var root = new Frame();
        stack.Push(root);

        foreach (var rec in records)
        {
            var lsct = rec.Block("lsct") ?? rec.Block("lsdk");
            int sectionType = 0;
            string groupBlend = null;
            if (lsct != null && lsct.Data.Length >= 4)
            {
                var br = new BeReader(lsct.Data);
                sectionType = (int)br.U32();
                if (lsct.Data.Length >= 12) { br.Sig(); groupBlend = br.Sig(); }
            }
            if (sectionType == 3)
            {
                stack.Push(new Frame());
                continue;
            }
            if (sectionType == 1 || sectionType == 2)
            {
                if (stack.Count == 1) { warnings.Add($"Group “{rec.Name}” has no start marker"); continue; }
                var frame = stack.Pop();
                var parent = stack.Peek();
                string name = UnicodeName(rec);
                string unique = name;
                int n = 2;
                while (parent.Groups.ContainsKey(unique) || parent.Layers.Any(l => l.Group == unique || l.Group.StartsWith(unique + "/"))) unique = $"{name} ({n++})";
                var info = new GroupInfo(name, (rec.Flags & 2) == 0, rec.Opacity / 255.0, groupBlend ?? rec.Blend, sectionType == 1)
                {
                    Blocks = rec.Blocks.Where(b => !PsdFormat.Regenerated.Contains(b.Key)).ToList()
                };
                parent.Groups[unique] = info;
                foreach (var (k, v) in frame.Groups) parent.Groups[unique + "/" + k] = v;
                foreach (var l in frame.Layers)
                {
                    l.Group = string.IsNullOrEmpty(l.Group) ? unique : unique + "/" + l.Group;
                    parent.Layers.Add(l);
                }
                continue;
            }
            try { stack.Peek().Layers.Add(BuildLayer(rec, w, h, mode, warnings)); }
            catch (Exception ex) { warnings.Add($"Layer “{rec.Name}” skipped: {ex.Message}"); }
        }
        // unterminated groups: flatten into parents
        while (stack.Count > 1)
        {
            var f = stack.Pop();
            stack.Peek().Layers.AddRange(f.Layers);
            foreach (var (k, v) in f.Groups) stack.Peek().Groups[k] = v;
        }

        var all = root.Layers;
        if (all.Count == 0)
        {
            var px = composite ?? new uint[w * h];
            var bg = new Layer("Background", w, h, px);
            all.Add(bg);
        }
        for (int i = all.Count - 1; i >= 0; i--) doc.Layers.Add(all[i]); // top first
        doc.Groups = root.Groups;
        doc.ActiveLayer = doc.Layers.FirstOrDefault(l => !l.IsAdjustmentLike && l.Visible) ?? doc.Layers.FirstOrDefault(l => !l.IsAdjustmentLike) ?? doc.Layers[0];
        foreach (var l in doc.Layers) if (l.Psd != null) l.Psd.SourceHash = PsdLayerData.Hash(l.Pixels, l.Mask);
        return doc;
    }

    static string UnicodeName(Rec rec)
    {
        var b = rec.Block("luni");
        if (b != null)
        {
            try { return new BeReader(b.Data).Unicode(); } catch { }
        }
        return rec.Name;
    }

    static Layer BuildLayer(Rec rec, int w, int h, int mode, List<string> warnings)
    {
        var name = UnicodeName(rec);
        var px = new uint[w * h];
        int colorCount = ColorChannelCount(mode);
        bool hasColor = Enumerable.Range(0, colorCount).Any(c => rec.Planes.ContainsKey((short)c));
        if (hasColor)
        {
            var ch = new byte[Math.Max(colorCount, 4)][];
            for (int c = 0; c < colorCount; c++) rec.Planes.TryGetValue((short)c, out ch[c]);
            rec.Planes.TryGetValue(-1, out var alpha);
            int rw = rec.Width;
            int y0 = Math.Max(0, rec.Top), y1 = Math.Min(h, rec.Bottom), x0 = Math.Max(0, rec.Left), x1 = Math.Min(w, rec.Right);
            Parallel.For(y0, Math.Max(y0, y1), y =>
            {
                for (int x = x0; x < x1; x++)
                {
                    int li = (y - rec.Top) * rw + (x - rec.Left);
                    uint c = ToRgb(mode, ch, li, null);
                    int a = alpha != null ? alpha[li] : 255;
                    px[y * w + x] = (c & 0x00FFFFFF) | (uint)a << 24;
                }
            });
            if (rec.Left < 0 || rec.Top < 0 || rec.Right > w || rec.Bottom > h) warnings.Add($"Layer “{name}” extends past the canvas — off-canvas pixels were cropped");
        }

        var layer = new Layer(name, w, h, px)
        {
            Visible = (rec.Flags & 2) == 0,
            Opacity = rec.Opacity / 255.0,
            Clipped = rec.Clipping != 0,
        };
        var blend = PsdFormat.FromKey(rec.Blend, out bool exact);
        layer.Blend = blend;
        if (!exact) warnings.Add($"Layer “{name}”: blend mode '{rec.Blend.Trim()}' approximated as {BlendModeInfo.Name(blend)}");

        var psd = new PsdLayerData { BlendKey = rec.Blend, BlendAtImport = blend, RecordFlags = rec.Flags };
        foreach (var b in rec.Blocks)
        {
            switch (b.Key)
            {
                case "lsct":
                case "lsdk":
                    break;
                case "luni":
                    psd.Blocks.Add(b);
                    break;
                case "iOpa":
                    if (b.Data.Length >= 1) layer.Fill = b.Data[0] / 255.0;
                    psd.Blocks.Add(b);
                    break;
                case "lspf":
                    if (b.Data.Length >= 4)
                    {
                        uint f = (uint)(b.Data[0] << 24 | b.Data[1] << 16 | b.Data[2] << 8 | b.Data[3]);
                        if ((f & 0x80000000) != 0) layer.Locked = true;
                        psd.Blocks.Add(b); // partial lock bits are kept; the writer refreshes 'lock all'
                    }
                    break;
                default:
                    psd.Blocks.Add(b);
                    break;
            }
        }

        // mask
        if (rec.Mask != null)
        {
            var m = rec.Mask;
            bool useReal = rec.Planes.ContainsKey(-3) && m.HasReal;
            short id = useReal ? (short)-3 : (short)-2;
            int mt = useReal ? m.RT : m.T, ml = useReal ? m.RL : m.L, mb = useReal ? m.RB : m.B, mr = useReal ? m.RR : m.R;
            byte def = useReal ? m.RDef : m.Def;
            byte flags = useReal ? m.RFlags : m.Flags;
            rec.Planes.TryGetValue(id, out var plane);
            var mask = Layer.NewMask(w, h, def);
            if (plane != null)
            {
                int mw = mr - ml;
                for (int y = Math.Max(0, mt); y < Math.Min(h, mb); y++)
                    for (int x = Math.Max(0, ml); x < Math.Min(w, mr); x++)
                        mask[y * w + x] = Masks.Gray(plane[(y - mt) * mw + (x - ml)]);
            }
            layer.SetMask(mask);
            layer.MaskEnabled = (flags & 2) == 0;
        }
        // content kinds
        var all = rec.Blocks;
        var adjBlock = all.FirstOrDefault(b => PsdAdjust.Supported.Contains(b.Key));
        var unrendered = all.FirstOrDefault(b => PsdAdjust.Unrendered.ContainsKey(b.Key));
        if (adjBlock != null)
        {
            try
            {
                var spec = PsdAdjust.Decode(adjBlock.Key, adjBlock.Data, all);
                if (spec != null) { layer.Adjustment = spec; psd.ImportedAdjustment = spec; }
            }
            catch (Exception ex)
            {
                warnings.Add($"Adjustment “{name}” could not be decoded ({ex.Message}); kept for export but not rendered");
                psd.UnrenderedAdjustment = true;
                psd.KindLabel = "Adjustment (preserved)";
            }
        }
        else if (unrendered != null)
        {
            psd.UnrenderedAdjustment = true;
            psd.KindLabel = PsdAdjust.Unrendered[unrendered.Key] + " (preserved, not rendered)";
            warnings.Add($"“{name}”: {PsdAdjust.Unrendered[unrendered.Key]} adjustments are preserved for Photoshop but not rendered");
        }

        var tysh = all.FirstOrDefault(b => b.Key == "TySh");
        if (tysh != null)
        {
            try
            {
                var spec = PsdText.Parse(tysh.Data, rec.Left, rec.Top);
                layer.Text = spec;
                psd.ImportedText = spec;
            }
            catch (Exception ex) { warnings.Add($"Text “{name}”: {ex.Message}"); psd.KindLabel = "Text (raster)"; }
        }
        if (all.Any(b => b.Key is "SoLd" or "PlLd" or "SoLE")) psd.KindLabel = "Smart Object";
        else if (all.Any(b => b.Key is "vmsk" or "vsms") && all.Any(b => b.Key is "SoCo" or "GdFl" or "PtFl" or "vscg")) psd.KindLabel = "Shape";
        else if (all.Any(b => b.Key == "SoCo"))
        {
            psd.KindLabel = "Color Fill";
            if (!hasColor) RenderSolidFill(all.First(b => b.Key == "SoCo"), px);
        }
        else if (all.Any(b => b.Key == "GdFl")) psd.KindLabel = "Gradient Fill";
        else if (all.Any(b => b.Key == "PtFl")) psd.KindLabel = "Pattern Fill";
        if (psd.HasEffects) warnings.Add($"“{name}”: layer effects are preserved for Photoshop but not rendered");

        layer.Psd = psd;
        return layer;
    }

    static void RenderSolidFill(PsdBlock soco, uint[] px)
    {
        try
        {
            var r = new BeReader(soco.Data);
            r.U32();
            var d = Descriptor.Read(r);
            var c = d.Obj("Clr ");
            if (c == null) return;
            uint col = Px.Pack(255, Px.Clamp(c.Num("Rd  ")), Px.Clamp(c.Num("Grn ")), Px.Clamp(c.Num("Bl  ")));
            Array.Fill(px, col);
        }
        catch { }
    }
}

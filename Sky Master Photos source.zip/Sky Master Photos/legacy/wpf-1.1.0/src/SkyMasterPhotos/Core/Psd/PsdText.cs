using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Media;

namespace SkyMasterPhotos.Core.Psd;

/// <summary>Extracts editable text information from Photoshop type layers ('TySh').</summary>
public static class PsdText
{
    static HashSet<string> _families;

    public static TextSpec Parse(byte[] tysh, int layerLeft, int layerTop)
    {
        var r = new BeReader(tysh);
        r.U16();
        double xx = r.F64(), xy = r.F64(), yx = r.F64(), yy = r.F64(), tx = r.F64(), ty = r.F64();
        r.U16();
        r.U32();
        var d = Descriptor.Read(r);
        string text = (d.Str("Txt ") ?? "").Replace("\r", "\n").TrimEnd('\n');
        double scale = Math.Sqrt(Math.Abs(xx * yy - xy * yx));
        if (scale <= 0) scale = 1;

        double size = 24;
        Color color = Colors.Black;
        string font = "Segoe UI";
        bool bold = false, italic = false;
        if (d["EngineData"] is byte[] eng)
        {
            var s = Encoding.Latin1.GetString(eng);
            var m = Regex.Match(s, @"/FontSize\s+([\d.]+)");
            if (m.Success && double.TryParse(m.Groups[1].Value, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out var fs)) size = fs;
            var c = Regex.Match(s, @"/FillColor\s*<<\s*/Type\s+1\s*/Values\s*\[\s*([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)\s+([\d.\-]+)");
            if (c.Success)
            {
                byte V(int g) => (byte)Math.Clamp(Math.Round(double.Parse(c.Groups[g].Value, System.Globalization.CultureInfo.InvariantCulture) * 255), 0, 255);
                color = Color.FromRgb(V(2), V(3), V(4));
            }
            var names = FontNames(eng);
            int fontIndex = 0;
            var fi = Regex.Match(s, @"/StyleRun.*?/Font\s+(\d+)", RegexOptions.Singleline);
            if (fi.Success) int.TryParse(fi.Groups[1].Value, out fontIndex);
            var ps = fontIndex < names.Count ? names[fontIndex] : names.FirstOrDefault(n => !n.StartsWith("AdobeInvis"));
            if (ps != null) (font, bold, italic) = MapPostScriptName(ps);
            if (Regex.IsMatch(s, @"/FauxBold\s+true")) bold = true;
            if (Regex.IsMatch(s, @"/FauxItalic\s+true")) italic = true;
        }
        size *= scale;
        // ty is the baseline of the first line; FormattedText draws from the top of the line box
        double ascent = size * 0.92;
        return new TextSpec { Text = text, Font = font, Size = Math.Max(1, size), Bold = bold, Italic = italic, Color = color, X = tx, Y = ty - ascent };
    }

    /// <summary>Font PostScript names from EngineData's FontSet (UTF-16BE strings with a BOM).</summary>
    static List<string> FontNames(byte[] eng)
    {
        var list = new List<string>();
        var marker = Encoding.ASCII.GetBytes("/Name (");
        for (int i = 0; i + marker.Length < eng.Length; i++)
        {
            bool hit = true;
            for (int k = 0; k < marker.Length; k++) if (eng[i + k] != marker[k]) { hit = false; break; }
            if (!hit) continue;
            int p = i + marker.Length;
            var bytes = new List<byte>();
            while (p < eng.Length)
            {
                byte b = eng[p];
                if (b == '\\' && p + 1 < eng.Length) { bytes.Add(eng[p + 1]); p += 2; continue; }
                if (b == ')') break;
                bytes.Add(b); p++;
            }
            var arr = bytes.ToArray();
            string name = arr.Length >= 2 && arr[0] == 0xFE && arr[1] == 0xFF ? Encoding.BigEndianUnicode.GetString(arr, 2, arr.Length - 2) : Encoding.Latin1.GetString(arr);
            list.Add(name.TrimEnd('\0'));
            i = p;
        }
        return list;
    }

    public static (string family, bool bold, bool italic) MapPostScriptName(string ps)
    {
        _families ??= new HashSet<string>(Fonts.SystemFontFamilies.Select(f => f.Source), StringComparer.OrdinalIgnoreCase);
        bool bold = ps.Contains("Bold", StringComparison.OrdinalIgnoreCase) || ps.Contains("Black", StringComparison.OrdinalIgnoreCase) || ps.Contains("Heavy", StringComparison.OrdinalIgnoreCase);
        bool italic = ps.Contains("Italic", StringComparison.OrdinalIgnoreCase) || ps.Contains("Oblique", StringComparison.OrdinalIgnoreCase);
        var basePart = ps.Split('-')[0];
        if (basePart.EndsWith("MT")) basePart = basePart[..^2];
        if (basePart.EndsWith("PS")) basePart = basePart[..^2];
        // "MyriadPro" → "Myriad Pro", "TimesNewRoman" → "Times New Roman"
        var spaced = Regex.Replace(basePart, "(?<=[a-z])(?=[A-Z])", " ");
        foreach (var candidate in new[] { basePart, spaced, spaced.Replace(" Pro", "") })
            if (_families.Contains(candidate)) return (candidate, bold, italic);
        return ("Segoe UI", bold, italic);
    }
}

using System.Windows;

namespace SkyMasterPhotos.Core;

/// <summary>
/// Content-aware fill used by the Spot Healing Brush and Edit ▸ Content-Aware Fill.
/// 1. find the best source patch near the hole by matching the ring of pixels around it,
/// 2. copy it in, 3. remove the seam with a smooth correction field (push-pull membrane),
/// 4. fall back to pure smooth fill when no clean source exists.
/// </summary>
public static class Inpaint
{
    public static uint[] Fill(uint[] src, int w, int h, byte[] mask)
    {
        var dst = (uint[])src.Clone();
        var b = SelectionOps.Bounds(mask, w, h);
        if (RectUtil.IsEmptyRect(b)) return dst;

        // binary hole, slightly dilated so edges of the blemish are replaced too
        var hole = new bool[w * h];
        for (int i = 0; i < hole.Length; i++) hole[i] = mask[i] >= 32;
        int ringW = Math.Clamp(Math.Max(b.Width, b.Height) / 6, 3, 24);
        var ring = RingAround(hole, w, h, b, ringW);

        var off = FindSource(src, w, h, hole, ring, b);
        if (off is Vector o)
        {
            int ox = (int)o.X, oy = (int)o.Y;
            // difference field on the ring, diffused into the hole
            var diff = new float[3][];
            for (int c = 0; c < 3; c++) diff[c] = new float[w * h];
            var known = new bool[w * h];
            foreach (int i in ring)
            {
                int x = i % w, y = i / w;
                int si = (y + oy) * w + x + ox;
                uint d = src[i], s = src[si];
                diff[0][i] = Px.R(d) - Px.R(s); diff[1][i] = Px.G(d) - Px.G(s); diff[2][i] = Px.B(d) - Px.B(s);
                known[i] = true;
            }
            var pad = Pad(b, ringW + 2, w, h);
            for (int c = 0; c < 3; c++) Membrane(diff[c], known, hole, w, pad);
            for (int y = b.Y; y < b.Y + b.Height; y++)
                for (int x = b.X; x < b.X + b.Width; x++)
                {
                    int i = y * w + x;
                    if (!hole[i]) continue;
                    uint s = src[(y + oy) * w + x + ox];
                    uint res = Px.Pack(Px.A(src[i]) == 0 ? Px.A(s) : Px.A(src[i]),
                        Px.Clamp(Px.R(s) + diff[0][i]), Px.Clamp(Px.G(s) + diff[1][i]), Px.Clamp(Px.B(s) + diff[2][i]));
                    dst[i] = mask[i] >= 255 ? res : Px.Lerp(src[i], res, Math.Min(1f, mask[i] / 160f));
                }
            return dst;
        }

        // no clean source: smooth membrane fill from the boundary
        {
            var pad = Pad(b, ringW + 2, w, h);
            var ch = new float[4][];
            var known = new bool[w * h];
            for (int c = 0; c < 4; c++) ch[c] = new float[w * h];
            for (int y = pad.Y; y < pad.Y + pad.Height; y++)
                for (int x = pad.X; x < pad.X + pad.Width; x++)
                {
                    int i = y * w + x;
                    if (hole[i]) continue;
                    uint p = src[i];
                    ch[0][i] = Px.R(p); ch[1][i] = Px.G(p); ch[2][i] = Px.B(p); ch[3][i] = Px.A(p);
                    known[i] = true;
                }
            for (int c = 0; c < 4; c++) Membrane(ch[c], known, hole, w, pad);
            var rnd = new Random(7);
            for (int y = b.Y; y < b.Y + b.Height; y++)
                for (int x = b.X; x < b.X + b.Width; x++)
                {
                    int i = y * w + x;
                    if (!hole[i]) continue;
                    double n = (rnd.NextDouble() - 0.5) * 6; // a little grain so it doesn't look plastic
                    dst[i] = Px.Pack(Px.Clamp(ch[3][i]), Px.Clamp(ch[0][i] + n), Px.Clamp(ch[1][i] + n), Px.Clamp(ch[2][i] + n));
                }
            return dst;
        }
    }

    static Int32Rect Pad(Int32Rect b, int p, int w, int h) => RectUtil.Clip(new Int32Rect(b.X - p, b.Y - p, b.Width + 2 * p, b.Height + 2 * p), w, h);

    static List<int> RingAround(bool[] hole, int w, int h, Int32Rect b, int ringW)
    {
        var ring = new List<int>();
        var area = Pad(b, ringW, w, h);
        // distance-limited ring: pixels outside the hole within ringW (chebyshev) of it
        var near = new bool[w * h];
        for (int y = b.Y; y < b.Y + b.Height; y++)
            for (int x = b.X; x < b.X + b.Width; x++)
            {
                if (!hole[y * w + x]) continue;
                for (int dy = -ringW; dy <= ringW; dy += Math.Max(1, ringW / 3))
                    for (int dx = -ringW; dx <= ringW; dx += Math.Max(1, ringW / 3))
                    {
                        int nx = x + dx, ny = y + dy;
                        if (nx >= 0 && ny >= 0 && nx < w && ny < h) near[ny * w + nx] = true;
                    }
            }
        for (int y = area.Y; y < area.Y + area.Height; y++)
            for (int x = area.X; x < area.X + area.Width; x++)
            {
                int i = y * w + x;
                if (near[i] && !hole[i]) ring.Add(i);
            }
        return ring;
    }

    static Vector? FindSource(uint[] src, int w, int h, bool[] hole, List<int> ring, Int32Rect b)
    {
        if (ring.Count == 0) return null;
        int size = Math.Max(b.Width, b.Height);
        int ringW = Math.Clamp(size / 6, 3, 24);
        var sample = ring.Count > 2500 ? ring.Where((_, k) => k % (ring.Count / 2500 + 1) == 0).ToList() : ring;
        double best = double.MaxValue;
        Vector? bestOff = null;
        var cands = new List<Vector>();
        for (double dist = 1.1; dist <= 3.2; dist += 0.35)
            for (int a = 0; a < 24; a++)
            {
                double ang = a * Math.PI / 12 + dist;
                cands.Add(new Vector(Math.Round(Math.Cos(ang) * size * dist), Math.Round(Math.Sin(ang) * size * dist)));
            }
        var lockObj = new object();
        Parallel.ForEach(cands, o =>
        {
            int ox = (int)o.X, oy = (int)o.Y;
            // whole source window (hole + ring) must be inside the image and outside the hole
            if (b.X - ringW + ox < 0 || b.Y - ringW + oy < 0 || b.X + b.Width + ringW + ox > w || b.Y + b.Height + ringW + oy > h) return;
            for (int y = b.Y; y < b.Y + b.Height; y += 2)
                for (int x = b.X; x < b.X + b.Width; x += 2)
                    if (hole[(y + oy) * w + x + ox]) return;
            double ssd = 0;
            foreach (int i in sample)
            {
                int x = i % w, y = i / w;
                uint d = src[i], s = src[(y + oy) * w + x + ox];
                int dr = Px.R(d) - Px.R(s), dg = Px.G(d) - Px.G(s), db = Px.B(d) - Px.B(s);
                ssd += dr * dr + dg * dg + db * db;
            }
            // texture term: prefer sources whose interior detail level matches the surroundings
            ssd /= sample.Count;
            ssd += o.Length * 0.02; // mild preference for nearby sources
            lock (lockObj) { if (ssd < best) { best = ssd; bestOff = o; } }
        });
        return bestOff;
    }

    /// <summary>Fill unknown pixels inside <paramref name="area"/> smoothly from known ones (pull-push pyramid).</summary>
    static void Membrane(float[] v, bool[] known, bool[] hole, int w, Int32Rect area)
    {
        int aw = area.Width, ah = area.Height;
        var val = new float[aw * ah];
        var wt = new float[aw * ah];
        for (int y = 0; y < ah; y++)
            for (int x = 0; x < aw; x++)
            {
                int i = (area.Y + y) * w + area.X + x;
                if (known[i]) { val[y * aw + x] = v[i]; wt[y * aw + x] = 1; }
            }
        var levels = new List<(float[] v, float[] w, int W, int H)> { (val, wt, aw, ah) };
        while (levels[^1].W > 1 || levels[^1].H > 1)
        {
            var (pv, pw, PW, PH) = levels[^1];
            int NW = Math.Max(1, (PW + 1) / 2), NH = Math.Max(1, (PH + 1) / 2);
            var nv = new float[NW * NH]; var nw = new float[NW * NH];
            for (int y = 0; y < PH; y++)
                for (int x = 0; x < PW; x++)
                {
                    int j = (y / 2) * NW + x / 2;
                    float ww = pw[y * PW + x];
                    nv[j] += pv[y * PW + x] * ww; nw[j] += ww;
                }
            for (int j = 0; j < nv.Length; j++) if (nw[j] > 0) { nv[j] /= nw[j]; nw[j] = Math.Min(1, nw[j]); }
            levels.Add((nv, nw, NW, NH));
        }
        for (int l = levels.Count - 2; l >= 0; l--)
        {
            var (cv, cw, CW, CH) = levels[l];
            var (pv, pw, PW, PH) = levels[l + 1];
            for (int y = 0; y < CH; y++)
                for (int x = 0; x < CW; x++)
                {
                    int i = y * CW + x;
                    if (cw[i] >= 1) continue;
                    // bilinear sample of the coarser level
                    double fx = Math.Clamp((x - 0.5) / 2.0, 0, PW - 1), fy = Math.Clamp((y - 0.5) / 2.0, 0, PH - 1);
                    int x0 = (int)fx, y0 = (int)fy, x1 = Math.Min(PW - 1, x0 + 1), y1 = Math.Min(PH - 1, y0 + 1);
                    double tx = fx - x0, ty = fy - y0;
                    double up = pv[y0 * PW + x0] * (1 - tx) * (1 - ty) + pv[y0 * PW + x1] * tx * (1 - ty) + pv[y1 * PW + x0] * (1 - tx) * ty + pv[y1 * PW + x1] * tx * ty;
                    cv[i] = (float)(cv[i] * cw[i] + up * (1 - cw[i]));
                    cw[i] = 1;
                }
        }
        for (int y = 0; y < ah; y++)
            for (int x = 0; x < aw; x++)
            {
                int i = (area.Y + y) * w + area.X + x;
                if (hole[i]) v[i] = val[y * aw + x];
            }
    }
}

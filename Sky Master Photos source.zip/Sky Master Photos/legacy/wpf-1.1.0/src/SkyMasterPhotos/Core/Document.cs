using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace SkyMasterPhotos.Core;

public sealed class Document : INotifyPropertyChanged
{
    public int Width { get; private set; }
    public int Height { get; private set; }
    public ObservableCollection<Layer> Layers { get; } = new();   // index 0 = top-most
    public History History { get; }
    /// <summary>Photoshop groups by path (layers reference them through Layer.Group).</summary>
    public Dictionary<string, GroupInfo> Groups { get; set; } = new();
    /// <summary>Document-level Photoshop data kept for round-trips (null for native documents).</summary>
    public PsdDocData PsdData { get; set; }

    public uint[] Flat { get; private set; }
    public WriteableBitmap Display { get; private set; }

    Layer _active;
    byte[] _selection;
    byte[] _previousSelection;
    string _filePath;
    string _title;
    bool _dirty;
    BitmapSource _thumb;

    public Geometry SelectionOutline { get; private set; }
    public Int32Rect SelectionBounds { get; private set; }

    /// <summary>Raised after pixels were re-rendered (rect in doc space).</summary>
    public event Action<Int32Rect> Rendered;
    /// <summary>Raised when size, selection or layer structure changes.</summary>
    public event Action StructureChanged;

    public Document(int w, int h, string title, string baseHistory = "New Document")
    {
        Width = w;
        Height = h;
        _title = title;
        History = new History(baseHistory);
        EnsureDisplay();
    }

    public static Document CreateBlank(int w, int h, string title, Color bg)
    {
        var d = new Document(w, h, title);
        var px = new uint[w * h];
        if (bg.A > 0) Array.Fill(px, Px.FromColor(bg));
        var layer = new Layer(bg.A > 0 ? "Background" : "Layer 1", w, h, px);
        d.Layers.Add(layer);
        d.ActiveLayer = layer;
        d.RenderAll();
        layer.RefreshThumbnail();
        return d;
    }

    public Layer ActiveLayer
    {
        get => _active;
        set
        {
            if (_active == value) return;
            if (_active != null) _active.IsActive = false;
            _active = value;
            if (_active != null) _active.IsActive = true;
            OnChanged();
        }
    }

    public int ActiveIndex => _active == null ? -1 : Layers.IndexOf(_active);

    public byte[] Selection => _selection;
    public bool HasSelection => _selection != null;

    public string FilePath { get => _filePath; set { _filePath = value; OnChanged(); } }
    public string Title { get => _title; set { _title = value; OnChanged(); OnChanged(nameof(TabTitle)); } }
    public bool IsDirty { get => _dirty; set { if (_dirty != value) { _dirty = value; OnChanged(); OnChanged(nameof(TabTitle)); } } }
    public string TabTitle => _dirty ? _title + " •" : _title;
    public BitmapSource Thumbnail { get => _thumb; private set { _thumb = value; OnChanged(); } }

    double _zoom = 1;
    public double Zoom { get => _zoom; set { _zoom = value; OnChanged(); OnChanged(nameof(ZoomText)); } }
    public string ZoomText => $"{Math.Round(_zoom * 100)}%";
    public Vector Pan;
    public bool ViewInitialized;

    public void EnsureDisplay()
    {
        if (Display == null || Display.PixelWidth != Width || Display.PixelHeight != Height)
        {
            Display = new WriteableBitmap(Width, Height, 96, 96, PixelFormats.Pbgra32, null);
            Flat = new uint[Width * Height];
            OnChanged(nameof(Display));
        }
    }

    public void Render(Int32Rect r)
    {
        r = RectUtil.Clip(r, Width, Height);
        if (RectUtil.IsEmptyRect(r)) return;
        EnsureDisplay();
        Compositor.Composite(Layers, Width, Height, r, Flat, null, 0, int.MaxValue, Groups);
        Display.Lock();
        Compositor.WritePremul(Flat, Width, r, Display.BackBuffer, Display.BackBufferStride);
        Display.AddDirtyRect(r);
        Display.Unlock();
        Rendered?.Invoke(r);
    }

    public void RenderAll() => Render(new Int32Rect(0, 0, Width, Height));

    public void RefreshThumbnail() => Thumbnail = ThumbnailMaker.Make(Flat, Width, Height, 64, true);

    public void RefreshAllLayerThumbs()
    {
        foreach (var l in Layers) l.RefreshThumbnail();
        RefreshThumbnail();
    }

    public void SetSelection(byte[] mask)
    {
        if (mask != null && mask.Length != Width * Height)
            throw new ArgumentException("Selection dimensions must match the document.", nameof(mask));
        if (mask != null && SelectionOps.IsEmpty(mask)) mask = null;
        if (_selection != null && _selection.Length == Width * Height && !ReferenceEquals(mask, _selection))
            _previousSelection = _selection;
        _selection = mask;
        SelectionOutline = mask == null ? null : SelectionOps.Outline(mask, Width, Height);
        SelectionBounds = mask == null ? Int32Rect.Empty : SelectionOps.Bounds(mask, Width, Height);
        OnChanged(nameof(HasSelection));
        StructureChanged?.Invoke();
    }

    public bool Reselect()
    {
        if (_previousSelection == null || _previousSelection.Length != Width * Height) return false;
        SetSelection(_previousSelection);
        return true;
    }

    public void NotifyStructure()
    {
        StructureChanged?.Invoke();
        OnChanged(nameof(Width));
        OnChanged(nameof(Height));
    }

    // ───────────────────────────── history ─────────────────────────────

    public DocState Capture()
    {
        return new DocState
        {
            W = Width,
            H = Height,
            Active = ActiveIndex,
            Sel = _selection,
            Groups = new Dictionary<string, GroupInfo>(Groups),
            Layers = Layers.Select(l => new LayerState
            {
                L = l, Pixels = l.Pixels, Mask = l.Mask, W = l.Width, H = l.Height, Name = l.Name,
                Visible = l.Visible, Locked = l.Locked, Opacity = l.Opacity, Fill = l.Fill, Blend = l.Blend,
                MaskEnabled = l.MaskEnabled, Clipped = l.Clipped, Group = l.Group,
                Adjustment = l.Adjustment, Text = l.Text, Psd = l.Psd, Style = l.Style,
            }).ToArray()
        };
    }

    public void Restore(DocState s)
    {
        Width = s.W;
        Height = s.H;
        Layers.Clear();
        foreach (var ls in s.Layers)
        {
            var l = ls.L;
            l.SetPixels(ls.Pixels, ls.W, ls.H);
            l.SetMask(ls.Mask);
            l.Name = ls.Name;
            l.Visible = ls.Visible;
            l.Locked = ls.Locked;
            l.Opacity = ls.Opacity;
            l.Fill = ls.Fill;
            l.Blend = ls.Blend;
            l.MaskEnabled = ls.MaskEnabled;
            l.Clipped = ls.Clipped;
            l.Group = ls.Group;
            l.Adjustment = ls.Adjustment;
            l.Text = ls.Text;
            l.Style = ls.Style;
            l.Psd = ls.Psd;
            l.IsActive = false;
            Layers.Add(l);
        }
        Groups = s.Groups != null ? new Dictionary<string, GroupInfo>(s.Groups) : new();
        _active = null;
        ActiveLayer = s.Active >= 0 && s.Active < Layers.Count ? Layers[s.Active] : Layers.FirstOrDefault();
        EnsureDisplay();
        SetSelection(s.Sel);
        RenderAll();
        RefreshAllLayerThumbs();
        NotifyStructure();
    }

    /// <summary>Record a structural / buffer-swap change: before was captured prior to the edit.</summary>
    public void Record(string name, DocState before, string icon = "•")
    {
        History.Push(new HistoryEntry { Name = name, Icon = icon, Before = before, After = Capture() });
        IsDirty = true;
    }

    /// <summary>Record an in-place pixel (or mask) edit inside rect r of layer l.</summary>
    public void RecordPatch(string name, Layer l, Int32Rect r, uint[] before, uint[] after, string icon = "•", bool isMask = false)
    {
        var st = Capture();
        History.Push(new HistoryEntry
        {
            Name = name, Icon = icon, Before = st, After = st,
            Patch = new PixelPatch { L = l, IsMask = isMask, R = r, Before = before, After = after }
        });
        IsDirty = true;
    }

    static uint[] PatchTarget(DocState st, PixelPatch p)
    {
        var ls = st.Layers.FirstOrDefault(x => x.L == p.L);
        if (ls == null) return null;
        return p.IsMask ? ls.Mask : ls.Pixels;
    }

    public bool Undo()
    {
        var e = History.TakeUndo();
        if (e == null) return false;
        if (e.Patch != null && PatchTarget(e.After, e.Patch) is uint[] t) PixelPatch.Put(t, e.Patch.L.Width, e.Patch.R, e.Patch.Before);
        Restore(e.Before);
        IsDirty = true;
        return true;
    }

    public bool Redo()
    {
        var e = History.TakeRedo();
        if (e == null) return false;
        // the patched buffer must be the one referenced by the After state
        if (e.Patch != null && PatchTarget(e.After, e.Patch) is uint[] t) PixelPatch.Put(t, e.Patch.L.Width, e.Patch.R, e.Patch.After);
        Restore(e.After);
        IsDirty = true;
        return true;
    }
    public void JumpTo(int entryIndex)
    {
        int target = entryIndex + 1;
        while (History.Index > target && Undo()) { }
        while (History.Index < target && Redo()) { }
    }

    /// <summary>Size changes (canvas/image size, crop, rotate) — caller replaces all layer buffers.</summary>
    public void SetSize(int w, int h)
    {
        _previousSelection = null;
        Width = w;
        Height = h;
        EnsureDisplay();
    }

    public event PropertyChangedEventHandler PropertyChanged;
    void OnChanged([CallerMemberName] string n = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(n));
}

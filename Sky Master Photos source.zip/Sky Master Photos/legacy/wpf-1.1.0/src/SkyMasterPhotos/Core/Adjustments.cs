using System.Windows;
using System.Windows.Media;

namespace SkyMasterPhotos.Core;

/// <summary>
/// Color / tone adjustments. Each per-pixel adjustment exists as a function builder (…Fn) used by
/// non-destructive adjustment layers in the compositor, plus an array version for destructive edits.
/// </summary>
public static class Adjustments
{
    public static uint[] Map(uint[] src, Func<uint, uint> f)
    {
        var o = new uint[src.Length];
        Parallel.For(0, src.Length / 4096 + 1, chunk =>
        {
            int s = chunk * 4096, e = Math.Min(src.Length, s + 4096);
            for (int i = s; i < e; i++) { uint p = src[i]; o[i] = (p >> 24) == 0 ? p : f(p); }
        });
        return o;
    }

    public static Func<uint, uint> LutFn(byte[] lr, byte[] lg, byte[] lb) => p => Px.Pack(Px.A(p), lr[Px.R(p)], lg[Px.G(p)], lb[Px.B(p)]);
    public static Func<uint, uint> LutFn(byte[] l) => LutFn(l, l, l);

    public static uint[] ApplyLut(uint[] src, byte[] lr, byte[] lg, byte[] lb) => Map(src, LutFn(lr, lg, lb));
    public static uint[] ApplyLut(uint[] src, byte[] l) => ApplyLut(src, l, l, l);

    static byte[] Lut(Func<double, double> f)
    {
        var l = new byte[256];
        for (int i = 0; i < 256; i++) l[i] = (byte)Px.Clamp(f(i));
        return l;
    }

    // ───────────────────────────── per-pixel builders ─────────────────────────────

    public static Func<uint, uint> BrightnessContrastFn(double brightness, double contrast)
    {
        double c = contrast / 100.0;
        double factor = c >= 0 ? 1 / (1 - Math.Min(0.99, c)) : 1 + c;
        return LutFn(Lut(v => (v + brightness * 1.27 - 127.5) * factor + 127.5));
    }

    public static Func<uint, uint> LevelsFn(double inBlack, double inWhite, double gamma, double outBlack, double outWhite)
    {
        if (inWhite <= inBlack + 1) inWhite = inBlack + 1;
        gamma = Math.Max(0.05, gamma);
        return LutFn(Lut(v =>
        {
            double t = Math.Clamp((v - inBlack) / (inWhite - inBlack), 0, 1);
            t = Math.Pow(t, 1 / gamma);
            return outBlack + t * (outWhite - outBlack);
        }));
    }

    public static Func<uint, uint> ExposureFn(double exposure, double offset, double gamma)
    {
        double m = Math.Pow(2, exposure);
        gamma = Math.Max(0.05, gamma);
        return LutFn(Lut(v =>
        {
            double lin = Math.Max(0, Math.Pow(v / 255.0, 2.2) * m + offset);
            return Math.Pow(Math.Pow(lin, 1 / 2.2), 1 / gamma) * 255;
        }));
    }

    public static Func<uint, uint> HueSaturationFn(double hueDeg, double satPct, double lightPct, bool colorize)
    {
        double hs = hueDeg / 360.0, ss = satPct / 100.0, ls = lightPct / 100.0;
        return p =>
        {
            Px.RgbToHsl(Px.R(p) / 255.0, Px.G(p) / 255.0, Px.B(p) / 255.0, out double h, out double s, out double l);
            if (colorize) { h = (hs + 1) % 1; s = Math.Clamp(0.25 + ss * 0.75 + 0.25, 0, 1) * 0.5; }
            else
            {
                h = (h + hs + 1) % 1;
                s = ss >= 0 ? s + (1 - s) * ss * s : s * (1 + ss);
                s = Math.Clamp(s, 0, 1);
            }
            l = ls >= 0 ? l + (1 - l) * ls : l * (1 + ls);
            Px.HslToRgb(h, s, l, out double r, out double g, out double b);
            return Px.Pack(Px.A(p), Px.Clamp(r * 255), Px.Clamp(g * 255), Px.Clamp(b * 255));
        };
    }

    public static Func<uint, uint> VibranceFn(double vibrance, double saturation)
    {
        double v = vibrance / 100.0, s = saturation / 100.0;
        return p =>
        {
            double r = Px.R(p), g = Px.G(p), b = Px.B(p);
            double mx = Math.Max(r, Math.Max(g, b));
            double sat = (mx - Math.Min(r, Math.Min(g, b))) / 255.0;
            double amt = s + v * (1 - sat) * 1.5;
            double lum = 0.299 * r + 0.587 * g + 0.114 * b;
            r = lum + (r - lum) * (1 + amt); g = lum + (g - lum) * (1 + amt); b = lum + (b - lum) * (1 + amt);
            return Px.Pack(Px.A(p), Px.Clamp(r), Px.Clamp(g), Px.Clamp(b));
        };
    }

    public static Func<uint, uint> ColorBalanceFn(double cyanRed, double magentaGreen, double yellowBlue, bool preserveLum)
    {
        return p =>
        {
            double r = Px.R(p), g = Px.G(p), b = Px.B(p);
            double l0 = 0.299 * r + 0.587 * g + 0.114 * b;
            double mid = Math.Clamp(1 - Math.Abs(l0 / 255.0 - 0.5) * 1.4, 0.15, 1);
            r += cyanRed * 1.1 * mid; g += magentaGreen * 1.1 * mid; b += yellowBlue * 1.1 * mid;
            if (preserveLum)
            {
                double l1 = 0.299 * r + 0.587 * g + 0.114 * b;
                double d = l0 - l1; r += d; g += d; b += d;
            }
            return Px.Pack(Px.A(p), Px.Clamp(r), Px.Clamp(g), Px.Clamp(b));
        };
    }

    public static Func<uint, uint> BlackWhiteFn(double reds, double yellows, double greens, double cyans, double blues, double magentas)
    {
        double[] wts = { reds, yellows, greens, cyans, blues, magentas };
        return p =>
        {
            double r = Px.R(p) / 255.0, g = Px.G(p) / 255.0, b = Px.B(p) / 255.0;
            Px.RgbToHsl(r, g, b, out double h, out double s, out double l);
            double hh = h * 6;
            int i0 = (int)Math.Floor(hh) % 6, i1 = (i0 + 1) % 6;
            double f = hh - Math.Floor(hh);
            double wgt = (wts[i0] * (1 - f) + wts[i1] * f) / 100.0;
            double v = 0.299 * r + 0.587 * g + 0.114 * b + (wgt - 0.5) * s * 0.9;
            int c = Px.Clamp(v * 255);
            return Px.Pack(Px.A(p), c, c, c);
        };
    }

    public static Func<uint, uint> PhotoFilterFn(Color c, double densityPct, bool preserveLum)
    {
        double d = densityPct / 100.0;
        return p =>
        {
            double r = Px.R(p), g = Px.G(p), b = Px.B(p);
            double l0 = 0.299 * r + 0.587 * g + 0.114 * b;
            r = r * (1 - d) + r * c.R / 255.0 * d + c.R * d * 0.25 * (1 - r / 255);
            g = g * (1 - d) + g * c.G / 255.0 * d + c.G * d * 0.25 * (1 - g / 255);
            b = b * (1 - d) + b * c.B / 255.0 * d + c.B * d * 0.25 * (1 - b / 255);
            if (preserveLum)
            {
                double l1 = 0.299 * r + 0.587 * g + 0.114 * b;
                if (l1 > 0.01) { double k = l0 / l1; r *= k; g *= k; b *= k; }
            }
            return Px.Pack(Px.A(p), Px.Clamp(r), Px.Clamp(g), Px.Clamp(b));
        };
    }

    public static Func<uint, uint> TemperatureTintFn(double temp, double tint)
    {
        double t = temp / 100.0, ti = tint / 100.0;
        var lr = Lut(v => v + t * 40 * (1 - Math.Abs(v / 127.5 - 1) * 0.5));
        var lb = Lut(v => v - t * 40 * (1 - Math.Abs(v / 127.5 - 1) * 0.5));
        var lg = Lut(v => v - ti * 35 * (1 - Math.Abs(v / 127.5 - 1) * 0.5));
        return LutFn(lr, lg, lb);
    }

    public static readonly Func<uint, uint> InvertFn = p => Px.Pack(Px.A(p), 255 - Px.R(p), 255 - Px.G(p), 255 - Px.B(p));
    public static readonly Func<uint, uint> DesaturateFn = p => { int l = Px.Clamp(Px.Luma(p)); return Px.Pack(Px.A(p), l, l, l); };

    public static Func<uint, uint> SepiaFn(double amountPct)
    {
        float k = (float)(amountPct / 100.0);
        return p =>
        {
            double r = Px.R(p), g = Px.G(p), b = Px.B(p);
            uint s = Px.Pack(Px.A(p), Px.Clamp(r * .393 + g * .769 + b * .189), Px.Clamp(r * .349 + g * .686 + b * .168), Px.Clamp(r * .272 + g * .534 + b * .131));
            return Px.Lerp(p, s, k);
        };
    }

    public static Func<uint, uint> PosterizeFn(int levels)
    {
        levels = Math.Clamp(levels, 2, 255);
        return LutFn(Lut(v => Math.Round(v / 255.0 * (levels - 1)) / (levels - 1) * 255));
    }

    public static Func<uint, uint> ThresholdFn(int level) => p => { int v = Px.Luma(p) >= level ? 255 : 0; return Px.Pack(Px.A(p), v, v, v); };

    public static Func<uint, uint> GradientMapFn(Color dark, Color light) => p =>
    {
        double t = Px.Luma(p) / 255.0;
        return Px.Pack(Px.A(p), Px.Clamp(dark.R + (light.R - dark.R) * t), Px.Clamp(dark.G + (light.G - dark.G) * t), Px.Clamp(dark.B + (light.B - dark.B) * t));
    };

    public static Func<uint, uint> CurvesFn(IList<Point> pts) => LutFn(CurveLut(pts));

    // ───────────────────────────── array versions ─────────────────────────────

    public static uint[] BrightnessContrast(uint[] src, double brightness, double contrast) => Map(src, BrightnessContrastFn(brightness, contrast));
    public static uint[] Levels(uint[] src, double inBlack, double inWhite, double gamma, double outBlack, double outWhite) => Map(src, LevelsFn(inBlack, inWhite, gamma, outBlack, outWhite));
    public static uint[] Exposure(uint[] src, double exposure, double offset, double gamma) => Map(src, ExposureFn(exposure, offset, gamma));
    public static uint[] HueSaturation(uint[] src, double hueDeg, double satPct, double lightPct, bool colorize) => Map(src, HueSaturationFn(hueDeg, satPct, lightPct, colorize));
    public static uint[] Vibrance(uint[] src, double vibrance, double saturation) => Map(src, VibranceFn(vibrance, saturation));
    public static uint[] ColorBalance(uint[] src, double cyanRed, double magentaGreen, double yellowBlue, bool preserveLum) => Map(src, ColorBalanceFn(cyanRed, magentaGreen, yellowBlue, preserveLum));
    public static uint[] BlackWhite(uint[] src, double reds, double yellows, double greens, double cyans, double blues, double magentas) => Map(src, BlackWhiteFn(reds, yellows, greens, cyans, blues, magentas));
    public static uint[] PhotoFilter(uint[] src, Color c, double densityPct, bool preserveLum) => Map(src, PhotoFilterFn(c, densityPct, preserveLum));
    public static uint[] TemperatureTint(uint[] src, double temp, double tint) => Map(src, TemperatureTintFn(temp, tint));
    public static uint[] Invert(uint[] src) => Map(src, InvertFn);
    public static uint[] Desaturate(uint[] src) => Map(src, DesaturateFn);
    public static uint[] Sepia(uint[] src, double amountPct) => Map(src, SepiaFn(amountPct));
    public static uint[] Posterize(uint[] src, int levels) => Map(src, PosterizeFn(levels));
    public static uint[] Threshold(uint[] src, int level) => Map(src, ThresholdFn(level));
    public static uint[] GradientMap(uint[] src, Color dark, Color light) => Map(src, GradientMapFn(dark, light));

    public static uint[] ShadowsHighlights(uint[] src, int w, int h, double shadowsPct, double highlightsPct)
    {
        // luminance mask from a heavily blurred copy so local contrast survives
        var lumSrc = Map(src, p => { int l = Px.Clamp(Px.Luma(p)); return Px.Pack(255, l, l, l); });
        var bl = Filters.GaussianBlur(lumSrc, w, h, Math.Max(8, Math.Min(w, h) / 40.0));
        double s = shadowsPct / 100.0, hl = highlightsPct / 100.0;
        var o = new uint[src.Length];
        Parallel.For(0, src.Length / 4096 + 1, chunk =>
        {
            int st = chunk * 4096, e = Math.Min(src.Length, st + 4096);
            for (int i = st; i < e; i++)
            {
                uint p = src[i];
                double m = Px.R(bl[i]) / 255.0;
                double shadowW = Math.Pow(1 - m, 2), hiW = Math.Pow(m, 2);
                double gain = 1 + s * shadowW * 1.6 - hl * hiW * 0.6;
                double lift = s * shadowW * 20 - hl * hiW * 30;
                o[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) * gain + lift), Px.Clamp(Px.G(p) * gain + lift), Px.Clamp(Px.B(p) * gain + lift));
            }
        });
        return o;
    }

    // ───────────────────────────── auto ─────────────────────────────

    static (int lo, int hi) Percentiles(int[] hist, long total, double clip)
    {
        long cut = (long)(total * clip);
        int lo = 0, hi = 255; long acc = 0;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc > cut) { lo = i; break; } }
        acc = 0;
        for (int i = 255; i >= 0; i--) { acc += hist[i]; if (acc > cut) { hi = i; break; } }
        if (hi <= lo) { lo = 0; hi = 255; }
        return (lo, hi);
    }

    public static uint[] AutoTone(uint[] src)
    {
        var hr = new int[256]; var hg = new int[256]; var hb = new int[256]; long n = 0;
        foreach (var p in src) { if ((p >> 24) < 128) continue; hr[Px.R(p)]++; hg[Px.G(p)]++; hb[Px.B(p)]++; n++; }
        if (n == 0) return (uint[])src.Clone();
        var (rl, rh) = Percentiles(hr, n, 0.001); var (gl, gh) = Percentiles(hg, n, 0.001); var (bl, bh) = Percentiles(hb, n, 0.001);
        byte[] L(int lo, int hi) => Lut(v => (v - lo) * 255.0 / (hi - lo));
        return ApplyLut(src, L(rl, rh), L(gl, gh), L(bl, bh));
    }

    public static uint[] AutoContrast(uint[] src)
    {
        var hl = new int[256]; long n = 0;
        foreach (var p in src) { if ((p >> 24) < 128) continue; hl[Px.Clamp(Px.Luma(p))]++; n++; }
        if (n == 0) return (uint[])src.Clone();
        var (lo, hi) = Percentiles(hl, n, 0.002);
        return ApplyLut(src, Lut(v => (v - lo) * 255.0 / (hi - lo)));
    }

    public static uint[] AutoColor(uint[] src)
    {
        double sr = 0, sg = 0, sb = 0; long n = 0;
        foreach (var p in src) { if ((p >> 24) < 128) continue; sr += Px.R(p); sg += Px.G(p); sb += Px.B(p); n++; }
        if (n == 0) return (uint[])src.Clone();
        double ar = sr / n, ag = sg / n, ab = sb / n, avg = (ar + ag + ab) / 3;
        double kr = avg / Math.Max(1, ar), kg = avg / Math.Max(1, ag), kb = avg / Math.Max(1, ab);
        // soften the correction so it never looks clinical
        kr = 1 + (kr - 1) * 0.7; kg = 1 + (kg - 1) * 0.7; kb = 1 + (kb - 1) * 0.7;
        var balanced = ApplyLut(src, Lut(v => v * kr), Lut(v => v * kg), Lut(v => v * kb));
        return AutoContrast(balanced);
    }

    public static uint[] AutoEnhance(uint[] src)
    {
        var a = AutoColor(src);
        var b = Vibrance(a, 18, 0);
        // blend 75% to stay natural
        var o = new uint[src.Length];
        for (int i = 0; i < o.Length; i++) o[i] = Px.Lerp(src[i], b[i], 0.75f);
        return o;
    }

    // ───────────────────────────── curves ─────────────────────────────

    /// <summary>Monotone cubic (Fritsch–Carlson) curve through control points in 0..255 space.</summary>
    public static byte[] CurveLut(IList<Point> pts)
    {
        var p = pts.OrderBy(q => q.X).ToList();
        if (p.Count == 0) p = new List<Point> { new(0, 0), new(255, 255) };
        if (p.Count == 1) p.Add(new Point(255, 255));
        int n = p.Count;
        var dx = new double[n - 1]; var dy = new double[n - 1]; var m = new double[n - 1];
        for (int i = 0; i < n - 1; i++) { dx[i] = Math.Max(1e-6, p[i + 1].X - p[i].X); dy[i] = p[i + 1].Y - p[i].Y; m[i] = dy[i] / dx[i]; }
        var t = new double[n];
        t[0] = m[0]; t[n - 1] = m[n - 2];
        for (int i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (m[i - 1] + m[i]) / 2;
        for (int i = 0; i < n - 1; i++)
        {
            if (Math.Abs(m[i]) < 1e-9) { t[i] = 0; t[i + 1] = 0; continue; }
            double a = t[i] / m[i], b = t[i + 1] / m[i], s = a * a + b * b;
            if (s > 9) { double k = 3 / Math.Sqrt(s); t[i] = k * a * m[i]; t[i + 1] = k * b * m[i]; }
        }
        var lut = new byte[256];
        for (int x = 0; x < 256; x++)
        {
            double y;
            if (x <= p[0].X) y = p[0].Y;
            else if (x >= p[n - 1].X) y = p[n - 1].Y;
            else
            {
                int i = 0;
                while (i < n - 2 && x > p[i + 1].X) i++;
                double h = dx[i], u = (x - p[i].X) / h;
                double h00 = 2 * u * u * u - 3 * u * u + 1, h10 = u * u * u - 2 * u * u + u, h01 = -2 * u * u * u + 3 * u * u, h11 = u * u * u - u * u;
                y = h00 * p[i].Y + h10 * h * t[i] + h01 * p[i + 1].Y + h11 * h * t[i + 1];
            }
            lut[x] = (byte)Px.Clamp(y);
        }
        return lut;
    }

    public static int[] LumaHistogram(uint[] src)
    {
        var h = new int[256];
        for (int i = 0; i < src.Length; i += 3) { uint p = src[i]; if ((p >> 24) > 0) h[Px.Clamp(Px.Luma(p))]++; }
        return h;
    }

    // ───────────────────────────── background removal ─────────────────────────────

    /// <summary>Removes the background connected to the image border (works best on studio / flat backgrounds).</summary>
    public static uint[] RemoveBackground(uint[] src, int w, int h, int tolerance)
    {
        var bgMask = new byte[w * h];
        // sample border colors, flood from every border pixel similar to its neighbourhood seed
        var q = new Queue<int>();
        int tol2 = tolerance * tolerance * 3;
        var seeds = new List<uint>();
        for (int x = 0; x < w; x += Math.Max(1, w / 32)) { seeds.Add(src[x]); seeds.Add(src[(h - 1) * w + x]); }
        for (int y = 0; y < h; y += Math.Max(1, h / 32)) { seeds.Add(src[y * w]); seeds.Add(src[y * w + w - 1]); }
        bool IsBg(uint p)
        {
            if ((p >> 24) < 16) return true;
            foreach (var s in seeds)
            {
                int dr = Px.R(p) - Px.R(s), dg = Px.G(p) - Px.G(s), db = Px.B(p) - Px.B(s);
                if (dr * dr + dg * dg + db * db <= tol2) return true;
            }
            return false;
        }
        void Try(int i) { if (bgMask[i] == 0 && IsBg(src[i])) { bgMask[i] = 255; q.Enqueue(i); } }
        for (int x = 0; x < w; x++) { Try(x); Try((h - 1) * w + x); }
        for (int y = 0; y < h; y++) { Try(y * w); Try(y * w + w - 1); }
        while (q.Count > 0)
        {
            int i = q.Dequeue(); int x = i % w, y = i / w;
            if (x > 0) Try(i - 1);
            if (x < w - 1) Try(i + 1);
            if (y > 0) Try(i - w);
            if (y < h - 1) Try(i + w);
        }
        var soft = SelectionOps.Feather(SelectionOps.Grow(bgMask, w, h, 1), w, h, 3);
        var o = new uint[src.Length];
        Parallel.For(0, src.Length, i =>
        {
            uint p = src[i];
            int a = Px.A(p) * (255 - soft[i]) / 255;
            o[i] = Px.WithAlpha(p, a);
        });
        return o;
    }
}

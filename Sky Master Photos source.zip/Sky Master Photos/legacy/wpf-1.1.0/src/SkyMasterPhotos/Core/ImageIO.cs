using System.IO;
using System.IO.Compression;
using System.Text.Json;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace SkyMasterPhotos.Core;

public static class ImageIO
{
    public const string ProjectExt = ".skyphoto";
    public const string OpenFilter = "All supported|*.skyphoto;*.psd;*.psb;*.png;*.jpg;*.jpeg;*.jfif;*.bmp;*.gif;*.tif;*.tiff;*.webp;*.heic;*.ico;*.jxr;*.wdp|Sky Photo project (*.skyphoto)|*.skyphoto|Photoshop (*.psd, *.psb)|*.psd;*.psb|Images|*.png;*.jpg;*.jpeg;*.jfif;*.bmp;*.gif;*.tif;*.tiff;*.webp;*.heic;*.ico|All files|*.*";
    public const string ImageFilter = "Images|*.psd;*.psb;*.png;*.jpg;*.jpeg;*.jfif;*.bmp;*.gif;*.tif;*.tiff;*.webp;*.heic;*.ico|All files|*.*";

    public static (uint[] px, int w, int h) LoadPixels(string path)
    {
        if (IsPsd(path))
        {
            var res = Psd.PsdReader.Read(path);
            res.Doc.RenderAll();
            return ((uint[])res.Doc.Flat.Clone(), res.Width, res.Height);
        }
        using var fs = File.OpenRead(path);
        return LoadPixels(fs);
    }

    public static (uint[] px, int w, int h) LoadPixels(Stream s)
    {
        var dec = BitmapDecoder.Create(s, BitmapCreateOptions.PreservePixelFormat | BitmapCreateOptions.IgnoreColorProfile, BitmapCacheOption.OnLoad);
        BitmapSource frame = dec.Frames[0];
        // honour EXIF orientation for photos
        frame = ApplyOrientation(frame);
        return FromBitmapSource(frame);
    }

    public static (uint[] px, int w, int h) FromBitmapSource(BitmapSource src)
    {
        if (src.Format != PixelFormats.Bgra32) src = new FormatConvertedBitmap(src, PixelFormats.Bgra32, null, 0);
        int w = src.PixelWidth, h = src.PixelHeight;
        var px = new uint[w * h];
        src.CopyPixels(px, w * 4, 0);
        return (px, w, h);
    }

    static BitmapSource ApplyOrientation(BitmapSource frame)
    {
        try
        {
            if (frame.Metadata is BitmapMetadata md && md.ContainsQuery("System.Photo.Orientation"))
            {
                var o = md.GetQuery("System.Photo.Orientation");
                if (o is ushort v && v != 1)
                {
                    var tg = new TransformGroup();
                    switch (v)
                    {
                        case 2: tg.Children.Add(new ScaleTransform(-1, 1)); break;
                        case 3: tg.Children.Add(new RotateTransform(180)); break;
                        case 4: tg.Children.Add(new ScaleTransform(1, -1)); break;
                        case 5: tg.Children.Add(new RotateTransform(90)); tg.Children.Add(new ScaleTransform(-1, 1)); break;
                        case 6: tg.Children.Add(new RotateTransform(90)); break;
                        case 7: tg.Children.Add(new RotateTransform(270)); tg.Children.Add(new ScaleTransform(-1, 1)); break;
                        case 8: tg.Children.Add(new RotateTransform(270)); break;
                    }
                    var tb = new TransformedBitmap(frame, tg);
                    tb.Freeze();
                    return tb;
                }
            }
        }
        catch { }
        return frame;
    }

    public static BitmapSource ToBitmapSource(uint[] px, int w, int h)
    {
        var b = BitmapSource.Create(w, h, 96, 96, PixelFormats.Bgra32, null, px, w * 4);
        b.Freeze();
        return b;
    }

    public static void SaveImage(string path, uint[] px, int w, int h, int jpegQuality = 92)
    {
        string ext = Path.GetExtension(path).ToLowerInvariant();
        BitmapEncoder enc;
        BitmapSource src = ToBitmapSource(px, w, h);
        switch (ext)
        {
            case ".jpg":
            case ".jpeg":
            case ".jfif":
                enc = new JpegBitmapEncoder { QualityLevel = Math.Clamp(jpegQuality, 1, 100) };
                src = Flatten(px, w, h, 0xFFFFFFFF);
                break;
            case ".bmp":
                enc = new BmpBitmapEncoder();
                break;
            case ".tif":
            case ".tiff":
                enc = new TiffBitmapEncoder { Compression = TiffCompressOption.Zip };
                break;
            case ".gif":
                enc = new GifBitmapEncoder();
                break;
            case ".jxr":
            case ".wdp":
                enc = new WmpBitmapEncoder();
                break;
            default:
                enc = new PngBitmapEncoder();
                break;
        }
        enc.Frames.Add(BitmapFrame.Create(src));
        string tmp = path + ".tmp";
        using (var fs = File.Create(tmp)) enc.Save(fs);
        File.Move(tmp, path, true);
    }

    static BitmapSource Flatten(uint[] px, int w, int h, uint bg)
    {
        var o = new uint[px.Length];
        Parallel.For(0, px.Length, i => o[i] = Px.Over(bg, px[i]));
        return ToBitmapSource(o, w, h);
    }

    public static byte[] EncodePng(uint[] px, int w, int h)
    {
        var enc = new PngBitmapEncoder();
        enc.Frames.Add(BitmapFrame.Create(ToBitmapSource(px, w, h)));
        using var ms = new MemoryStream();
        enc.Save(ms);
        return ms.ToArray();
    }

    // ───────────────────────────── project files ─────────────────────────────

    public static bool IsPsd(string path)
    {
        var e = Path.GetExtension(path).ToLowerInvariant();
        return e == ".psd" || e == ".psb";
    }

    sealed class ProjectManifest
    {
        public string App { get; set; } = "Sky Master Photos";
        public int Version { get; set; } = 2;
        public int Width { get; set; }
        public int Height { get; set; }
        public int Active { get; set; }
        public List<ProjectLayer> Layers { get; set; } = new();
        public List<ProjectGroup> Groups { get; set; }
        public List<ProjectBlock> PsdGlobal { get; set; }
        public List<ProjectResource> PsdResources { get; set; }
    }

    sealed class ProjectLayer
    {
        public string Name { get; set; }
        public bool Visible { get; set; }
        public bool Locked { get; set; }
        public double Opacity { get; set; }
        public double Fill { get; set; } = 1;
        public string Blend { get; set; }
        public string File { get; set; }
        public string MaskFile { get; set; }
        public bool MaskEnabled { get; set; } = true;
        public bool Clipped { get; set; }
        public string Group { get; set; }
        public ProjectAdjust Adjustment { get; set; }
        public ProjectText Text { get; set; }
        public LayerStyle Style { get; set; }
        public ProjectPsd Psd { get; set; }
    }

    sealed class ProjectAdjust
    {
        public string Kind { get; set; }
        public Dictionary<string, double> P { get; set; }
        public List<double[]> Curve { get; set; }
        public string C1 { get; set; }
        public string C2 { get; set; }
        public bool FromPsd { get; set; }
    }

    sealed class ProjectText
    {
        public string Text { get; set; }
        public string Font { get; set; }
        public double Size { get; set; }
        public bool Bold { get; set; }
        public bool Italic { get; set; }
        public string Color { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public bool FromPsd { get; set; }
    }

    sealed class ProjectPsd
    {
        public List<ProjectBlock> Blocks { get; set; }
        public ulong SourceHash { get; set; }
        public string KindLabel { get; set; }
        public bool Unrendered { get; set; }
        public string BlendKey { get; set; }
        public string BlendAtImport { get; set; }
    }

    sealed class ProjectBlock
    {
        public string Key { get; set; }
        public string Data { get; set; }
    }

    sealed class ProjectResource
    {
        public int Id { get; set; }
        public string Data { get; set; }
    }

    sealed class ProjectGroup
    {
        public string Path { get; set; }
        public string Name { get; set; }
        public bool Visible { get; set; }
        public double Opacity { get; set; }
        public string Blend { get; set; }
        public bool Open { get; set; }
        public List<ProjectBlock> Blocks { get; set; }
    }

    static string Hex(Color c) => $"#{c.A:X2}{c.R:X2}{c.G:X2}{c.B:X2}";
    static Color FromHex(string s)
    {
        try { return (Color)ColorConverter.ConvertFromString(s); } catch { return Colors.Black; }
    }

    static List<ProjectBlock> Blocks(IEnumerable<PsdBlock> b) => b?.Select(x => new ProjectBlock { Key = x.Key, Data = Convert.ToBase64String(x.Data) }).ToList();
    static List<PsdBlock> Blocks(List<ProjectBlock> b) => b?.Select(x => new PsdBlock(x.Key, Convert.FromBase64String(x.Data))).ToList() ?? new();

    public static void SaveProject(Document doc, string path)
    {
        var man = new ProjectManifest { Width = doc.Width, Height = doc.Height, Active = doc.ActiveIndex };
        string tmp = path + ".tmp";
        using (var fs = File.Create(tmp))
        using (var zip = new ZipArchive(fs, ZipArchiveMode.Create))
        {
            void Png(string file, uint[] px)
            {
                var e = zip.CreateEntry(file, CompressionLevel.Fastest);
                using var es = e.Open();
                var bytes = EncodePng(px, doc.Width, doc.Height);
                es.Write(bytes, 0, bytes.Length);
            }
            for (int i = 0; i < doc.Layers.Count; i++)
            {
                var l = doc.Layers[i];
                var pl = new ProjectLayer
                {
                    Name = l.Name, Visible = l.Visible, Locked = l.Locked, Opacity = l.Opacity, Fill = l.Fill, Blend = l.Blend.ToString(),
                    File = $"layers/{i:D3}.png", MaskEnabled = l.MaskEnabled, Clipped = l.Clipped, Group = l.Group, Style = l.Style,
                };
                Png(pl.File, l.Pixels);
                if (l.Mask != null) { pl.MaskFile = $"layers/{i:D3}_mask.png"; Png(pl.MaskFile, l.Mask); }
                if (l.Adjustment is AdjustmentSpec a)
                    pl.Adjustment = new ProjectAdjust
                    {
                        Kind = a.Kind, P = a.P.ToDictionary(k => k.Key, k => k.Value), Curve = a.Curve?.Select(p => new[] { p.X, p.Y }).ToList(),
                        C1 = Hex(a.C1), C2 = Hex(a.C2), FromPsd = l.Psd != null && ReferenceEquals(l.Psd.ImportedAdjustment, a)
                    };
                if (l.Text is TextSpec t)
                    pl.Text = new ProjectText
                    {
                        Text = t.Text, Font = t.Font, Size = t.Size, Bold = t.Bold, Italic = t.Italic, Color = Hex(t.Color), X = t.X, Y = t.Y,
                        FromPsd = l.Psd != null && ReferenceEquals(l.Psd.ImportedText, t)
                    };
                if (l.Psd is PsdLayerData p)
                    pl.Psd = new ProjectPsd
                    {
                        Blocks = Blocks(p.Blocks), SourceHash = p.SourceHash, KindLabel = p.KindLabel, Unrendered = p.UnrenderedAdjustment,
                        BlendKey = p.BlendKey, BlendAtImport = p.BlendAtImport.ToString()
                    };
                man.Layers.Add(pl);
            }
            if (doc.Groups.Count > 0)
                man.Groups = doc.Groups.Select(g => new ProjectGroup { Path = g.Key, Name = g.Value.Name, Visible = g.Value.Visible, Opacity = g.Value.Opacity, Blend = g.Value.BlendKey, Open = g.Value.Open, Blocks = Blocks(g.Value.Blocks) }).ToList();
            if (doc.PsdData != null)
            {
                man.PsdGlobal = Blocks(doc.PsdData.GlobalBlocks);
                man.PsdResources = doc.PsdData.Resources.Select(r => new ProjectResource { Id = r.id, Data = Convert.ToBase64String(r.data) }).ToList();
            }
            // composite thumbnail for the home screen
            var thumb = MakeThumbPixels(doc.Flat, doc.Width, doc.Height, 512, out int tw, out int th);
            var te = zip.CreateEntry("thumbnail.png", CompressionLevel.Fastest);
            using (var ts = te.Open()) { var b = EncodePng(thumb, tw, th); ts.Write(b, 0, b.Length); }
            var me = zip.CreateEntry("manifest.json");
            using (var ms = me.Open())
                JsonSerializer.Serialize(ms, man, new JsonSerializerOptions { WriteIndented = true });
        }
        File.Move(tmp, path, true);
    }

    public static Document LoadProject(string path)
    {
        using var fs = File.OpenRead(path);
        using var zip = new ZipArchive(fs, ZipArchiveMode.Read);
        ProjectManifest man;
        using (var ms = zip.GetEntry("manifest.json").Open()) man = JsonSerializer.Deserialize<ProjectManifest>(ms);
        var doc = new Document(man.Width, man.Height, Path.GetFileNameWithoutExtension(path), "Open");
        uint[] ReadPng(string file)
        {
            using var es = zip.GetEntry(file).Open();
            using var mem = new MemoryStream();
            es.CopyTo(mem);
            mem.Position = 0;
            var (p, w, h) = LoadPixels(mem);
            return (w == man.Width && h == man.Height) ? p : Transforms.Canvas(p, w, h, man.Width, man.Height, 0, 0, 0);
        }
        foreach (var pl in man.Layers)
        {
            var l = new Layer(pl.Name, man.Width, man.Height, ReadPng(pl.File))
            {
                Visible = pl.Visible,
                Locked = pl.Locked,
                Opacity = pl.Opacity,
                Fill = pl.Fill <= 0 && man.Version < 2 ? 1 : pl.Fill,
                Blend = Enum.TryParse<BlendMode>(pl.Blend, out var bm) ? bm : BlendMode.Normal,
                Clipped = pl.Clipped,
                Group = pl.Group ?? "",
                Style = pl.Style,
            };
            if (pl.MaskFile != null) l.SetMask(Masks.Normalize(ReadPng(pl.MaskFile)));
            l.MaskEnabled = pl.MaskEnabled;
            if (pl.Psd != null)
                l.Psd = new PsdLayerData
                {
                    Blocks = Blocks(pl.Psd.Blocks), SourceHash = pl.Psd.SourceHash, KindLabel = pl.Psd.KindLabel, UnrenderedAdjustment = pl.Psd.Unrendered,
                    BlendKey = pl.Psd.BlendKey, BlendAtImport = Enum.TryParse<BlendMode>(pl.Psd.BlendAtImport, out var bi) ? bi : BlendMode.Normal
                };
            if (pl.Adjustment != null)
            {
                var a = new AdjustmentSpec
                {
                    Kind = pl.Adjustment.Kind, P = pl.Adjustment.P ?? new(),
                    Curve = pl.Adjustment.Curve?.Select(c => new System.Windows.Point(c[0], c[1])).ToList(),
                    C1 = FromHex(pl.Adjustment.C1), C2 = FromHex(pl.Adjustment.C2)
                };
                l.Adjustment = a;
                if (pl.Adjustment.FromPsd && l.Psd != null) l.Psd.ImportedAdjustment = a;
            }
            if (pl.Text != null)
            {
                var t = new TextSpec { Text = pl.Text.Text, Font = pl.Text.Font, Size = pl.Text.Size, Bold = pl.Text.Bold, Italic = pl.Text.Italic, Color = FromHex(pl.Text.Color), X = pl.Text.X, Y = pl.Text.Y };
                l.Text = t;
                if (pl.Text.FromPsd && l.Psd != null) l.Psd.ImportedText = t;
            }
            doc.Layers.Add(l);
        }
        if (man.Groups != null)
            foreach (var g in man.Groups) doc.Groups[g.Path] = new GroupInfo(g.Name, g.Visible, g.Opacity, g.Blend, g.Open) { Blocks = Blocks(g.Blocks) };
        if (man.PsdGlobal != null || man.PsdResources != null)
            doc.PsdData = new PsdDocData
            {
                GlobalBlocks = Blocks(man.PsdGlobal),
                Resources = man.PsdResources?.Select(r => ((ushort)r.Id, Convert.FromBase64String(r.Data))).ToList() ?? new(),
            };
        if (doc.Layers.Count == 0) doc.Layers.Add(new Layer("Layer 1", man.Width, man.Height));
        doc.ActiveLayer = doc.Layers[Math.Clamp(man.Active, 0, doc.Layers.Count - 1)];
        doc.FilePath = path;
        return doc;
    }

    public static BitmapSource LoadThumbnail(string path, int max)
    {
        try
        {
            if (IsPsd(path))
            {
                var (px, w, h) = Psd.PsdReader.ReadComposite(path);
                if (px == null) return null;
                var t = MakeThumbPixels(px, w, h, max, out int tw, out int th);
                return ToBitmapSource(t, tw, th);
            }
            if (Path.GetExtension(path).Equals(ProjectExt, StringComparison.OrdinalIgnoreCase))
            {
                using var fs = File.OpenRead(path);
                using var zip = new ZipArchive(fs, ZipArchiveMode.Read);
                var e = zip.GetEntry("thumbnail.png");
                if (e == null) return null;
                using var es = e.Open();
                using var mem = new MemoryStream();
                es.CopyTo(mem);
                mem.Position = 0;
                return DecodeScaled(mem, max);
            }
            using var f = File.OpenRead(path);
            return DecodeScaled(f, max);
        }
        catch { return null; }
    }

    static BitmapSource DecodeScaled(Stream s, int max)
    {
        var bi = new BitmapImage();
        bi.BeginInit();
        bi.CacheOption = BitmapCacheOption.OnLoad;
        bi.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
        bi.DecodePixelWidth = max;
        bi.StreamSource = s;
        bi.EndInit();
        bi.Freeze();
        return bi;
    }

    public static uint[] MakeThumbPixels(uint[] px, int w, int h, int max, out int tw, out int th)
    {
        double s = Math.Min(1.0, (double)max / Math.Max(w, h));
        tw = Math.Max(1, (int)(w * s)); th = Math.Max(1, (int)(h * s));
        return Transforms.Resize(px, w, h, tw, th);
    }
}

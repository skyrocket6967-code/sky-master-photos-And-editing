using System.Windows;
using System.Windows.Media;

namespace SkyMasterPhotos.Core;

/// <summary>
/// Immutable description of a non-destructive adjustment layer. Edits create a new instance so history
/// snapshots can keep references.
/// </summary>
public sealed class AdjustmentSpec
{
    public string Kind { get; init; }
    public IReadOnlyDictionary<string, double> P { get; init; } = new Dictionary<string, double>();
    public IReadOnlyList<Point> Curve { get; init; }
    public Color C1 { get; init; } = Colors.Black;
    public Color C2 { get; init; } = Colors.White;

    public double this[string key] => P.TryGetValue(key, out var v) ? v : 0;
    public bool B(string key) => this[key] >= 0.5;

    public static readonly string[] Kinds = { "brightness", "levels", "curves", "exposure", "vibrance", "huesat", "colorbalance", "bw", "photofilter", "invert", "posterize", "threshold", "gradientmap" };

    public string Title => Kind switch
    {
        "brightness" => "Brightness/Contrast",
        "levels" => "Levels",
        "curves" => "Curves",
        "exposure" => "Exposure",
        "vibrance" => "Vibrance",
        "huesat" => "Hue/Saturation",
        "colorbalance" => "Color Balance",
        "bw" => "Black & White",
        "photofilter" => "Photo Filter",
        "invert" => "Invert",
        "posterize" => "Posterize",
        "threshold" => "Threshold",
        "gradientmap" => "Gradient Map",
        _ => Kind
    };

    public string Icon => Kind switch
    {
        "brightness" => "brightness",
        "levels" => "levels",
        "curves" => "curves",
        "exposure" => "exposure",
        "vibrance" => "vibrance",
        "huesat" => "huesat",
        "colorbalance" => "colorbalance",
        "bw" => "bw",
        "photofilter" => "photofilter",
        "invert" => "invert",
        "posterize" => "posterize",
        "threshold" => "threshold",
        "gradientmap" => "gradientmap",
        _ => "sliders"
    };

    public Func<uint, uint> Build() => Kind switch
    {
        "brightness" => Adjustments.BrightnessContrastFn(this["b"], this["c"]),
        "levels" => Adjustments.LevelsFn(this["ib"], P.ContainsKey("iw") ? this["iw"] : 255, P.ContainsKey("g") ? this["g"] : 1, this["ob"], P.ContainsKey("ow") ? this["ow"] : 255),
        "curves" => Adjustments.CurvesFn(Curve?.ToList() ?? new List<Point> { new(0, 0), new(255, 255) }),
        "exposure" => Adjustments.ExposureFn(this["e"], this["o"], P.ContainsKey("g") ? this["g"] : 1),
        "vibrance" => Adjustments.VibranceFn(this["v"], this["s"]),
        "huesat" => Adjustments.HueSaturationFn(this["h"], this["s"], this["l"], B("c")),
        "colorbalance" => Adjustments.ColorBalanceFn(this["r"], this["g"], this["b"], !P.ContainsKey("p") || B("p")),
        "bw" => Adjustments.BlackWhiteFn(this["r"], this["y"], this["g"], this["c"], this["b"], this["m"]),
        "photofilter" => Adjustments.PhotoFilterFn(C1, P.ContainsKey("d") ? this["d"] : 25, !P.ContainsKey("l") || B("l")),
        "invert" => Adjustments.InvertFn,
        "posterize" => Adjustments.PosterizeFn((int)Math.Max(2, this["l"])),
        "threshold" => Adjustments.ThresholdFn((int)(P.ContainsKey("t") ? this["t"] : 128)),
        "gradientmap" => Adjustments.GradientMapFn(C1, C2),
        _ => p => p
    };

    public static AdjustmentSpec Default(string kind) => kind switch
    {
        "brightness" => new() { Kind = kind, P = D(("b", 0), ("c", 0)) },
        "levels" => new() { Kind = kind, P = D(("ib", 0), ("g", 1), ("iw", 255), ("ob", 0), ("ow", 255)) },
        "curves" => new() { Kind = kind, Curve = new List<Point> { new(0, 0), new(255, 255) } },
        "exposure" => new() { Kind = kind, P = D(("e", 0), ("o", 0), ("g", 1)) },
        "vibrance" => new() { Kind = kind, P = D(("v", 25), ("s", 0)) },
        "huesat" => new() { Kind = kind, P = D(("h", 0), ("s", 0), ("l", 0), ("c", 0)) },
        "colorbalance" => new() { Kind = kind, P = D(("r", 0), ("g", 0), ("b", 0), ("p", 1)) },
        "bw" => new() { Kind = kind, P = D(("r", 40), ("y", 60), ("g", 40), ("c", 60), ("b", 20), ("m", 80)) },
        "photofilter" => new() { Kind = kind, P = D(("d", 25), ("l", 1)), C1 = Color.FromRgb(236, 138, 0) },
        "invert" => new() { Kind = kind },
        "posterize" => new() { Kind = kind, P = D(("l", 6)) },
        "threshold" => new() { Kind = kind, P = D(("t", 128)) },
        "gradientmap" => new() { Kind = kind, C1 = Colors.Black, C2 = Colors.White },
        _ => new() { Kind = kind }
    };

    public static Dictionary<string, double> D(params (string k, double v)[] items) => items.ToDictionary(i => i.k, i => i.v);
}

/// <summary>Editable text source for text layers.</summary>
public sealed class TextSpec
{
    public string Text { get; init; } = "";
    public string Font { get; init; } = "Segoe UI";
    public double Size { get; init; } = 72;
    public bool Bold { get; init; }
    public bool Italic { get; init; }
    public Color Color { get; init; } = Colors.Black;
    /// <summary>Top-left of the text box in document pixels.</summary>
    public double X { get; init; }
    public double Y { get; init; }
}

/// <summary>A raw Photoshop "additional layer information" block (key + payload).</summary>
public sealed record PsdBlock(string Key, byte[] Data);

/// <summary>Photoshop-specific data kept on a layer so unedited features survive a PSD round-trip.</summary>
public sealed class PsdLayerData
{
    public List<PsdBlock> Blocks { get; set; } = new();
    /// <summary>Hash of pixels + mask at import; if unchanged on export, content-defining blocks are re-emitted.</summary>
    public ulong SourceHash { get; set; }
    /// <summary>Human label for preserved-but-not-editable kinds (Smart Object, Shape, Fill…).</summary>
    public string KindLabel { get; set; }
    /// <summary>The adjustment / text spec created at import; when still the current one, the original block is reused verbatim.</summary>
    public AdjustmentSpec ImportedAdjustment { get; set; }
    public TextSpec ImportedText { get; set; }
    /// <summary>Raw adjustment block for adjustments we preserve but cannot render (e.g. Channel Mixer).</summary>
    public bool UnrenderedAdjustment { get; set; }
    /// <summary>Original Photoshop blend key (e.g. 'diss'), reused on export while the mapped mode is unchanged.</summary>
    public string BlendKey { get; set; }
    public BlendMode BlendAtImport { get; set; }
    /// <summary>Original layer-record flags (transparency lock, 'pixel data irrelevant' for vector layers…).</summary>
    public byte RecordFlags { get; set; } = 0x08;

    static readonly HashSet<string> EffectKeys = new() { "lfx2", "lrFX", "lmfx" };
    public bool HasEffects => Blocks.Any(b => EffectKeys.Contains(b.Key));

    public PsdLayerData CloneForCopy() => new()
    {
        Blocks = Blocks.Where(b => b.Key != "lyid").ToList(),
        SourceHash = SourceHash,
        KindLabel = KindLabel,
        ImportedAdjustment = ImportedAdjustment,
        ImportedText = ImportedText,
        UnrenderedAdjustment = UnrenderedAdjustment,
        BlendKey = BlendKey,
        BlendAtImport = BlendAtImport,
        RecordFlags = RecordFlags,
    };

    public static ulong Hash(uint[] px, uint[] mask)
    {
        ulong h = 1469598103934665603UL;
        void Mix(uint[] a)
        {
            if (a == null) { h ^= 0x9E3779B97F4A7C15UL; return; }
            for (int i = 0; i < a.Length; i++) { h ^= a[i]; h *= 1099511628211UL; }
        }
        Mix(px);
        Mix(mask);
        return h;
    }
}

/// <summary>Properties of a Photoshop layer group (groups are kept as a path on each layer).</summary>
public sealed record GroupInfo(string Name, bool Visible, double Opacity, string BlendKey, bool Open)
{
    public List<PsdBlock> Blocks { get; init; } = new();
}

/// <summary>Document-level Photoshop data preserved for round-trips.</summary>
public sealed class PsdDocData
{
    public List<PsdBlock> GlobalBlocks { get; set; } = new();
    /// <summary>Image resources (id → data) that are safe to write back unchanged.</summary>
    public List<(ushort id, byte[] data)> Resources { get; set; } = new();
    public string SourceInfo { get; set; }
}

using System.Windows;
using System.Windows.Media;

namespace SkyMasterPhotos.Core;

public static class Transforms
{
    public static uint[] FlipH(uint[] src, int w, int h)
    {
        var o = new uint[src.Length];
        Parallel.For(0, h, y => { int r = y * w; for (int x = 0; x < w; x++) o[r + x] = src[r + w - 1 - x]; });
        return o;
    }

    public static uint[] FlipV(uint[] src, int w, int h)
    {
        var o = new uint[src.Length];
        Parallel.For(0, h, y => Array.Copy(src, (h - 1 - y) * w, o, y * w, w));
        return o;
    }

    /// <summary>Rotate 90° clockwise. Result is h × w.</summary>
    public static uint[] Rotate90(uint[] src, int w, int h)
    {
        var o = new uint[src.Length];
        Parallel.For(0, h, y => { for (int x = 0; x < w; x++) o[x * h + (h - 1 - y)] = src[y * w + x]; });
        return o;
    }

    public static uint[] Rotate270(uint[] src, int w, int h)
    {
        var o = new uint[src.Length];
        Parallel.For(0, h, y => { for (int x = 0; x < w; x++) o[(w - 1 - x) * h + y] = src[y * w + x]; });
        return o;
    }

    public static uint[] Rotate180(uint[] src, int w, int h)
    {
        var o = new uint[src.Length];
        int n = src.Length;
        Parallel.For(0, n, i => o[i] = src[n - 1 - i]);
        return o;
    }

    public static uint[] Crop(uint[] src, int w, int h, Int32Rect r)
    {
        var o = new uint[r.Width * r.Height];
        Parallel.For(0, r.Height, y =>
        {
            int sy = r.Y + y;
            if (sy < 0 || sy >= h) return;
            for (int x = 0; x < r.Width; x++)
            {
                int sx = r.X + x;
                if (sx >= 0 && sx < w) o[y * r.Width + x] = src[sy * w + sx];
            }
        });
        return o;
    }

    /// <summary>Canvas resize: places old content at offset (ox, oy) in a new nw×nh buffer filled with fill.</summary>
    public static uint[] Canvas(uint[] src, int w, int h, int nw, int nh, int ox, int oy, uint fill)
    {
        var o = new uint[nw * nh];
        if (fill != 0) Array.Fill(o, fill);
        Parallel.For(0, h, y =>
        {
            int ny = y + oy;
            if (ny < 0 || ny >= nh) return;
            for (int x = 0; x < w; x++)
            {
                int nx = x + ox;
                if (nx >= 0 && nx < nw) o[ny * nw + nx] = src[y * w + x];
            }
        });
        return o;
    }

    /// <summary>High quality resize: area-average when shrinking, bicubic when enlarging.</summary>
    public static uint[] Resize(uint[] src, int w, int h, int nw, int nh)
    {
        if (nw == w && nh == h) return (uint[])src.Clone();
        if (nw <= w && nh <= h) return AreaDown(src, w, h, nw, nh);
        if (nw >= w && nh >= h) return Bicubic(src, w, h, nw, nh);
        // mixed: shrink one axis first
        var mid = AreaDown(src, w, h, Math.Min(w, nw), Math.Min(h, nh));
        return Bicubic(mid, Math.Min(w, nw), Math.Min(h, nh), nw, nh);
    }

    static uint[] AreaDown(uint[] src, int w, int h, int nw, int nh)
    {
        var o = new uint[nw * nh];
        double sx = (double)w / nw, sy = (double)h / nh;
        Parallel.For(0, nh, ty =>
        {
            double y0 = ty * sy, y1 = y0 + sy;
            for (int tx = 0; tx < nw; tx++)
            {
                double x0 = tx * sx, x1 = x0 + sx;
                double a = 0, r = 0, g = 0, b = 0, wt = 0;
                for (int y = (int)y0; y < Math.Min(h, (int)Math.Ceiling(y1)); y++)
                {
                    double wy = Math.Min(y + 1, y1) - Math.Max(y, y0);
                    if (wy <= 0) continue;
                    for (int x = (int)x0; x < Math.Min(w, (int)Math.Ceiling(x1)); x++)
                    {
                        double wx = Math.Min(x + 1, x1) - Math.Max(x, x0);
                        if (wx <= 0) continue;
                        double k = wx * wy;
                        uint p = src[y * w + x];
                        double pa = Px.A(p) * k;
                        a += pa; r += Px.R(p) * pa; g += Px.G(p) * pa; b += Px.B(p) * pa; wt += k;
                    }
                }
                o[ty * nw + tx] = a <= 0 ? 0 : Px.Pack(Px.Clamp(a / wt), Px.Clamp(r / a), Px.Clamp(g / a), Px.Clamp(b / a));
            }
        });
        return o;
    }

    static double Cubic(double x)
    {
        const double A = -0.5;
        x = Math.Abs(x);
        if (x <= 1) return (A + 2) * x * x * x - (A + 3) * x * x + 1;
        if (x < 2) return A * x * x * x - 5 * A * x * x + 8 * A * x - 4 * A;
        return 0;
    }

    static uint[] Bicubic(uint[] src, int w, int h, int nw, int nh)
    {
        var o = new uint[nw * nh];
        double sx = (double)w / nw, sy = (double)h / nh;
        Parallel.For(0, nh, ty =>
        {
            double fy = (ty + 0.5) * sy - 0.5;
            int iy = (int)Math.Floor(fy);
            Span<double> wy = stackalloc double[4];
            Span<double> wx = stackalloc double[4];
            for (int k = 0; k < 4; k++) wy[k] = Cubic(fy - (iy - 1 + k));
            for (int tx = 0; tx < nw; tx++)
            {
                double fx = (tx + 0.5) * sx - 0.5;
                int ix = (int)Math.Floor(fx);
                for (int k = 0; k < 4; k++) wx[k] = Cubic(fx - (ix - 1 + k));
                double a = 0, r = 0, g = 0, b = 0, wsum = 0;
                for (int ky = 0; ky < 4; ky++)
                {
                    int yy = Math.Clamp(iy - 1 + ky, 0, h - 1);
                    for (int kx = 0; kx < 4; kx++)
                    {
                        int xx = Math.Clamp(ix - 1 + kx, 0, w - 1);
                        double k = wx[kx] * wy[ky];
                        uint p = src[yy * w + xx];
                        double pa = Px.A(p) * k;
                        a += pa; r += Px.R(p) * pa; g += Px.G(p) * pa; b += Px.B(p) * pa; wsum += k;
                    }
                }
                o[ty * nw + tx] = a <= 0.5 ? 0 : Px.Pack(Px.Clamp(a / wsum), Px.Clamp(r / a), Px.Clamp(g / a), Px.Clamp(b / a));
            }
        });
        return o;
    }

    /// <summary>
    /// Render src transformed by m (src space → dst space) into a dstW×dstH buffer.
    /// Uses inverse mapping with bilinear sampling (or nearest for pure integer translations).
    /// </summary>
    public static uint[] Affine(uint[] src, int w, int h, Matrix m, int dstW, int dstH)
    {
        var o = new uint[dstW * dstH];
        if (!m.HasInverse) return o;
        bool integerTranslate = m.M11 == 1 && m.M22 == 1 && m.M12 == 0 && m.M21 == 0 &&
                                m.OffsetX == Math.Round(m.OffsetX) && m.OffsetY == Math.Round(m.OffsetY);
        if (integerTranslate)
            return Canvas(src, w, h, dstW, dstH, (int)m.OffsetX, (int)m.OffsetY, 0);

        var inv = m; inv.Invert();
        // bounds of transformed rect
        var corners = new[] { new Point(0, 0), new Point(w, 0), new Point(0, h), new Point(w, h) }.Select(m.Transform).ToArray();
        int x0 = Math.Max(0, (int)Math.Floor(corners.Min(p => p.X))), x1 = Math.Min(dstW, (int)Math.Ceiling(corners.Max(p => p.X)));
        int y0 = Math.Max(0, (int)Math.Floor(corners.Min(p => p.Y))), y1 = Math.Min(dstH, (int)Math.Ceiling(corners.Max(p => p.Y)));
        if (x1 <= x0 || y1 <= y0) return o;
        // area-ish quality when shrinking a lot: pre-shrink the source
        double scale = Math.Sqrt(Math.Abs(m.M11 * m.M22 - m.M12 * m.M21));
        if (scale < 0.5)
        {
            int sw = Math.Max(1, (int)(w * scale * 1.5)), sh = Math.Max(1, (int)(h * scale * 1.5));
            var small = AreaDown(src, w, h, sw, sh);
            var pre = new Matrix((double)w / sw, 0, 0, (double)h / sh, 0, 0);
            pre.Append(m);
            return Affine(small, sw, sh, pre, dstW, dstH);
        }
        Parallel.For(y0, y1, y =>
        {
            for (int x = x0; x < x1; x++)
            {
                var sp = inv.Transform(new Point(x + 0.5, y + 0.5));
                if (sp.X < -1 || sp.Y < -1 || sp.X > w + 1 || sp.Y > h + 1) continue;
                o[y * dstW + x] = Filters.SampleBilinear(src, w, h, sp.X, sp.Y);
            }
        });
        return o;
    }

    /// <summary>Bounding box of non-transparent pixels.</summary>
    public static Int32Rect OpaqueBounds(uint[] px, int w, int h)
    {
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++)
                if ((px[y * w + x] >> 24) != 0)
                {
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    maxY = y;
                }
        return maxX < 0 ? Int32Rect.Empty : new Int32Rect(minX, minY, maxX - minX + 1, maxY - minY + 1);
    }
}

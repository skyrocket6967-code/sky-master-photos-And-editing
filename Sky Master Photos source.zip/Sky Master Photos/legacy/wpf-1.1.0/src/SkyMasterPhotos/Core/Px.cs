using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Media;

namespace SkyMasterPhotos.Core;

/// <summary>Helpers for packed BGRA32 (straight alpha) pixels stored as 0xAARRGGBB.</summary>
public static class Px
{
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint Pack(int a, int r, int g, int b) => (uint)((a << 24) | (r << 16) | (g << 8) | b);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int A(uint p) => (int)(p >> 24);
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int R(uint p) => (int)((p >> 16) & 255);
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int G(uint p) => (int)((p >> 8) & 255);
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int B(uint p) => (int)(p & 255);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int Clamp(int v) => v < 0 ? 0 : v > 255 ? 255 : v;

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static int Clamp(double v) => v <= 0 ? 0 : v >= 255 ? 255 : (int)(v + 0.5);

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint WithAlpha(uint p, int a) => (p & 0x00FFFFFFu) | ((uint)a << 24);

    public static uint FromColor(Color c) => Pack(c.A, c.R, c.G, c.B);
    public static Color ToColor(uint p) => Color.FromArgb((byte)A(p), (byte)R(p), (byte)G(p), (byte)B(p));

    /// <summary>Linear interpolation between two straight-alpha pixels, t in 0..1.</summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint Lerp(uint a, uint b, float t)
    {
        if (t <= 0) return a;
        if (t >= 1) return b;
        float aa = A(a), ba = A(b);
        float oa = aa + (ba - aa) * t;
        if (oa < 0.5f) return 0;
        // interpolate premultiplied so transparent pixels don't bleed black
        float r = (R(a) * aa + (R(b) * ba - R(a) * aa) * t) / oa;
        float g = (G(a) * aa + (G(b) * ba - G(a) * aa) * t) / oa;
        float bl = (B(a) * aa + (B(b) * ba - B(a) * aa) * t) / oa;
        return Pack(Clamp(oa), Clamp(r), Clamp(g), Clamp(bl));
    }

    /// <summary>Source-over composite of src onto dst (both straight alpha) with extra opacity.</summary>
    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    public static uint Over(uint dst, uint src, float opacity = 1f)
    {
        float sa = A(src) / 255f * opacity;
        if (sa <= 0) return dst;
        float da = A(dst) / 255f;
        float oa = sa + da * (1 - sa);
        if (oa <= 0) return 0;
        float k = da * (1 - sa);
        float r = (R(src) * sa + R(dst) * k) / oa;
        float g = (G(src) * sa + G(dst) * k) / oa;
        float b = (B(src) * sa + B(dst) * k) / oa;
        return Pack(Clamp(oa * 255f), Clamp(r), Clamp(g), Clamp(b));
    }

    public static double Luma(uint p) => 0.299 * R(p) + 0.587 * G(p) + 0.114 * B(p);

    public static void RgbToHsl(double r, double g, double b, out double h, out double s, out double l)
    {
        double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
        l = (max + min) / 2;
        if (max == min) { h = 0; s = 0; return; }
        double d = max - min;
        s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
        if (max == r) h = (g - b) / d + (g < b ? 6 : 0);
        else if (max == g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;
        h /= 6;
    }

    static double Hue2Rgb(double p, double q, double t)
    {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1.0 / 6) return p + (q - p) * 6 * t;
        if (t < 0.5) return q;
        if (t < 2.0 / 3) return p + (q - p) * (2.0 / 3 - t) * 6;
        return p;
    }

    public static void HslToRgb(double h, double s, double l, out double r, out double g, out double b)
    {
        if (s <= 0) { r = g = b = l; return; }
        double q = l < 0.5 ? l * (1 + s) : l + s - l * s;
        double p = 2 * l - q;
        r = Hue2Rgb(p, q, h + 1.0 / 3);
        g = Hue2Rgb(p, q, h);
        b = Hue2Rgb(p, q, h - 1.0 / 3);
    }

    public static void RgbToHsv(double r, double g, double b, out double h, out double s, out double v)
    {
        double max = Math.Max(r, Math.Max(g, b)), min = Math.Min(r, Math.Min(g, b));
        v = max;
        double d = max - min;
        s = max <= 0 ? 0 : d / max;
        if (d <= 0) { h = 0; return; }
        if (max == r) h = (g - b) / d + (g < b ? 6 : 0);
        else if (max == g) h = (b - r) / d + 2;
        else h = (r - g) / d + 4;
        h /= 6;
    }

    public static void HsvToRgb(double h, double s, double v, out double r, out double g, out double b)
    {
        h = (h % 1 + 1) % 1 * 6;
        int i = (int)Math.Floor(h);
        double f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
        switch (i % 6)
        {
            case 0: r = v; g = t; b = p; break;
            case 1: r = q; g = v; b = p; break;
            case 2: r = p; g = v; b = t; break;
            case 3: r = p; g = q; b = v; break;
            case 4: r = t; g = p; b = v; break;
            default: r = v; g = p; b = q; break;
        }
    }

    public static string ToHex(Color c) => $"{c.R:X2}{c.G:X2}{c.B:X2}";

    public static bool TryParseHex(string s, out Color c)
    {
        c = Colors.Black;
        if (string.IsNullOrWhiteSpace(s)) return false;
        s = s.Trim().TrimStart('#');
        if (s.Length == 3) s = string.Concat(s[0], s[0], s[1], s[1], s[2], s[2]);
        if (s.Length != 6) return false;
        if (!uint.TryParse(s, System.Globalization.NumberStyles.HexNumber, null, out uint v)) return false;
        c = Color.FromRgb((byte)(v >> 16), (byte)(v >> 8), (byte)v);
        return true;
    }
}

public static class RectUtil
{
    public static Int32Rect Union(Int32Rect a, Int32Rect b)
    {
        if (a.IsEmpty || a.Width <= 0 || a.Height <= 0) return b;
        if (b.IsEmpty || b.Width <= 0 || b.Height <= 0) return a;
        int x0 = Math.Min(a.X, b.X), y0 = Math.Min(a.Y, b.Y);
        int x1 = Math.Max(a.X + a.Width, b.X + b.Width), y1 = Math.Max(a.Y + a.Height, b.Y + b.Height);
        return new Int32Rect(x0, y0, x1 - x0, y1 - y0);
    }

    public static Int32Rect Clip(Int32Rect r, int w, int h)
    {
        int x0 = Math.Max(0, r.X), y0 = Math.Max(0, r.Y);
        int x1 = Math.Min(w, r.X + r.Width), y1 = Math.Min(h, r.Y + r.Height);
        if (x1 <= x0 || y1 <= y0) return Int32Rect.Empty;
        return new Int32Rect(x0, y0, x1 - x0, y1 - y0);
    }

    public static bool IsEmptyRect(Int32Rect r) => r.IsEmpty || r.Width <= 0 || r.Height <= 0;

    public static Int32Rect FromPoints(double x0, double y0, double x1, double y1, double pad = 0)
    {
        int ax = (int)Math.Floor(Math.Min(x0, x1) - pad), ay = (int)Math.Floor(Math.Min(y0, y1) - pad);
        int bx = (int)Math.Ceiling(Math.Max(x0, x1) + pad), by = (int)Math.Ceiling(Math.Max(y0, y1) + pad);
        return new Int32Rect(ax, ay, Math.Max(1, bx - ax), Math.Max(1, by - ay));
    }
}

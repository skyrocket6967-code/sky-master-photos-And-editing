using System.IO;
using System.Windows;
using System.Windows.Threading;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos;

public partial class App : Application
{
    public static string[] StartupFiles = Array.Empty<string>();
    public static bool SelfTest;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        DispatcherUnhandledException += OnUnhandled;
        AppDomain.CurrentDomain.UnhandledException += (_, a) => LogCrash(a.ExceptionObject as Exception);
        AppStore.Load();
        StartupFiles = e.Args.Where(a => !a.StartsWith("--") && File.Exists(a)).ToArray();
        SelfTest = e.Args.Contains("--selftest");
        var w = new MainWindow();
        MainWindow = w;
        w.Show();
    }

    void OnUnhandled(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        LogCrash(e.Exception);
        e.Handled = true;
        try { SkyDialog.Alert(MainWindow, "Something went wrong", e.Exception.Message + "\n\nYour work is still open — saving a copy is recommended."); } catch { }
    }

    static void LogCrash(Exception ex)
    {
        if (ex == null) return;
        try
        {
            Directory.CreateDirectory(AppStore.Dir);
            File.AppendAllText(Path.Combine(AppStore.Dir, "errors.log"), $"[{DateTime.Now:u}] {ex}\n\n");
        }
        catch { }
    }
}

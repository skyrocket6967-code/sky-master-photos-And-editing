using System.Windows;
using System.Windows.Controls;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos;

public partial class MainWindow
{
    void EditLayerStyle()
    {
        if (!RequireDoc() || _active.ActiveLayer == null) return;
        var doc = _active;
        var layer = doc.ActiveLayer;
        if (layer.Locked || layer.IsAdjustmentLike) { Toast("Select an unlocked pixel or text layer"); return; }
        var original = layer.Style;
        var before = doc.Capture();
        var style = original ?? new LayerStyle();
        var dialog = new SkyDialog(this, "Layer style");
        var panel = new StackPanel { Width = 340 };
        var checks = new List<CheckBox>();
        foreach (var item in new[] { ("Drop shadow", style.Shadow), ("Outer glow", style.OuterGlow),
            ("Inner glow", style.InnerGlow), ("Bevel & emboss", style.Bevel), ("Stroke", style.Stroke) })
        {
            var check = new CheckBox { Content = item.Item1, IsChecked = item.Item2, Margin = new Thickness(0, 5, 0, 5) };
            checks.Add(check); panel.Children.Add(check);
        }
        Slider Slider(string label, double min, double max, double value)
        {
            var text = new TextBlock { Margin = new Thickness(0, 10, 0, 4) };
            var slider = new Slider { Minimum = min, Maximum = max, Value = value };
            void Update() => text.Text = $"{label}: {Math.Round(slider.Value)}";
            slider.ValueChanged += (_, _) => Update(); Update();
            panel.Children.Add(text); panel.Children.Add(slider); return slider;
        }
        var size = Slider("Size (px)", 1, 100, style.Size);
        var distance = Slider("Shadow distance (px)", 0, 100, style.Distance);
        var angle = Slider("Light angle", -180, 180, style.Angle);
        var strength = Slider("Opacity (%)", 0, 100, style.Strength * 100);
        uint color = style.Color;
        var colorButton = new Button { Content = "Use foreground color", Margin = new Thickness(0, 12, 0, 0) };
        panel.Children.Add(colorButton);
        void Preview()
        {
            layer.Style = new LayerStyle { Shadow = checks[0].IsChecked == true, OuterGlow = checks[1].IsChecked == true,
                InnerGlow = checks[2].IsChecked == true, Bevel = checks[3].IsChecked == true, Stroke = checks[4].IsChecked == true,
                Size = (int)size.Value, Distance = (int)distance.Value, Angle = angle.Value,
                Strength = strength.Value / 100, Color = color };
            doc.RenderAll();
        }
        var timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(180) };
        timer.Tick += (_, _) => { timer.Stop(); Preview(); };
        void Queue() { timer.Stop(); timer.Start(); }
        foreach (var check in checks) { check.Checked += (_, _) => Queue(); check.Unchecked += (_, _) => Queue(); }
        foreach (var slider in new[] { size, distance, angle, strength }) slider.ValueChanged += (_, _) => Queue();
        colorButton.Click += (_, _) => { color = Px.FromColor(_fg); Queue(); };
        dialog.Body = panel;
        dialog.AddButton("Cancel", false, () => dialog.DialogResult = false);
        dialog.AddButton("Clear", false, () => { timer.Stop(); layer.Style = null; dialog.DialogResult = true; });
        dialog.AddButton("Apply", true, () => { timer.Stop(); Preview(); dialog.DialogResult = true; });
        bool applied = dialog.ShowDialog() == true;
        timer.Stop();
        if (applied) doc.Record("Layer Style", before);
        else layer.Style = original;
        doc.RenderAll();
        layer.NotifyInfo();
    }
}

using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace SkyMasterPhotos.UI;

/// <summary>Small factory helpers for building themed UI from code.</summary>
public static class UIx
{
    public static T R<T>(string key) where T : class => Application.Current.TryFindResource(key) as T;

    public static TextBlock Label(string t, double size = 12, string brush = "Text2", FontWeight? weight = null) => new()
    {
        Text = t, FontSize = size, Foreground = R<Brush>(brush), VerticalAlignment = VerticalAlignment.Center,
        FontWeight = weight ?? FontWeights.Normal
    };

    public static Border VDivider() => new() { Width = 1, Height = 22, Background = R<Brush>("Line2"), Margin = new Thickness(10, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center };

    /// <summary>Compact "label ─●── 42px" control for the options bar.</summary>
    public static FrameworkElement OptSlider(string label, double min, double max, double value, Action<double> onChange, string suffix = "", int decimals = 0, double width = 110, Func<double, double> toDisplay = null)
    {
        toDisplay ??= v => v;
        var sp = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 14, 0) };
        sp.Children.Add(Label(label, 12, "Text3"));
        var s = new Slider { Minimum = min, Maximum = max, Value = value, Width = width, Margin = new Thickness(8, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center };
        var box = new TextBox { Width = 52, Padding = new Thickness(6, 3, 6, 3), FontSize = 12, Text = Fmt(toDisplay(value), decimals) + suffix, HorizontalContentAlignment = HorizontalAlignment.Center };
        bool updating = false;
        s.ValueChanged += (_, e) =>
        {
            if (updating) return;
            updating = true;
            box.Text = Fmt(toDisplay(e.NewValue), decimals) + suffix;
            updating = false;
            onChange(e.NewValue);
        };
        void Commit()
        {
            var txt = box.Text.Replace(suffix, "").Trim();
            if (double.TryParse(txt, NumberStyles.Float, CultureInfo.InvariantCulture, out double v) || double.TryParse(txt, out v))
            {
                // invert display mapping by search when needed
                double target = v;
                if (toDisplay(1) != 1 || toDisplay(0) != 0)
                {
                    double best = min, bestErr = double.MaxValue;
                    for (int i = 0; i <= 400; i++) { double c = min + (max - min) * i / 400; double err = Math.Abs(toDisplay(c) - v); if (err < bestErr) { bestErr = err; best = c; } }
                    target = best;
                }
                s.Value = Math.Clamp(target, min, max);
            }
            box.Text = Fmt(toDisplay(s.Value), decimals) + suffix;
        }
        box.KeyDown += (_, e) => { if (e.Key == Key.Enter) { Commit(); Keyboard.ClearFocus(); e.Handled = true; } };
        box.LostKeyboardFocus += (_, _) => Commit();
        sp.Children.Add(s);
        sp.Children.Add(box);
        sp.Tag = s;
        return sp;
    }

    static string Fmt(double v, int decimals) => v.ToString(decimals == 0 ? "0" : "0." + new string('0', decimals), CultureInfo.InvariantCulture);

    /// <summary>Full-width labelled slider row used in dialogs and panels.</summary>
    public static (FrameworkElement row, Slider slider) SliderRow(string label, double min, double max, double value, Action<double> onChange, int decimals = 0, string suffix = "", double width = 340)
    {
        var g = new Grid { Width = width, Margin = new Thickness(0, 0, 0, 12) };
        g.ColumnDefinitions.Add(new ColumnDefinition());
        g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        var lbl = Label(label, 12.5, "Text2");
        g.Children.Add(lbl);
        var box = new TextBox { Width = 64, Padding = new Thickness(6, 3, 6, 3), FontSize = 12, HorizontalContentAlignment = HorizontalAlignment.Right, Text = Fmt(value, decimals) + suffix, Margin = new Thickness(0, 0, 0, 4) };
        Grid.SetColumn(box, 1);
        g.Children.Add(box);
        var s = new Slider { Minimum = min, Maximum = max, Value = value, Margin = new Thickness(0, 2, 0, 0) };
        if (max - min <= 20 && decimals == 0) { s.TickFrequency = 1; s.IsSnapToTickEnabled = true; }
        Grid.SetRow(s, 1);
        Grid.SetColumnSpan(s, 2);
        g.Children.Add(s);
        bool upd = false;
        s.ValueChanged += (_, e) =>
        {
            if (upd) return;
            upd = true;
            box.Text = Fmt(e.NewValue, decimals) + suffix;
            upd = false;
            onChange(e.NewValue);
        };
        void Commit()
        {
            var txt = box.Text.Replace(suffix, "").Trim();
            if (double.TryParse(txt, NumberStyles.Float, CultureInfo.InvariantCulture, out double v) || double.TryParse(txt, out v))
                s.Value = Math.Clamp(v, min, max);
            box.Text = Fmt(s.Value, decimals) + suffix;
        }
        box.KeyDown += (_, e) => { if (e.Key == Key.Enter) { Commit(); e.Handled = true; } };
        box.LostKeyboardFocus += (_, _) => Commit();
        // double-click label resets
        double def = value;
        lbl.MouseLeftButtonDown += (_, e) => { if (e.ClickCount == 2) s.Value = def; };
        lbl.ToolTip = "Double-click to reset";
        return (g, s);
    }

    public static ToggleButton Seg(object content, bool isChecked, Action onClick, string tip = null)
    {
        var t = new ToggleButton { Content = content, IsChecked = isChecked, Style = R<Style>("Segment"), ToolTip = tip };
        t.Click += (_, _) => onClick();
        return t;
    }

    /// <summary>A pill containing mutually exclusive segment toggles.</summary>
    public static Border SegGroup(IEnumerable<(object content, string tip)> items, int selected, Action<int> onSelect)
    {
        var sp = new StackPanel { Orientation = Orientation.Horizontal };
        var list = new List<ToggleButton>();
        int i = 0;
        foreach (var (content, tip) in items)
        {
            int idx = i++;
            ToggleButton t = null;
            t = Seg(content, idx == selected, () =>
            {
                foreach (var o in list) o.IsChecked = o == t;
                onSelect(idx);
            }, tip);
            list.Add(t);
            sp.Children.Add(t);
        }
        return new Border { Child = sp, Background = R<Brush>("Bg0"), CornerRadius = new CornerRadius(9), Padding = new Thickness(2), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 12, 0), Tag = list };
    }

    public static Button DropButton(string text, Func<ContextMenu> build, double minWidth = 120)
    {
        var tb = new TextBlock { Text = text, VerticalAlignment = VerticalAlignment.Center, Foreground = R<Brush>("Text") };
        var content = new DockPanel { LastChildFill = true, MinWidth = minWidth - 20 };
        var chev = new Ico("chev-down", 14) { Margin = new Thickness(8, 0, 0, 0) };
        DockPanel.SetDock(chev, Dock.Right);
        content.Children.Add(chev);
        content.Children.Add(tb);
        var b = new Button { Content = content, Style = R<Style>("Secondary"), Padding = new Thickness(10, 4, 8, 4), HorizontalContentAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Center, Tag = tb };
        b.Click += (_, _) =>
        {
            var m = build();
            m.PlacementTarget = b;
            m.Placement = PlacementMode.Bottom;
            m.IsOpen = true;
        };
        return b;
    }

    public static void SetDropText(Button b, string text) { if (b.Tag is TextBlock tb) tb.Text = text; }

    public static MenuItem Item(string header, Action click, string gesture = null, string icon = null, bool isChecked = false)
    {
        var mi = new MenuItem { Header = header, InputGestureText = gesture ?? "", IsChecked = isChecked };
        if (icon != null) mi.Icon = new Ico(icon, 15);
        if (click != null) mi.Click += (_, _) => click();
        return mi;
    }

    public static Border Card(UIElement child, double radius = 12, string bg = "Bg2") => new()
    {
        Child = child, Background = R<Brush>(bg), CornerRadius = new CornerRadius(radius), BorderBrush = R<Brush>("Line"), BorderThickness = new Thickness(1)
    };

    public static ImageBrush Checker(double cell = 8, bool dark = true)
    {
        var px = new uint[4];
        uint a = dark ? 0xFF2A2E38u : 0xFFFFFFFFu, b = dark ? 0xFF20232B : 0xFFD4D8DF;
        px[0] = a; px[1] = b; px[2] = b; px[3] = a;
        var bmp = System.Windows.Media.Imaging.BitmapSource.Create(2, 2, 96, 96, PixelFormats.Bgra32, null, px, 8);
        bmp.Freeze();
        var br = new ImageBrush(bmp) { TileMode = TileMode.Tile, Viewport = new Rect(0, 0, cell * 2, cell * 2), ViewportUnits = BrushMappingMode.Absolute, Stretch = Stretch.Fill };
        RenderOptions.SetBitmapScalingMode(br, BitmapScalingMode.NearestNeighbor);
        br.Freeze();
        return br;
    }
}

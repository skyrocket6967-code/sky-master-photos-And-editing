using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace SkyMasterPhotos.UI;

public sealed class FuncConverter : IValueConverter
{
    readonly Func<object, object> _f;
    public FuncConverter(Func<object, object> f) => _f = f;
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => _f(value);
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}

public static class Conv
{
    public static readonly IValueConverter TagToVis = new FuncConverter(v => v is true || (v is string s && s.Length > 0) ? Visibility.Visible : Visibility.Collapsed);
    public static readonly IValueConverter BoolToVis = new FuncConverter(v => v is true ? Visibility.Visible : Visibility.Collapsed);
    public static readonly IValueConverter NotBoolToVis = new FuncConverter(v => v is true ? Visibility.Collapsed : Visibility.Visible);
    public static readonly IValueConverter EyeKind = new FuncConverter(v => v is true ? "eye" : "eyeoff");
    public static readonly IValueConverter LockKind = new FuncConverter(v => v is true ? "lock" : "unlock");
    public static readonly IValueConverter HalfOpacity = new FuncConverter(v => v is true ? 0.35 : 1.0);
    public static readonly IValueConverter VisibleOpacity = new FuncConverter(v => v is true ? 1.0 : 0.4);
    public static readonly IValueConverter DepthIndent = new FuncConverter(v => new Thickness(v is int d ? d * 12 : 0, 0, 0, 0));
    public static readonly IValueConverter TargetBorder = new FuncConverter(v => v is true ? (object)System.Windows.Media.Brushes.White : Application.Current.TryFindResource("Line2"));
    public static readonly IValueConverter NullToVis = new FuncConverter(v => v == null ? Visibility.Collapsed : Visibility.Visible);
}

using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;

namespace SkyMasterPhotos.UI;

public enum SaveChoice { Save, DontSave, Cancel }

/// <summary>Frameless, rounded, shadowed dialog shell used by every popup window in the app.</summary>
public class SkyDialog : Window
{
    readonly ContentControl _body = new();
    readonly DockPanel _footer = new() { LastChildFill = false };
    readonly StackPanel _footerRight = new() { Orientation = Orientation.Horizontal };
    readonly StackPanel _footerLeft = new() { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
    readonly TextBlock _title = new();
    readonly TextBlock _subtitle = new();
    public Button DefaultButton { get; private set; }

    public SkyDialog(Window owner, string title, string subtitle = null)
    {
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        ResizeMode = ResizeMode.NoResize;
        ShowInTaskbar = false;
        SizeToContent = SizeToContent.WidthAndHeight;
        if (owner != null && owner.IsLoaded) { Owner = owner; WindowStartupLocation = WindowStartupLocation.CenterOwner; }
        else WindowStartupLocation = WindowStartupLocation.CenterScreen;
        FontFamily = R<FontFamily>("UiFont");
        Foreground = R<Brush>("Text");
        UseLayoutRounding = true;
        TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
        Title = title;

        _title.Text = title;
        _title.Style = R<Style>("H2");
        _subtitle.Text = subtitle ?? "";
        _subtitle.Style = R<Style>("Muted");
        _subtitle.Margin = new Thickness(0, 3, 0, 0);
        _subtitle.Visibility = string.IsNullOrEmpty(subtitle) ? Visibility.Collapsed : Visibility.Visible;
        _subtitle.TextWrapping = TextWrapping.Wrap;
        _subtitle.MaxWidth = 520;

        var close = new Button { Style = R<Style>("IconBtn"), Content = new Ico("close", 16), HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top };
        close.Click += (_, _) => { DialogResult = false; };

        var header = new Grid { Margin = new Thickness(24, 20, 16, 0), Background = Brushes.Transparent };
        header.ColumnDefinitions.Add(new ColumnDefinition());
        header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        var titles = new StackPanel();
        titles.Children.Add(_title);
        titles.Children.Add(_subtitle);
        header.Children.Add(titles);
        Grid.SetColumn(close, 1);
        header.Children.Add(close);
        header.MouseLeftButtonDown += (_, e) => { if (e.ButtonState == MouseButtonState.Pressed) try { DragMove(); } catch { } };

        _body.Margin = new Thickness(24, 16, 24, 0);
        _footer.Margin = new Thickness(24, 20, 24, 22);
        DockPanel.SetDock(_footerLeft, Dock.Left);
        DockPanel.SetDock(_footerRight, Dock.Right);
        _footer.Children.Add(_footerLeft);
        _footer.Children.Add(_footerRight);

        var stack = new DockPanel { LastChildFill = true };
        DockPanel.SetDock(header, Dock.Top);
        DockPanel.SetDock(_footer, Dock.Bottom);
        stack.Children.Add(header);
        stack.Children.Add(_footer);
        stack.Children.Add(_body);

        // accent hairline on top
        var accent = new Border { Height = 2, Background = R<Brush>("AccentGradH"), VerticalAlignment = VerticalAlignment.Top, CornerRadius = new CornerRadius(16, 16, 0, 0), Opacity = 0.9 };
        var grid = new Grid();
        grid.Children.Add(stack);
        grid.Children.Add(accent);

        Content = new Border
        {
            Margin = new Thickness(28),
            Background = R<Brush>("Bg1"),
            BorderBrush = R<Brush>("Line2"),
            BorderThickness = new Thickness(1),
            CornerRadius = new CornerRadius(16),
            Effect = R<System.Windows.Media.Effects.Effect>("Shadow"),
            Child = grid,
            ClipToBounds = false,
        };

        PreviewKeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape) { DialogResult = false; e.Handled = true; }
            else if (e.Key == Key.Enter && DefaultButton != null && !(Keyboard.FocusedElement is TextBox tb && tb.AcceptsReturn))
            {
                DefaultButton.RaiseEvent(new RoutedEventArgs(ButtonBase.ClickEvent));
                e.Handled = true;
            }
        };
    }

    public object Body { get => _body.Content; set => _body.Content = value; }

    public Button AddButton(string text, bool primary, Action onClick)
    {
        var b = new Button { Content = text, Style = R<Style>(primary ? "Primary" : "Secondary"), Margin = new Thickness(10, 0, 0, 0), MinWidth = 96 };
        b.Click += (_, _) => onClick?.Invoke();
        _footerRight.Children.Add(b);
        if (primary) DefaultButton = b;
        return b;
    }

    public void AddFooterLeft(UIElement e) => _footerLeft.Children.Add(e);

    public static T R<T>(string key) where T : class => Application.Current.TryFindResource(key) as T;

    // ───────────────────────────── stock dialogs ─────────────────────────────

    public static void Alert(Window owner, string title, string message)
    {
        var d = new SkyDialog(owner, title);
        d.Body = new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap, MaxWidth = 440, Foreground = R<Brush>("Text2"), FontSize = 13, LineHeight = 20 };
        d.AddButton("OK", true, () => d.DialogResult = true);
        d.ShowDialog();
    }

    public static bool Confirm(Window owner, string title, string message, string yes = "OK", string no = "Cancel")
    {
        var d = new SkyDialog(owner, title);
        d.Body = new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap, MaxWidth = 440, Foreground = R<Brush>("Text2"), FontSize = 13, LineHeight = 20 };
        d.AddButton(no, false, () => d.DialogResult = false);
        d.AddButton(yes, true, () => d.DialogResult = true);
        return d.ShowDialog() == true;
    }

    public static SaveChoice AskSave(Window owner, string docName)
    {
        var result = SaveChoice.Cancel;
        var d = new SkyDialog(owner, "Save changes?", $"“{docName}” has unsaved changes.");
        d.Body = new TextBlock { Text = "If you don't save, your changes since the last save will be lost.", TextWrapping = TextWrapping.Wrap, MaxWidth = 420, Foreground = R<Brush>("Text2"), FontSize = 13 };
        d.AddButton("Cancel", false, () => { result = SaveChoice.Cancel; d.DialogResult = false; });
        d.AddButton("Don't save", false, () => { result = SaveChoice.DontSave; d.DialogResult = true; });
        d.AddButton("Save", true, () => { result = SaveChoice.Save; d.DialogResult = true; });
        d.ShowDialog();
        return result;
    }

    public static string Prompt(Window owner, string title, string label, string value)
    {
        var d = new SkyDialog(owner, title);
        var sp = new StackPanel { Width = 360 };
        sp.Children.Add(new TextBlock { Text = label, Foreground = R<Brush>("Text2"), Margin = new Thickness(0, 0, 0, 6), FontSize = 12 });
        var tb = new TextBox { Text = value };
        sp.Children.Add(tb);
        d.Body = sp;
        string result = null;
        d.AddButton("Cancel", false, () => d.DialogResult = false);
        d.AddButton("OK", true, () => { result = tb.Text; d.DialogResult = true; });
        d.Loaded += (_, _) => { tb.Focus(); tb.SelectAll(); };
        return d.ShowDialog() == true ? result : null;
    }
}

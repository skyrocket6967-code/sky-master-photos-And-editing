using System.Windows;
using System.Windows.Media;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

/// <summary>RGB + luminance histogram of the composite image.</summary>
public sealed class HistogramView : FrameworkElement
{
    int[] _r = new int[256], _g = new int[256], _b = new int[256], _l = new int[256];
    string _info = "";

    public void Update(uint[] px)
    {
        var r = new int[256]; var g = new int[256]; var b = new int[256]; var l = new int[256];
        if (px != null)
        {
            int step = Math.Max(1, px.Length / 400_000);
            long n = 0; double sum = 0;
            for (int i = 0; i < px.Length; i += step)
            {
                uint p = px[i];
                if ((p >> 24) < 8) continue;
                r[Px.R(p)]++; g[Px.G(p)]++; b[Px.B(p)]++;
                int lum = Px.Clamp(Px.Luma(p));
                l[lum]++;
                sum += lum; n++;
            }
            _info = n == 0 ? "Transparent" : $"Mean {sum / n:0}   ·   Samples {n:N0}";
        }
        _r = r; _g = g; _b = b; _l = l;
        InvalidateVisual();
    }

    protected override void OnRender(DrawingContext dc)
    {
        double w = ActualWidth, h = ActualHeight - 18;
        dc.DrawRoundedRectangle(UIx.R<Brush>("Bg0"), null, new Rect(0, 0, w, h), 10, 10);
        double max = 1;
        for (int i = 2; i < 254; i++) max = Math.Max(max, Math.Max(_l[i], Math.Max(_r[i], Math.Max(_g[i], _b[i]))));
        void Plot(int[] data, Color c)
        {
            var geo = new StreamGeometry();
            using (var ctx = geo.Open())
            {
                ctx.BeginFigure(new Point(6, h - 6), true, true);
                for (int i = 0; i < 256; i++)
                {
                    double y = h - 6 - Math.Min(1, data[i] / max) * (h - 16);
                    ctx.LineTo(new Point(6 + i / 255.0 * (w - 12), y), true, false);
                }
                ctx.LineTo(new Point(w - 6, h - 6), true, false);
            }
            dc.DrawGeometry(new SolidColorBrush(c), null, geo);
        }
        Plot(_r, Color.FromArgb(90, 255, 80, 90));
        Plot(_g, Color.FromArgb(90, 80, 230, 120));
        Plot(_b, Color.FromArgb(90, 90, 140, 255));
        Plot(_l, Color.FromArgb(70, 255, 255, 255));
        var ft = new FormattedText(_info, System.Globalization.CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, new Typeface("Segoe UI"), 10.5, UIx.R<Brush>("Text3"), 1.0);
        dc.DrawText(ft, new Point(2, h + 4));
    }
}

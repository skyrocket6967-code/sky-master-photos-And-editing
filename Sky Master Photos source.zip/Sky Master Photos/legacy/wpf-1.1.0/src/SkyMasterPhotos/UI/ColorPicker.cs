using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

/// <summary>HSV saturation/value square + hue strip + hex/RGB entry.</summary>
public sealed class ColorPicker : Grid
{
    readonly SvSquare _sv = new();
    readonly HueStrip _hue = new();
    readonly TextBox _hex = new() { Width = 78 };
    readonly TextBox _r = new() { Width = 44 }, _g = new() { Width = 44 }, _b = new() { Width = 44 };
    double _h, _s, _v;
    bool _updating;

    public event Action<Color> ColorChanged;

    public ColorPicker()
    {
        RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(26) });

        _sv.Margin = new Thickness(0, 0, 8, 0);
        Children.Add(_sv);
        Grid.SetColumn(_hue, 1);
        Children.Add(_hue);

        var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 10, 0, 0) };
        row.Children.Add(Lbl("#"));
        row.Children.Add(_hex);
        row.Children.Add(Lbl("R")); row.Children.Add(_r);
        row.Children.Add(Lbl("G")); row.Children.Add(_g);
        row.Children.Add(Lbl("B")); row.Children.Add(_b);
        foreach (var t in new[] { _hex, _r, _g, _b }) { t.Padding = new Thickness(5, 3, 5, 3); t.FontSize = 11.5; }
        Grid.SetRow(row, 1);
        Grid.SetColumnSpan(row, 2);
        Children.Add(row);

        _sv.Changed += (s, v) => { _s = s; _v = v; Push(); };
        _hue.Changed += h => { _h = h; _sv.Hue = h; Push(); };
        _hex.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitHex(); };
        _hex.LostKeyboardFocus += (_, _) => CommitHex();
        foreach (var t in new[] { _r, _g, _b })
        {
            t.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitRgb(); };
            t.LostKeyboardFocus += (_, _) => CommitRgb();
        }
    }

    static TextBlock Lbl(string s) => new() { Text = s, Foreground = UIx.R<Brush>("Text3"), FontSize = 11, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 4, 0) };

    public Color Color
    {
        get { Px.HsvToRgb(_h, _s, _v, out double r, out double g, out double b); return Color.FromRgb((byte)Px.Clamp(r * 255), (byte)Px.Clamp(g * 255), (byte)Px.Clamp(b * 255)); }
    }

    public void SetColor(Color c)
    {
        Px.RgbToHsv(c.R / 255.0, c.G / 255.0, c.B / 255.0, out double h, out double s, out double v);
        if (s > 0.001 && v > 0.001) _h = h; // keep hue for greys
        _s = s; _v = v;
        _updating = true;
        _sv.Hue = _h; _sv.Set(_s, _v); _hue.Set(_h);
        UpdateTexts(c);
        _updating = false;
    }

    void Push()
    {
        var c = Color;
        UpdateTexts(c);
        if (!_updating) ColorChanged?.Invoke(c);
    }

    void UpdateTexts(Color c)
    {
        if (!_hex.IsKeyboardFocused) _hex.Text = Px.ToHex(c);
        if (!_r.IsKeyboardFocused) _r.Text = c.R.ToString();
        if (!_g.IsKeyboardFocused) _g.Text = c.G.ToString();
        if (!_b.IsKeyboardFocused) _b.Text = c.B.ToString();
    }

    void CommitHex()
    {
        if (Px.TryParseHex(_hex.Text, out var c)) { SetColor(c); ColorChanged?.Invoke(c); }
        else _hex.Text = Px.ToHex(Color);
    }

    void CommitRgb()
    {
        if (byte.TryParse(_r.Text, out var r) && byte.TryParse(_g.Text, out var g) && byte.TryParse(_b.Text, out var b))
        {
            var c = Color.FromRgb(r, g, b);
            SetColor(c);
            ColorChanged?.Invoke(c);
        }
        else UpdateTexts(Color);
    }

    sealed class SvSquare : FrameworkElement
    {
        double _hue, _s = 1, _v = 1;
        public event Action<double, double> Changed;
        public double Hue { get => _hue; set { _hue = value; InvalidateVisual(); } }
        public void Set(double s, double v) { _s = s; _v = v; InvalidateVisual(); }

        public SvSquare() { Cursor = Cursors.Cross; ClipToBounds = false; }

        protected override void OnRender(DrawingContext dc)
        {
            var r = new Rect(0, 0, ActualWidth, ActualHeight);
            Px.HsvToRgb(_hue, 1, 1, out double hr, out double hg, out double hb);
            var hueC = Color.FromRgb((byte)(hr * 255), (byte)(hg * 255), (byte)(hb * 255));
            var geo = new RectangleGeometry(r, 10, 10);
            dc.PushClip(geo);
            dc.DrawRectangle(new LinearGradientBrush(Colors.White, hueC, 0), null, r);
            dc.DrawRectangle(new LinearGradientBrush(Color.FromArgb(0, 0, 0, 0), Colors.Black, 90), null, r);
            dc.Pop();
            var p = new Point(_s * r.Width, (1 - _v) * r.Height);
            dc.DrawEllipse(null, new Pen(Brushes.Black, 3) { Brush = new SolidColorBrush(Color.FromArgb(90, 0, 0, 0)) }, p, 7.5, 7.5);
            dc.DrawEllipse(null, new Pen(Brushes.White, 2), p, 7, 7);
        }

        protected override void OnMouseDown(MouseButtonEventArgs e) { CaptureMouse(); Pick(e.GetPosition(this)); }
        protected override void OnMouseMove(MouseEventArgs e) { if (IsMouseCaptured) Pick(e.GetPosition(this)); }
        protected override void OnMouseUp(MouseButtonEventArgs e) => ReleaseMouseCapture();

        void Pick(Point p)
        {
            _s = Math.Clamp(p.X / Math.Max(1, ActualWidth), 0, 1);
            _v = 1 - Math.Clamp(p.Y / Math.Max(1, ActualHeight), 0, 1);
            InvalidateVisual();
            Changed?.Invoke(_s, _v);
        }
    }

    sealed class HueStrip : FrameworkElement
    {
        double _h;
        public event Action<double> Changed;
        public void Set(double h) { _h = h; InvalidateVisual(); }
        public HueStrip() { Cursor = Cursors.Hand; }

        protected override void OnRender(DrawingContext dc)
        {
            var r = new Rect(5, 0, Math.Max(0, ActualWidth - 10), ActualHeight);
            var lg = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(0, 1) };
            for (int i = 0; i <= 6; i++)
            {
                Px.HsvToRgb(i / 6.0, 1, 1, out double rr, out double gg, out double bb);
                lg.GradientStops.Add(new GradientStop(Color.FromRgb((byte)(rr * 255), (byte)(gg * 255), (byte)(bb * 255)), i / 6.0));
            }
            dc.DrawRoundedRectangle(lg, null, r, 7, 7);
            double y = _h * ActualHeight;
            var knob = new Rect(1, Math.Clamp(y - 4, 0, ActualHeight - 8), ActualWidth - 2, 8);
            dc.DrawRoundedRectangle(null, new Pen(new SolidColorBrush(Color.FromArgb(120, 0, 0, 0)), 3), knob, 4, 4);
            dc.DrawRoundedRectangle(null, new Pen(Brushes.White, 2), knob, 4, 4);
        }

        protected override void OnMouseDown(MouseButtonEventArgs e) { CaptureMouse(); Pick(e.GetPosition(this)); }
        protected override void OnMouseMove(MouseEventArgs e) { if (IsMouseCaptured) Pick(e.GetPosition(this)); }
        protected override void OnMouseUp(MouseButtonEventArgs e) => ReleaseMouseCapture();

        void Pick(Point p)
        {
            _h = Math.Clamp(p.Y / Math.Max(1, ActualHeight), 0, 0.9999);
            InvalidateVisual();
            Changed?.Invoke(_h);
        }
    }
}

/// <summary>Interactive tone curve editor (click to add, drag to move, right-click to remove).</summary>
public sealed class CurvesEditor : FrameworkElement
{
    public List<Point> Points { get; } = new() { new Point(0, 0), new Point(255, 255) };
    public int[] Histogram;
    int _drag = -1;
    public event Action Changed;

    public CurvesEditor() { Width = 300; Height = 300; Cursor = Cursors.Cross; }

    Point ToScreen(Point p) => new(p.X / 255 * ActualWidth, (1 - p.Y / 255) * ActualHeight);
    Point ToCurve(Point s) => new(Math.Clamp(s.X / ActualWidth * 255, 0, 255), Math.Clamp((1 - s.Y / ActualHeight) * 255, 0, 255));

    protected override void OnRender(DrawingContext dc)
    {
        var r = new Rect(0, 0, ActualWidth, ActualHeight);
        dc.DrawRoundedRectangle(UIx.R<Brush>("Bg0"), new Pen(UIx.R<Brush>("Line2"), 1), r, 8, 8);
        if (Histogram != null)
        {
            double max = Math.Max(1, Histogram.Max());
            var g = new StreamGeometry();
            using (var c = g.Open())
            {
                c.BeginFigure(new Point(0, ActualHeight), true, true);
                for (int i = 0; i < 256; i++) c.LineTo(new Point(i / 255.0 * ActualWidth, ActualHeight - Math.Sqrt(Histogram[i] / max) * ActualHeight * 0.9), true, false);
                c.LineTo(new Point(ActualWidth, ActualHeight), true, false);
            }
            dc.DrawGeometry(new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)), null, g);
        }
        var grid = new Pen(new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)), 1);
        for (int i = 1; i < 4; i++)
        {
            dc.DrawLine(grid, new Point(i * ActualWidth / 4, 0), new Point(i * ActualWidth / 4, ActualHeight));
            dc.DrawLine(grid, new Point(0, i * ActualHeight / 4), new Point(ActualWidth, i * ActualHeight / 4));
        }
        dc.DrawLine(new Pen(new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)), 1) { DashStyle = DashStyles.Dash }, new Point(0, ActualHeight), new Point(ActualWidth, 0));
        var lut = Adjustments.CurveLut(Points);
        var curve = new StreamGeometry();
        using (var c = curve.Open())
        {
            c.BeginFigure(ToScreen(new Point(0, lut[0])), false, false);
            for (int i = 1; i < 256; i++) c.LineTo(ToScreen(new Point(i, lut[i])), true, true);
        }
        dc.DrawGeometry(null, new Pen(UIx.R<Brush>("AccentGradH"), 2.2), curve);
        foreach (var p in Points)
        {
            var s = ToScreen(p);
            dc.DrawEllipse(UIx.R<Brush>("Bg1"), new Pen(Brushes.White, 2), s, 5, 5);
        }
    }

    int Hit(Point s)
    {
        for (int i = 0; i < Points.Count; i++) if ((ToScreen(Points[i]) - s).Length < 9) return i;
        return -1;
    }

    protected override void OnMouseDown(MouseButtonEventArgs e)
    {
        var s = e.GetPosition(this);
        int h = Hit(s);
        if (e.ChangedButton == MouseButton.Right)
        {
            if (h > 0 && h < Points.Count - 1 || (h >= 0 && Points.Count > 2)) { Points.RemoveAt(h); InvalidateVisual(); Changed?.Invoke(); }
            return;
        }
        if (h < 0)
        {
            Points.Add(ToCurve(s));
            Points.Sort((a, b) => a.X.CompareTo(b.X));
            h = Hit(s);
        }
        _drag = h;
        CaptureMouse();
        InvalidateVisual();
        Changed?.Invoke();
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        if (_drag < 0 || !IsMouseCaptured) return;
        var p = ToCurve(e.GetPosition(this));
        double minX = _drag > 0 ? Points[_drag - 1].X + 1 : 0, maxX = _drag < Points.Count - 1 ? Points[_drag + 1].X - 1 : 255;
        Points[_drag] = new Point(Math.Clamp(p.X, minX, maxX), p.Y);
        InvalidateVisual();
        Changed?.Invoke();
    }

    protected override void OnMouseUp(MouseButtonEventArgs e) { _drag = -1; ReleaseMouseCapture(); }

    public void Reset()
    {
        Points.Clear();
        Points.Add(new Point(0, 0));
        Points.Add(new Point(255, 255));
        InvalidateVisual();
        Changed?.Invoke();
    }
}

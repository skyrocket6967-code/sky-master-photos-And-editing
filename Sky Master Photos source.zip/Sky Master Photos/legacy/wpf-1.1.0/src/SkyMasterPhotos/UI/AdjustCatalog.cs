using System.Windows;
using System.Windows.Media;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

/// <summary>Controls for each adjustment-layer kind (shared by "new" and "edit").</summary>
public static class AdjustCatalog
{
    public static readonly (string name, Color c)[] PhotoFilters =
    {
        ("Warming", Color.FromRgb(236, 138, 0)), ("Cooling", Color.FromRgb(0, 109, 255)), ("Sepia", Color.FromRgb(172, 122, 51)),
        ("Red", Color.FromRgb(234, 26, 26)), ("Green", Color.FromRgb(25, 201, 25)), ("Violet", Color.FromRgb(155, 60, 255)), ("Foreground", Colors.Transparent),
    };

    static AdjustParam S(string k, string label, double min, double max, double v, int dec = 0, string suffix = "") => AdjustParam.S(k, label, min, max, v, dec, suffix);

    public static IList<AdjustParam> Params(AdjustmentSpec s)
    {
        double V(string k, double def) => s.P.ContainsKey(k) ? s[k] : def;
        switch (s.Kind)
        {
            case "brightness": return new[] { S("b", "Brightness", -150, 150, V("b", 0)), S("c", "Contrast", -50, 100, V("c", 0)) };
            case "levels":
                return new[] { S("ib", "Input black", 0, 253, V("ib", 0)), S("g", "Midtones (gamma)", 0.1, 9.99, V("g", 1), 2), S("iw", "Input white", 2, 255, V("iw", 255)), S("ob", "Output black", 0, 255, V("ob", 0)), S("ow", "Output white", 0, 255, V("ow", 255)) };
            case "curves": return new[] { AdjustParam.Curve("curve") };
            case "exposure": return new[] { S("e", "Exposure", -5, 5, V("e", 0), 2, " EV"), S("o", "Offset", -0.5, 0.5, V("o", 0), 3), S("g", "Gamma", 0.1, 3, V("g", 1), 2) };
            case "vibrance": return new[] { S("v", "Vibrance", -100, 100, V("v", 0)), S("s", "Saturation", -100, 100, V("s", 0)) };
            case "huesat": return new[] { S("h", "Hue", -180, 180, V("h", 0), 0, "°"), S("s", "Saturation", -100, 100, V("s", 0)), S("l", "Lightness", -100, 100, V("l", 0)), AdjustParam.C("c", "Colorize", V("c", 0) >= 0.5) };
            case "colorbalance": return new[] { S("r", "Cyan ↔ Red", -100, 100, V("r", 0)), S("g", "Magenta ↔ Green", -100, 100, V("g", 0)), S("b", "Yellow ↔ Blue", -100, 100, V("b", 0)), AdjustParam.C("p", "Preserve luminosity", V("p", 1) >= 0.5) };
            case "bw":
                return new[] { S("r", "Reds", -200, 300, V("r", 40), 0, "%"), S("y", "Yellows", -200, 300, V("y", 60), 0, "%"), S("g", "Greens", -200, 300, V("g", 40), 0, "%"), S("c", "Cyans", -200, 300, V("c", 60), 0, "%"), S("b", "Blues", -200, 300, V("b", 20), 0, "%"), S("m", "Magentas", -200, 300, V("m", 80), 0, "%") };
            case "photofilter":
            {
                int idx = Array.FindIndex(PhotoFilters, p => p.c == s.C1);
                var names = PhotoFilters.Select(p => p.name).ToList();
                if (idx < 0) { names.Add("Custom"); idx = names.Count - 1; }
                return new[] { AdjustParam.Ch("f", "Filter", idx, names.ToArray()), S("d", "Density", 1, 100, V("d", 25), 0, "%"), AdjustParam.C("l", "Preserve luminosity", V("l", 1) >= 0.5) };
            }
            case "posterize": return new[] { S("l", "Levels", 2, 32, V("l", 6)) };
            case "threshold": return new[] { S("t", "Threshold level", 1, 255, V("t", 128)) };
            case "gradientmap": return new[] { AdjustParam.C("r", "Reverse", false), AdjustParam.C("u", "Use current foreground → background colors", false) };
            default: return Array.Empty<AdjustParam>();
        }
    }

    public static AdjustmentSpec Build(AdjustmentSpec prev, AdjustContext c, Color fg, Color bg)
    {
        Dictionary<string, double> P(params string[] keys) => keys.ToDictionary(k => k, k => c[k]);
        switch (prev.Kind)
        {
            case "brightness": return new AdjustmentSpec { Kind = prev.Kind, P = P("b", "c") };
            case "levels": return new AdjustmentSpec { Kind = prev.Kind, P = P("ib", "g", "iw", "ob", "ow") };
            case "curves": return new AdjustmentSpec { Kind = prev.Kind, Curve = c.Curves?.Points.OrderBy(p => p.X).ToList() ?? prev.Curve };
            case "exposure": return new AdjustmentSpec { Kind = prev.Kind, P = P("e", "o", "g") };
            case "vibrance": return new AdjustmentSpec { Kind = prev.Kind, P = P("v", "s") };
            case "huesat": return new AdjustmentSpec { Kind = prev.Kind, P = P("h", "s", "l", "c") };
            case "colorbalance": return new AdjustmentSpec { Kind = prev.Kind, P = P("r", "g", "b", "p") };
            case "bw": return new AdjustmentSpec { Kind = prev.Kind, P = P("r", "y", "g", "c", "b", "m") };
            case "photofilter":
            {
                int f = (int)c["f"];
                var col = f < PhotoFilters.Length ? (PhotoFilters[f].c.A == 0 ? fg : PhotoFilters[f].c) : prev.C1;
                return new AdjustmentSpec { Kind = prev.Kind, P = P("d", "l"), C1 = col };
            }
            case "posterize": return new AdjustmentSpec { Kind = prev.Kind, P = P("l") };
            case "threshold": return new AdjustmentSpec { Kind = prev.Kind, P = P("t") };
            case "gradientmap":
            {
                Color a = prev.C1, b = prev.C2;
                if (c.B("u")) { a = fg; b = bg; }
                if (c.B("r")) (a, b) = (b, a);
                return new AdjustmentSpec { Kind = prev.Kind, C1 = a, C2 = b };
            }
            default: return prev;
        }
    }
}

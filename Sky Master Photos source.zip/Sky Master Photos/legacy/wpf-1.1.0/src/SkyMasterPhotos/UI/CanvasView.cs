using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Tools;

namespace SkyMasterPhotos.UI;

/// <summary>The zoomable, pannable document viewport.</summary>
public sealed class CanvasView : FrameworkElement
{
    Document _doc;
    public ToolController Ctl;
    public event Action ViewChanged;
    public event Action<Point?> CursorMoved;

    Point? _mouse;
    readonly DispatcherTimer _ants;
    public double AntOffset { get; private set; }
    bool _panning;
    Point _panStart;
    Vector _panOrigin;
    static readonly ImageBrush CheckerBrush = UIx.Checker(8, false);

    static readonly double[] Steps = { 0.01, 0.02, 0.03, 0.05, 0.0667, 0.1, 0.125, 0.1667, 0.25, 0.3333, 0.5, 0.6667, 1, 1.5, 2, 3, 4, 5, 6, 8, 12, 16, 24, 32, 48, 64 };

    public CanvasView()
    {
        Focusable = true;
        FocusVisualStyle = null;
        ClipToBounds = true;
        SnapsToDevicePixels = true;
        _ants = new DispatcherTimer(DispatcherPriority.Render) { Interval = TimeSpan.FromMilliseconds(110) };
        _ants.Tick += (_, _) =>
        {
            if (_doc?.HasSelection == true || Ctl?.HasAntsPreview == true)
            {
                AntOffset = (AntOffset + 1) % 8;
                InvalidateVisual();
            }
        };
        _ants.Start();
        AllowDrop = true;
    }

    public Document Doc
    {
        get => _doc;
        set
        {
            if (_doc == value) return;
            if (_doc != null) { _doc.Rendered -= OnRendered; _doc.StructureChanged -= OnStructure; }
            _doc = value;
            if (_doc != null)
            {
                _doc.Rendered += OnRendered;
                _doc.StructureChanged += OnStructure;
                if (!_doc.ViewInitialized && ActualWidth > 0) Fit();
            }
            InvalidateVisual();
            ViewChanged?.Invoke();
        }
    }

    void OnRendered(Int32Rect r) => InvalidateVisual();
    void OnStructure() => InvalidateVisual();

    public double Zoom => _doc?.Zoom ?? 1;
    Vector Pan => _doc?.Pan ?? new Vector();

    public Matrix View => new(Zoom, 0, 0, Zoom, Pan.X, Pan.Y);
    public Point ToDoc(Point s) => new((s.X - Pan.X) / Zoom, (s.Y - Pan.Y) / Zoom);
    public Point ToScreen(Point d) => new(d.X * Zoom + Pan.X, d.Y * Zoom + Pan.Y);
    public Point? MouseScreen => _mouse;

    public void Fit()
    {
        if (_doc == null || ActualWidth < 10 || ActualHeight < 10) return;
        double z = Math.Min((ActualWidth - 80) / _doc.Width, (ActualHeight - 80) / _doc.Height);
        z = Math.Clamp(z, 0.01, 1.0 * Math.Max(1, Math.Floor(z)));
        if (z > 1) z = Math.Min(z, 4);
        SetView(z, new Vector((ActualWidth - _doc.Width * z) / 2, (ActualHeight - _doc.Height * z) / 2));
        _doc.ViewInitialized = true;
    }

    public void ActualPixels()
    {
        if (_doc == null) return;
        SetView(1, new Vector(Math.Round((ActualWidth - _doc.Width) / 2), Math.Round((ActualHeight - _doc.Height) / 2)));
    }

    void SetView(double z, Vector pan)
    {
        if (_doc == null) return;
        _doc.Zoom = z;
        _doc.Pan = pan;
        InvalidateVisual();
        ViewChanged?.Invoke();
    }

    public void ZoomAt(Point s, double nz)
    {
        if (_doc == null) return;
        nz = Math.Clamp(nz, 0.01, 64);
        var d = ToDoc(s);
        SetView(nz, new Vector(s.X - d.X * nz, s.Y - d.Y * nz));
    }

    public void ZoomStep(bool zoomIn, Point? at = null)
    {
        var p = at ?? new Point(ActualWidth / 2, ActualHeight / 2);
        double z = Zoom;
        double nz = zoomIn ? Steps.FirstOrDefault(s => s > z * 1.001, 64) : Steps.LastOrDefault(s => s < z / 1.001, 0.01);
        if (nz == 0) nz = zoomIn ? 64 : 0.01;
        ZoomAt(p, nz);
    }

    public void PanBy(Vector v) { if (_doc != null) SetView(Zoom, Pan + v); }

    /// <summary>Center the view on a document point (used by the navigator).</summary>
    public void CenterOn(Point d)
    {
        if (_doc == null) return;
        SetView(Zoom, new Vector(ActualWidth / 2 - d.X * Zoom, ActualHeight / 2 - d.Y * Zoom));
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
    {
        base.OnRenderSizeChanged(sizeInfo);
        if (_doc != null && !_doc.ViewInitialized) Fit();
        else if (_doc != null && sizeInfo.PreviousSize.Width > 0)
        {
            // keep the image centered relative to the resize
            var d = new Vector((sizeInfo.NewSize.Width - sizeInfo.PreviousSize.Width) / 2, (sizeInfo.NewSize.Height - sizeInfo.PreviousSize.Height) / 2);
            SetView(Zoom, Pan + new Vector(d.X, d.Y));
        }
        ViewChanged?.Invoke();
    }

    // ───────────────────────────── rendering ─────────────────────────────

    protected override void OnRender(DrawingContext dc)
    {
        dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, ActualWidth, ActualHeight));
        if (_doc == null) return;
        double z = Zoom;
        RenderOptions.SetBitmapScalingMode(this, z >= 2 ? BitmapScalingMode.NearestNeighbor : z < 1 ? BitmapScalingMode.HighQuality : BitmapScalingMode.Linear);
        var rect = new Rect(Pan.X, Pan.Y, _doc.Width * z, _doc.Height * z);

        // soft drop shadow
        for (int i = 1; i <= 4; i++)
        {
            var r = rect;
            r.Inflate(i * 3, i * 3);
            r.Offset(0, i * 1.5);
            dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb((byte)(26 - i * 5), 0, 0, 0)), null, r, i * 3, i * 3);
        }
        dc.DrawRectangle(CheckerBrush, null, rect);

        var xf = Ctl?.Xf;
        if (xf != null)
        {
            dc.DrawImage(xf.Below, rect);
            var m = xf.M;
            m.Append(View);
            dc.PushTransform(new MatrixTransform(m));
            dc.PushOpacity(xf.Layer.Opacity);
            dc.DrawImage(xf.Float, new Rect(0, 0, _doc.Width, _doc.Height));
            dc.Pop();
            dc.Pop();
            if (xf.Above != null) dc.DrawImage(xf.Above, rect);
        }
        else
        {
            dc.DrawImage(_doc.Display, rect);
        }
        dc.DrawRectangle(null, new Pen(new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)), 1), Snap(rect));

        // marching ants
        if (_doc.SelectionOutline != null)
        {
            var m = View;
            if (xf != null && xf.HadSelection) { var mm = xf.M; mm.Append(View); m = mm; }
            double scale = Math.Sqrt(Math.Abs(m.Determinant));
            dc.PushTransform(new MatrixTransform(m));
            DrawAnts(dc, _doc.SelectionOutline, 1.0 / scale);
            dc.Pop();
        }

        Ctl?.DrawOverlay(dc, this);

        // brush cursor
        if (_mouse is Point mp && Ctl != null && ToolInfo.IsBrushLike(Ctl.Tool) && !Ctl.SpaceHeld && xf == null)
        {
            double r = Math.Max(1.5, Ctl.CurrentBrush.Size / 2 * z);
            dc.DrawEllipse(null, new Pen(new SolidColorBrush(Color.FromArgb(150, 0, 0, 0)), 2.5), mp, r, r);
            dc.DrawEllipse(null, new Pen(Brushes.White, 1.2), mp, r, r);
            if (r < 6 || Ctl.Tool is Tool.Clone or Tool.Heal)
            {
                var pen = new Pen(Brushes.White, 1);
                dc.DrawLine(pen, new Point(mp.X - 5, mp.Y), new Point(mp.X + 5, mp.Y));
                dc.DrawLine(pen, new Point(mp.X, mp.Y - 5), new Point(mp.X, mp.Y + 5));
            }
        }
    }

    static Rect Snap(Rect r) => new(Math.Round(r.X) + 0.5, Math.Round(r.Y) + 0.5, Math.Round(r.Width) - 1, Math.Round(r.Height) - 1);

    public void DrawAnts(DrawingContext dc, Geometry g, double thickness)
    {
        var black = new Pen(Brushes.Black, thickness);
        var white = new Pen(Brushes.White, thickness) { DashStyle = new DashStyle(new double[] { 4, 4 }, AntOffset), DashCap = PenLineCap.Flat };
        dc.DrawGeometry(null, black, g);
        dc.DrawGeometry(null, white, g);
    }

    // ───────────────────────────── input ─────────────────────────────

    protected override void OnMouseDown(MouseButtonEventArgs e)
    {
        base.OnMouseDown(e);
        Focus();
        if (_doc == null) return;
        var s = e.GetPosition(this);
        if (e.ChangedButton == MouseButton.Middle || (e.ChangedButton == MouseButton.Left && (Ctl.SpaceHeld || (Ctl.Tool == Tool.Hand && Ctl.Xf == null))))
        {
            _panning = true;
            _panStart = s;
            _panOrigin = Pan;
            CaptureMouse();
            UpdateCursor();
            e.Handled = true;
            return;
        }
        if (e.ChangedButton == MouseButton.Left && Ctl.Tool == Tool.Zoom && Ctl.Xf == null)
        {
            ZoomStep((Keyboard.Modifiers & ModifierKeys.Alt) == 0, s);
            e.Handled = true;
            return;
        }
        if (e.ChangedButton == MouseButton.Left)
        {
            CaptureMouse();
            Ctl.MouseDown(s, ToDoc(s), Keyboard.Modifiers, e.ClickCount);
            e.Handled = true;
        }
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        var s = e.GetPosition(this);
        _mouse = s;
        if (_doc == null) return;
        if (_panning)
        {
            SetView(Zoom, _panOrigin + (s - _panStart));
            return;
        }
        Ctl.MouseMove(s, ToDoc(s), Keyboard.Modifiers, e.LeftButton == MouseButtonState.Pressed && IsMouseCaptured);
        CursorMoved?.Invoke(ToDoc(s));
        UpdateCursor();
        InvalidateVisual();
    }

    protected override void OnMouseUp(MouseButtonEventArgs e)
    {
        base.OnMouseUp(e);
        if (_doc == null) return;
        var s = e.GetPosition(this);
        if (_panning)
        {
            if (e.ChangedButton == MouseButton.Middle || e.ChangedButton == MouseButton.Left)
            {
                _panning = false;
                ReleaseMouseCapture();
                UpdateCursor();
            }
            return;
        }
        if (e.ChangedButton == MouseButton.Left)
        {
            Ctl.MouseUp(s, ToDoc(s), Keyboard.Modifiers);
            ReleaseMouseCapture();
            InvalidateVisual();
        }
    }

    protected override void OnLostMouseCapture(MouseEventArgs e)
    {
        base.OnLostMouseCapture(e);
        if (_panning) { _panning = false; UpdateCursor(); }
        Ctl?.CaptureLost();
    }

    protected override void OnMouseLeave(MouseEventArgs e)
    {
        base.OnMouseLeave(e);
        _mouse = null;
        CursorMoved?.Invoke(null);
        InvalidateVisual();
    }

    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        base.OnMouseWheel(e);
        if (_doc == null) return;
        var s = e.GetPosition(this);
        var mods = Keyboard.Modifiers;
        if ((mods & ModifierKeys.Shift) != 0) PanBy(new Vector(e.Delta * 0.6, 0));
        else if ((mods & ModifierKeys.Control) != 0 && false) PanBy(new Vector(0, e.Delta * 0.6));
        else
        {
            double f = Math.Pow(1.0018, e.Delta);
            ZoomAt(s, Zoom * f);
        }
        e.Handled = true;
    }

    public void UpdateCursor()
    {
        if (Ctl == null) return;
        if (_panning) { Cursor = Cursors.SizeAll; return; }
        if (Ctl.SpaceHeld || (Ctl.Tool == Tool.Hand && Ctl.Xf == null)) { Cursor = Cursors.Hand; return; }
        Cursor = Ctl.CursorFor(_mouse);
    }
}

using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.Tools;

/// <summary>
/// A floating layer (or selection) being moved / scaled / rotated. While active the canvas draws three
/// cached bitmaps (below, floating, above) and the floating one goes through a GPU transform, so dragging
/// stays smooth on any image size. Pixels are resampled only on commit.
/// </summary>
public sealed class TransformSession
{
    public Layer Layer;
    public DocState Before;
    public uint[] FloatPx;
    public uint[] Remainder;
    public WriteableBitmap Below, Float, Above;
    public Rect Bounds;
    public double Sx = 1, Sy = 1, Angle;
    public Vector T;
    public bool Handles;
    public bool HadSelection;
    int _w, _h;

    public Point Center => new(Bounds.X + Bounds.Width / 2, Bounds.Y + Bounds.Height / 2);

    public Matrix M
    {
        get
        {
            var c = Center;
            var m = Matrix.Identity;
            m.Translate(-c.X, -c.Y);
            m.Scale(Sx, Sy);
            m.Rotate(Angle);
            m.Translate(c.X + T.X, c.Y + T.Y);
            return m;
        }
    }

    public bool IsIdentity => Sx == 1 && Sy == 1 && Angle == 0 && T.X == 0 && T.Y == 0;

    public static TransformSession Begin(Document doc, bool handles)
    {
        var layer = doc.ActiveLayer;
        if (layer == null) return null;
        int w = doc.Width, h = doc.Height;
        var s = new TransformSession { Layer = layer, Before = doc.Capture(), Handles = handles, _w = w, _h = h };
        var px = layer.Pixels;
        var sel = doc.Selection;
        s.HadSelection = sel != null;
        if (sel != null)
        {
            s.FloatPx = new uint[px.Length];
            s.Remainder = new uint[px.Length];
            Parallel.For(0, px.Length, i =>
            {
                uint p = px[i];
                int a = Px.A(p), m = sel[i];
                if (m == 0) { s.Remainder[i] = p; return; }
                s.FloatPx[i] = Px.WithAlpha(p, a * m / 255);
                s.Remainder[i] = Px.WithAlpha(p, a * (255 - m) / 255);
            });
            var b = doc.SelectionBounds;
            s.Bounds = new Rect(b.X, b.Y, b.Width, b.Height);
        }
        else
        {
            s.FloatPx = px;
            var b = Transforms.OpaqueBounds(px, w, h);
            if (RectUtil.IsEmptyRect(b)) b = new Int32Rect(0, 0, w, h);
            s.Bounds = new Rect(b.X, b.Y, b.Width, b.Height);
        }

        int ai = doc.ActiveIndex;
        var full = new Int32Rect(0, 0, w, h);
        var below = new uint[w * h];
        Compositor.Composite(doc.Layers, w, h, full, below, null, ai + 1, int.MaxValue, doc.Groups);
        if (s.Remainder != null)
        {
            float op = (float)layer.Opacity;
            var rem = s.Remainder;
            Parallel.For(0, below.Length, i => { if (rem[i] >> 24 != 0) below[i] = Px.Over(below[i], rem[i], op); });
        }
        var above = new uint[w * h];
        if (ai > 0) Compositor.Composite(doc.Layers, w, h, full, above, null, 0, ai - 1, doc.Groups);

        s.Below = ToBitmap(below, w, h);
        s.Above = ai > 0 ? ToBitmap(above, w, h) : null;
        // preview shows the layer through its mask (the mask itself is transformed on commit)
        var preview = s.FloatPx;
        if (layer.Mask != null && layer.MaskEnabled)
        {
            var m = layer.Mask;
            preview = new uint[s.FloatPx.Length];
            var fp = s.FloatPx;
            Parallel.For(0, fp.Length, i => preview[i] = Px.WithAlpha(fp[i], Px.A(fp[i]) * Masks.Value(m[i]) / 255));
        }
        s.Float = ToBitmap(preview, w, h);
        return s;
    }

    static WriteableBitmap ToBitmap(uint[] px, int w, int h)
    {
        var wb = new WriteableBitmap(w, h, 96, 96, PixelFormats.Pbgra32, null);
        wb.Lock();
        Compositor.WritePremul(px, w, new Int32Rect(0, 0, w, h), wb.BackBuffer, wb.BackBufferStride);
        wb.AddDirtyRect(new Int32Rect(0, 0, w, h));
        wb.Unlock();
        return wb;
    }

    public Point[] Corners()
    {
        var m = M;
        return new[]
        {
            m.Transform(Bounds.TopLeft), m.Transform(Bounds.TopRight),
            m.Transform(Bounds.BottomRight), m.Transform(Bounds.BottomLeft)
        };
    }

    public void Commit(Document doc, string name)
    {
        if (IsIdentity) { Cancel(doc); return; }
        var m = M;
        var moved = Transforms.Affine(FloatPx, _w, _h, m, _w, _h);
        uint[] result;
        if (Remainder != null)
        {
            result = (uint[])Remainder.Clone();
            Parallel.For(0, result.Length, i => { if (moved[i] >> 24 != 0) result[i] = Px.Over(result[i], moved[i]); });
        }
        else result = moved;
        Layer.SetPixels(result, _w, _h);
        if (Layer.Mask != null && !HadSelection)
        {
            // linked mask follows the layer; uncovered areas take the mask's background value
            byte fill = Masks.EdgeValue(Layer.Mask, _w, _h);
            var mm = Transforms.Affine(Layer.Mask, _w, _h, m, _w, _h);
            var nm = new uint[mm.Length];
            Parallel.For(0, mm.Length, i =>
            {
                int a = Px.A(mm[i]);
                int v = (Masks.Value(mm[i]) * a + fill * (255 - a)) / 255;
                nm[i] = Masks.Gray((byte)v);
            });
            Layer.SetMask(nm);
        }
        if (HadSelection && doc.Selection != null)
        {
            var sel = doc.Selection;
            var asPx = new uint[sel.Length];
            for (int i = 0; i < sel.Length; i++) asPx[i] = (uint)sel[i] << 24 | 0xFFFFFF;
            var t = Transforms.Affine(asPx, _w, _h, m, _w, _h);
            var ns = new byte[sel.Length];
            for (int i = 0; i < ns.Length; i++) ns[i] = (byte)(t[i] >> 24);
            doc.SetSelection(ns);
        }
        doc.RenderAll();
        Layer.RefreshThumbnail();
        doc.RefreshThumbnail();
        doc.Record(name, Before, "⤧");
    }

    public void Cancel(Document doc)
    {
        doc.RenderAll();
    }
}

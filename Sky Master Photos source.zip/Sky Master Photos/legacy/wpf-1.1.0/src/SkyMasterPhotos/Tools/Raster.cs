using System.Globalization;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.Tools;

/// <summary>Uses WPF's antialiased vector renderer to rasterize text and shapes into layer pixels.</summary>
public static class Raster
{
    public static uint[] Render(int w, int h, Action<DrawingContext> draw)
    {
        var dv = new DrawingVisual();
        using (var dc = dv.RenderOpen()) draw(dc);
        var rtb = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Pbgra32);
        RenderOptions.SetEdgeMode(dv, EdgeMode.Unspecified);
        rtb.Render(dv);
        var px = new uint[w * h];
        rtb.CopyPixels(px, w * 4, 0);
        // unpremultiply
        Parallel.For(0, px.Length, i =>
        {
            uint p = px[i];
            uint a = p >> 24;
            if (a == 0 || a == 255) return;
            uint r = Math.Min(255u, ((p >> 16) & 255) * 255 / a), g = Math.Min(255u, ((p >> 8) & 255) * 255 / a), b = Math.Min(255u, (p & 255) * 255 / a);
            px[i] = (a << 24) | (r << 16) | (g << 8) | b;
        });
        return px;
    }

    public static FormattedText MakeText(string text, FontFamily ff, double size, bool bold, bool italic, Brush brush, TextAlignment align = TextAlignment.Left)
    {
        var ft = new FormattedText(text ?? "", CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
            new Typeface(ff, italic ? FontStyles.Italic : FontStyles.Normal, bold ? FontWeights.Bold : FontWeights.Normal, FontStretches.Normal),
            Math.Max(1, size), brush, 1.0) { TextAlignment = align };
        return ft;
    }

    public static uint[] Text(int w, int h, string text, Point pos, FontFamily ff, double size, bool bold, bool italic, Color color)
    {
        return Render(w, h, dc => dc.DrawText(MakeText(text, ff, size, bold, italic, new SolidColorBrush(color)), pos));
    }

    public static Geometry ShapeGeometry(Tool tool, Point a, Point b, double corner)
    {
        var r = new Rect(a, b);
        return tool switch
        {
            Tool.ShapeEllipse => new EllipseGeometry(r),
            Tool.ShapeLine => new LineGeometry(a, b),
            _ => new RectangleGeometry(r, corner, corner),
        };
    }

    public static uint[] Shape(int w, int h, Geometry g, Brush fill, Pen pen)
    {
        return Render(w, h, dc => dc.DrawGeometry(fill, pen, g));
    }

    public static uint[] OverAll(uint[] dst, uint[] src, byte[] mask = null)
    {
        var o = new uint[dst.Length];
        Parallel.For(0, dst.Length, i =>
        {
            uint s = src[i];
            if (s >> 24 == 0) { o[i] = dst[i]; return; }
            float op = mask == null ? 1f : mask[i] / 255f;
            o[i] = Px.Over(dst[i], s, op);
        });
        return o;
    }
}

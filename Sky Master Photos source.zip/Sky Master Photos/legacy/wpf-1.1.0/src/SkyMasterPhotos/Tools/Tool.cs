using System.Windows.Input;

namespace SkyMasterPhotos.Tools;

public enum Tool
{
    Move, MarqueeRect, MarqueeEllipse, Lasso, PolyLasso, MagicWand, Crop, Eyedropper,
    SpotHeal, Heal, Brush, Pencil, Clone, Eraser, Gradient, Bucket,
    Blur, Sharpen, Smudge, Dodge, Burn, Sponge,
    Text, ShapeRect, ShapeEllipse, ShapeLine, Hand, Zoom
}

public sealed class ToolGroup
{
    public string Id;
    public Tool[] Tools;
    public Tool Current;
    public Key Key;
    public ToolGroup(string id, Key key, params Tool[] tools) { Id = id; Key = key; Tools = tools; Current = tools[0]; }
}

public static class ToolInfo
{
    public static readonly ToolGroup[] Groups =
    {
        new("move", Key.V, Tool.Move),
        new("marquee", Key.M, Tool.MarqueeRect, Tool.MarqueeEllipse),
        new("lasso", Key.L, Tool.Lasso, Tool.PolyLasso),
        new("wand", Key.W, Tool.MagicWand),
        new("crop", Key.C, Tool.Crop),
        new("eyedropper", Key.I, Tool.Eyedropper),
        new("heal", Key.J, Tool.SpotHeal, Tool.Heal),
        new("brush", Key.B, Tool.Brush, Tool.Pencil),
        new("clone", Key.S, Tool.Clone),
        new("eraser", Key.E, Tool.Eraser),
        new("fill", Key.G, Tool.Gradient, Tool.Bucket),
        new("blur", Key.R, Tool.Blur, Tool.Sharpen, Tool.Smudge),
        new("dodge", Key.O, Tool.Dodge, Tool.Burn, Tool.Sponge),
        new("text", Key.T, Tool.Text),
        new("shape", Key.U, Tool.ShapeRect, Tool.ShapeEllipse, Tool.ShapeLine),
        new("hand", Key.H, Tool.Hand),
        new("zoom", Key.Z, Tool.Zoom),
    };

    public static ToolGroup GroupOf(Tool t) => Groups.First(g => g.Tools.Contains(t));

    public static string Name(Tool t) => t switch
    {
        Tool.Move => "Move",
        Tool.MarqueeRect => "Rectangular Marquee",
        Tool.MarqueeEllipse => "Elliptical Marquee",
        Tool.Lasso => "Lasso",
        Tool.PolyLasso => "Polygonal Lasso",
        Tool.MagicWand => "Magic Wand",
        Tool.Crop => "Crop",
        Tool.Eyedropper => "Eyedropper",
        Tool.SpotHeal => "Spot Healing Brush",
        Tool.Heal => "Healing Brush",
        Tool.Brush => "Brush",
        Tool.Pencil => "Pencil",
        Tool.Clone => "Clone Stamp",
        Tool.Eraser => "Eraser",
        Tool.Gradient => "Gradient",
        Tool.Bucket => "Paint Bucket",
        Tool.Blur => "Blur",
        Tool.Sharpen => "Sharpen",
        Tool.Smudge => "Smudge",
        Tool.Dodge => "Dodge",
        Tool.Burn => "Burn",
        Tool.Sponge => "Sponge",
        Tool.Text => "Type",
        Tool.ShapeRect => "Rectangle",
        Tool.ShapeEllipse => "Ellipse",
        Tool.ShapeLine => "Line",
        Tool.Hand => "Hand",
        Tool.Zoom => "Zoom",
        _ => t.ToString()
    };

    public static string Icon(Tool t) => t switch
    {
        Tool.Move => "move",
        Tool.MarqueeRect => "marquee",
        Tool.MarqueeEllipse => "ellipse-marquee",
        Tool.Lasso => "lasso",
        Tool.PolyLasso => "polylasso",
        Tool.MagicWand => "wand",
        Tool.Crop => "crop",
        Tool.Eyedropper => "eyedropper",
        Tool.SpotHeal => "spotheal",
        Tool.Heal => "heal",
        Tool.Brush => "brush",
        Tool.Pencil => "pencil",
        Tool.Clone => "clone",
        Tool.Eraser => "eraser",
        Tool.Gradient => "gradient",
        Tool.Bucket => "bucket",
        Tool.Blur => "blur",
        Tool.Sharpen => "sharpen",
        Tool.Smudge => "smudge",
        Tool.Dodge => "dodge",
        Tool.Burn => "burn",
        Tool.Sponge => "sponge",
        Tool.Text => "text",
        Tool.ShapeRect => "rect",
        Tool.ShapeEllipse => "ellipse",
        Tool.ShapeLine => "line",
        Tool.Hand => "hand",
        Tool.Zoom => "zoom",
        _ => "more"
    };

    public static string Hint(Tool t) => t switch
    {
        Tool.Move => "Drag to move the layer or selection · Ctrl+T free transform",
        Tool.MarqueeRect or Tool.MarqueeEllipse => "Drag to select · Shift add · Alt subtract · Shift-drag constrains",
        Tool.Lasso => "Draw around an area to select it",
        Tool.PolyLasso => "Click to add points · double-click or Enter to close · Backspace removes a point",
        Tool.MagicWand => "Click to select similar colors · Shift add · Alt subtract",
        Tool.Crop => "Drag to set the crop · Enter to apply · Esc to cancel",
        Tool.Eyedropper => "Click to pick the foreground color · Alt-click for background",
        Tool.SpotHeal => "Paint over blemishes or objects — they disappear when you release",
        Tool.Heal => "Alt-click to set the source, then paint over blemishes",
        Tool.Clone => "Alt-click to set the source, then paint to clone",
        Tool.Brush or Tool.Pencil => "Paint · [ ] change size · Alt-click picks a color · Shift-click draws a straight line",
        Tool.Eraser => "Erase to transparency · [ ] change size",
        Tool.Gradient => "Drag to draw a gradient · Shift snaps to 45°",
        Tool.Bucket => "Click to fill similar colors",
        Tool.Blur or Tool.Sharpen or Tool.Smudge => "Paint to soften, crisp up or push pixels",
        Tool.Dodge or Tool.Burn or Tool.Sponge => "Paint to lighten, darken or change saturation",
        Tool.Text => "Click to place text · Ctrl+Enter to commit · Esc to cancel",
        Tool.ShapeRect or Tool.ShapeEllipse or Tool.ShapeLine => "Drag to draw a shape on a new layer · Shift constrains",
        Tool.Hand => "Drag to pan · hold Space with any tool",
        Tool.Zoom => "Click to zoom in · Alt-click to zoom out · or use the mouse wheel",
        _ => ""
    };

    public static bool IsBrushLike(Tool t) => t is Tool.Brush or Tool.Pencil or Tool.Eraser or Tool.Clone or Tool.Heal or Tool.SpotHeal
        or Tool.Blur or Tool.Sharpen or Tool.Smudge or Tool.Dodge or Tool.Burn or Tool.Sponge;
}

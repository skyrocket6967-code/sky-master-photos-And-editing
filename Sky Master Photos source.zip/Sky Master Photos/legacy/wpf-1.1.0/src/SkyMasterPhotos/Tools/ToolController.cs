using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos.Tools;

public interface IEditorHost
{
    Document ActiveDoc { get; }
    Color Fg { get; }
    Color Bg { get; }
    void SetFg(Color c);
    void SetBg(Color c);
    void Toast(string msg);
    Canvas TextHost { get; }
    void OnToolStateChanged();
}

/// <summary>Implements every canvas tool: selection, painting, transform, crop, text, shapes, fills.</summary>
public sealed class ToolController
{
    readonly IEditorHost _host;
    public CanvasView Canvas;
    Document Doc => _host.ActiveDoc;

    Tool _tool = Tool.Brush;
    public event Action ToolChanged;

    // ── settings ──
    public readonly BrushSettings BrushS = new() { Size = 30, Hardness = 0.8 };
    public readonly BrushSettings PencilS = new() { Size = 4, Hardness = 1, Spacing = 0.05 };
    public readonly BrushSettings EraserS = new() { Size = 60, Hardness = 0.6 };
    public readonly BrushSettings CloneS = new() { Size = 60, Hardness = 0.5 };
    public readonly BrushSettings HealS = new() { Size = 40, Hardness = 0.5 };
    public readonly BrushSettings EffectS = new() { Size = 60, Hardness = 0.3, Strength = 0.5 };
    public readonly BrushSettings ToneS = new() { Size = 90, Hardness = 0.2, Strength = 0.35 };

    public SelectMode SelMode = SelectMode.New;
    public int Feather;
    public int WandTolerance = 32;
    public bool WandContiguous = true;
    public bool SampleAll = true;
    public int BucketTolerance = 32;
    public bool BucketContiguous = true;
    public int GradientType;      // 0 linear, 1 radial, 2 reflected
    public int GradientMode;      // 0 fg→bg, 1 fg→transparent
    public bool ShapeFill = true, ShapeStroke;
    public double StrokeWidth = 6, CornerRadius;
    public string FontName = "Segoe UI";
    public double FontSize = 96;
    public bool Bold, Italic;
    public bool AutoSelect;
    public int CropRatio;         // index into CropRatios
    public static readonly (string name, double ratio)[] CropRatios = { ("Free", 0), ("1 : 1", 1), ("4 : 3", 4.0 / 3), ("3 : 2", 1.5), ("16 : 9", 16.0 / 9), ("9 : 16", 9.0 / 16), ("4 : 5", 0.8) };

    // ── state ──
    Point _down, _last, _hover;
    ModifierKeys _downMods;
    bool _dragging;
    StrokeSession _stroke;
    Point? _lastStrokeEnd;
    Point? _cloneSrc;
    Vector? _cloneOffset;
    List<Point> _lasso;
    List<Point> _poly;
    Rect? _crop;
    int _cropHandle = -1;
    Rect _cropStart;
    TextBox _textBox;
    Point _textPos;
    public TransformSession Xf { get; private set; }
    enum XfMode { None, Move, Rotate, Scale }
    XfMode _xfMode;
    int _xfHandle;
    double _sx0, _sy0, _ang0;
    Vector _t0;
    Point _anchor;

    public bool SpaceHeld;

    public ToolController(IEditorHost host) { _host = host; }

    public Tool Tool
    {
        get => _tool;
        set
        {
            if (_tool == value) return;
            FinishPending();
            _tool = value;
            if (_tool == Tool.Crop && Doc != null) _crop = new Rect(0, 0, Doc.Width, Doc.Height);
            ToolChanged?.Invoke();
            Canvas?.InvalidateVisual();
            Canvas?.UpdateCursor();
        }
    }

    public BrushSettings CurrentBrush => _tool switch
    {
        Tool.Pencil => PencilS,
        Tool.Eraser => EraserS,
        Tool.Clone => CloneS,
        Tool.Heal or Tool.SpotHeal => HealS,
        Tool.Blur or Tool.Sharpen or Tool.Smudge => EffectS,
        Tool.Dodge or Tool.Burn or Tool.Sponge => ToneS,
        _ => BrushS
    };

    public bool HasAntsPreview => (_dragging && (_tool is Tool.MarqueeRect or Tool.MarqueeEllipse or Tool.Lasso)) || _poly != null;
    public bool CropActive => _crop != null && _tool == Tool.Crop;
    public bool TextActive => _textBox != null;
    public bool Busy => _stroke != null || _dragging;

    /// <summary>Commit / cancel any modal tool state (used when switching tools or documents).</summary>
    public void FinishPending()
    {
        if (_stroke != null) { _stroke.Commit(StrokeName()); _stroke = null; }
        if (Xf != null) CommitTransform();
        if (_textBox != null) CommitText();
        _poly = null;
        _lasso = null;
        _crop = null;
        _dragging = false;
        _host.OnToolStateChanged();
    }

    public void OnDocumentSwitched()
    {
        _stroke = null;
        Xf = null;
        if (_textBox != null) CancelText();
        _poly = null;
        _lasso = null;
        _crop = _tool == Tool.Crop && Doc != null ? new Rect(0, 0, Doc.Width, Doc.Height) : null;
        _cloneSrc = null;
        _cloneOffset = null;
        _dragging = false;
        _host.OnToolStateChanged();
    }

    // ───────────────────────────── helpers ─────────────────────────────

    bool LayerEditable(bool needVisible = true)
    {
        var l = Doc?.ActiveLayer;
        if (l == null) { _host.Toast("Select a layer first"); return false; }
        if (l.Locked) { _host.Toast($"“{l.Name}” is locked"); return false; }
        if (needVisible && !l.Visible) { _host.Toast($"“{l.Name}” is hidden"); return false; }
        return true;
    }

    SelectMode ModeFrom(ModifierKeys m)
    {
        bool shift = (m & ModifierKeys.Shift) != 0, alt = (m & ModifierKeys.Alt) != 0;
        if (shift && alt) return SelectMode.Intersect;
        if (shift) return SelectMode.Add;
        if (alt) return SelectMode.Subtract;
        return SelMode;
    }

    void ApplySelection(string name, byte[] mask, SelectMode mode)
    {
        var d = Doc;
        if (Feather > 0) mask = SelectionOps.Feather(mask, d.Width, d.Height, Feather);
        var before = d.Capture();
        d.SetSelection(SelectionOps.Combine(d.Selection, mask, mode));
        d.Record(name, before, "⬚");
    }

    uint Sample(Point p, bool all)
    {
        var d = Doc;
        int x = (int)Math.Floor(p.X), y = (int)Math.Floor(p.Y);
        if (x < 0 || y < 0 || x >= d.Width || y >= d.Height) return 0;
        return all || d.ActiveLayer == null ? d.Flat[y * d.Width + x] : d.ActiveLayer.Pixels[y * d.Width + x];
    }

    void PickColor(Point p, bool bg)
    {
        uint c = Sample(p, SampleAll);
        if ((c >> 24) == 0) return;
        var col = Px.ToColor(c);
        col.A = 255;
        if (bg) _host.SetBg(col); else _host.SetFg(col);
    }

    string StrokeName() => ToolInfo.Name(_tool);

    StrokeKind KindFor(Tool t) => t switch
    {
        Tool.Pencil => StrokeKind.Pencil,
        Tool.Eraser => StrokeKind.Erase,
        Tool.Clone => StrokeKind.Clone,
        Tool.Heal => StrokeKind.Heal,
        Tool.SpotHeal => StrokeKind.SpotHeal,
        Tool.Blur => StrokeKind.Blur,
        Tool.Sharpen => StrokeKind.Sharpen,
        Tool.Smudge => StrokeKind.Smudge,
        Tool.Dodge => StrokeKind.Dodge,
        Tool.Burn => StrokeKind.Burn,
        Tool.Sponge => StrokeKind.Sponge,
        _ => StrokeKind.Paint
    };

    Point Snap45(Point a, Point b)
    {
        var v = b - a;
        double ang = Math.Round(Math.Atan2(v.Y, v.X) / (Math.PI / 4)) * (Math.PI / 4);
        double len = v.Length;
        return new Point(a.X + Math.Cos(ang) * len, a.Y + Math.Sin(ang) * len);
    }

    Rect MarqueeRect(Point a, Point b, ModifierKeys m)
    {
        bool constrain = (m & ModifierKeys.Shift) != 0 && (_downMods & ModifierKeys.Shift) == 0;
        bool center = (m & ModifierKeys.Alt) != 0 && (_downMods & ModifierKeys.Alt) == 0;
        double dx = b.X - a.X, dy = b.Y - a.Y;
        if (constrain) { double s = Math.Max(Math.Abs(dx), Math.Abs(dy)); dx = Math.Sign(dx == 0 ? 1 : dx) * s; dy = Math.Sign(dy == 0 ? 1 : dy) * s; }
        Rect r = center ? new Rect(new Point(a.X - dx, a.Y - dy), new Point(a.X + dx, a.Y + dy)) : new Rect(a, new Point(a.X + dx, a.Y + dy));
        return new Rect(Math.Round(r.X), Math.Round(r.Y), Math.Round(r.Width), Math.Round(r.Height));
    }

    // ───────────────────────────── mouse ─────────────────────────────

    public void MouseDown(Point s, Point d, ModifierKeys m, int clicks)
    {
        if (Doc == null) return;
        _down = d;
        _last = d;
        _downMods = m;
        _dragging = true;
        bool alt = (m & ModifierKeys.Alt) != 0;

        if (Xf != null && Xf.Handles) { XfDown(s, d); return; }
        if (_textBox != null) { CommitText(); _dragging = false; return; }

        switch (_tool)
        {
            case Tool.Move:
                if (AutoSelect) AutoPickLayer(d);
                if (!LayerEditable()) { _dragging = false; return; }
                if (Doc.ActiveLayer.IsAdjustment) { _host.Toast("Adjustment layers have no pixels to move"); _dragging = false; return; }
                Xf = TransformSession.Begin(Doc, false);
                _xfMode = XfMode.Move;
                _t0 = new Vector();
                break;

            case Tool.MarqueeRect:
            case Tool.MarqueeEllipse:
                break;

            case Tool.Lasso:
                _lasso = new List<Point> { d };
                break;

            case Tool.PolyLasso:
                _dragging = false;
                if (_poly == null) _poly = new List<Point> { d };
                else if (clicks >= 2 || (_poly.Count > 2 && (Canvas.ToScreen(_poly[0]) - s).Length < 9)) ClosePoly();
                else _poly.Add(d);
                break;

            case Tool.MagicWand:
            {
                _dragging = false;
                var src = SampleAll || Doc.ActiveLayer == null ? Doc.Flat : Doc.ActiveLayer.Pixels;
                var mask = SelectionOps.MagicWand(src, Doc.Width, Doc.Height, (int)Math.Floor(d.X), (int)Math.Floor(d.Y), WandTolerance, WandContiguous);
                ApplySelection("Magic Wand", mask, ModeFrom(m));
                break;
            }

            case Tool.Crop:
                if (_crop != null && clicks >= 2 && _crop.Value.Contains(d)) { ApplyCrop(); _dragging = false; return; }
                _cropHandle = _crop == null ? -1 : HitCrop(s);
                if (_cropHandle < 0) { _crop = new Rect(d, d); _cropHandle = 9; }
                _cropStart = _crop.Value;
                break;

            case Tool.Eyedropper:
                PickColor(d, alt);
                break;

            case Tool.Brush:
            case Tool.Pencil:
                if (alt) { PickColor(d, false); _dragging = false; return; }
                goto case Tool.Eraser;

            case Tool.Clone:
            case Tool.Heal:
                if (alt) { _cloneSrc = d; _cloneOffset = null; _host.Toast("Source set — now paint"); _dragging = false; return; }
                if (_cloneSrc == null) { _host.Toast("Alt-click to set a source point first"); _dragging = false; return; }
                _cloneOffset ??= _cloneSrc.Value - d;
                goto case Tool.Eraser;

            case Tool.SpotHeal:
            case Tool.Eraser:
            case Tool.Blur:
            case Tool.Sharpen:
            case Tool.Smudge:
            case Tool.Dodge:
            case Tool.Burn:
            case Tool.Sponge:
            {
                if (!LayerEditable()) { _dragging = false; return; }
                if (!PrepareForPixelEdit(Doc.ActiveLayer)) { _dragging = false; return; }
                _stroke = new StrokeSession(Doc, Doc.ActiveLayer, KindFor(_tool), CurrentBrush, Px.FromColor(_host.Fg), _cloneOffset ?? new Vector());
                Int32Rect r;
                if ((m & ModifierKeys.Shift) != 0 && _lastStrokeEnd is Point lp)
                {
                    _stroke.MoveTo(lp);
                    r = _stroke.MoveTo(d);
                }
                else r = _stroke.MoveTo(d);
                Doc.Render(r);
                break;
            }

            case Tool.Gradient:
                if (!LayerEditable() || !PrepareForPixelEdit(Doc.ActiveLayer)) _dragging = false;
                break;

            case Tool.Bucket:
                _dragging = false;
                if (alt) { PickColor(d, false); return; }
                if (LayerEditable() && PrepareForPixelEdit(Doc.ActiveLayer)) BucketFill(d);
                break;

            case Tool.Text:
                _dragging = false;
                BeginText(d);
                break;

            case Tool.ShapeRect:
            case Tool.ShapeEllipse:
            case Tool.ShapeLine:
                if (alt) { PickColor(d, false); _dragging = false; }
                break;
        }
        Canvas.InvalidateVisual();
    }

    public void MouseMove(Point s, Point d, ModifierKeys m, bool leftDown)
    {
        if (Doc == null) return;
        _hover = d;
        if (Xf != null)
        {
            if (leftDown && _xfMode != XfMode.None) XfDrag(d, m);
            return;
        }
        if (!leftDown || !_dragging) return;

        switch (_tool)
        {
            case Tool.Brush:
            case Tool.Pencil:
            case Tool.Eraser:
            case Tool.Clone:
            case Tool.Heal:
            case Tool.SpotHeal:
            case Tool.Blur:
            case Tool.Sharpen:
            case Tool.Smudge:
            case Tool.Dodge:
            case Tool.Burn:
            case Tool.Sponge:
                if (_stroke != null)
                {
                    var r = _stroke.MoveTo(d);
                    if (!RectUtil.IsEmptyRect(r)) Doc.Render(r);
                }
                break;
            case Tool.Lasso:
                if (_lasso != null && (Canvas.ToScreen(_lasso[^1]) - s).Length > 1.5) _lasso.Add(d);
                break;
            case Tool.Crop:
                DragCrop(d, m);
                break;
            case Tool.Eyedropper:
                PickColor(d, (m & ModifierKeys.Alt) != 0);
                break;
        }
        _last = d;
    }

    public void MouseUp(Point s, Point d, ModifierKeys m)
    {
        if (Doc == null) return;
        if (Xf != null)
        {
            if (!Xf.Handles) CommitTransform();
            else _xfMode = XfMode.None;
            _dragging = false;
            return;
        }
        if (!_dragging) return;
        _dragging = false;

        switch (_tool)
        {
            case Tool.MarqueeRect:
            case Tool.MarqueeEllipse:
            {
                var r = MarqueeRect(_down, d, m);
                if (r.Width < 1 || r.Height < 1)
                {
                    if (Doc.HasSelection && ModeFrom(_downMods) == SelectMode.New) Deselect();
                    break;
                }
                var ir = new Int32Rect((int)r.X, (int)r.Y, (int)r.Width, (int)r.Height);
                var mask = _tool == Tool.MarqueeRect ? SelectionOps.Rect(Doc.Width, Doc.Height, ir) : SelectionOps.Ellipse(Doc.Width, Doc.Height, ir);
                ApplySelection(ToolInfo.Name(_tool), mask, ModeFrom(_downMods));
                break;
            }
            case Tool.Lasso:
                if (_lasso != null && _lasso.Count > 2)
                    ApplySelection("Lasso", SelectionOps.Polygon(Doc.Width, Doc.Height, _lasso), ModeFrom(_downMods));
                else if (Doc.HasSelection) Deselect();
                _lasso = null;
                break;
            case Tool.Crop:
                if (_crop is Rect cr)
                {
                    if (cr.Width < 2 || cr.Height < 2) _crop = new Rect(0, 0, Doc.Width, Doc.Height);
                    _host.OnToolStateChanged();
                }
                break;
            case Tool.Gradient:
                if ((d - _down).Length > 0.5) ApplyGradient(_down, (m & ModifierKeys.Shift) != 0 ? Snap45(_down, d) : d);
                break;
            case Tool.ShapeRect:
            case Tool.ShapeEllipse:
            case Tool.ShapeLine:
                ApplyShape(_down, d, m);
                break;
            default:
                if (_stroke != null)
                {
                    _stroke.Commit(StrokeName());
                    _stroke = null;
                    _lastStrokeEnd = d;
                }
                break;
        }
        Canvas.InvalidateVisual();
    }

    public void CaptureLost()
    {
        // if capture is stolen mid-stroke (e.g. alt-tab), keep the work
        if (_stroke != null) { _stroke.Commit(StrokeName()); _stroke = null; }
        if (Xf != null && !Xf.Handles) CommitTransform();
        _dragging = false;
    }

    public void Deselect()
    {
        if (Doc == null || !Doc.HasSelection) return;
        var before = Doc.Capture();
        Doc.SetSelection(null);
        Doc.Record("Deselect", before, "⬚");
    }

    void AutoPickLayer(Point d)
    {
        int x = (int)d.X, y = (int)d.Y;
        if (x < 0 || y < 0 || x >= Doc.Width || y >= Doc.Height) return;
        foreach (var l in Doc.Layers)
            if (l.Visible && (l.Pixels[y * Doc.Width + x] >> 24) > 8) { Doc.ActiveLayer = l; return; }
    }

    // ───────────────────────────── polygon lasso ─────────────────────────────

    void ClosePoly()
    {
        if (_poly != null && _poly.Count > 2) ApplySelection("Polygonal Lasso", SelectionOps.Polygon(Doc.Width, Doc.Height, _poly), ModeFrom(_downMods));
        _poly = null;
        Canvas.InvalidateVisual();
    }

    // ───────────────────────────── fills ─────────────────────────────

    void BucketFill(Point d)
    {
        var doc = Doc;
        var layer = doc.ActiveLayer;
        var src = SampleAll ? doc.Flat : layer.Pixels;
        var mask = SelectionOps.MagicWand(src, doc.Width, doc.Height, (int)Math.Floor(d.X), (int)Math.Floor(d.Y), BucketTolerance, BucketContiguous);
        if (doc.Selection != null) mask = SelectionOps.Combine(doc.Selection, mask, SelectMode.Intersect);
        // soften the edge a touch so fills don't look jagged
        mask = SelectionOps.Feather(SelectionOps.Grow(mask, doc.Width, doc.Height, 1), doc.Width, doc.Height, 1);
        uint c = TargetColor(layer, _host.Fg);
        var before = doc.Capture();
        var px = layer.Target;
        var o = new uint[px.Length];
        Parallel.For(0, px.Length, i => o[i] = mask[i] == 0 ? px[i] : Px.Over(px[i], c, mask[i] / 255f));
        layer.SetTarget(o);
        doc.RenderAll();
        layer.RefreshThumbnail();
        doc.RefreshThumbnail();
        doc.Record("Paint Bucket", before, "◧");
    }

    void ApplyGradient(Point a, Point b)
    {
        var doc = Doc;
        var layer = doc.ActiveLayer;
        uint c0 = TargetColor(layer, _host.Fg);
        uint c1 = GradientMode == 0 ? TargetColor(layer, _host.Bg) : layer.EditMask ? 0xFF000000u : Px.WithAlpha(c0, 0);
        var before = doc.Capture();
        var px = layer.Target;
        var o = new uint[px.Length];
        var sel = doc.Selection;
        int w = doc.Width, h = doc.Height;
        double vx = b.X - a.X, vy = b.Y - a.Y, len2 = Math.Max(1e-6, vx * vx + vy * vy), len = Math.Sqrt(len2);
        int type = GradientType;
        Parallel.For(0, h, y =>
        {
            var rnd = new Random(y * 31 + 7);
            for (int x = 0; x < w; x++)
            {
                double px0 = x + 0.5 - a.X, py0 = y + 0.5 - a.Y;
                double t = type switch
                {
                    1 => Math.Sqrt(px0 * px0 + py0 * py0) / len,
                    2 => Math.Abs((px0 * vx + py0 * vy) / len2),
                    _ => (px0 * vx + py0 * vy) / len2
                };
                t = Math.Clamp(t + (rnd.NextDouble() - 0.5) / 255.0, 0, 1); // tiny dither kills banding
                uint col = Px.Lerp(c0, c1, (float)t);
                int i = y * w + x;
                float op = sel == null ? 1f : sel[i] / 255f;
                o[i] = op <= 0 ? px[i] : Px.Over(px[i], col, op);
            }
        });
        layer.SetTarget(o);
        doc.RenderAll();
        layer.RefreshThumbnail();
        doc.RefreshThumbnail();
        doc.Record("Gradient", before, "◐");
    }

    // ───────────────────────────── shapes ─────────────────────────────

    (Point a, Point b) ShapePoints(Point a, Point b, ModifierKeys m)
    {
        if (_tool == Tool.ShapeLine) return (a, (m & ModifierKeys.Shift) != 0 ? Snap45(a, b) : b);
        if ((m & ModifierKeys.Shift) != 0)
        {
            double dx = b.X - a.X, dy = b.Y - a.Y, s = Math.Max(Math.Abs(dx), Math.Abs(dy));
            b = new Point(a.X + Math.Sign(dx == 0 ? 1 : dx) * s, a.Y + Math.Sign(dy == 0 ? 1 : dy) * s);
        }
        if ((m & ModifierKeys.Alt) != 0) a = new Point(2 * a.X - b.X, 2 * a.Y - b.Y);
        return (a, b);
    }

    (Brush fill, Pen pen) ShapeStyle()
    {
        var fg = new SolidColorBrush(_host.Fg);
        if (_tool == Tool.ShapeLine) return (null, new Pen(fg, Math.Max(1, StrokeWidth)) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round });
        Brush fill = ShapeFill ? fg : null;
        Pen pen = ShapeStroke ? new Pen(new SolidColorBrush(ShapeFill ? _host.Bg : _host.Fg), Math.Max(1, StrokeWidth)) { LineJoin = PenLineJoin.Round } : null;
        if (fill == null && pen == null) fill = fg;
        return (fill, pen);
    }

    void ApplyShape(Point a, Point b, ModifierKeys m)
    {
        (a, b) = ShapePoints(a, b, m);
        if ((b - a).Length < 2) return;
        var doc = Doc;
        var g = Raster.ShapeGeometry(_tool, a, b, CornerRadius);
        var (fill, pen) = ShapeStyle();
        var px = Raster.Shape(doc.Width, doc.Height, g, fill, pen);
        var before = doc.Capture();
        int n = doc.Layers.Count(l => l.Name.StartsWith(ToolInfo.Name(_tool))) + 1;
        var layer = new Layer($"{ToolInfo.Name(_tool)} {n}", doc.Width, doc.Height, px);
        int idx = Math.Max(0, doc.ActiveIndex);
        doc.Layers.Insert(idx, layer);
        doc.ActiveLayer = layer;
        doc.RenderAll();
        layer.RefreshThumbnail();
        doc.RefreshThumbnail();
        doc.Record(ToolInfo.Name(_tool), before, "▭");
    }

    // ───────────────────────────── text ─────────────────────────────

    Layer _textLayer;          // existing text layer being re-edited (null for new text)
    DocState _textBefore;

    /// <summary>Masks get grayscale paint; everything else gets the color as-is.</summary>
    public static uint TargetColor(Layer l, Color c)
    {
        uint p = Px.FromColor(c);
        if (l?.EditMask != true) return p;
        return Masks.Gray((byte)Px.Clamp(Px.Luma(p)));
    }

    /// <summary>
    /// Called before any pixel edit: adjustment layers are edited through their mask (created on demand),
    /// and editable text layers are rasterized (recorded in history).
    /// </summary>
    public bool PrepareForPixelEdit(Layer l)
    {
        if (l == null) return false;
        var doc = Doc;
        if (l.IsAdjustment || l.Psd?.UnrenderedAdjustment == true)
        {
            if (l.Mask == null)
            {
                var before = doc.Capture();
                l.SetMask(Layer.NewMask(l.Width, l.Height, 255));
                l.RefreshThumbnail();
                doc.Record("Add Layer Mask", before, "◐");
            }
            l.EditMask = true;
            return true;
        }
        if (l.Text != null && !l.EditMask)
        {
            var before = doc.Capture();
            l.Text = null;
            doc.Record("Rasterize Type", before, "T");
            _host.Toast("Text layer rasterized — it's now regular pixels");
        }
        return true;
    }

    /// <summary>Topmost visible text layer under a document point.</summary>
    Layer TextLayerAt(Point d)
    {
        int x = (int)d.X, y = (int)d.Y;
        foreach (var l in Doc.Layers)
        {
            if (l.Text == null || !l.Visible) continue;
            var b = Transforms.OpaqueBounds(l.Pixels, l.Width, l.Height);
            if (RectUtil.IsEmptyRect(b)) continue;
            if (x >= b.X - 4 && y >= b.Y - 4 && x <= b.X + b.Width + 4 && y <= b.Y + b.Height + 4) return l;
        }
        return null;
    }

    public void EditTextLayer(Layer l)
    {
        if (l?.Text == null) return;
        if (_tool != Tool.Text) Tool = Tool.Text;
        BeginText(new Point(l.Text.X, l.Text.Y), l);
    }

    void BeginText(Point d, Layer existing = null)
    {
        var host = _host.TextHost;
        if (host == null) return;
        existing ??= TextLayerAt(d);
        if (existing != null && existing.Locked) { _host.Toast($"“{existing.Name}” is locked"); return; }
        _textLayer = existing;
        _textBefore = Doc.Capture();
        if (existing != null)
        {
            var t = existing.Text;
            FontName = t.Font; FontSize = t.Size; Bold = t.Bold; Italic = t.Italic;
            _host.SetFg(t.Color);
            _textPos = new Point(t.X, t.Y);
            existing.Visible = false; // hide the rendered copy while editing
            Doc.RenderAll();
        }
        else _textPos = d;
        _textBox = new TextBox
        {
            AcceptsReturn = true,
            Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
            BorderBrush = UIx.R<Brush>("Accent"),
            BorderThickness = new Thickness(1),
            Foreground = new SolidColorBrush(_host.Fg),
            CaretBrush = new SolidColorBrush(_host.Fg),
            MinWidth = 24,
            Padding = new Thickness(0),
            Style = null,
            Template = null,
            Text = existing?.Text.Text ?? "",
        };
        _textBox.Template = BuildTextTemplate();
        ApplyTextStyle();
        _textBox.PreviewKeyDown += (_, e) =>
        {
            if (e.Key == Key.Enter && (Keyboard.Modifiers & ModifierKeys.Control) != 0) { CommitText(); e.Handled = true; }
            else if (e.Key == Key.Escape) { CancelText(); e.Handled = true; }
        };
        host.Children.Add(_textBox);
        PositionTextBox();
        _textBox.Loaded += (_, _) => { _textBox?.Focus(); Keyboard.Focus(_textBox); _textBox?.SelectAll(); };
        _host.OnToolStateChanged();
    }
    static ControlTemplate BuildTextTemplate()
    {
        var t = new ControlTemplate(typeof(TextBox));
        var border = new FrameworkElementFactory(typeof(Border));
        border.SetValue(Border.BorderBrushProperty, new TemplateBindingExtension(Control.BorderBrushProperty));
        border.SetValue(Border.BorderThicknessProperty, new TemplateBindingExtension(Control.BorderThicknessProperty));
        border.SetValue(Border.BackgroundProperty, new TemplateBindingExtension(Control.BackgroundProperty));
        var sv = new FrameworkElementFactory(typeof(ScrollViewer)) { Name = "PART_ContentHost" };
        sv.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Hidden);
        sv.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Hidden);
        sv.SetValue(UIElement.FocusableProperty, false);
        border.AppendChild(sv);
        t.VisualTree = border;
        return t;
    }

    public void ApplyTextStyle()
    {
        if (_textBox == null) return;
        _textBox.FontFamily = new FontFamily(FontName);
        _textBox.FontSize = Math.Max(1, FontSize * Canvas.Zoom);
        _textBox.FontWeight = Bold ? FontWeights.Bold : FontWeights.Normal;
        _textBox.FontStyle = Italic ? FontStyles.Italic : FontStyles.Normal;
        _textBox.Foreground = new SolidColorBrush(_host.Fg);
        PositionTextBox();
    }

    public void PositionTextBox()
    {
        if (_textBox == null) return;
        var s = Canvas.ToScreen(_textPos);
        // TextBoxView adds a ~2px gutter; compensate so the committed text lands where it was typed
        System.Windows.Controls.Canvas.SetLeft(_textBox, s.X - 3);
        System.Windows.Controls.Canvas.SetTop(_textBox, s.Y - 1);
    }

    public void CommitText()
    {
        if (_textBox == null) return;
        var text = _textBox.Text;
        var tb = _textBox;
        _textBox = null;
        _host.TextHost.Children.Remove(tb);
        var doc = Doc;
        var existing = _textLayer;
        _textLayer = null;
        if (doc == null) { _host.OnToolStateChanged(); return; }
        if (existing != null) existing.Visible = true;
        if (!string.IsNullOrWhiteSpace(text))
        {
            var spec = new TextSpec { Text = text, Font = FontName, Size = FontSize, Bold = Bold, Italic = Italic, Color = _host.Fg, X = _textPos.X, Y = _textPos.Y };
            var px = Raster.Text(doc.Width, doc.Height, text, _textPos, new FontFamily(FontName), FontSize, Bold, Italic, _host.Fg);
            var name = text.Replace("\r", " ").Replace("\n", " ").Trim();
            if (name.Length > 28) name = name[..28] + "…";
            Layer layer = existing;
            if (existing == null)
            {
                layer = new Layer(name, doc.Width, doc.Height, px);
                doc.Layers.Insert(Math.Max(0, doc.ActiveIndex), layer);
            }
            else
            {
                if (existing.Text?.Text == text && existing.Text.Font == FontName && existing.Text.Size == FontSize && existing.Text.Bold == Bold && existing.Text.Italic == Italic && existing.Text.Color == _host.Fg)
                {
                    // nothing changed: keep the original (Photoshop-rendered) pixels
                    doc.RenderAll();
                    Canvas.Focus();
                    _host.OnToolStateChanged();
                    return;
                }
                layer.SetPixels(px, doc.Width, doc.Height);
                if (layer.Name == TrimName(existing.Text?.Text)) layer.Name = name;
            }
            layer.Text = spec;
            doc.ActiveLayer = layer;
            doc.RenderAll();
            layer.RefreshThumbnail();
            doc.RefreshThumbnail();
            doc.Record(existing == null ? "Type" : "Edit Type", _textBefore, "T");
        }
        else doc.RenderAll();
        Canvas.Focus();
        _host.OnToolStateChanged();
    }

    static string TrimName(string text)
    {
        var name = (text ?? "").Replace("\r", " ").Replace("\n", " ").Trim();
        return name.Length > 28 ? name[..28] + "…" : name;
    }

    public void CancelText()
    {
        if (_textBox == null) return;
        _host.TextHost.Children.Remove(_textBox);
        _textBox = null;
        if (_textLayer != null) { _textLayer.Visible = true; Doc?.RenderAll(); _textLayer = null; }
        Canvas?.Focus();
        _host.OnToolStateChanged();
    }
    // ───────────────────────────── crop ─────────────────────────────

    Point[] CropHandles(Rect r) => new[]
    {
        r.TopLeft, new Point(r.X + r.Width / 2, r.Y), r.TopRight, new Point(r.Right, r.Y + r.Height / 2),
        r.BottomRight, new Point(r.X + r.Width / 2, r.Bottom), r.BottomLeft, new Point(r.X, r.Y + r.Height / 2)
    };

    int HitCrop(Point s)
    {
        if (_crop is not Rect r) return -1;
        var hs = CropHandles(r);
        for (int i = 0; i < hs.Length; i++) if ((Canvas.ToScreen(hs[i]) - s).Length < 10) return i;
        if (r.Contains(Canvas.ToDoc(s))) return 8;
        return -1;
    }

    void DragCrop(Point d, ModifierKeys m)
    {
        var r = _cropStart;
        double ratio = CropRatios[CropRatio].ratio;
        if ((m & ModifierKeys.Shift) != 0 && ratio == 0) ratio = r.Width > 0 && r.Height > 0 ? r.Width / r.Height : 1;
        Rect nr;
        switch (_cropHandle)
        {
            case 9:
            {
                var b = d;
                if (ratio > 0)
                {
                    double dx = b.X - _down.X, dy = b.Y - _down.Y;
                    double w = Math.Abs(dx), h = Math.Abs(dy);
                    if (w / Math.Max(1e-6, h) > ratio) h = w / ratio; else w = h * ratio;
                    b = new Point(_down.X + Math.Sign(dx == 0 ? 1 : dx) * w, _down.Y + Math.Sign(dy == 0 ? 1 : dy) * h);
                }
                nr = new Rect(_down, b);
                break;
            }
            case 8:
                nr = r;
                nr.Offset(d - _down);
                break;
            default:
            {
                double l = r.Left, t = r.Top, rr = r.Right, bb = r.Bottom;
                var delta = d - _down;
                int hnd = _cropHandle;
                if (hnd is 0 or 6 or 7) l += delta.X;
                if (hnd is 2 or 3 or 4) rr += delta.X;
                if (hnd is 0 or 1 or 2) t += delta.Y;
                if (hnd is 4 or 5 or 6) bb += delta.Y;
                if (ratio > 0 && hnd is 0 or 2 or 4 or 6)
                {
                    double w = Math.Abs(rr - l), h = w / ratio;
                    if (hnd is 0 or 2) t = bb - h; else bb = t + h;
                }
                nr = new Rect(new Point(l, t), new Point(rr, bb));
                break;
            }
        }
        _crop = new Rect(Math.Round(nr.X), Math.Round(nr.Y), Math.Round(nr.Width), Math.Round(nr.Height));
    }

    public void ApplyCrop()
    {
        if (_crop is not Rect cr || Doc == null) return;
        var doc = Doc;
        var r = new Int32Rect((int)cr.X, (int)cr.Y, (int)cr.Width, (int)cr.Height);
        if (r.Width < 1 || r.Height < 1) return;
        if (r.X == 0 && r.Y == 0 && r.Width == doc.Width && r.Height == doc.Height) { _host.Toast("Drag a smaller crop area first"); return; }
        var before = doc.Capture();
        foreach (var l in doc.Layers)
        {
            l.SetPixels(Transforms.Crop(l.Pixels, doc.Width, doc.Height, r), r.Width, r.Height);
            if (l.Mask != null) l.SetMask(Transforms.Crop(l.Mask, doc.Width, doc.Height, r));
        }
        doc.SetSize(r.Width, r.Height);
        doc.SetSelection(null);
        doc.RenderAll();
        doc.RefreshAllLayerThumbs();
        doc.NotifyStructure();
        doc.Record("Crop", before, "⌗");
        _crop = new Rect(0, 0, doc.Width, doc.Height);
        doc.ViewInitialized = false;
        Canvas.Fit();
        _host.OnToolStateChanged();
    }

    public void CancelCrop()
    {
        _crop = Doc != null ? new Rect(0, 0, Doc.Width, Doc.Height) : null;
        Canvas.InvalidateVisual();
        _host.OnToolStateChanged();
    }

    // ───────────────────────────── transform ─────────────────────────────

    public void BeginFreeTransform()
    {
        if (Doc == null || Xf != null) return;
        if (!LayerEditable()) return;
        FinishPending();
        Xf = TransformSession.Begin(Doc, true);
        Canvas.InvalidateVisual();
        _host.OnToolStateChanged();
        _host.Toast("Drag handles to scale · drag outside to rotate · Enter to apply");
    }

    public void CommitTransform()
    {
        if (Xf == null) return;
        var x = Xf;
        Xf = null;
        _xfMode = XfMode.None;
        x.Commit(Doc, x.Handles ? "Free Transform" : "Move");
        Canvas?.InvalidateVisual();
        _host.OnToolStateChanged();
    }

    public void CancelTransform()
    {
        if (Xf == null) return;
        var x = Xf;
        Xf = null;
        x.Cancel(Doc);
        Canvas?.InvalidateVisual();
        _host.OnToolStateChanged();
    }

    static readonly (int hx, int hy)[] HandleDirs = { (-1, -1), (1, -1), (1, 1), (-1, 1), (0, -1), (1, 0), (0, 1), (-1, 0) };

    Point[] XfHandlePoints()
    {
        var c = Xf.Corners();
        return new[]
        {
            c[0], c[1], c[2], c[3],
            Mid(c[0], c[1]), Mid(c[1], c[2]), Mid(c[2], c[3]), Mid(c[3], c[0])
        };
    }

    static Point Mid(Point a, Point b) => new((a.X + b.X) / 2, (a.Y + b.Y) / 2);

    int HitXf(Point s, out bool inside, out bool nearCorner)
    {
        inside = false;
        nearCorner = false;
        var hs = XfHandlePoints();
        for (int i = 0; i < hs.Length; i++) if ((Canvas.ToScreen(hs[i]) - s).Length < 9) return i;
        var d = Canvas.ToDoc(s);
        var poly = new PathGeometry();
        var c = Xf.Corners();
        var fig = new PathFigure { StartPoint = c[0], IsClosed = true };
        fig.Segments.Add(new PolyLineSegment(new[] { c[1], c[2], c[3] }, true));
        poly.Figures.Add(fig);
        inside = poly.FillContains(d);
        return -1;
    }

    static Vector Rot(Vector v, double deg)
    {
        var m = Matrix.Identity;
        m.Rotate(deg);
        return m.Transform(v);
    }

    void XfDown(Point s, Point d)
    {
        _sx0 = Xf.Sx; _sy0 = Xf.Sy; _ang0 = Xf.Angle; _t0 = Xf.T;
        int h = HitXf(s, out bool inside, out _);
        if (h >= 0)
        {
            _xfMode = XfMode.Scale;
            _xfHandle = h;
            var (hx, hy) = HandleDirs[h];
            var a = new Vector(-hx * Xf.Bounds.Width / 2, -hy * Xf.Bounds.Height / 2);
            var c = Xf.Center;
            _anchor = c + _t0 + Rot(new Vector(a.X * _sx0, a.Y * _sy0), _ang0);
        }
        else _xfMode = inside ? XfMode.Move : XfMode.Rotate;
    }

    void XfDrag(Point d, ModifierKeys m)
    {
        var x = Xf;
        switch (_xfMode)
        {
            case XfMode.Move:
                x.T = _t0 + (d - _down);
                if (!x.Handles) { x.T = new Vector(Math.Round(x.T.X), Math.Round(x.T.Y)); }
                break;
            case XfMode.Rotate:
            {
                var pivot = x.Center + _t0;
                double a0 = Math.Atan2(_down.Y - pivot.Y, _down.X - pivot.X), a1 = Math.Atan2(d.Y - pivot.Y, d.X - pivot.X);
                double ang = _ang0 + (a1 - a0) * 180 / Math.PI;
                if ((m & ModifierKeys.Shift) != 0) ang = Math.Round(ang / 15) * 15;
                x.Angle = ang;
                break;
            }
            case XfMode.Scale:
            {
                var (hx, hy) = HandleDirs[_xfHandle];
                double hw = x.Bounds.Width / 2, hh = x.Bounds.Height / 2;
                var v = Rot(d - _anchor, -_ang0);
                double sx = _sx0, sy = _sy0;
                if (hx != 0 && hw > 0) sx = v.X / (2 * hx * hw);
                if (hy != 0 && hh > 0) sy = v.Y / (2 * hy * hh);
                bool corner = hx != 0 && hy != 0;
                if (corner && (m & ModifierKeys.Shift) == 0)
                {
                    var h0 = new Vector(2 * hx * hw * _sx0, 2 * hy * hh * _sy0);
                    double k = (v.X * h0.X + v.Y * h0.Y) / Math.Max(1e-9, h0.LengthSquared);
                    sx = _sx0 * k;
                    sy = _sy0 * k;
                }
                if (Math.Abs(sx) < 0.005) sx = 0.005 * (sx < 0 ? -1 : 1);
                if (Math.Abs(sy) < 0.005) sy = 0.005 * (sy < 0 ? -1 : 1);
                x.Sx = sx;
                x.Sy = sy;
                var a = new Vector(-hx * hw, -hy * hh);
                x.T = (_anchor - x.Center) - Rot(new Vector(a.X * sx, a.Y * sy), _ang0);
                break;
            }
        }
        Canvas.InvalidateVisual();
    }

    public void Nudge(int dx, int dy)
    {
        if (Doc == null || Xf != null || !LayerEditable()) return;
        var s = TransformSession.Begin(Doc, false);
        if (s == null) return;
        s.T = new Vector(dx, dy);
        s.Commit(Doc, "Nudge");
    }

    // ───────────────────────────── keyboard ─────────────────────────────

    public bool KeyDown(Key k, ModifierKeys m)
    {
        if (Xf != null && Xf.Handles)
        {
            if (k == Key.Enter || k == Key.Return) { CommitTransform(); return true; }
            if (k == Key.Escape) { CancelTransform(); return true; }
        }
        if (_tool == Tool.Crop && _crop != null)
        {
            if (k == Key.Enter || k == Key.Return) { ApplyCrop(); return true; }
            if (k == Key.Escape) { CancelCrop(); return true; }
        }
        if (_poly != null)
        {
            if (k == Key.Enter || k == Key.Return) { ClosePoly(); return true; }
            if (k == Key.Escape) { _poly = null; Canvas.InvalidateVisual(); return true; }
            if (k == Key.Back) { if (_poly.Count > 1) _poly.RemoveAt(_poly.Count - 1); else _poly = null; Canvas.InvalidateVisual(); return true; }
        }
        if (_tool == Tool.Move && m != ModifierKeys.Control && Xf == null)
        {
            int step = (m & ModifierKeys.Shift) != 0 ? 10 : 1;
            switch (k)
            {
                case Key.Left: Nudge(-step, 0); return true;
                case Key.Right: Nudge(step, 0); return true;
                case Key.Up: Nudge(0, -step); return true;
                case Key.Down: Nudge(0, step); return true;
            }
        }
        return false;
    }

    // ───────────────────────────── cursor ─────────────────────────────

    public Cursor CursorFor(Point? s)
    {
        if (Xf != null && Xf.Handles && s is Point sp)
        {
            int h = HitXf(sp, out bool inside, out _);
            if (h >= 0)
            {
                // pick a resize cursor by the handle's on-screen direction
                var c = Canvas.ToScreen(Xf.Center + Xf.T);
                var hp = Canvas.ToScreen(XfHandlePoints()[h]);
                double ang = (Math.Atan2(hp.Y - c.Y, hp.X - c.X) * 180 / Math.PI + 360) % 180;
                if (ang < 22.5 || ang >= 157.5) return Cursors.SizeWE;
                if (ang < 67.5) return Cursors.SizeNWSE;
                if (ang < 112.5) return Cursors.SizeNS;
                return Cursors.SizeNESW;
            }
            return inside ? Cursors.SizeAll : Cursors.ScrollAll;
        }
        if (ToolInfo.IsBrushLike(_tool)) return Cursors.None;
        if (_tool == Tool.Crop && s is Point cs)
        {
            int h = HitCrop(cs);
            return h switch { 0 or 4 => Cursors.SizeNWSE, 2 or 6 => Cursors.SizeNESW, 1 or 5 => Cursors.SizeNS, 3 or 7 => Cursors.SizeWE, 8 => Cursors.SizeAll, _ => Cursors.Cross };
        }
        return _tool switch
        {
            Tool.Move => Cursors.SizeAll,
            Tool.Text => Cursors.IBeam,
            Tool.Eyedropper => Cursors.Pen,
            _ => Cursors.Cross
        };
    }

    // ───────────────────────────── overlay ─────────────────────────────

    public void DrawOverlay(DrawingContext dc, CanvasView cv)
    {
        if (Doc == null) return;
        var view = cv.View;

        if (Xf != null)
        {
            var c = Xf.Corners().Select(cv.ToScreen).ToArray();
            var pen = new Pen(UIx.R<Brush>("Accent"), 1.2);
            var g = new StreamGeometry();
            using (var ctx = g.Open())
            {
                ctx.BeginFigure(c[0], false, true);
                ctx.PolyLineTo(new[] { c[1], c[2], c[3] }, true, false);
            }
            dc.DrawGeometry(null, pen, g);
            if (Xf.Handles)
            {
                foreach (var hp in XfHandlePoints().Select(cv.ToScreen))
                {
                    var r = new Rect(hp.X - 4.5, hp.Y - 4.5, 9, 9);
                    dc.DrawRoundedRectangle(Brushes.White, new Pen(UIx.R<Brush>("Accent"), 1.5), r, 2, 2);
                }
                var ctr = cv.ToScreen(Xf.Center + Xf.T);
                dc.DrawEllipse(null, new Pen(Brushes.White, 1.2), ctr, 4, 4);
            }
            return;
        }

        if (_dragging && (_tool is Tool.MarqueeRect or Tool.MarqueeEllipse))
        {
            var r = MarqueeRect(_down, _last, Keyboard.Modifiers);
            var sr = new Rect(cv.ToScreen(r.TopLeft), cv.ToScreen(r.BottomRight));
            Geometry g = _tool == Tool.MarqueeRect ? new RectangleGeometry(sr) : new EllipseGeometry(sr);
            cv.DrawAnts(dc, g, 1);
            DrawSizeBadge(dc, sr.BottomRight, $"{r.Width:0} × {r.Height:0}");
        }

        if (_lasso != null && _lasso.Count > 1) cv.DrawAnts(dc, PolyGeo(_lasso.Select(cv.ToScreen), false), 1);

        if (_poly != null)
        {
            var pts = _poly.Select(cv.ToScreen).ToList();
            pts.Add(cv.ToScreen(_hover));
            cv.DrawAnts(dc, PolyGeo(pts, false), 1);
            var first = cv.ToScreen(_poly[0]);
            dc.DrawEllipse(UIx.R<Brush>("Accent"), new Pen(Brushes.White, 1.5), first, 4, 4);
        }

        if (_tool == Tool.Crop && _crop is Rect cr)
        {
            var sr = new Rect(cv.ToScreen(cr.TopLeft), cv.ToScreen(cr.BottomRight));
            var full = new RectangleGeometry(new Rect(0, 0, cv.ActualWidth, cv.ActualHeight));
            var outside = new CombinedGeometry(GeometryCombineMode.Exclude, full, new RectangleGeometry(sr));
            dc.DrawGeometry(new SolidColorBrush(Color.FromArgb(150, 5, 6, 10)), null, outside);
            var thin = new Pen(new SolidColorBrush(Color.FromArgb(110, 255, 255, 255)), 1);
            for (int i = 1; i < 3; i++)
            {
                dc.DrawLine(thin, new Point(sr.X + sr.Width * i / 3, sr.Y), new Point(sr.X + sr.Width * i / 3, sr.Bottom));
                dc.DrawLine(thin, new Point(sr.X, sr.Y + sr.Height * i / 3), new Point(sr.Right, sr.Y + sr.Height * i / 3));
            }
            dc.DrawRectangle(null, new Pen(Brushes.White, 1.5), sr);
            foreach (var h in CropHandles(cr).Select(cv.ToScreen))
                dc.DrawRoundedRectangle(Brushes.White, new Pen(new SolidColorBrush(Color.FromArgb(120, 0, 0, 0)), 1), new Rect(h.X - 5, h.Y - 5, 10, 10), 2, 2);
            DrawSizeBadge(dc, sr.BottomRight, $"{cr.Width:0} × {cr.Height:0}");
        }

        if (_dragging && _tool == Tool.Gradient)
        {
            var b = (Keyboard.Modifiers & ModifierKeys.Shift) != 0 ? Snap45(_down, _last) : _last;
            var a = cv.ToScreen(_down);
            var bs = cv.ToScreen(b);
            dc.DrawLine(new Pen(new SolidColorBrush(Color.FromArgb(140, 0, 0, 0)), 3.5), a, bs);
            dc.DrawLine(new Pen(Brushes.White, 1.5), a, bs);
            dc.DrawEllipse(new SolidColorBrush(_host.Fg), new Pen(Brushes.White, 2), a, 6, 6);
            dc.DrawEllipse(GradientMode == 0 ? new SolidColorBrush(_host.Bg) : UIx.Checker(3, false), new Pen(Brushes.White, 2), bs, 6, 6);
        }

        if (_dragging && _tool is Tool.ShapeRect or Tool.ShapeEllipse or Tool.ShapeLine)
        {
            var (a, b) = ShapePoints(_down, _last, Keyboard.Modifiers);
            var g = Raster.ShapeGeometry(_tool, a, b, CornerRadius);
            var (fill, pen) = ShapeStyle();
            dc.PushTransform(new MatrixTransform(view));
            dc.PushOpacity(0.85);
            dc.DrawGeometry(fill, pen, g);
            dc.Pop();
            dc.Pop();
            var sb = cv.ToScreen(b);
            DrawSizeBadge(dc, sb, $"{Math.Abs(b.X - a.X):0} × {Math.Abs(b.Y - a.Y):0}");
        }

        if (_tool is Tool.Clone or Tool.Heal && cv.MouseScreen is Point mp)
        {
            Point? src = null;
            if (_stroke != null && _cloneOffset is Vector off) src = cv.ToScreen(cv.ToDoc(mp) + off);
            else if (_cloneSrc is Point cs && _cloneOffset is null) src = cv.ToScreen(cs);
            else if (_cloneOffset is Vector off2) src = cv.ToScreen(cv.ToDoc(mp) + off2);
            if (src is Point sp)
            {
                var pen = new Pen(Brushes.White, 1.2);
                dc.DrawLine(pen, new Point(sp.X - 7, sp.Y), new Point(sp.X + 7, sp.Y));
                dc.DrawLine(pen, new Point(sp.X, sp.Y - 7), new Point(sp.X, sp.Y + 7));
                double r = CurrentBrush.Size / 2 * cv.Zoom;
                dc.DrawEllipse(null, new Pen(new SolidColorBrush(Color.FromArgb(130, 255, 255, 255)), 1) { DashStyle = DashStyles.Dash }, sp, r, r);
            }
        }
    }

    static Geometry PolyGeo(IEnumerable<Point> pts, bool closed)
    {
        var list = pts.ToList();
        var g = new StreamGeometry();
        using (var ctx = g.Open())
        {
            ctx.BeginFigure(list[0], false, closed);
            ctx.PolyLineTo(list.Skip(1).ToList(), true, false);
        }
        return g;
    }

    static void DrawSizeBadge(DrawingContext dc, Point at, string text)
    {
        var ft = Raster.MakeText(text, new FontFamily("Segoe UI"), 11, false, false, Brushes.White);
        var r = new Rect(at.X + 10, at.Y + 10, ft.Width + 14, ft.Height + 8);
        dc.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb(220, 20, 22, 28)), null, r, 6, 6);
        dc.DrawText(ft, new Point(r.X + 7, r.Y + 4));
    }
}

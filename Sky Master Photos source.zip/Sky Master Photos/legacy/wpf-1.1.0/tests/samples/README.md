# Test samples

`psd-tools/` contains real Adobe Photoshop files from the
[psd-tools](https://github.com/psd-tools/psd-tools) project (`tests/psd_files`),
used under the MIT license (see `psd-tools/LICENSE.txt`).

`psd-tools/expected.json` is the ground truth produced by psd-tools 1.24
(`tests/tools/dump_psd.py`). The test suite compares Sky Master Photos' PSD reader against it,
and re-validates every PSD the app writes with psd-tools when `SKY_PSD_PYTHON` points to a
Python that has `psd-tools` installed.

Regenerate the ground truth:

```powershell
python -m venv .venv
.venv\Scripts\python -m pip install psd-tools
.venv\Scripts\python tests\tools\dump_psd.py tests\samples\psd-tools\expected.json (Get-ChildItem tests\samples\psd-tools\*.ps?)
```

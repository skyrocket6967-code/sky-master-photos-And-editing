using System.Windows;
using System.Windows.Media;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Tools;
using Xunit;

namespace SkyMasterPhotos.Tests;

/// <summary>Engine-level checks for the new editing features (masks, adjustment layers, clipping, groups, healing).</summary>
public class EditingTests
{
    static Document Doc(int w = 200, int h = 120)
    {
        var d = Document.CreateBlank(w, h, "t", Colors.White);
        var px = new uint[w * h];
        Array.Fill(px, 0xFF2040C0);
        var l = new Layer("Blue", w, h, px);
        d.Layers.Insert(0, l);
        d.ActiveLayer = l;
        d.RenderAll();
        return d;
    }

    [Fact]
    public void Painting_on_a_mask_changes_only_the_mask_and_undoes()
    {
        TestUtil.Sta(() =>
        {
            var d = Doc();
            var l = d.ActiveLayer;
            l.SetMask(Layer.NewMask(d.Width, d.Height, 255));
            l.EditMask = true;
            var pixelsBefore = (uint[])l.Pixels.Clone();
            var s = new StrokeSession(d, l, StrokeKind.Paint, new BrushSettings { Size = 30, Hardness = 1 }, 0xFFFFFFFF /* white */, new Vector());
            // painting black hides: use an explicit black stroke
            s = new StrokeSession(d, l, StrokeKind.Paint, new BrushSettings { Size = 30, Hardness = 1 }, 0xFF000000, new Vector());
            d.Render(s.MoveTo(new Point(100, 60)));
            s.Commit("Brush");
            Assert.Equal(0, Masks.Value(l.Mask[60 * d.Width + 100]));
            Assert.True(l.Pixels.SequenceEqual(pixelsBefore));
            Assert.Equal(0xFFFFFFFFu, d.Flat[60 * d.Width + 100]); // layer hidden there → white background shows
            d.Undo();
            Assert.Equal(255, Masks.Value(l.Mask[60 * d.Width + 100]));
        });
    }

    [Fact]
    public void Eraser_on_a_mask_hides_instead_of_making_transparent_mask()
    {
        TestUtil.Sta(() =>
        {
            var d = Doc();
            var l = d.ActiveLayer;
            l.SetMask(Layer.NewMask(d.Width, d.Height, 255));
            l.EditMask = true;
            var s = new StrokeSession(d, l, StrokeKind.Erase, new BrushSettings { Size = 20, Hardness = 1 }, 0xFFFF0000, new Vector());
            d.Render(s.MoveTo(new Point(50, 50)));
            s.Commit("Eraser");
            uint m = l.Mask[50 * d.Width + 50];
            Assert.Equal(0xFF000000u, m); // opaque black, still a valid mask
        });
    }

    [Fact]
    public void Adjustment_layer_changes_render_without_touching_pixels()
    {
        TestUtil.Sta(() =>
        {
            var d = Doc();
            var blue = d.ActiveLayer;
            var orig = (uint[])blue.Pixels.Clone();
            var adj = new Layer("Invert", d.Width, d.Height) { Adjustment = new AdjustmentSpec { Kind = "invert" } };
            adj.SetMask(Layer.NewMask(d.Width, d.Height, 255));
            d.Layers.Insert(0, adj);
            d.RenderAll();
            uint c = d.Flat[10 * d.Width + 10];
            Assert.Equal(Px.Pack(255, 255 - 0x20, 255 - 0x40, 255 - 0xC0), c);
            Assert.True(blue.Pixels.SequenceEqual(orig));
            // masking the adjustment restores the original look there
            var m = adj.Mask;
            m[10 * d.Width + 10] = Masks.Gray(0);
            d.RenderAll();
            Assert.Equal(0xFF2040C0u, d.Flat[10 * d.Width + 10]);
        });
    }

    [Fact]
    public void Clipping_mask_limits_layer_to_the_shape_below()
    {
        TestUtil.Sta(() =>
        {
            var d = Document.CreateBlank(100, 100, "c", Colors.White);
            var shape = new uint[100 * 100];
            for (int y = 20; y < 40; y++) for (int x = 20; x < 40; x++) shape[y * 100 + x] = 0xFF00FF00;
            var baseL = new Layer("Base", 100, 100, shape);
            var red = new uint[100 * 100];
            Array.Fill(red, 0xFFFF0000);
            var clip = new Layer("Clip", 100, 100, red) { Clipped = true };
            d.Layers.Insert(0, baseL);
            d.Layers.Insert(0, clip);
            d.RenderAll();
            Assert.Equal(0xFFFF0000u, d.Flat[30 * 100 + 30]); // inside base → red
            Assert.Equal(0xFFFFFFFFu, d.Flat[70 * 100 + 70]); // outside base → background
        });
    }

    [Fact]
    public void Hidden_group_hides_its_layers()
    {
        TestUtil.Sta(() =>
        {
            var d = Doc();
            d.ActiveLayer.Group = "G";
            d.Groups["G"] = new GroupInfo("G", false, 1, "pass", true);
            d.RenderAll();
            Assert.Equal(0xFFFFFFFFu, d.Flat[0]);
            d.Groups["G"] = d.Groups["G"] with { Visible = true };
            d.RenderAll();
            Assert.Equal(0xFF2040C0u, d.Flat[0]);
        });
    }

    [Fact]
    public void Moving_a_layer_moves_its_mask()
    {
        TestUtil.Sta(() =>
        {
            var d = Doc();
            var l = d.ActiveLayer;
            var m = Layer.NewMask(d.Width, d.Height, 0);
            m[50 * d.Width + 50] = Masks.Gray(255);
            l.SetMask(m);
            var s = TransformSession.Begin(d, false);
            s.T = new Vector(10, 5);
            s.Commit(d, "Move");
            Assert.Equal(255, Masks.Value(l.Mask[55 * d.Width + 60]));
            Assert.Equal(0, Masks.Value(l.Mask[50 * d.Width + 50]));
        });
    }

    [Fact]
    public void Spot_healing_removes_a_blemish()
    {
        TestUtil.Sta(() =>
        {
            int w = 240, h = 160;
            var d = Document.CreateBlank(w, h, "s", Colors.White);
            var px = new uint[w * h];
            for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) px[y * w + x] = Px.Pack(255, 150 + (x * 7 + y * 3) % 20, 120, 100);
            for (int y = 75; y < 85; y++) for (int x = 115; x < 125; x++) px[y * w + x] = 0xFF000000;
            var l = new Layer("Photo", w, h, px);
            d.Layers.Clear();
            d.Layers.Add(l);
            d.ActiveLayer = l;
            d.RenderAll();
            var s = new StrokeSession(d, l, StrokeKind.SpotHeal, new BrushSettings { Size = 18, Hardness = 0.8 }, 0, new Vector());
            s.MoveTo(new Point(120, 80));
            s.Commit("Spot Healing Brush");
            uint c = l.Pixels[80 * w + 120];
            Assert.InRange(Px.R(c), 130, 185);
            Assert.InRange(Px.G(c), 100, 140);
        });
    }

    [Fact]
    public void Adjustment_specs_are_immutable_snapshots_in_history()
    {
        TestUtil.Sta(() =>
        {
            var d = Doc();
            var adj = new Layer("Levels", d.Width, d.Height) { Adjustment = AdjustmentSpec.Default("levels") };
            d.Layers.Insert(0, adj);
            var before = d.Capture();
            adj.Adjustment = new AdjustmentSpec { Kind = "levels", P = AdjustmentSpec.D(("ib", 50), ("g", 1), ("iw", 200), ("ob", 0), ("ow", 255)) };
            d.Record("Edit Levels", before);
            d.Undo();
            Assert.Equal(0, adj.Adjustment["ib"]);
            d.Redo();
            Assert.Equal(50, adj.Adjustment["ib"]);
        });
    }
}

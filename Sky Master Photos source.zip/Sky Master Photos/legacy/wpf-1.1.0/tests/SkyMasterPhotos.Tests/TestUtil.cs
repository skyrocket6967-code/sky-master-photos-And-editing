using System.Diagnostics;
using System.Text.Json;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.Tests;

public static class TestUtil
{
    /// <summary>Run on an STA thread (WPF text rendering and bitmaps expect it).</summary>
    public static void Sta(Action a)
    {
        Exception err = null;
        var t = new Thread(() => { try { a(); } catch (Exception e) { err = e; } });
        t.SetApartmentState(ApartmentState.STA);
        t.Start();
        t.Join();
        if (err != null) System.Runtime.ExceptionServices.ExceptionDispatchInfo.Capture(err).Throw();
    }

    public static string Root
    {
        get
        {
            var d = new DirectoryInfo(AppContext.BaseDirectory);
            while (d != null && !Directory.Exists(Path.Combine(d.FullName, "tests", "samples"))) d = d.Parent;
            return d?.FullName ?? throw new DirectoryNotFoundException("tests/samples not found");
        }
    }

    public static string SampleDir => Path.Combine(Root, "tests", "samples", "psd-tools");

    public static IEnumerable<object[]> Samples() =>
        Directory.GetFiles(Path.Combine(Root, "tests", "samples", "psd-tools"))
            .Where(f => f.EndsWith(".psd", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".psb", StringComparison.OrdinalIgnoreCase))
            .OrderBy(f => f)
            .Select(f => new object[] { Path.GetFileName(f) });

    static Dictionary<string, JsonElement> _expected;

    /// <summary>Ground truth produced by psd-tools (tests/tools/dump_psd.py).</summary>
    public static JsonElement Expected(string file)
    {
        if (_expected == null)
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(Path.Combine(SampleDir, "expected.json")));
            _expected = doc.RootElement.EnumerateArray().ToDictionary(e => Path.GetFileName(e.GetProperty("file").GetString()), e => e.Clone());
        }
        return _expected[file];
    }

    /// <summary>Python interpreter with psd-tools, from SKY_PSD_PYTHON (null when not configured).</summary>
    public static string Python
    {
        get
        {
            var p = Environment.GetEnvironmentVariable("SKY_PSD_PYTHON");
            return !string.IsNullOrEmpty(p) && File.Exists(p) ? p : null;
        }
    }

    /// <summary>Dump files through psd-tools; returns parsed JSON array.</summary>
    public static JsonElement PsdTools(params string[] files)
    {
        var outJson = Path.Combine(Path.GetTempPath(), $"skypsd_{Guid.NewGuid():N}.json");
        var psi = new ProcessStartInfo(Python) { UseShellExecute = false, RedirectStandardError = true, RedirectStandardOutput = true, CreateNoWindow = true };
        psi.ArgumentList.Add("-I");
        psi.ArgumentList.Add(Path.Combine(Root, "tests", "tools", "dump_psd.py"));
        psi.ArgumentList.Add(outJson);
        foreach (var f in files) psi.ArgumentList.Add(f);
        using var p = Process.Start(psi);
        string err = p.StandardError.ReadToEnd();
        p.WaitForExit(120000);
        if (!File.Exists(outJson)) throw new Exception("psd-tools failed: " + err);
        using var doc = JsonDocument.Parse(File.ReadAllText(outJson));
        File.Delete(outJson);
        return doc.RootElement.Clone();
    }

    public static string BlendName(BlendMode m) => m switch
    {
        BlendMode.Normal => "NORMAL", BlendMode.Darken => "DARKEN", BlendMode.Multiply => "MULTIPLY", BlendMode.ColorBurn => "COLOR_BURN",
        BlendMode.LinearBurn => "LINEAR_BURN", BlendMode.Lighten => "LIGHTEN", BlendMode.Screen => "SCREEN", BlendMode.ColorDodge => "COLOR_DODGE",
        BlendMode.LinearDodge => "LINEAR_DODGE", BlendMode.Overlay => "OVERLAY", BlendMode.SoftLight => "SOFT_LIGHT", BlendMode.HardLight => "HARD_LIGHT",
        BlendMode.VividLight => "VIVID_LIGHT", BlendMode.LinearLight => "LINEAR_LIGHT", BlendMode.PinLight => "PIN_LIGHT", BlendMode.Difference => "DIFFERENCE",
        BlendMode.Exclusion => "EXCLUSION", BlendMode.Subtract => "SUBTRACT", BlendMode.Divide => "DIVIDE", BlendMode.Hue => "HUE",
        BlendMode.Saturation => "SATURATION", BlendMode.Color => "COLOR", BlendMode.Luminosity => "LUMINOSITY", _ => "?"
    };

    /// <summary>psd-tools layer kind → what our model should report.</summary>
    public static string KindOf(Layer l)
    {
        if (l.Adjustment != null) return l.Adjustment.Kind switch
        {
            "brightness" => "brightnesscontrast", "huesat" => "huesaturation", "bw" => "blackandwhite", var k => k
        };
        if (l.Psd?.UnrenderedAdjustment == true) return "unrendered";
        if (l.Text != null) return "type";
        return l.Psd?.KindLabel switch
        {
            "Smart Object" => "smartobject", "Shape" => "shape", "Color Fill" => "solidcolorfill", "Gradient Fill" => "gradientfill", "Pattern Fill" => "patternfill",
            _ => "pixel"
        };
    }

    public static readonly HashSet<string> UnrenderedKinds = new() { "channelmixer", "colorlookup", "selectivecolor" };
}

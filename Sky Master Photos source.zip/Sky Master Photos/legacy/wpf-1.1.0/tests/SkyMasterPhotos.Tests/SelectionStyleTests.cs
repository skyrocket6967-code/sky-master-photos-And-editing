using System.Windows;
using System.Windows.Media;
using SkyMasterPhotos.Core;
using Xunit;

namespace SkyMasterPhotos.Tests;

public class SelectionStyleTests
{
    [Fact]
    public void Psd_export_preserves_styled_appearance_and_original_editability()
    {
        TestUtil.Sta(() =>
        {
            var doc = Document.CreateBlank(32, 32, "styled", Colors.Transparent);
            for (int y = 10; y < 22; y++) for (int x = 10; x < 22; x++) doc.ActiveLayer.Pixels[y * 32 + x] = 0xFFFF0000;
            var style = new LayerStyle { OuterGlow = true, Shadow = true, Bevel = true, Size = 2, Distance = 3 };
            doc.ActiveLayer.Style = style;
            doc.RenderAll();
            var expected = (uint[])doc.Flat.Clone();
            var bytes = SkyMasterPhotos.Core.Psd.PsdWriter.Write(doc);
            var loaded = SkyMasterPhotos.Core.Psd.PsdReader.Read(bytes, "styled.psd").Doc;
            loaded.RenderAll();
            Assert.Equal(expected, loaded.Flat);
            Assert.Equal(style, doc.ActiveLayer.Style);
            Assert.Equal(0u, doc.ActiveLayer.Pixels[9 * 32 + 16]);
        });
    }

    [Fact]
    public void Styles_survive_project_save_undo_and_duplicate()
    {
        TestUtil.Sta(() =>
        {
            var doc = Document.CreateBlank(20, 20, "styles", Colors.Transparent);
            var before = doc.Capture();
            var style = new LayerStyle { Shadow = true, OuterGlow = true, Bevel = true };
            doc.ActiveLayer.Style = style;
            doc.Record("Style", before);
            Assert.Equal(style, doc.ActiveLayer.CloneDeep().Style);
            Assert.True(doc.Undo()); Assert.Null(doc.ActiveLayer.Style);
            Assert.True(doc.Redo()); Assert.Equal(style, doc.ActiveLayer.Style);
            var path = System.IO.Path.Combine(System.IO.Path.GetTempPath(), Guid.NewGuid() + ".skyphoto");
            try
            {
                ImageIO.SaveProject(doc, path);
                var loaded = ImageIO.LoadProject(path);
                Assert.Equal(style, loaded.Layers[0].Style);
            }
            finally { System.IO.File.Delete(path); }
        });
    }

    [Fact]
    public void Smooth_removes_isolated_pixels_without_mutating_source()
    {
        var mask = new byte[49]; mask[24] = 255;
        Assert.All(SelectionOps.Smooth(mask, 7, 7, 1), value => Assert.Equal(0, value));
        Assert.Equal(255, mask[24]);
    }

    [Fact]
    public void Border_keeps_edge_and_excludes_center()
    {
        var mask = SelectionOps.Rect(11, 11, new Int32Rect(3, 3, 5, 5));
        var border = SelectionOps.Border(mask, 11, 11, 1);
        Assert.Equal(0, border[5 * 11 + 5]);
        Assert.Equal(255, border[3 * 11 + 3]);
        Assert.Equal(255, border[2 * 11 + 3]);
    }

    [Fact]
    public void Reselect_restores_mask_and_invalidates_after_resize()
    {
        TestUtil.Sta(() =>
        {
            var doc = Document.CreateBlank(10, 10, "t", Colors.Transparent);
            var mask = SelectionOps.Rect(10, 10, new Int32Rect(2, 2, 3, 3));
            doc.SetSelection(mask); doc.SetSelection(null);
            Assert.True(doc.Reselect()); Assert.Equal(mask, doc.Selection);
            doc.SetSize(20, 20); doc.SetSelection(null);
            Assert.False(doc.Reselect());
        });
    }

    [Fact]
    public void Styles_render_outside_content_without_mutating_source()
    {
        var pixels = new uint[441];
        for (int y = 7; y < 14; y++) for (int x = 7; x < 14; x++) pixels[y * 21 + x] = 0xFFFF0000;
        var style = new LayerStyle { OuterGlow = true, Shadow = true, Bevel = true, Stroke = true, Size = 2 };
        var rendered = style.Render(pixels, null, 21, 21, 1);
        Assert.NotEqual(0u, rendered[6 * 21 + 10]);
        Assert.Equal(0u, pixels[6 * 21 + 10]);
        Assert.Equal(0xFFFF0000u, rendered[10 * 21 + 10]);
    }
}

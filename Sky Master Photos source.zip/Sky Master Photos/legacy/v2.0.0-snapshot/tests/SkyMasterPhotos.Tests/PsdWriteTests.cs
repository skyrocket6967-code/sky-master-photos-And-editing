using System.Text.Json;
using Avalonia;
using Avalonia.Media;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Core.Psd;
using Xunit;
using Xunit.Abstractions;

namespace SkyMasterPhotos.Tests;

public class PsdWriteTests
{
    readonly ITestOutputHelper _out;
    public PsdWriteTests(ITestOutputHelper o) => _out = o;

    public static IEnumerable<object[]> Samples() => TestUtil.Samples();

    static string Temp(string name) => Path.Combine(Path.GetTempPath(), "SkyPsdTests", name);

    /// <summary>Fully transparent pixels carry no visible color; Photoshop trims them away.</summary>
    static uint[] Visible(uint[] p) => p.Select(v => (v >> 24) == 0 ? 0u : v).ToArray();

    static string FirstDiff(uint[] a, uint[] b)
    {
        for (int i = 0; i < a.Length; i++) { uint x = (a[i] >> 24) == 0 ? 0 : a[i], y = (b[i] >> 24) == 0 ? 0 : b[i]; if (x != y) return $"{i}: {a[i]:X8} vs {b[i]:X8}"; }
        return "none";
    }

    static void AssertSameLayers(Document a, Document b, string ctx, bool pixels = true)
    {
        Assert.Equal(a.Width, b.Width);
        Assert.Equal(a.Height, b.Height);
        Assert.True(a.Layers.Count == b.Layers.Count, $"{ctx}: layer count {a.Layers.Count} vs {b.Layers.Count}");
        for (int i = 0; i < a.Layers.Count; i++)
        {
            var x = a.Layers[i];
            var y = b.Layers[i];
            string c = $"{ctx} layer '{x.Name}'";
            Assert.True(x.Name == y.Name, $"{c}: name '{y.Name}'");
            Assert.True(x.Visible == y.Visible, $"{c}: visible");
            Assert.True(Math.Abs(x.Opacity - y.Opacity) < 0.003, $"{c}: opacity");
            Assert.True(Math.Abs(x.Fill - y.Fill) < 0.003, $"{c}: fill");
            Assert.True(x.Blend == y.Blend, $"{c}: blend {x.Blend} vs {y.Blend}");
            Assert.True(x.Clipped == y.Clipped, $"{c}: clipped");
            Assert.True(x.Locked == y.Locked, $"{c}: locked");
            Assert.True(x.Group == y.Group, $"{c}: group '{x.Group}' vs '{y.Group}'");
            Assert.True(x.HasMask == y.HasMask, $"{c}: mask presence");
            if (x.HasMask)
            {
                Assert.True(x.MaskEnabled == y.MaskEnabled, $"{c}: mask enabled");
                Assert.True(x.Mask.SequenceEqual(y.Mask), $"{c}: mask pixels");
            }
            Assert.True((x.Adjustment?.Kind) == (y.Adjustment?.Kind), $"{c}: adjustment kind");
            if (x.Adjustment != null)
            {
                foreach (var (k, v) in x.Adjustment.P)
                    Assert.True(Math.Abs(v - y.Adjustment[k]) <= Math.Max(0.02, Math.Abs(v) * 0.011), $"{c}: adjustment {k} {v} vs {y.Adjustment[k]}");
                if (x.Adjustment.Curve != null) Assert.Equal(x.Adjustment.Curve.Count, y.Adjustment.Curve.Count);
            }
            Assert.True((x.Text?.Text) == (y.Text?.Text), $"{c}: text");
            if (pixels && !x.IsAdjustment) Assert.True(Visible(x.Pixels).SequenceEqual(Visible(y.Pixels)), $"{c}: pixels differ (first at {FirstDiff(x.Pixels, y.Pixels)})");
        }
    }

    [Theory]
    [MemberData(nameof(Samples))]
    public void Round_trip_preserves_layers_masks_and_settings(string file)
    {
        TestUtil.Sta(() =>
        {
            var src = PsdReader.Read(Path.Combine(TestUtil.SampleDir, file)).Doc;
            src.RenderAll();
            var bytes = PsdWriter.Write(src);
            var back = PsdReader.Read(bytes, file).Doc;
            back.RenderAll();
            AssertSameLayers(src, back, file);
            Assert.True(src.Flat.SequenceEqual(back.Flat), $"{file}: rendered result changed after round-trip");
            // unedited Photoshop-only data is written back verbatim
            foreach (var (l, r) in src.Layers.Zip(back.Layers))
            {
                var keys = l.Psd?.Blocks.Select(b => b.Key).ToHashSet() ?? new();
                var rkeys = r.Psd?.Blocks.Select(b => b.Key).ToHashSet() ?? new();
                foreach (var k in new[] { "TySh", "SoLd", "PlLd", "lfx2", "vmsk", "vsms", "SoCo", "mixr", "clrL", "selc", "lyid" })
                    if (keys.Contains(k)) Assert.True(rkeys.Contains(k), $"{file} '{l.Name}': block {k} was not preserved");
            }
        });
    }

    [Theory]
    [MemberData(nameof(Samples))]
    public void Round_trip_output_is_readable_by_psd_tools(string file)
    {
        if (TestUtil.Python == null) { _out.WriteLine("SKY_PSD_PYTHON not set — external validation skipped"); return; }
        string path = Temp("rt_" + Path.ChangeExtension(file, ".psd"));
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        Document src = null;
        TestUtil.Sta(() =>
        {
            src = PsdReader.Read(Path.Combine(TestUtil.SampleDir, file)).Doc;
            src.RenderAll();
            PsdWriter.Save(src, path);
        });
        var dump = TestUtil.PsdTools(path)[0];
        Assert.False(dump.TryGetProperty("error", out var err), $"psd-tools could not read our {file}: {(dump.TryGetProperty("error", out var e2) ? e2.GetString() : "")}");
        var exp = TestUtil.Expected(file);
        Assert.Equal(exp.GetProperty("width").GetInt32(), dump.GetProperty("width").GetInt32());
        Assert.Equal(8, dump.GetProperty("depth").GetInt32());
        var expLeaves = exp.GetProperty("items").EnumerateArray().Where(i => i.TryGetProperty("name", out _)).ToList();
        var gotLeaves = dump.GetProperty("items").EnumerateArray().Where(i => i.TryGetProperty("name", out _)).ToList();
        if (expLeaves.Count == 0) return;
        Assert.Equal(expLeaves.Count, gotLeaves.Count);
        for (int i = 0; i < expLeaves.Count; i++)
        {
            var a = expLeaves[i]; var b = gotLeaves[i];
            string ctx = $"{file} layer {i} '{a.GetProperty("name").GetString()}'";
            Assert.True(a.GetProperty("name").GetString() == b.GetProperty("name").GetString(), $"{ctx}: name");
            Assert.True(a.GetProperty("visible").GetBoolean() == b.GetProperty("visible").GetBoolean(), $"{ctx}: visible");
            Assert.True(Math.Abs(a.GetProperty("opacity").GetInt32() - b.GetProperty("opacity").GetInt32()) <= 1, $"{ctx}: opacity");
            Assert.True(a.GetProperty("clipping").GetBoolean() == b.GetProperty("clipping").GetBoolean(), $"{ctx}: clipping");
            Assert.True(a.GetProperty("has_mask").GetBoolean() == b.GetProperty("has_mask").GetBoolean(), $"{ctx}: mask");
            Assert.True(a.GetProperty("kind").GetString() == b.GetProperty("kind").GetString(), $"{ctx}: kind {b.GetProperty("kind").GetString()} vs {a.GetProperty("kind").GetString()}");
            Assert.True(a.GetProperty("depth").GetInt32() == b.GetProperty("depth").GetInt32(), $"{ctx}: group depth");
            Assert.True(a.GetProperty("blend").GetString() == b.GetProperty("blend").GetString(), $"{ctx}: blend");
            if (a.TryGetProperty("text", out var t)) Assert.True(t.GetString() == b.GetProperty("text").GetString(), $"{ctx}: text");
        }
    }

    /// <summary>A document built in Sky Master Photos using every PSD-relevant feature.</summary>
    static Document NativeDocument()
    {
        int w = 320, h = 200;
        var d = Document.CreateBlank(w, h, "native", Colors.White);
        var grad = new uint[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) grad[y * w + x] = Px.Pack(255, x * 255 / w, y * 255 / h, 128);
        var g = new Layer("Gradient", w, h, grad) { Blend = BlendMode.Multiply, Opacity = 0.8 };
        var mask = Layer.NewMask(w, h, 255);
        for (int y = 0; y < h; y++) for (int x = 0; x < w / 2; x++) mask[y * w + x] = Masks.Gray((byte)(x * 2));
        g.SetMask(mask);
        var dot = new uint[w * h];
        for (int y = 40; y < 160; y++) for (int x = 100; x < 220; x++) dot[y * w + x] = 0xFFFF2040;
        var clipped = new Layer("Clipped red", w, h, dot) { Clipped = true, Fill = 0.6 };
        var hidden = new Layer("Hidden", w, h, (uint[])dot.Clone()) { Visible = false, Locked = true };
        var t = new TextSpec { Text = "Sky Photo", Font = "Segoe UI", Size = 40, Color = Colors.Navy, X = 20, Y = 20 };
        var text = new Layer("Sky Photo", w, h, Tools.Raster.Text(w, h, t.Text, new Point(t.X, t.Y), t.Font, t.Size, false, false, t.Color)) { Text = t, Group = "Group A/Inner" };
        var inGroup = new Layer("In group", w, h, (uint[])dot.Clone()) { Group = "Group A", Blend = BlendMode.Screen };
        d.Groups["Group A"] = new GroupInfo("Group A", true, 0.8, "pass", true);
        d.Groups["Group A/Inner"] = new GroupInfo("Inner", true, 1, "pass", false);
        // top first
        var adj = new List<Layer>();
        var specs = new[]
        {
            new AdjustmentSpec { Kind = "brightness", P = AdjustmentSpec.D(("b", 20), ("c", 15)) },
            new AdjustmentSpec { Kind = "levels", P = AdjustmentSpec.D(("ib", 10), ("g", 1.2), ("iw", 240), ("ob", 5), ("ow", 250)) },
            new AdjustmentSpec { Kind = "curves", Curve = new List<Point> { new(0, 0), new(70, 50), new(190, 210), new(255, 255) } },
            new AdjustmentSpec { Kind = "exposure", P = AdjustmentSpec.D(("e", 0.5), ("o", 0.015625), ("g", 1.125)) },
            new AdjustmentSpec { Kind = "vibrance", P = AdjustmentSpec.D(("v", 30), ("s", -10)) },
            new AdjustmentSpec { Kind = "huesat", P = AdjustmentSpec.D(("h", 25), ("s", 10), ("l", -5), ("c", 0)) },
            new AdjustmentSpec { Kind = "colorbalance", P = AdjustmentSpec.D(("r", 20), ("g", -10), ("b", 5), ("p", 1)) },
            new AdjustmentSpec { Kind = "bw", P = AdjustmentSpec.D(("r", 40), ("y", 60), ("g", 40), ("c", 60), ("b", 20), ("m", 80)) },
            new AdjustmentSpec { Kind = "photofilter", P = AdjustmentSpec.D(("d", 30), ("l", 1)), C1 = Color.FromRgb(236, 138, 0) },
            new AdjustmentSpec { Kind = "invert" },
            new AdjustmentSpec { Kind = "posterize", P = AdjustmentSpec.D(("l", 6)) },
            new AdjustmentSpec { Kind = "threshold", P = AdjustmentSpec.D(("t", 128)) },
            new AdjustmentSpec { Kind = "gradientmap", C1 = Colors.DarkBlue, C2 = Colors.Gold },
        };
        foreach (var s in specs)
        {
            var l = new Layer(s.Title, w, h) { Adjustment = s, Visible = s.Kind is "brightness" or "levels" or "curves" };
            l.SetMask(Layer.NewMask(w, h, 255));
            adj.Add(l);
        }
        var bg = d.Layers[0];
        d.Layers.Clear();
        foreach (var l in adj) d.Layers.Add(l);
        d.Layers.Add(text);
        d.Layers.Add(inGroup);
        d.Layers.Add(hidden);
        d.Layers.Add(clipped);
        d.Layers.Add(g);
        d.Layers.Add(bg);
        d.ActiveLayer = g;
        d.RenderAll();
        return d;
    }

    [Fact]
    public void Native_document_exports_every_feature_as_layered_psd()
    {
        TestUtil.Sta(() =>
        {
            var d = NativeDocument();
            var bytes = PsdWriter.Write(d);
            var res = PsdReader.Read(bytes, "native.psd");
            var back = res.Doc;
            back.RenderAll();
            Assert.Empty(res.Warnings);
            // text created in Sky Master Photos is exported as a raster layer (no Photoshop text engine data)
            foreach (var l in d.Layers) if (l.Text != null) l.Text = null;
            AssertSameLayers(d, back, "native");
            Assert.True(d.Flat.SequenceEqual(back.Flat), "render changed after export");
            Assert.True(bytes.Length > 10_000);
        });
    }

    [Fact]
    public void Native_document_is_readable_by_psd_tools_with_real_adjustment_layers()
    {
        if (TestUtil.Python == null) { _out.WriteLine("SKY_PSD_PYTHON not set — external validation skipped"); return; }
        string path = Temp("native.psd");
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        TestUtil.Sta(() => PsdWriter.Save(NativeDocument(), path));
        var dump = TestUtil.PsdTools(path)[0];
        Assert.False(dump.TryGetProperty("error", out _), "psd-tools failed: " + dump.ToString());
        var items = dump.GetProperty("items").EnumerateArray().ToList();
        var kinds = items.Where(i => i.TryGetProperty("kind", out _)).Select(i => i.GetProperty("kind").GetString()).ToList();
        _out.WriteLine(string.Join(", ", kinds));
        foreach (var k in new[] { "brightnesscontrast", "levels", "curves", "exposure", "vibrance", "huesaturation", "colorbalance", "blackandwhite", "photofilter", "invert", "posterize", "threshold", "gradientmap" })
            Assert.Contains(k, kinds);
        var groups = items.Where(i => i.TryGetProperty("group_start", out _)).Select(i => i.GetProperty("group_start").GetString()).ToList();
        Assert.Equal(new[] { "Group A", "Inner" }, groups);
        var gradient = items.First(i => i.TryGetProperty("name", out var n) && n.GetString() == "Gradient");
        Assert.True(gradient.GetProperty("has_mask").GetBoolean());
        Assert.Equal("MULTIPLY", gradient.GetProperty("blend").GetString());
        var clipped = items.First(i => i.TryGetProperty("name", out var n) && n.GetString() == "Clipped red");
        Assert.True(clipped.GetProperty("clipping").GetBoolean());
        var hidden = items.First(i => i.TryGetProperty("name", out var n) && n.GetString() == "Hidden");
        Assert.False(hidden.GetProperty("visible").GetBoolean());
    }

    [Fact]
    public void Edited_adjustment_is_re_encoded()
    {
        TestUtil.Sta(() =>
        {
            var d = PsdReader.Read(Path.Combine(TestUtil.SampleDir, "fill_adjustments.psd")).Doc;
            var lv = d.Layers.First(l => l.Adjustment?.Kind == "levels");
            lv.Adjustment = new AdjustmentSpec { Kind = "levels", P = AdjustmentSpec.D(("ib", 30), ("g", 1.5), ("iw", 220), ("ob", 0), ("ow", 255)) };
            var back = PsdReader.Read(PsdWriter.Write(d), "x.psd").Doc;
            var lv2 = back.Layers.First(l => l.Name == lv.Name);
            Assert.Equal(30, lv2.Adjustment["ib"]);
            Assert.Equal(220, lv2.Adjustment["iw"]);
            Assert.Equal(1.5, lv2.Adjustment["g"], 2);
        });
    }

    [Fact]
    public void Edited_text_layer_keeps_pixels_and_drops_stale_text_engine_data()
    {
        TestUtil.Sta(() =>
        {
            var d = PsdReader.Read(Path.Combine(TestUtil.SampleDir, "text.psd")).Doc;
            var tl = d.Layers.First(l => l.Text != null);
            var unchanged = PsdReader.Read(PsdWriter.Write(d), "x.psd").Doc.Layers.First(l => l.Name == tl.Name);
            Assert.Contains(unchanged.Psd.Blocks, b => b.Key == "TySh");   // untouched → still editable in Photoshop
            var px = (uint[])tl.Pixels.Clone();
            px[0] = 0xFF00FF00;
            tl.SetPixels(px, d.Width, d.Height);
            var edited = PsdReader.Read(PsdWriter.Write(d), "y.psd").Doc.Layers.First(l => l.Name == tl.Name);
            Assert.DoesNotContain(edited.Psd.Blocks, b => b.Key == "TySh"); // edited → exported as pixels
            Assert.Equal(0xFF00FF00u, edited.Pixels[0]);
        });
    }

    [Fact]
    public void Png_export_and_import_still_work()
    {
        TestUtil.Sta(() =>
        {
            var d = NativeDocument();
            string path = Temp("check.png");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            ImageIO.SaveImage(path, d.Flat, d.Width, d.Height);
            var (px, w, h) = ImageIO.LoadPixels(path);
            Assert.Equal(d.Width, w);
            Assert.Equal(d.Height, h);
            Assert.True(px.SequenceEqual(d.Flat));
        });
    }

    [Fact]
    public void Project_format_keeps_masks_adjustments_text_and_groups()
    {
        TestUtil.Sta(() =>
        {
            var d = NativeDocument();
            string path = Temp("check.skyphoto");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            ImageIO.SaveProject(d, path);
            var back = ImageIO.LoadProject(path);
            back.RenderAll();
            AssertSameLayers(d, back, "project");
            Assert.Equal(d.Groups.Count, back.Groups.Count);
            Assert.True(d.Flat.SequenceEqual(back.Flat));
        });
    }

    [Fact]
    public void Psd_project_round_trips_through_skyphoto_and_back_to_psd()
    {
        TestUtil.Sta(() =>
        {
            var d = PsdReader.Read(Path.Combine(TestUtil.SampleDir, "text.psd")).Doc;
            string path = Temp("from_psd.skyphoto");
            Directory.CreateDirectory(Path.GetDirectoryName(path));
            ImageIO.SaveProject(d, path);
            var back = ImageIO.LoadProject(path);
            var psd = PsdReader.Read(PsdWriter.Write(back), "z.psd").Doc;
            Assert.Contains(psd.Layers, l => l.Psd?.Blocks.Any(b => b.Key == "TySh") == true);
        });
    }
}

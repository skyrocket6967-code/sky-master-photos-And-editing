using System.Text.Json;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.Core.Psd;
using Xunit;
using Xunit.Abstractions;

namespace SkyMasterPhotos.Tests;

/// <summary>Reads real Photoshop files and compares against psd-tools (independent implementation).</summary>
public class PsdReadTests
{
    readonly ITestOutputHelper _out;
    public PsdReadTests(ITestOutputHelper o) => _out = o;

    public static IEnumerable<object[]> Samples() => TestUtil.Samples();

    record Leaf(string Name, string Kind, bool Visible, int Opacity, string Blend, bool Clipping, bool HasMask, string Group, string Text);

    static List<Leaf> ExpectedLeaves(JsonElement e)
    {
        var list = new List<Leaf>();
        var stack = new List<string>();
        foreach (var it in e.GetProperty("items").EnumerateArray())
        {
            if (it.TryGetProperty("group_start", out var gs)) { stack.Add(gs.GetString()); continue; }
            if (it.TryGetProperty("group_end", out _)) { stack.RemoveAt(stack.Count - 1); continue; }
            list.Add(new Leaf(
                it.GetProperty("name").GetString(), it.GetProperty("kind").GetString(), it.GetProperty("visible").GetBoolean(),
                it.GetProperty("opacity").GetInt32(), it.GetProperty("blend").GetString(), it.GetProperty("clipping").GetBoolean(),
                it.GetProperty("has_mask").GetBoolean(), string.Join("/", stack),
                it.TryGetProperty("text", out var t) ? t.GetString() : null));
        }
        return list;
    }

    static string Norm(string s) => (s ?? "").Replace("\r\n", "\n").Replace("\r", "\n").Trim();

    [Theory]
    [MemberData(nameof(Samples))]
    public void Reads_real_photoshop_file(string file)
    {
        TestUtil.Sta(() =>
        {
            var res = PsdReader.Read(Path.Combine(TestUtil.SampleDir, file));
            var exp = TestUtil.Expected(file);
            Assert.Equal(exp.GetProperty("width").GetInt32(), res.Doc.Width);
            Assert.Equal(exp.GetProperty("height").GetInt32(), res.Doc.Height);
            Assert.Equal(exp.GetProperty("depth").GetInt32(), res.Depth);
            Assert.True(res.Doc.Layers.Count >= 1);
            res.Doc.RenderAll();
            foreach (var w in res.Warnings) _out.WriteLine("warning: " + w);
        });
    }

    [Theory]
    [MemberData(nameof(Samples))]
    public void Layer_structure_matches_psd_tools(string file)
    {
        TestUtil.Sta(() =>
        {
            var res = PsdReader.Read(Path.Combine(TestUtil.SampleDir, file));
            var exp = ExpectedLeaves(TestUtil.Expected(file));
            if (exp.Count == 0) { Assert.Single(res.Doc.Layers); return; } // flattened file → one Background layer from the merged image
            var ours = res.Doc.Layers.Reverse().ToList(); // bottom → top like the file
            Assert.Equal(exp.Count, ours.Count);
            for (int i = 0; i < exp.Count; i++)
            {
                var e = exp[i];
                var l = ours[i];
                string ctx = $"{file} layer {i} '{e.Name}'";
                Assert.True(e.Name == l.Name, $"{ctx}: name '{l.Name}'");
                Assert.True(e.Visible == l.Visible, $"{ctx}: visible");
                Assert.True(Math.Abs(e.Opacity - (int)Math.Round(l.Opacity * 255)) <= 1, $"{ctx}: opacity {l.Opacity}");
                Assert.True(e.Clipping == l.Clipped, $"{ctx}: clipping");
                Assert.True(e.HasMask == l.HasMask, $"{ctx}: mask");
                if (e.Blend is not ("DISSOLVE" or "DARKER_COLOR" or "LIGHTER_COLOR" or "HARD_MIX" or "PASS_THROUGH"))
                    Assert.True(e.Blend == TestUtil.BlendName(l.Blend), $"{ctx}: blend {l.Blend} vs {e.Blend}");
                string kind = TestUtil.KindOf(l);
                string ek = TestUtil.UnrenderedKinds.Contains(e.Kind) ? "unrendered" : e.Kind;
                Assert.True(ek == kind, $"{ctx}: kind {kind} vs {e.Kind}");
                Assert.True(e.Group == System.Text.RegularExpressions.Regex.Replace(l.Group, @" \(\d+\)", ""), $"{ctx}: group '{l.Group}' vs '{e.Group}'");
                if (e.Text != null) Assert.True(Norm(e.Text).Replace("\n", "") == Norm(l.Text?.Text).Replace("\n", ""), $"{ctx}: text '{l.Text?.Text}'");
            }
        });
    }

    /// <summary>Our renderer vs. Photoshop's own merged image stored in the file.</summary>
    [Theory]
    [MemberData(nameof(Samples))]
    public void Composite_matches_photoshop_where_features_are_supported(string file)
    {
        TestUtil.Sta(() =>
        {
            var res = PsdReader.Read(Path.Combine(TestUtil.SampleDir, file));
            if (res.Composite == null) return;
            var d = res.Doc;
            d.RenderAll();
            bool unsupported = d.Layers.Any(l => (l.Visible && (l.HasEffects || l.Psd?.UnrenderedAdjustment == true || l.Psd?.KindLabel is "Shape" or "Gradient Fill" or "Pattern Fill" || l.Psd?.Blocks.Any(b => b.Key is "vmsk" or "vsms") == true)))
                || res.ColorMode != PsdFormat.ModeRgb || res.Depth != 8
                || d.Layers.Any(l => l.Visible && (l.Adjustment?.Kind is "levels" or "curves" or "huesat" or "colorbalance" or "bw" or "photofilter" or "vibrance" or "exposure" or "gradientmap"))
                || d.Groups.Values.Any(g => g.BlendKey != "pass" && g.BlendKey != "norm");
            double sum = 0; int max = 0; long n = 0;
            for (int i = 0; i < d.Flat.Length; i++)
            {
                uint a = d.Flat[i], b = res.Composite[i];
                if ((b >> 24) < 250 && (a >> 24) < 250) continue; // compare opaque regions
                for (int s = 0; s < 24; s += 8)
                {
                    int diff = Math.Abs((int)((a >> s) & 255) - (int)((b >> s) & 255));
                    sum += diff; n++; if (diff > max) max = diff;
                }
            }
            double mean = n == 0 ? 0 : sum / n;
            _out.WriteLine($"{file}: mean diff {mean:0.00}, max {max}, {(unsupported ? "contains unsupported/approximate features" : "fully supported")}");
            if (!unsupported) Assert.True(mean < 2.0, $"{file}: composite differs from Photoshop (mean {mean:0.00})");
        });
    }
}

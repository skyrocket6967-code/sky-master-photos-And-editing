"""Dump PSD structure as JSON using psd-tools (an independent reference implementation).

Used to (1) generate ground-truth expectations for the real sample files and
(2) independently validate PSDs written by Sky Master Photos.

usage: python dump_psd.py <out.json> <file.psd> [more files...]
"""
import json
import sys

from psd_tools import PSDImage


def leaf_info(layer, depth):
    info = {
        "name": layer.name,
        "kind": layer.kind,
        "visible": bool(layer.visible),
        "opacity": int(layer.opacity),
        "blend": str(layer.blend_mode).split(".")[-1],
        "clipping": bool(getattr(layer, "clipping", False)),
        "has_mask": bool(layer.has_mask()),
        "depth": depth,
        "bbox": list(layer.bbox),
    }
    if layer.kind == "type":
        try:
            info["text"] = layer.text
        except Exception:
            pass
    return info


def walk(group, depth, out):
    for layer in group:  # bottom -> top
        if layer.is_group():
            out.append({"group_start": layer.name, "visible": bool(layer.visible), "opacity": int(layer.opacity),
                        "blend": str(layer.blend_mode).split(".")[-1], "depth": depth})
            walk(layer, depth + 1, out)
            out.append({"group_end": layer.name, "depth": depth})
        else:
            out.append(leaf_info(layer, depth))


def dump(path):
    psd = PSDImage.open(path)
    items = []
    walk(psd, 0, items)
    return {
        "file": path,
        "width": psd.width,
        "height": psd.height,
        "depth": psd.depth,
        "color_mode": getattr(psd.color_mode, "name", str(psd.color_mode)),
        "version": psd.version,
        "items": items,
    }


if __name__ == "__main__":
    result = []
    for p in sys.argv[2:]:
        try:
            result.append(dump(p))
        except Exception as e:  # report, don't crash the batch
            result.append({"file": p, "error": f"{type(e).__name__}: {e}"})
    with open(sys.argv[1], "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=1)

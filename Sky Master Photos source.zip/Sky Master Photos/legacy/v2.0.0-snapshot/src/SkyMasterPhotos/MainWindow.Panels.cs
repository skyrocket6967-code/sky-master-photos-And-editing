using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Controls.Shapes;
using Avalonia.Threading;
using SkyMasterPhotos.Core;
using Transforms = SkyMasterPhotos.Core.Transforms;
using SkyMasterPhotos.Tools;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos;

public partial class MainWindow
{
    readonly Dictionary<ToolGroup, ToggleButton> _toolButtons = new();
    Border _fgSwatch, _bgSwatch;
    Button _blendButton;
    bool _layerSync, _historySync, _opSync, _navSync;
    DocState _opBefore;
    readonly DispatcherTimer _opCommit = new() { Interval = TimeSpan.FromMilliseconds(450) };
    Point _layerDragStart;
    Layer _layerDragItem;

    static readonly string[] SwatchHex = { "000000", "FFFFFF", "FF4D5E", "FF9F43", "FFD93D", "2ED47A", "38BDF8", "5B8CFF", "A46BFF", "FF6BD6" };

    // ───────────────────────────── toolbar ─────────────────────────────

    void BuildToolbar()
    {
        ToolStack.Children.Clear();
        string[] breaks = { "wand", "eyedropper", "fill", "dodge", "shape" };
        foreach (var g in ToolInfo.Groups)
        {
            var group = g;
            var icon = new Ico(ToolInfo.Icon(g.Current), 19);
            var b = new ToggleButton { Style = UIx.R<Style>("ToolBtn"), Content = icon, Tag = g.Tools.Length > 1 ? "more" : null };
            UpdateToolTip(b, g);
            b.Click += (_, _) => { Ctl.Tool = group.Current; b.IsChecked = Ctl.Tool == group.Current; };
            if (g.Tools.Length > 1)
            {
                var hold = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(380) };
                hold.Tick += (_, _) => { hold.Stop(); ShowToolFlyout(group, b); };
                b.OnLeftDown(_ => hold.Start(), true);
                b.OnLeftUp(_ => hold.Stop(), true);
                b.PointerExited += (_, _) => hold.Stop();
                b.OnRightUp(e => { ShowToolFlyout(group, b); e.Handled = true; }, true);
            }
            _toolButtons[g] = b;
            ToolStack.Children.Add(b);
            if (breaks.Contains(g.Id)) ToolStack.Children.Add(new Border { Height = 1, Width = 26, Background = UIx.R<Brush>("Line2"), Margin = new Thickness(0, 6, 0, 6) });
        }
    }

    static void UpdateToolTip(ToggleButton b, ToolGroup g)
    {
        var sp = new StackPanel();
        var row = new StackPanel { Orientation = Orientation.Horizontal };
        row.Children.Add(new TextBlock { Text = ToolInfo.Name(g.Current), FontWeight = FontWeights.SemiBold });
        row.Children.Add(new Border { Background = UIx.R<Brush>("Bg4"), CornerRadius = new CornerRadius(4), Padding = new Thickness(5, 0, 5, 0), Margin = new Thickness(8, 0, 0, 0), Child = new TextBlock { Text = g.Key.ToString(), FontSize = 11 } });
        sp.Children.Add(row);
        sp.Children.Add(new TextBlock { Text = ToolInfo.Hint(g.Current), Foreground = UIx.R<Brush>("Text3"), FontSize = 11.5, Margin = new Thickness(0, 3, 0, 0), MaxWidth = 260, TextWrapping = TextWrapping.Wrap });
        if (g.Tools.Length > 1) sp.Children.Add(new TextBlock { Text = "Hold or right-click for more", Foreground = UIx.R<Brush>("Text3"), FontSize = 11, Margin = new Thickness(0, 3, 0, 0), FontStyle = FontStyles.Italic });
        b.ToolTip = sp;
        ToolTip.SetPlacement(b, PlacementMode.Right);
        ToolTip.SetShowDelay(b, 450);
    }

    void ShowToolFlyout(ToolGroup g, ToggleButton b)
    {
        var m = new ContextMenu { PlacementTarget = b, Placement = PlacementMode.Right };
        foreach (var t in g.Tools)
        {
            var tool = t;
            m.Items.Add(UIx.Item(ToolInfo.Name(t), () => { g.Current = tool; Ctl.Tool = tool; }, g.Key.ToString(), ToolInfo.Icon(t), Ctl.Tool == t));
        }
        m.Show();
    }

    void OnToolChanged()
    {
        var tool = Ctl.Tool;
        var g = ToolInfo.GroupOf(tool);
        g.Current = tool;
        foreach (var (grp, b) in _toolButtons)
        {
            b.IsChecked = grp == g;
            if (b.Content is Ico ico) ico.Kind = ToolInfo.Icon(grp.Current);
            UpdateToolTip(b, grp);
        }
        OptToolIcon.Kind = ToolInfo.Icon(tool);
        OptToolName.Text = ToolInfo.Name(tool);
        StatusHint.Text = ToolInfo.Hint(tool);
        BuildOptions();
    }

    // ───────────────────────────── colors ─────────────────────────────

    void BuildColorWell()
    {
        var g = new Grid { Width = 46, Height = 46 };
        _bgSwatch = new Border { Width = 28, Height = 28, CornerRadius = new CornerRadius(8), BorderBrush = UIx.R<Brush>("Line2"), BorderThickness = new Thickness(2), HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Bottom, Cursor = Cursors.Hand, ToolTip = "Background color" };
        _fgSwatch = new Border { Width = 28, Height = 28, CornerRadius = new CornerRadius(8), BorderBrush = Brushes.White, BorderThickness = new Thickness(2), HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top, Cursor = Cursors.Hand, ToolTip = "Foreground color", BoxShadow = BoxShadows.Parse("0 2 10 0 #59000000") };
        _fgSwatch.OnLeftDown(_ => { _editingBg = false; Picker.SetColor(_fg); UpdateColorWell(); });
        _bgSwatch.OnLeftDown(_ => { _editingBg = true; Picker.SetColor(_bg); UpdateColorWell(); });
        g.Children.Add(_bgSwatch);
        g.Children.Add(_fgSwatch);
        ColorWell.Children.Add(g);
        var row = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 6, 0, 0) };
        var swap = new Button { Style = UIx.R<Style>("IconBtn"), Width = 22, Height = 22, Content = new Ico("swap", 13), ToolTip = "Swap colors (X)" };
        swap.Click += (_, _) => { var t = _fg; SetFg(_bg); SetBg(t); Picker.SetColor(_editingBg ? _bg : _fg); };
        var reset = new Button { Style = UIx.R<Style>("IconBtn"), Width = 22, Height = 22, ToolTip = "Default colors (D)" };
        var mini = new Grid { Width = 12, Height = 12 };
        mini.Children.Add(new Rectangle { Width = 8, Height = 8, Fill = Brushes.White, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Bottom });
        mini.Children.Add(new Rectangle { Width = 8, Height = 8, Fill = Brushes.Black, Stroke = Brushes.White, StrokeThickness = 1, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top });
        reset.Content = mini;
        reset.Click += (_, _) => { SetFg(Colors.Black); SetBg(Colors.White); Picker.SetColor(_editingBg ? _bg : _fg); };
        row.Children.Add(reset);
        row.Children.Add(swap);
        ColorWell.Children.Add(row);
        UpdateColorWell();
    }

    void UpdateColorWell()
    {
        if (_fgSwatch == null) return;
        _fgSwatch.Background = new SolidColorBrush(_fg);
        _bgSwatch.Background = new SolidColorBrush(_bg);
        _fgSwatch.BorderBrush = !_editingBg ? Brushes.White : UIx.R<Brush>("Line2");
        _bgSwatch.BorderBrush = _editingBg ? Brushes.White : UIx.R<Brush>("Line2");
        _fgSwatch.ZIndex = _editingBg ? 0 : 1;
        _bgSwatch.ZIndex = _editingBg ? 1 : 0;
    }

    // ───────────────────────────── panels ─────────────────────────────

    void BuildPanels()
    {
        // swatches
        foreach (var hex in SwatchHex)
        {
            Px.TryParseHex(hex, out var c);
            var e = new Border { Width = 14, Height = 14, CornerRadius = new CornerRadius(7), Background = new SolidColorBrush(c), Margin = new Thickness(3, 0, 0, 0), Cursor = Cursors.Hand, BorderBrush = UIx.R<Brush>("Line2"), BorderThickness = new Thickness(1), ToolTip = $"#{hex} — click: foreground · right-click: background" };
            e.OnLeftDown(_ => { SetFg(c); if (!_editingBg) Picker.SetColor(c); });
            e.OnRightDown(_ => { SetBg(c); if (_editingBg) Picker.SetColor(c); });
            SwatchRow.Children.Add(e);
        }

        // top tabs
        BuildTabStrip(TopTabs, new[] { ("navigator", "Navigator"), ("sliders", "Adjust"), ("levels", "Histogram") }, i =>
        {
            NavigatorPane.Visibility = i == 0 ? Visibility.Visible : Visibility.Collapsed;
            AdjustPane.Visibility = i == 1 ? Visibility.Visible : Visibility.Collapsed;
            HistoPane.Visibility = i == 2 ? Visibility.Visible : Visibility.Collapsed;
            if (i == 2) Histo.Update(_active?.Flat);
        });
        BuildTabStrip(BottomTabs, new[] { ("layers", "Layers"), ("history", "History") }, i =>
        {
            LayersPane.Visibility = i == 0 ? Visibility.Visible : Visibility.Collapsed;
            HistoryList.Visibility = i == 1 ? Visibility.Visible : Visibility.Collapsed;
            SyncHistorySelection();
        });

        // adjustments grid
        // adjustment layers (non-destructive) + a few one-shot pixel edits
        var adj = new (string icon, string name, Action act)[]
        {
            ("brightness", "Brightness", () => NewAdjustmentLayer("brightness")), ("levels", "Levels", () => NewAdjustmentLayer("levels")), ("curves", "Curves", () => NewAdjustmentLayer("curves")),
            ("exposure", "Exposure", () => NewAdjustmentLayer("exposure")), ("vibrance", "Vibrance", () => NewAdjustmentLayer("vibrance")), ("huesat", "Hue / Sat", () => NewAdjustmentLayer("huesat")),
            ("colorbalance", "Color Bal.", () => NewAdjustmentLayer("colorbalance")), ("bw", "B & W", () => NewAdjustmentLayer("bw")), ("photofilter", "Photo Filter", () => NewAdjustmentLayer("photofilter")),
            ("invert", "Invert", () => NewAdjustmentLayer("invert")), ("posterize", "Posterize", () => NewAdjustmentLayer("posterize")), ("threshold", "Threshold", () => NewAdjustmentLayer("threshold")),
            ("gradientmap", "Gradient Map", () => NewAdjustmentLayer("gradientmap")), ("temp", "Temp / Tint", AdjTemperature), ("shadows", "Shadows", AdjShadows),
            ("sepia", "Sepia", AdjSepia), ("sparkle", "Auto", AutoEnhance), ("cutout", "Remove BG", RemoveBackground),
        };        foreach (var (icon, name, act) in adj)
        {
            var sp = new StackPanel();
            sp.Children.Add(new Ico(icon, 20) { HorizontalAlignment = HorizontalAlignment.Center });
            sp.Children.Add(new TextBlock { Text = name, FontSize = 10.5, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 5, 0, 0), TextTrimming = TextTrimming.CharacterEllipsis });
            bool isLayer = Array.IndexOf(new[] { "temp", "shadows", "sepia", "sparkle", "cutout" }, icon) < 0;
            var b = new Button { Content = sp, Style = UIx.R<Style>("Ghost"), Padding = new Thickness(2, 8, 2, 6), Margin = new Thickness(1), ToolTip = isLayer ? $"New {name} adjustment layer (non-destructive)" : $"{name} — applies to the current layer" };
            var a = act;
            b.Click += (_, _) => a();
            AdjustWrap.Children.Add(b);
        }

        // navigator
        bool navDrag = false;
        NavBox.OnLeftDown(e => { navDrag = true; e.Pointer.Capture(NavBox); NavJump(e.GetPosition(NavBox)); });
        NavBox.PointerMoved += (_, e) => { if (navDrag) NavJump(e.GetPosition(NavBox)); };
        NavBox.PointerReleased += (_, e) => { navDrag = false; e.Pointer.Capture(null); };
        NavBox.PointerCaptureLost += (_, _) => navDrag = false;
        NavBox.SizeChanged += (_, _) => UpdateNavRect();
        NavSlider.ValueChanged += (_, e) =>
        {
            if (_navSync || _active == null) return;
            Canvas.ZoomAt(new Point(Canvas.ActualWidth / 2, Canvas.ActualHeight / 2), 0.01 * Math.Pow(6400, e.NewValue));
        };

        // blend + opacity
        _blendButton = UIx.DropButton("Normal", BuildBlendMenu, 130);
        _blendButton.Height = 30;
        BlendHost.Content = _blendButton;
        _opCommit.Tick += (_, _) =>
        {
            _opCommit.Stop();
            if (_opBefore != null && _active != null) { _active.Record("Layer Opacity", _opBefore, "◔"); _opBefore = null; }
        };
        OpacitySlider.ValueChanged += (_, e) =>
        {
            OpacityText.Text = $"{(int)e.NewValue}%";
            if (_opSync || _active?.ActiveLayer == null) return;
            _opBefore ??= _active.Capture();
            _active.ActiveLayer.Opacity = e.NewValue / 100.0;
            _active.RenderAll();
            _opCommit.Stop();
            _opCommit.Start();
        };

        // layer list
        LayerList.SelectionChanged += (_, _) =>
        {
            if (_layerSync || _active == null) return;
            if (LayerList.SelectedItem is Layer l && l != _active.ActiveLayer) { _active.ActiveLayer = l; }
        };
        LayerList.DoubleTapped += (_, e) =>
        {
            if (ItemUnder(e.Source) is not Layer l) return;
            if (l.IsAdjustment) EditAdjustmentLayer(l);
            else if (l.IsText) Ctl.EditTextLayer(l);
            else RenameLayer(l);
        };
        LayerList.OnLeftDown(e =>
        {
            _layerDragStart = e.GetPosition(LayerList);
            _layerDragItem = ItemUnder(e.Source);
            if ((Keyboard.From(e.KeyModifiers) & ModifierKeys.Control) != 0 && _layerDragItem != null && IsInThumb(e.Source))
            {
                SelectLayerPixels(_layerDragItem);
                e.Handled = true;
            }
        }, true);
        LayerList.AddHandler(PointerMovedEvent, (_, e) =>
        {
            if (!e.GetCurrentPoint(LayerList).Properties.IsLeftButtonPressed || _layerDragItem == null) return;
            var p = e.GetPosition(LayerList);
            if (Math.Abs(p.Y - _layerDragStart.Y) > 6 && !PointerHooks.HasAncestor<Button>(e.Source))
            {
                var item = _layerDragItem;
                _layerDragItem = null;
                var data = new DataObject();
                data.Set(LayerDragFormat, item);
                _ = DragDrop.DoDragDrop(e, data, DragDropEffects.Move);
            }
        }, Avalonia.Interactivity.RoutingStrategies.Tunnel);
        LayerList.AddHandler(PointerReleasedEvent, (_, _) => _layerDragItem = null, Avalonia.Interactivity.RoutingStrategies.Tunnel);
        DragDrop.SetAllowDrop(LayerList, true);
        LayerList.AddHandler(DragDrop.DragOverEvent, (_, e) => { e.DragEffects = e.Data.Contains(LayerDragFormat) ? DragDropEffects.Move : DragDropEffects.None; e.Handled = true; });
        LayerList.AddHandler(DragDrop.DropEvent, (_, e) =>
        {
            if (!e.Data.Contains(LayerDragFormat)) return;
            e.Handled = true;
            if (_active == null || e.Data.Get(LayerDragFormat) is not Layer src) return;
            var target = ItemUnder(e.Source);
            int from = _active.Layers.IndexOf(src);
            int to = target == null ? _active.Layers.Count - 1 : _active.Layers.IndexOf(target);
            if (from < 0 || to < 0 || from == to) return;
            var before = _active.Capture();
            _active.Layers.Move(from, to);
            _active.RenderAll();
            _active.Record("Reorder Layers", before, "⇅");
            SyncLayerSelection();
        });
        LayerList.ContextRequested += (_, e) =>
        {
            e.Handled = true;
            var l = ItemUnder(e.Source);
            if (l == null || _active == null) return;
            _active.ActiveLayer = l;
            BuildLayerMenu(l).Open(LayerList);
        };

        // layer buttons
        void LB(string icon, string tip, Action a)
        {
            var b = new Button { Style = UIx.R<Style>("IconBtn"), Width = 30, Height = 28, Content = new Ico(icon, 15), ToolTip = tip, Margin = new Thickness(2, 0, 0, 0) };
            b.Click += (_, _) => a();
            LayerButtons.Children.Add(b);
        }
        {
            var ab = new Button { Style = UIx.R<Style>("IconBtn"), Width = 30, Height = 28, Content = new Ico("adjlayer", 15), ToolTip = "New adjustment layer", Margin = new Thickness(2, 0, 0, 0) };
            ab.Click += (_, _) => { var m = AdjustmentLayerMenu(); m.PlacementTarget = ab; m.Placement = PlacementMode.Top; m.Show(); };
            LayerButtons.Children.Add(ab);
        }
        LB("mask", "Add layer mask (from selection if there is one)", () => AddMask(_active?.HasSelection == true ? 2 : 0));
        LB("up", "Move layer up", () => MoveLayer(-1));
        LB("down", "Move layer down", () => MoveLayer(1));
        LB("merge", "Merge down (Ctrl+E)", MergeDown);
        LB("duplicate", "Duplicate layer (Ctrl+J)", DuplicateLayer);
        LB("plus", "New layer (Ctrl+Shift+N)", NewLayer);
        LB("trash", "Delete layer", DeleteLayer);

        // history
        HistoryList.SelectionChanged += (_, _) =>
        {
            if (_historySync || _active == null || HistoryList.SelectedIndex < 0) return;
            if (Ctl.Busy) return;
            Ctl.FinishPending();
            _active.JumpTo(HistoryList.SelectedIndex);
            AfterHistoryMove();
        };
    }

    void BuildTabStrip(StackPanel host, (string icon, string text)[] tabs, Action<int> onSelect)
    {
        var list = new List<ToggleButton>();
        for (int i = 0; i < tabs.Length; i++)
        {
            int idx = i;
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            sp.Children.Add(new Ico(tabs[i].icon, 14) { Margin = new Thickness(0, 0, 6, 0) });
            sp.Children.Add(new TextBlock { Text = tabs[i].text, FontSize = 12, FontWeight = FontWeights.SemiBold });
            var t = new ToggleButton { Content = sp, Style = UIx.R<Style>("Segment"), IsChecked = i == 0, Margin = new Thickness(0, 0, 4, 0), Padding = new Thickness(9, 4, 10, 4) };
            t.Click += (_, _) => { foreach (var o in list) o.IsChecked = o == t; onSelect(idx); };
            list.Add(t);
            host.Children.Add(t);
        }
    }

    const string LayerDragFormat = "application/x-sky-layer";

    static Layer ItemUnder(object src) => PointerHooks.ItemData<Layer>(src);

    static bool IsInThumb(object src) => PointerHooks.HasAncestor<Image>(src);

    void BindPanels()
    {
        var d = _active;
        _layerSync = true;
        LayerList.ItemsSource = d?.Layers;
        _layerSync = false;
        _historySync = true;
        HistoryList.ItemsSource = d?.History.Entries;
        _historySync = false;
        SyncLayerSelection();
        SyncHistorySelection();
    }

    void SyncLayerSelection()
    {
        var d = _active;
        _layerSync = true;
        LayerList.SelectedItem = d?.ActiveLayer;
        if (d?.ActiveLayer != null) LayerList.ScrollIntoView(d.ActiveLayer);
        _layerSync = false;
        _opSync = true;
        OpacitySlider.Value = (d?.ActiveLayer?.Opacity ?? 1) * 100;
        _opSync = false;
        UIx.SetDropText(_blendButton, d?.ActiveLayer?.BlendName ?? "Normal");
        UpdateStatus();
        BuildOptions();
    }

    void SyncHistorySelection()
    {
        var d = _active;
        if (d == null) return;
        _historySync = true;
        HistoryList.SelectedIndex = d.History.Index - 1;
        if (HistoryList.SelectedItem != null && HistoryList.IsVisible) HistoryList.ScrollIntoView(HistoryList.SelectedItem);
        _historySync = false;
    }

    ContextMenu BuildBlendMenu()
    {
        var m = new ContextMenu();
        var cur = _active?.ActiveLayer?.Blend ?? BlendMode.Normal;
        bool first = true;
        foreach (var grp in BlendModeInfo.Groups)
        {
            if (!first) m.Items.Add(new Separator());
            first = false;
            foreach (var bm in grp)
            {
                var mode = bm;
                m.Items.Add(UIx.Item(BlendModeInfo.Name(bm), () => SetBlend(mode), null, null, bm == cur));
            }
        }
        return m;
    }

    void SetBlend(BlendMode m)
    {
        var l = _active?.ActiveLayer;
        if (l == null || l.Blend == m) return;
        var before = _active.Capture();
        l.Blend = m;
        _active.RenderAll();
        _active.Record($"Blend: {BlendModeInfo.Name(m)}", before, "◑");
        UIx.SetDropText(_blendButton, l.BlendName);
    }

    ContextMenu BuildLayerMenu(Layer l)
    {
        var m = new ContextMenu();
        m.Items.Add(UIx.Item("Rename…", () => RenameLayer(l), "Double-click", "text"));
        m.Items.Add(UIx.Item("Duplicate layer", DuplicateLayer, "Ctrl+J", "duplicate"));
        m.Items.Add(UIx.Item("Delete layer", DeleteLayer, null, "trash"));
        m.Items.Add(new Separator());
        m.Items.Add(UIx.Item("Select layer pixels", () => SelectLayerPixels(l), "Ctrl+click thumb", "selectall"));
        if (l.IsAdjustment) m.Items.Add(UIx.Item("Edit adjustment…", () => EditAdjustmentLayer(l), "Double-click", l.AdjustIcon));
        if (l.IsText) m.Items.Add(UIx.Item("Edit text", () => Ctl.EditTextLayer(l), "Double-click", "text"));
        if (l.IsText || l.Psd?.KindLabel != null) m.Items.Add(UIx.Item("Rasterize layer", RasterizeLayer, null, "image"));
        m.Items.Add(new Separator());
        if (!l.HasMask) { m.Items.Add(UIx.Item("Add mask", () => AddMask(0), null, "mask")); if (_active?.HasSelection == true) m.Items.Add(UIx.Item("Add mask from selection", () => AddMask(2))); }
        else
        {
            m.Items.Add(UIx.Item(l.MaskEnabled ? "Disable mask" : "Enable mask", ToggleMaskEnabled, "Shift+click mask", "mask"));
            m.Items.Add(UIx.Item("Invert mask", InvertMask, null, "invert"));
            if (!l.IsAdjustment) m.Items.Add(UIx.Item("Apply mask", () => DeleteMask(true), null, "check"));
            m.Items.Add(UIx.Item("Delete mask", () => DeleteMask(false), null, "trash"));
        }
        m.Items.Add(UIx.Item(l.Clipped ? "Release clipping mask" : "Create clipping mask", ToggleClipping, "Ctrl+Alt+G", "clip"));
        if (!string.IsNullOrEmpty(l.Group)) m.Items.Add(UIx.Item("Remove from group", UngroupActiveLayer, "Ctrl+Shift+G", "folder-group"));
        else m.Items.Add(UIx.Item("Put in new group", GroupActiveLayer, "Ctrl+G", "folder-group"));
        m.Items.Add(UIx.Item(l.Locked ? "Unlock layer" : "Lock layer", () => ToggleLock(l), null, l.Locked ? "unlock" : "lock"));
        m.Items.Add(UIx.Item(l.Visible ? "Hide layer" : "Show layer", () => ToggleVisible(l), null, l.Visible ? "eyeoff" : "eye"));
        m.Items.Add(new Separator());
        m.Items.Add(UIx.Item("Merge down", MergeDown, "Ctrl+E", "merge"));
        m.Items.Add(UIx.Item("Merge visible", MergeVisible, "Ctrl+Shift+E", "layers"));
        m.Items.Add(UIx.Item("Flatten image", FlattenImage, null, "image"));
        m.Items.Add(new Separator());
        m.Items.Add(UIx.Item("Flip horizontal", () => LayerTransform("Flip Layer Horizontal", Transforms.FlipH), null, "fliph"));
        m.Items.Add(UIx.Item("Flip vertical", () => LayerTransform("Flip Layer Vertical", Transforms.FlipV), null, "flipv"));
        m.Items.Add(UIx.Item("Free transform", Ctl.BeginFreeTransform, "Ctrl+T", "transform"));
        return m;
    }

    void OnLayerThumbDown(object sender, PointerPressedEventArgs e)
    {
        if ((sender as Control)?.Tag is not Layer l || e.ClickCount > 1 || !e.GetCurrentPoint(null).Properties.IsLeftButtonPressed) return;
        if ((Keyboard.From(e.KeyModifiers) & ModifierKeys.Control) != 0) { SelectLayerPixels(l); e.Handled = true; return; }
        if (l.EditMask || _active?.ActiveLayer != l) { _active.ActiveLayer = l; if (l.EditMask && !l.IsAdjustment) SetEditTarget(l, false); }
    }

    void OnLayerMaskDown(object sender, PointerPressedEventArgs e)
    {
        if ((sender as Control)?.Tag is not Layer l || !e.GetCurrentPoint(null).Properties.IsLeftButtonPressed) return;
        var mods = Keyboard.From(e.KeyModifiers);
        if ((mods & ModifierKeys.Shift) != 0) { _active.ActiveLayer = l; ToggleMaskEnabled(); e.Handled = true; return; }
        if ((mods & ModifierKeys.Control) != 0) { _active.ActiveLayer = l; MaskToSelection(); e.Handled = true; return; }
        if (!l.EditMask || _active?.ActiveLayer != l) SetEditTarget(l, true);
        e.Handled = true;
    }

    void OnLayerEyeClick(object sender, RoutedEventArgs e)
    {
        if ((sender as Control)?.Tag is Layer l) ToggleVisible(l);
        e.Handled = true;
    }

    void OnLayerLockClick(object sender, RoutedEventArgs e)
    {
        if ((sender as Control)?.Tag is Layer l) ToggleLock(l);
        e.Handled = true;
    }

    void ToggleVisible(Layer l)
    {
        if (_active == null) return;
        var before = _active.Capture();
        l.Visible = !l.Visible;
        _active.RenderAll();
        _active.Record(l.Visible ? "Show Layer" : "Hide Layer", before, "◉");
    }

    void ToggleLock(Layer l)
    {
        if (_active == null) return;
        var before = _active.Capture();
        l.Locked = !l.Locked;
        _active.Record(l.Locked ? "Lock Layer" : "Unlock Layer", before, "🔒");
    }

    // ───────────────────────────── navigator ─────────────────────────────

    Rect NavImageRect()
    {
        var d = _active;
        double bw = NavBox.ActualWidth - 12, bh = NavBox.ActualHeight - 12;
        if (d == null || bw <= 0 || bh <= 0) return default;
        double s = Math.Min(bw / d.Width, bh / d.Height);
        double w = d.Width * s, h = d.Height * s;
        return new Rect(6 + (bw - w) / 2, 6 + (bh - h) / 2, w, h);
    }

    void UpdateNavRect()
    {
        var d = _active;
        var ir = NavImageRect();
        if (d == null || ir.Width <= 0 || Canvas.ActualWidth <= 0) { NavRect.Visibility = Visibility.Collapsed; return; }
        double s = ir.Width / d.Width;
        var tl = Canvas.ToDoc(new Point(0, 0));
        var br = Canvas.ToDoc(new Point(Canvas.ActualWidth, Canvas.ActualHeight));
        var r = new Rect(new Point(ir.X + tl.X * s, ir.Y + tl.Y * s), new Point(ir.X + br.X * s, ir.Y + br.Y * s));
        r = r.Intersect(new Rect(ir.X - 1, ir.Y - 1, ir.Width + 2, ir.Height + 2));
        if (r.Width <= 0 || r.Height <= 0) { NavRect.Visibility = Visibility.Collapsed; return; }
        NavRect.Visibility = Visibility.Visible;
        Avalonia.Controls.Canvas.SetLeft(NavRect, r.X);
        Avalonia.Controls.Canvas.SetTop(NavRect, r.Y);
        NavRect.Width = Math.Max(4, r.Width);
        NavRect.Height = Math.Max(4, r.Height);
    }

    void NavJump(Point p)
    {
        var d = _active;
        var ir = NavImageRect();
        if (d == null || ir.Width <= 0) return;
        double s = ir.Width / d.Width;
        Canvas.CenterOn(new Point((p.X - ir.X) / s, (p.Y - ir.Y) / s));
    }

    // ───────────────────────────── task bar ─────────────────────────────

    void BuildTaskBar() => RebuildTaskBar();

    void RebuildTaskBar()
    {
        TaskBarStack.Children.Clear();
        if (_active == null) { TaskBar.Visibility = Visibility.Collapsed; return; }
        TaskBar.Visibility = Visibility.Visible;
        void T(string icon, string text, Action a, bool accent = false)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            sp.Children.Add(new Ico(icon, 15) { Margin = new Thickness(0, 0, 7, 0), Foreground = accent ? UIx.R<Brush>("AccentGradH") : null });
            if (!accent) sp.Children[0].ClearValue(Ico.ForegroundProperty);
            sp.Children.Add(new TextBlock { Text = text, FontSize = 12 });
            var b = new Button { Content = sp, Style = UIx.R<Style>("Ghost"), Padding = new Thickness(11, 7, 12, 7) };
            b.Click += (_, _) => a();
            TaskBarStack.Children.Add(b);
        }
        void Sep() => TaskBarStack.Children.Add(new Border { Width = 1, Height = 18, Background = UIx.R<Brush>("Line2"), Margin = new Thickness(4, 0, 4, 0), VerticalAlignment = VerticalAlignment.Center });

        if (_active.HasSelection)
        {
            T("crop", "Crop to selection", CropToSelection);
            T("invert", "Invert", InvertSelection);
            T("bucket", "Fill", () => FillSelection(true));
            T("duplicate", "Layer via copy", LayerViaCopy);
            Sep();
            T("deselect", "Deselect", Ctl.Deselect);
        }
        else
        {
            T("sparkle", "Auto enhance", AutoEnhance, true);
            T("cutout", "Remove background", RemoveBackground, true);
            Sep();
            T("image", "Add image", () => PlaceImage());
            T("transform", "Transform", Ctl.BeginFreeTransform);
            T("export", "Export", ExportDoc);
        }
    }

    // ───────────────────────────── options bar ─────────────────────────────

    void BuildOptions()
    {
        OptionsHost.Children.Clear();
        OptRight.Children.Clear();
        var tool = Ctl.Tool;
        void Add(Control e) => OptionsHost.Children.Add(e);
        var al = _active?.ActiveLayer;
        if (al != null && al.EditMask)
        {
            var chip = new Button { Style = UIx.R<Style>("Secondary"), Padding = new Thickness(10, 4, 10, 4), Margin = new Thickness(0, 0, 10, 0), ToolTip = al.IsAdjustment ? "Adjustment layers are edited through their mask" : "Click to edit pixels instead" };
            var cs = new StackPanel { Orientation = Orientation.Horizontal };
            cs.Children.Add(new Ico("mask", 14) { Margin = new Thickness(0, 0, 6, 0) });
            cs.Children.Add(new TextBlock { Text = al.IsAdjustment ? "Editing adjustment mask" : "Editing mask  ·  back to pixels" });
            chip.Content = cs;
            chip.Click += (_, _) => { if (!al.IsAdjustment) { SetEditTarget(al, false); BuildOptions(); } };
            OptRight.Children.Add(chip);
        }
        void Div() => Add(UIx.VDivider());
        Button Btn(string text, string icon, Action a, bool primary = false)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            if (icon != null) sp.Children.Add(new Ico(icon, 14) { Margin = new Thickness(0, 0, text == null ? 0 : 6, 0), Foreground = primary ? Brushes.White : null });
            if (primary && icon != null) { } else if (icon != null) sp.Children[0].ClearValue(Ico.ForegroundProperty);
            if (text != null) sp.Children.Add(new TextBlock { Text = text });
            var b = new Button { Content = sp, Style = UIx.R<Style>(primary ? "Primary" : "Secondary"), Padding = new Thickness(12, 5, 12, 5), Margin = new Thickness(0, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center };
            b.Click += (_, _) => a();
            return b;
        }
        CheckBox Check(string text, bool v, Action<bool> set)
        {
            var c = new CheckBox { Content = text, IsChecked = v, Margin = new Thickness(0, 0, 16, 0), VerticalAlignment = VerticalAlignment.Center };
            c.Click += (_, _) => set(c.IsChecked == true);
            return c;
        }

        if (Ctl.Xf != null && Ctl.Xf.Handles)
        {
            Add(UIx.Label("Free transform — drag handles to scale (Shift: free), outside to rotate (Shift: 15° steps)", 12, "Text2"));
            OptRight.Children.Add(Btn("Cancel", "close", Ctl.CancelTransform));
            OptRight.Children.Add(Btn("Apply", "check", Ctl.CommitTransform, true));
            return;
        }

        var b = Ctl.CurrentBrush;
        switch (tool)
        {
            case Tool.Move:
                Add(Check("Auto-select layer", Ctl.AutoSelect, v => Ctl.AutoSelect = v));
                Div();
                Add(Btn("Free transform", "transform", Ctl.BeginFreeTransform));
                Add(Btn(null, "fliph", () => LayerTransform("Flip Layer Horizontal", Transforms.FlipH)));
                Add(Btn(null, "flipv", () => LayerTransform("Flip Layer Vertical", Transforms.FlipV)));
                Div();
                Add(UIx.Label("Align", 12, "Text3"));
                foreach (var (name, ax, ay) in new[] { ("Left", 0, -1), ("Center", 1, -1), ("Right", 2, -1), ("Top", -1, 0), ("Middle", -1, 1), ("Bottom", -1, 2) })
                {
                    var bt = new Button { Content = name, Style = UIx.R<Style>("Ghost"), Padding = new Thickness(8, 4, 8, 4), FontSize = 12 };
                    int x = ax, y = ay;
                    bt.Click += (_, _) => AlignLayer(x, y);
                    Add(bt);
                }
                break;

            case Tool.MarqueeRect:
            case Tool.MarqueeEllipse:
            case Tool.Lasso:
            case Tool.PolyLasso:
            case Tool.MagicWand:
                Add(UIx.SegGroup(new (object, string)[] { ("New", "New selection"), ("Add", "Add to selection (Shift)"), ("Subtract", "Subtract (Alt)"), ("Intersect", "Intersect (Shift+Alt)") }, (int)Ctl.SelMode, i => Ctl.SelMode = (SelectMode)i));
                Add(UIx.OptSlider("Feather", 0, 100, Ctl.Feather, v => Ctl.Feather = (int)v, "px", 0, 80));
                if (tool == Tool.MagicWand)
                {
                    Add(UIx.OptSlider("Tolerance", 0, 255, Ctl.WandTolerance, v => Ctl.WandTolerance = (int)v, "", 0, 90));
                    Add(Check("Contiguous", Ctl.WandContiguous, v => Ctl.WandContiguous = v));
                    Add(Check("Sample all layers", Ctl.SampleAll, v => Ctl.SampleAll = v));
                }
                Div();
                Add(Btn("Select all", "selectall", SelectAll));
                Add(Btn("Invert", "invert", InvertSelection));
                Add(Btn("Deselect", "deselect", Ctl.Deselect));
                break;

            case Tool.Crop:
            {
                var ratio = UIx.DropButton(ToolController.CropRatios[Ctl.CropRatio].name, () =>
                {
                    var m = new ContextMenu();
                    for (int i = 0; i < ToolController.CropRatios.Length; i++)
                    {
                        int idx = i;
                        m.Items.Add(UIx.Item(ToolController.CropRatios[i].name, () => { Ctl.CropRatio = idx; BuildOptions(); }, null, null, idx == Ctl.CropRatio));
                    }
                    return m;
                }, 110);
                Add(UIx.Label("Ratio", 12, "Text3"));
                ratio.Margin = new Thickness(8, 0, 14, 0);
                Add(ratio);
                Add(UIx.Label("Drag the handles · double-click inside or press Enter to crop", 12, "Text3"));
                OptRight.Children.Add(Btn("Reset", "close", Ctl.CancelCrop));
                OptRight.Children.Add(Btn("Crop", "check", Ctl.ApplyCrop, true));
                break;
            }

            case Tool.Eyedropper:
                Add(Check("Sample all layers", Ctl.SampleAll, v => Ctl.SampleAll = v));
                Add(UIx.Label("Click: foreground  ·  Alt-click: background", 12, "Text3"));
                break;

            case Tool.Brush:
            case Tool.Eraser:
            case Tool.Clone:
                Add(UIx.OptSlider("Size", 1, 1000, b.Size, v => { b.Size = v; Canvas.InvalidateVisual(); }, "px", 0, 110));
                Add(UIx.OptSlider("Hardness", 0, 100, b.Hardness * 100, v => b.Hardness = v / 100, "%", 0, 80));
                Add(UIx.OptSlider("Opacity", 1, 100, b.Opacity * 100, v => b.Opacity = v / 100, "%", 0, 80));
                Add(UIx.OptSlider("Flow", 1, 100, b.Flow * 100, v => b.Flow = v / 100, "%", 0, 80));
                if (tool == Tool.Clone) Add(UIx.Label("Alt-click sets the source", 12, "Text3"));
                break;

            case Tool.Pencil:
                Add(UIx.OptSlider("Size", 1, 200, b.Size, v => { b.Size = v; Canvas.InvalidateVisual(); }, "px", 0, 110));
                Add(UIx.OptSlider("Opacity", 1, 100, b.Opacity * 100, v => b.Opacity = v / 100, "%", 0, 80));
                break;

            case Tool.Heal:
                Add(UIx.OptSlider("Size", 1, 600, b.Size, v => { b.Size = v; Canvas.InvalidateVisual(); }, "px", 0, 110));
                Add(UIx.OptSlider("Hardness", 0, 100, b.Hardness * 100, v => b.Hardness = v / 100, "%", 0, 80));
                Add(UIx.Label("Alt-click a clean area, then paint over blemishes", 12, "Text3"));
                break;

            case Tool.Blur:
            case Tool.Sharpen:
            case Tool.Smudge:
            case Tool.Dodge:
            case Tool.Burn:
            case Tool.Sponge:
                Add(UIx.OptSlider("Size", 1, 800, b.Size, v => { b.Size = v; Canvas.InvalidateVisual(); }, "px", 0, 110));
                Add(UIx.OptSlider("Hardness", 0, 100, b.Hardness * 100, v => b.Hardness = v / 100, "%", 0, 80));
                Add(UIx.OptSlider(tool is Tool.Dodge or Tool.Burn ? "Exposure" : "Strength", 1, 100, b.Strength * 100, v => b.Strength = v / 100, "%", 0, 80));
                if (tool == Tool.Sponge)
                    Add(UIx.SegGroup(new (object, string)[] { ("Desaturate", null), ("Saturate", null) }, b.SpongeSaturate ? 1 : 0, i => b.SpongeSaturate = i == 1));
                break;

            case Tool.Gradient:
                Add(UIx.SegGroup(new (object, string)[] { ("Linear", null), ("Radial", null), ("Reflected", null) }, Ctl.GradientType, i => Ctl.GradientType = i));
                Add(UIx.SegGroup(new (object, string)[] { ("Foreground → Background", null), ("Foreground → Transparent", null) }, Ctl.GradientMode, i => Ctl.GradientMode = i));
                break;

            case Tool.Bucket:
                Add(UIx.OptSlider("Tolerance", 0, 255, Ctl.BucketTolerance, v => Ctl.BucketTolerance = (int)v, "", 0, 90));
                Add(Check("Contiguous", Ctl.BucketContiguous, v => Ctl.BucketContiguous = v));
                Add(Check("Sample all layers", Ctl.SampleAll, v => Ctl.SampleAll = v));
                break;

            case Tool.Text:
            {
                var font = UIx.DropButton(Ctl.FontName, BuildFontMenu, 170);
                font.Margin = new Thickness(0, 0, 14, 0);
                Add(font);
                Add(UIx.OptSlider("Size", 6, 600, Ctl.FontSize, v => { Ctl.FontSize = v; Ctl.ApplyTextStyle(); }, "px", 0, 110));
                var bold = new ToggleButton { Content = new TextBlock { Text = "B", FontWeight = FontWeights.Bold }, Style = UIx.R<Style>("Segment"), IsChecked = Ctl.Bold, ToolTip = "Bold" };
                bold.Click += (_, _) => { Ctl.Bold = bold.IsChecked == true; Ctl.ApplyTextStyle(); };
                var italic = new ToggleButton { Content = new TextBlock { Text = "I", FontStyle = FontStyles.Italic, FontFamily = new FontFamily("Georgia") }, Style = UIx.R<Style>("Segment"), IsChecked = Ctl.Italic, ToolTip = "Italic", Margin = new Thickness(4, 0, 14, 0) };
                italic.Click += (_, _) => { Ctl.Italic = italic.IsChecked == true; Ctl.ApplyTextStyle(); };
                Add(bold); Add(italic);
                Add(UIx.Label("Uses the foreground color", 12, "Text3"));
                if (Ctl.TextActive)
                {
                    OptRight.Children.Add(Btn("Cancel", "close", Ctl.CancelText));
                    OptRight.Children.Add(Btn("Commit", "check", Ctl.CommitText, true));
                }
                break;
            }

            case Tool.ShapeRect:
            case Tool.ShapeEllipse:
            case Tool.ShapeLine:
                if (tool != Tool.ShapeLine)
                {
                    Add(Check("Fill", Ctl.ShapeFill, v => Ctl.ShapeFill = v));
                    Add(Check("Stroke", Ctl.ShapeStroke, v => Ctl.ShapeStroke = v));
                }
                Add(UIx.OptSlider(tool == Tool.ShapeLine ? "Weight" : "Stroke", 1, 200, Ctl.StrokeWidth, v => Ctl.StrokeWidth = v, "px", 0, 90));
                if (tool == Tool.ShapeRect) Add(UIx.OptSlider("Radius", 0, 500, Ctl.CornerRadius, v => Ctl.CornerRadius = v, "px", 0, 90));
                Add(UIx.Label("Fill uses foreground, stroke uses background", 12, "Text3"));
                break;

            case Tool.Hand:
            case Tool.Zoom:
                Add(Btn("Fit screen", "fit", Canvas.Fit));
                Add(Btn("100%", null, Canvas.ActualPixels));
                Add(Btn(null, "minus", () => Canvas.ZoomStep(false)));
                Add(Btn(null, "plus", () => Canvas.ZoomStep(true)));
                break;
        }
    }

    ContextMenu BuildFontMenu()
    {
        var m = new ContextMenu();
        var fonts = FontCatalog.Families.Where(n => !n.StartsWith("@")).Distinct().OrderBy(n => n).ToList();
        // favourites from Windows and common Linux desktops, shown in their own face
        string[] fav = { "Segoe UI", "Segoe UI Variable Display", "Arial", "Impact", "Georgia", "Bahnschrift", "Consolas", "Times New Roman", "Verdana", "Comic Sans MS",
                         "Inter", "Noto Sans", "Noto Serif", "DejaVu Sans", "Liberation Sans", "Liberation Serif", "Cantarell", "Ubuntu", "Fira Sans", "JetBrains Mono" };
        foreach (var f in fav.Where(fonts.Contains))
        {
            var name = f;
            var mi = new MenuItem { Header = new TextBlock { Text = f, FontFamily = new FontFamily(f), FontSize = 14 }, Icon = f == Ctl.FontName ? new Ico("check", 14) : null };
            mi.Click += (_, _) => { Ctl.FontName = name; Ctl.ApplyTextStyle(); BuildOptions(); };
            m.Items.Add(mi);
        }
        m.Items.Add(new Separator());
        foreach (var f in fonts)
        {
            var name = f;
            m.Items.Add(UIx.Item(f, () => { Ctl.FontName = name; Ctl.ApplyTextStyle(); BuildOptions(); }, null, null, f == Ctl.FontName));
        }
        return m;
    }
}

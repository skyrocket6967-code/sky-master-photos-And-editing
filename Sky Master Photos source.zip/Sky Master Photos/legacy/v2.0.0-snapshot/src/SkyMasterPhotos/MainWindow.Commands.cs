using System.Diagnostics;
using System.IO;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using SkyMasterPhotos.Core;
using Transforms = SkyMasterPhotos.Core.Transforms;
using SkyMasterPhotos.Tools;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos;

public partial class MainWindow
{
    uint[] _clipPx;
    int _clipW, _clipH, _clipX, _clipY;

    // ───────────────────────────── menu ─────────────────────────────

    static MenuItem M(string header, Action a, string gesture = null, string icon = null) => UIx.Item(header, a, gesture, icon);

    static MenuItem Sub(string header, string icon, params object[] items)
    {
        var mi = new MenuItem { Header = header };
        if (icon != null) mi.Icon = new Ico(icon, 15);
        foreach (var i in items) mi.Items.Add(i);
        return mi;
    }

    static Separator S() => new();

    MenuItem AdjMenu()
    {
        var mi = new MenuItem { Header = "New adjustment layer", Icon = new Ico("adjlayer", 15) };
        foreach (var k in AdjustmentSpec.Kinds)
        {
            var sp = AdjustmentSpec.Default(k);
            var kind = k;
            mi.Items.Add(M(sp.Title + "…", () => NewAdjustmentLayer(kind), null, sp.Icon));
        }
        return mi;
    }

    void BuildMenu()
    {
        MainMenu.Items.Clear();
        var recent = new MenuItem { Header = "Open recent", Icon = new Ico("history", 15) };
        recent.Items.Add(new MenuItem { Header = "(empty)", IsEnabled = false });
        recent.SubmenuOpened += (_, _) =>
        {
            recent.Items.Clear();
            var list = AppStore.GetRecent();
            if (list.Count == 0) recent.Items.Add(new MenuItem { Header = "No recent files", IsEnabled = false });
            foreach (var r in list.Take(15)) { var p = r.Path; recent.Items.Add(M(r.Name, () => OpenPath(p))); }
        };

        MainMenu.Items.Add(Sub("File", null,
            M("New…", NewDocument, "Ctrl+N", "new"),
            M("Open…", OpenFiles, "Ctrl+O", "folder"),
            recent,
            M("Place image…", () => PlaceImage(), null, "image"),
            S(),
            M("Save", () => SaveDoc(_active, false), "Ctrl+S", "save"),
            M("Save as…", () => SaveDoc(_active, true), "Ctrl+Shift+S"),
            M("Export…", ExportDoc, "Ctrl+Alt+E", "export"),
            S(),
            M("Close", () => CloseDoc(_active), "Ctrl+W", "close"),
            M("Close all", () => { foreach (var d in Docs.ToList()) if (!CloseDoc(d)) break; }),
            S(),
            M("Photoshop compatibility…", ShowPsdInfo, null, "info"),
            S(),
            M("Home", ShowHome, null, "home"),
            M("Exit", Close)));

        MainMenu.Items.Add(Sub("Edit", null,
            M("Undo", Undo, "Ctrl+Z", "undo"),
            M("Redo", Redo, "Ctrl+Shift+Z", "redo"),
            S(),
            M("Cut", Cut, "Ctrl+X"),
            M("Copy", () => Copy(false), "Ctrl+C", "duplicate"),
            M("Copy merged", () => Copy(true), "Ctrl+Shift+C"),
            M("Paste", Paste, "Ctrl+V", "paste"),
            M("Clear", ClearSelection, "Delete", "eraser"),
            S(),
            M("Fill with foreground", () => FillSelection(true), "Alt+Backspace", "bucket"),
            M("Fill with background", () => FillSelection(false), "Ctrl+Backspace"),
            M("Stroke selection", StrokeSelection, null, "marquee"),
            M("Content-Aware Fill", ContentAwareFill, "Shift+F5", "contentaware"),
            S(),
            M("Free transform", () => Ctl.BeginFreeTransform(), "Ctrl+T", "transform"),
            M("Flip layer horizontal", () => LayerTransform("Flip Layer Horizontal", Transforms.FlipH), null, "fliph"),
            M("Flip layer vertical", () => LayerTransform("Flip Layer Vertical", Transforms.FlipV), null, "flipv")));

        MainMenu.Items.Add(Sub("Image", null,
            Sub("Adjustments", "sliders",
                M("Brightness / Contrast…", AdjBrightness, null, "brightness"),
                M("Levels…", AdjLevels, "Ctrl+L", "levels"),
                M("Curves…", AdjCurves, "Ctrl+M", "curves"),
                M("Exposure…", AdjExposure, null, "exposure"),
                S(),
                M("Vibrance…", AdjVibrance, null, "vibrance"),
                M("Hue / Saturation…", AdjHueSat, "Ctrl+U", "huesat"),
                M("Color balance…", AdjColorBalance, "Ctrl+B", "colorbalance"),
                M("Black & white…", AdjBlackWhite, null, "bw"),
                M("Photo filter…", AdjPhotoFilter, null, "photofilter"),
                M("Temperature & tint…", AdjTemperature, null, "temp"),
                M("Shadows / Highlights…", AdjShadows, null, "shadows"),
                S(),
                M("Invert", () => QuickAdjust("Invert", Adjustments.Invert), "Ctrl+I", "invert"),
                M("Posterize…", AdjPosterize, null, "posterize"),
                M("Threshold…", AdjThreshold, null, "threshold"),
                M("Gradient map", AdjGradientMap, null, "gradientmap"),
                M("Desaturate", () => QuickAdjust("Desaturate", Adjustments.Desaturate), "Ctrl+Shift+U"),
                M("Sepia…", AdjSepia, null, "sepia")),
            S(),
            M("Auto enhance", AutoEnhance, null, "sparkle"),
            M("Auto tone", () => QuickAdjust("Auto Tone", Adjustments.AutoTone)),
            M("Auto contrast", () => QuickAdjust("Auto Contrast", Adjustments.AutoContrast)),
            M("Auto color", () => QuickAdjust("Auto Color", Adjustments.AutoColor)),
            M("Remove background…", RemoveBackground, null, "cutout"),
            S(),
            M("Image size…", ImageSize, "Ctrl+Alt+I", "fit"),
            M("Canvas size…", CanvasSize, "Ctrl+Alt+C", "selectall"),
            Sub("Rotate & flip", "rotate",
                M("Rotate 90° clockwise", () => RotateCanvas(1), null, "rotate"),
                M("Rotate 90° counter-clockwise", () => RotateCanvas(-1), null, "rotate-left"),
                M("Rotate 180°", () => RotateCanvas(2)),
                S(),
                M("Flip canvas horizontal", () => FlipCanvas(true), null, "fliph"),
                M("Flip canvas vertical", () => FlipCanvas(false), null, "flipv")),
            S(),
            M("Crop to selection", CropToSelection, null, "crop"),
            M("Trim transparent pixels", Trim),
            M("Flatten image", FlattenImage, null, "layers")));

        MainMenu.Items.Add(Sub("Layer", null,
            M("New layer", NewLayer, "Ctrl+Shift+N", "plus"),
            AdjMenu(),
            M("Duplicate layer", DuplicateLayer, null, "duplicate"),
            M("Layer style…", EditLayerStyle),
            M("Delete layer", DeleteLayer, null, "trash"),
            M("Rename layer…", () => { if (_active?.ActiveLayer != null) RenameLayer(_active.ActiveLayer); }, null, "text"),
            S(),
            M("New layer via copy", LayerViaCopy, "Ctrl+J"),
            M("New layer via cut", LayerViaCut, "Ctrl+Shift+J"),
            S(),
            M("Merge down", MergeDown, "Ctrl+E", "merge"),
            M("Merge visible", MergeVisible, "Ctrl+Shift+E"),
            M("Flatten image", FlattenImage),
            S(),
            M("Bring forward", () => MoveLayer(-1), null, "up"),
            M("Send backward", () => MoveLayer(1), null, "down"),
            M("Bring to front", () => MoveLayerTo(true)),
            M("Send to back", () => MoveLayerTo(false)),
            S(),
            M("Lock / unlock", () => { if (_active?.ActiveLayer != null) ToggleLock(_active.ActiveLayer); }, null, "lock"),
            M("Show / hide", () => { if (_active?.ActiveLayer != null) ToggleVisible(_active.ActiveLayer); }, null, "eye"),
            S(),
            Sub("Layer mask", "mask",
                M("Reveal all", () => AddMask(0), null, "mask"),
                M("Hide all", () => AddMask(1)),
                M("From selection", () => AddMask(2), null, "selectall"),
                S(),
                M("Disable / enable", ToggleMaskEnabled, "Shift+click mask"),
                M("Invert mask", InvertMask, null, "invert"),
                M("Load as selection", MaskToSelection),
                S(),
                M("Apply mask", () => DeleteMask(true), null, "check"),
                M("Delete mask", () => DeleteMask(false), null, "trash")),
            M("Create / release clipping mask", ToggleClipping, "Ctrl+Alt+G", "clip"),
            Sub("Group", "folder-group",
                M("Put in new group", GroupActiveLayer, "Ctrl+G", "folder-group"),
                M("Remove from group", UngroupActiveLayer, "Ctrl+Shift+G"),
                M("Show / hide group", ToggleGroupVisibility, null, "eye")),
            M("Rasterize layer", RasterizeLayer, null, "image")));

        MainMenu.Items.Add(Sub("Select", null,
            M("All", SelectAll, "Ctrl+A", "selectall"),
            M("Deselect", () => Ctl.Deselect(), "Ctrl+D", "deselect"),
            M("Inverse", InvertSelection, "Ctrl+Shift+I", "invert"),
            M("Reselect", Reselect, "Ctrl+Shift+D"),
            S(),
            M("Select layer pixels", () => { if (_active?.ActiveLayer != null) SelectLayerPixels(_active.ActiveLayer); }),
            M("Select by foreground color", SelectByColor, null, "wand"),
            S(),
            M("Smooth…", () => ModifySelection("Smooth Selection", "Sample radius (px)", 2, SelectionOps.Smooth)),
            M("Border…", () => ModifySelection("Selection Border", "Border radius (px)", 2, SelectionOps.Border)),
            M("Feather…", () => ModifySelection("Feather", "Feather radius (px)", 8, (m, w, h, v) => SelectionOps.Feather(m, w, h, v))),
            M("Expand…", () => ModifySelection("Expand Selection", "Expand by (px)", 4, (m, w, h, v) => SelectionOps.Grow(m, w, h, v))),
            M("Contract…", () => ModifySelection("Contract Selection", "Contract by (px)", 4, (m, w, h, v) => SelectionOps.Grow(m, w, h, -v)))));

        MainMenu.Items.Add(Sub("Filter", null,
            Sub("Blur", "blur",
                M("Gaussian blur…", FGaussian),
                M("Box blur…", () => Dlg("Box Blur", null, new[] { AdjustParam.S("r", "Radius", 1, 100, 6, 0, "px") }, (c, p, w, h) => Filters.BoxBlur(p, w, h, (int)c["r"]))),
                M("Motion blur…", () => Dlg("Motion Blur", null, new[] { AdjustParam.S("a", "Angle", -180, 180, 0, 0, "°"), AdjustParam.S("d", "Distance", 1, 200, 20, 0, "px") }, (c, p, w, h) => Filters.MotionBlur(p, w, h, c["a"], (int)c["d"]))),
                M("Radial blur…", () => Dlg("Radial Blur", "Spin around the center", new[] { AdjustParam.S("a", "Amount", 1, 100, 20) }, (c, p, w, h) => Filters.RadialBlur(p, w, h, c["a"], false))),
                M("Zoom blur…", () => Dlg("Zoom Blur", "Burst from the center", new[] { AdjustParam.S("a", "Amount", 1, 100, 25) }, (c, p, w, h) => Filters.RadialBlur(p, w, h, c["a"], true))),
                M("Tilt-shift…", () => Dlg("Tilt-Shift", "Miniature-style focus band", new[] { AdjustParam.S("r", "Blur", 1, 60, 14, 0, "px"), AdjustParam.S("f", "Focus position", 0, 100, 55, 0, "%"), AdjustParam.S("b", "Focus size", 2, 100, 22, 0, "%") }, (c, p, w, h) => Filters.TiltShift(p, w, h, c["r"], c["f"], c["b"])))),
            Sub("Sharpen", "sharpen",
                M("Sharpen", () => LayerOp("Sharpen", Filters.Sharpen)),
                M("Unsharp mask…", () => Dlg("Unsharp Mask", null, new[] { AdjustParam.S("a", "Amount", 1, 500, 120, 0, "%"), AdjustParam.S("r", "Radius", 0.5, 50, 2, 1, "px"), AdjustParam.S("t", "Threshold", 0, 64, 2) }, (c, p, w, h) => Filters.UnsharpMask(p, w, h, c["a"], c["r"], (int)c["t"])))),
            Sub("Noise", "noise",
                M("Add noise…", () => Dlg("Add Noise", null, new[] { AdjustParam.S("a", "Amount", 1, 100, 10, 0, "%"), AdjustParam.C("m", "Monochromatic", true), AdjustParam.C("g", "Gaussian", true) }, (c, p, w, h) => Filters.AddNoise(p, w, h, c["a"], c.B("m"), c.B("g")))),
                M("Reduce noise (median)…", () => Dlg("Reduce Noise", "Median filter", new[] { AdjustParam.S("r", "Radius", 1, 10, 2, 0, "px") }, (c, p, w, h) => Filters.Median(p, w, h, (int)c["r"])))),
            Sub("Stylize", "sparkle",
                M("Oil paint…", () => Dlg("Oil Paint", "Painterly Kuwahara filter", new[] { AdjustParam.S("r", "Brush size", 1, 12, 4) }, (c, p, w, h) => Filters.OilPaint(p, w, h, (int)c["r"]))),
                M("Glow…", () => Dlg("Glow", "Dreamy soft glow", new[] { AdjustParam.S("r", "Radius", 1, 100, 18, 0, "px"), AdjustParam.S("s", "Strength", 0, 100, 45, 0, "%") }, (c, p, w, h) => Filters.Glow(p, w, h, c["r"], c["s"]))),
                M("Vignette…", () => Dlg("Vignette", null, new[] { AdjustParam.S("a", "Amount", -100, 100, 55, 0, "%"), AdjustParam.S("s", "Size", 0, 100, 45, 0, "%"), AdjustParam.S("f", "Softness", 1, 100, 60, 0, "%") }, (c, p, w, h) => Filters.Vignette(p, w, h, c["a"], c["s"], c["f"]))),
                M("Pixelate…", () => Dlg("Pixelate", "Mosaic", new[] { AdjustParam.S("c", "Cell size", 2, 200, 12, 0, "px") }, (c, p, w, h) => Filters.Pixelate(p, w, h, (int)c["c"]))),
                M("Emboss…", () => Dlg("Emboss", null, new[] { AdjustParam.S("a", "Angle", -180, 180, 135, 0, "°"), AdjustParam.S("s", "Height", 10, 500, 150, 0, "%") }, (c, p, w, h) => Filters.Emboss(p, w, h, c["a"], c["s"]))),
                M("Find edges", () => LayerOp("Find Edges", (p, w, h) => Filters.FindEdges(p, w, h, true)))),
            Sub("Distort", "rotate",
                M("Twirl…", () => Dlg("Twirl", null, new[] { AdjustParam.S("a", "Angle", -720, 720, 180, 0, "°") }, (c, p, w, h) => Filters.Twirl(p, w, h, c["a"]))),
                M("Pinch / Bulge…", () => Dlg("Pinch / Bulge", "Negative pinches, positive bulges", new[] { AdjustParam.S("a", "Amount", -100, 100, 50, 0, "%") }, (c, p, w, h) => Filters.Bulge(p, w, h, c["a"]))),
                M("Wave…", () => Dlg("Wave", null, new[] { AdjustParam.S("a", "Amplitude", 1, 100, 10, 0, "px"), AdjustParam.S("l", "Wavelength", 4, 600, 80, 0, "px") }, (c, p, w, h) => Filters.Wave(p, w, h, c["a"], c["l"])))),
            Sub("Render", "drop",
                M("Clouds", () => LayerOp("Clouds", (p, w, h) => Filters.Clouds(w, h, _fg, _bg, Math.Max(w, h) / 6.0, Environment.TickCount)))),
            S(),
            M("Auto enhance", AutoEnhance, null, "sparkle"),
            M("Remove background…", RemoveBackground, null, "cutout")));

        MainMenu.Items.Add(Sub("View", null,
            M("Zoom in", () => Canvas.ZoomStep(true), "Ctrl++", "plus"),
            M("Zoom out", () => Canvas.ZoomStep(false), "Ctrl+-", "minus"),
            M("Fit on screen", Canvas.Fit, "Ctrl+0", "fit"),
            M("Actual pixels (100%)", Canvas.ActualPixels, "Ctrl+1"),
            S(),
            M("Show / hide panels", TogglePanels, "Tab", "layers"),
            M("Show / hide task bar", () => TaskBar.Opacity = TaskBar.Opacity > 0.5 ? 0 : 1, null, "more")));

        MainMenu.Items.Add(Sub("Help", null,
            M("Keyboard shortcuts", () => InfoDialogs.Shortcuts(this), null, "keyboard"),
            M("Open app data folder", () => { try { Directory.CreateDirectory(AppStore.Dir); Process.Start("explorer.exe", AppStore.Dir); } catch { } }, null, "folder"),
            S(),
            M("About Sky Master Photos", () => InfoDialogs.About(this), null, "info")));
    }

    // ───────────────────────────── helpers ─────────────────────────────

    bool EditableLayer()
    {
        if (!RequireDoc()) return false;
        var l = _active.ActiveLayer;
        if (l == null) { Toast("Select a layer first"); return false; }
        if (l.Locked) { Toast($"“{l.Name}” is locked"); return false; }
        return true;
    }

    void Finish(Document d, Layer l = null)
    {
        d.RenderAll();
        if (l != null) l.RefreshThumbnail(); else d.RefreshAllLayerThumbs();
        d.RefreshThumbnail();
        d.NotifyStructure();
    }

    void LayerOp(string name, Func<uint[], int, int, uint[]> f, string icon = "◑")
    {
        if (!EditableLayer()) return;
        Ctl.FinishPending();
        var d = _active;
        var l = d.ActiveLayer;
        try
        {
            Mouse.OverrideCursor = Cursors.Wait;
            if (!Ctl.PrepareForPixelEdit(l)) return;
            var before = d.Capture();
            var src = l.Target;
            var res = Filters.Masked(src, f(src, d.Width, d.Height), d.Selection);
            l.SetTarget(res);
            Finish(d, l);
            d.Record(l.EditMask ? name + " (mask)" : name, before, icon);
        }
        finally { Mouse.OverrideCursor = null; }
    }

    void QuickAdjust(string name, Func<uint[], uint[]> f) => LayerOp(name, (p, w, h) => f(p));

    void Dlg(string title, string sub, IList<AdjustParam> ps, Func<AdjustContext, uint[], int, int, uint[]> fn)
    {
        if (!EditableLayer()) return;
        Ctl.FinishPending();
        if (!Ctl.PrepareForPixelEdit(_active.ActiveLayer)) return;
        if (AdjustDialog.Show(this, _active, title, sub, ps, fn)) { _active.NotifyStructure(); Toast($"{title} applied"); }
    }

    void Undo()
    {
        if (_active == null) return;
        if (Ctl.Xf != null) { Ctl.CancelTransform(); return; }
        if (Ctl.TextActive) { Ctl.CancelText(); return; }
        if (Ctl.Busy) return;
        if (_active.Undo()) AfterHistoryMove();
    }

    void Redo()
    {
        if (_active == null || Ctl.Busy || Ctl.Xf != null) return;
        if (_active.Redo()) AfterHistoryMove();
    }

    void AfterHistoryMove()
    {
        SyncLayerSelection();
        SyncHistorySelection();
        UpdateTitle();
        RebuildTaskBar();
        if (Ctl.Tool == Tool.Crop) Ctl.CancelCrop();
        Canvas.InvalidateVisual();
    }

    // ───────────────────────────── adjustments ─────────────────────────────

    void AdjBrightness() => Dlg("Brightness / Contrast", null,
        new[] { AdjustParam.S("b", "Brightness", -150, 150, 0), AdjustParam.S("c", "Contrast", -100, 100, 0) },
        (c, p, w, h) => Adjustments.BrightnessContrast(p, c["b"], c["c"]));

    void AdjLevels() => Dlg("Levels", "Input and output tonal range",
        new[] { AdjustParam.S("ib", "Input black", 0, 253, 0), AdjustParam.S("g", "Midtones (gamma)", 0.1, 9.99, 1, 2), AdjustParam.S("iw", "Input white", 2, 255, 255), AdjustParam.S("ob", "Output black", 0, 255, 0), AdjustParam.S("ow", "Output white", 0, 255, 255) },
        (c, p, w, h) => Adjustments.Levels(p, c["ib"], c["iw"], c["g"], c["ob"], c["ow"]));

    void AdjCurves() => Dlg("Curves", null, new[] { AdjustParam.Curve("curve") },
        (c, p, w, h) => Adjustments.ApplyLut(p, Adjustments.CurveLut(c.Curves.Points.ToList())));

    void AdjExposure() => Dlg("Exposure", null,
        new[] { AdjustParam.S("e", "Exposure", -5, 5, 0, 2, " EV"), AdjustParam.S("o", "Offset", -0.5, 0.5, 0, 3), AdjustParam.S("g", "Gamma", 0.1, 3, 1, 2) },
        (c, p, w, h) => Adjustments.Exposure(p, c["e"], c["o"], c["g"]));

    void AdjVibrance() => Dlg("Vibrance", "Boost muted colors without oversaturating skin",
        new[] { AdjustParam.S("v", "Vibrance", -100, 100, 25), AdjustParam.S("s", "Saturation", -100, 100, 0) },
        (c, p, w, h) => Adjustments.Vibrance(p, c["v"], c["s"]));

    void AdjHueSat() => Dlg("Hue / Saturation", null,
        new[] { AdjustParam.S("h", "Hue", -180, 180, 0, 0, "°"), AdjustParam.S("s", "Saturation", -100, 100, 0), AdjustParam.S("l", "Lightness", -100, 100, 0), AdjustParam.C("c", "Colorize", false) },
        (c, p, w, h) => Adjustments.HueSaturation(p, c["h"], c["s"], c["l"], c.B("c")));

    void AdjColorBalance() => Dlg("Color Balance", "Shift the midtones",
        new[] { AdjustParam.S("r", "Cyan ↔ Red", -100, 100, 0), AdjustParam.S("g", "Magenta ↔ Green", -100, 100, 0), AdjustParam.S("b", "Yellow ↔ Blue", -100, 100, 0), AdjustParam.C("p", "Preserve luminosity", true) },
        (c, p, w, h) => Adjustments.ColorBalance(p, c["r"], c["g"], c["b"], c.B("p")));

    void AdjBlackWhite() => Dlg("Black & White", "Control how each color converts to gray",
        new[] { AdjustParam.S("r", "Reds", -200, 300, 40, 0, "%"), AdjustParam.S("y", "Yellows", -200, 300, 60, 0, "%"), AdjustParam.S("g", "Greens", -200, 300, 40, 0, "%"), AdjustParam.S("c", "Cyans", -200, 300, 60, 0, "%"), AdjustParam.S("b", "Blues", -200, 300, 20, 0, "%"), AdjustParam.S("m", "Magentas", -200, 300, 80, 0, "%") },
        (c, p, w, h) => Adjustments.BlackWhite(p, c["r"], c["y"], c["g"], c["c"], c["b"], c["m"]));

    static readonly (string name, Color c)[] PhotoFilters =
    {
        ("Warming", Color.FromRgb(236, 138, 0)), ("Cooling", Color.FromRgb(0, 109, 255)), ("Sepia", Color.FromRgb(172, 122, 51)),
        ("Red", Color.FromRgb(234, 26, 26)), ("Green", Color.FromRgb(25, 201, 25)), ("Violet", Color.FromRgb(155, 60, 255)), ("Foreground", Colors.Transparent),
    };

    void AdjPhotoFilter() => Dlg("Photo Filter", "Simulate a colored lens filter",
        new[] { AdjustParam.Ch("f", "Filter", 0, PhotoFilters.Select(x => x.name).ToArray()), AdjustParam.S("d", "Density", 1, 100, 25, 0, "%"), AdjustParam.C("l", "Preserve luminosity", true) },
        (c, p, w, h) =>
        {
            var pf = PhotoFilters[(int)c["f"]];
            var col = pf.c.A == 0 ? _fg : pf.c;
            return Adjustments.PhotoFilter(p, col, c["d"], c.B("l"));
        });

    void AdjTemperature() => Dlg("Temperature & Tint", "Warm up or cool down the image",
        new[] { AdjustParam.S("t", "Temperature", -100, 100, 0), AdjustParam.S("i", "Tint", -100, 100, 0) },
        (c, p, w, h) => Adjustments.TemperatureTint(p, c["t"], c["i"]));

    void AdjShadows() => Dlg("Shadows / Highlights", "Recover detail in dark and bright areas",
        new[] { AdjustParam.S("s", "Shadows", 0, 100, 35, 0, "%"), AdjustParam.S("h", "Highlights", 0, 100, 0, 0, "%") },
        (c, p, w, h) => Adjustments.ShadowsHighlights(p, w, h, c["s"], c["h"]));

    void AdjPosterize() => Dlg("Posterize", null, new[] { AdjustParam.S("l", "Levels", 2, 32, 6) }, (c, p, w, h) => Adjustments.Posterize(p, (int)c["l"]));

    void AdjThreshold() => Dlg("Threshold", null, new[] { AdjustParam.S("t", "Threshold level", 1, 255, 128) }, (c, p, w, h) => Adjustments.Threshold(p, (int)c["t"]));

    void AdjGradientMap() => Dlg("Gradient Map", "Maps shadows to the foreground and highlights to the background color",
        new[] { AdjustParam.C("r", "Reverse", false), AdjustParam.S("m", "Mix", 0, 100, 100, 0, "%") },
        (c, p, w, h) =>
        {
            var map = c.B("r") ? Adjustments.GradientMap(p, _bg, _fg) : Adjustments.GradientMap(p, _fg, _bg);
            float k = (float)(c["m"] / 100);
            var o = new uint[p.Length];
            Parallel.For(0, p.Length, i => o[i] = Px.Lerp(p[i], map[i], k));
            return o;
        });

    void AdjSepia() => Dlg("Sepia", null, new[] { AdjustParam.S("a", "Amount", 0, 100, 80, 0, "%") }, (c, p, w, h) => Adjustments.Sepia(p, c["a"]));

    void FGaussian() => Dlg("Gaussian Blur", null, new[] { AdjustParam.S("r", "Radius", 0.5, 250, 6, 1, "px") }, (c, p, w, h) => Filters.GaussianBlur(p, w, h, c["r"]));

    void AutoEnhance()
    {
        LayerOp("Auto Enhance", (p, w, h) => Adjustments.AutoEnhance(p), "✦");
        if (_active != null) Toast("Auto enhanced ✦");
    }

    void RemoveBackground() => Dlg("Remove Background", "Removes the background touching the image edges. Best on plain or studio backgrounds.",
        new[] { AdjustParam.S("t", "Tolerance", 1, 120, 38) },
        (c, p, w, h) => Adjustments.RemoveBackground(p, w, h, (int)c["t"]));

    // ───────────────────────────── layers ─────────────────────────────

    void NewLayer()
    {
        if (!RequireDoc()) return;
        Ctl.FinishPending();
        var d = _active;
        var before = d.Capture();
        int n = 1;
        while (d.Layers.Any(l => l.Name == $"Layer {n}")) n++;
        var layer = new Layer($"Layer {n}", d.Width, d.Height);
        d.Layers.Insert(Math.Max(0, d.ActiveIndex), layer);
        d.ActiveLayer = layer;
        layer.RefreshThumbnail();
        d.NotifyStructure();
        d.Record("New Layer", before, "+");
    }

    void DuplicateLayer()
    {
        if (!RequireDoc() || _active.ActiveLayer == null) return;
        Ctl.FinishPending();
        var d = _active;
        var before = d.Capture();
        var src = d.ActiveLayer;
        var copy = src.CloneDeep(src.Name + " copy");
        d.Layers.Insert(d.ActiveIndex, copy);
        d.ActiveLayer = copy;
        copy.RefreshThumbnail();
        d.RenderAll();
        d.NotifyStructure();
        d.Record("Duplicate Layer", before, "⧉");
    }

    void DeleteLayer()
    {
        if (!RequireDoc() || _active.ActiveLayer == null) return;
        Ctl.FinishPending();
        var d = _active;
        if (d.Layers.Count <= 1) { Toast("A document needs at least one layer"); return; }
        var before = d.Capture();
        int i = d.ActiveIndex;
        d.Layers.RemoveAt(i);
        d.ActiveLayer = d.Layers[Math.Min(i, d.Layers.Count - 1)];
        d.RenderAll();
        d.RefreshThumbnail();
        d.NotifyStructure();
        d.Record("Delete Layer", before, "✕");
    }

    void MoveLayer(int dir)
    {
        if (!RequireDoc() || _active.ActiveLayer == null) return;
        var d = _active;
        int i = d.ActiveIndex, j = i + dir;
        if (j < 0 || j >= d.Layers.Count) return;
        var before = d.Capture();
        d.Layers.Move(i, j);
        d.RenderAll();
        d.Record(dir < 0 ? "Bring Forward" : "Send Backward", before, "⇅");
        SyncLayerSelection();
    }

    void MoveLayerTo(bool front)
    {
        if (!RequireDoc() || _active.ActiveLayer == null) return;
        var d = _active;
        int i = d.ActiveIndex, j = front ? 0 : d.Layers.Count - 1;
        if (i == j) return;
        var before = d.Capture();
        d.Layers.Move(i, j);
        d.RenderAll();
        d.Record(front ? "Bring to Front" : "Send to Back", before, "⇅");
        SyncLayerSelection();
    }

    void RenameLayer(Layer l)
    {
        if (_active == null) return;
        var name = SkyDialog.Prompt(this, "Rename layer", "Layer name", l.Name);
        if (string.IsNullOrWhiteSpace(name) || name == l.Name) return;
        var before = _active.Capture();
        l.Name = name.Trim();
        _active.Record("Rename Layer", before, "T");
    }

    void MergeDown()
    {
        if (!RequireDoc() || _active.ActiveLayer == null) return;
        Ctl.FinishPending();
        var d = _active;
        int i = d.ActiveIndex;
        if (i >= d.Layers.Count - 1) { Toast("There's no layer below to merge into"); return; }
        var top = d.Layers[i];
        var bottom = d.Layers[i + 1];
        if (bottom.Locked) { Toast($"“{bottom.Name}” is locked"); return; }
        if (bottom.IsAdjustment) { Toast("Can't merge into an adjustment layer"); return; }
        var before = d.Capture();
        var buf = new uint[d.Width * d.Height];
        Compositor.Composite(new List<Layer> { top, bottom }, d.Width, d.Height, new Int32Rect(0, 0, d.Width, d.Height), buf);
        var merged = new Layer(bottom.Name, d.Width, d.Height, buf) { Group = bottom.Group };
        d.Layers.RemoveAt(i);
        d.Layers[i] = merged;
        d.ActiveLayer = merged;
        Finish(d);
        d.Record("Merge Down", before, "⤓");
    }

    void MergeVisible()
    {
        if (!RequireDoc()) return;
        Ctl.FinishPending();
        var d = _active;
        var vis = d.Layers.Where(l => l.Visible).ToList();
        if (vis.Count < 2) { Toast("Need at least two visible layers"); return; }
        var before = d.Capture();
        var buf = new uint[d.Width * d.Height];
        Compositor.Composite(d.Layers, d.Width, d.Height, new Int32Rect(0, 0, d.Width, d.Height), buf, null, 0, int.MaxValue, d.Groups);
        int at = d.Layers.IndexOf(vis[0]);
        var merged = new Layer("Merged", d.Width, d.Height, buf);
        foreach (var l in vis) d.Layers.Remove(l);
        d.Layers.Insert(Math.Min(at, d.Layers.Count), merged);
        d.ActiveLayer = merged;
        Finish(d);
        d.Record("Merge Visible", before, "⤓");
    }

    void FlattenImage()
    {
        if (!RequireDoc()) return;
        Ctl.FinishPending();
        var d = _active;
        if (d.Layers.Count == 1) { Toast("Already flat"); return; }
        var before = d.Capture();
        var buf = (uint[])d.Flat.Clone();
        d.Layers.Clear();
        d.Groups.Clear();
        var l = new Layer("Background", d.Width, d.Height, buf);
        d.Layers.Add(l);
        d.ActiveLayer = l;
        Finish(d);
        d.Record("Flatten Image", before, "▤");
    }

    void SelectLayerPixels(Layer l)
    {
        var d = _active;
        if (d == null) return;
        var m = new byte[d.Width * d.Height];
        var px = l.Pixels;
        Parallel.For(0, m.Length, i => m[i] = (byte)(px[i] >> 24));
        var before = d.Capture();
        d.SetSelection(m);
        d.Record("Select Layer Pixels", before, "⬚");
    }

    uint[] SelectedPixels(uint[] src, out Int32Rect r)
    {
        var d = _active;
        r = d.HasSelection ? d.SelectionBounds : new Int32Rect(0, 0, d.Width, d.Height);
        var o = Transforms.Crop(src, d.Width, d.Height, r);
        if (d.Selection != null)
        {
            var sel = d.Selection;
            var rr = r;
            Parallel.For(0, rr.Height, y =>
            {
                for (int x = 0; x < rr.Width; x++)
                {
                    int i = y * rr.Width + x;
                    int m = sel[(rr.Y + y) * d.Width + rr.X + x];
                    if (m < 255) o[i] = Px.WithAlpha(o[i], Px.A(o[i]) * m / 255);
                }
            });
        }
        return o;
    }

    void LayerViaCopy()
    {
        if (!RequireDoc() || _active.ActiveLayer == null) return;
        if (!_active.HasSelection) { DuplicateLayer(); return; }
        Ctl.FinishPending();
        var d = _active;
        var part = SelectedPixels(d.ActiveLayer.Pixels, out var r);
        var before = d.Capture();
        var layer = new Layer("Layer via Copy", d.Width, d.Height, Transforms.Canvas(part, r.Width, r.Height, d.Width, d.Height, r.X, r.Y, 0)) { Group = d.ActiveLayer.Group };
        d.Layers.Insert(d.ActiveIndex, layer);
        d.ActiveLayer = layer;
        Finish(d, layer);
        d.Record("Layer via Copy", before, "⧉");
    }

    void LayerViaCut()
    {
        if (!EditableLayer()) return;
        if (!_active.HasSelection) { Toast("Make a selection first"); return; }
        Ctl.FinishPending();
        var d = _active;
        var src = d.ActiveLayer;
        var part = SelectedPixels(src.Pixels, out var r);
        var before = d.Capture();
        var sel = d.Selection;
        var rest = new uint[src.Pixels.Length];
        var sp = src.Pixels;
        Parallel.For(0, rest.Length, i => rest[i] = sel[i] == 0 ? sp[i] : Px.WithAlpha(sp[i], Px.A(sp[i]) * (255 - sel[i]) / 255));
        src.SetPixels(rest, d.Width, d.Height);
        var layer = new Layer("Layer via Cut", d.Width, d.Height, Transforms.Canvas(part, r.Width, r.Height, d.Width, d.Height, r.X, r.Y, 0)) { Group = src.Group };
        d.Layers.Insert(d.ActiveIndex, layer);
        d.ActiveLayer = layer;
        Finish(d);
        d.Record("Layer via Cut", before, "✂");
    }

    void LayerTransform(string name, Func<uint[], int, int, uint[]> f)
    {
        if (!EditableLayer()) return;
        Ctl.FinishPending();
        var d = _active;
        var l = d.ActiveLayer;
        var before = d.Capture();
        l.SetPixels(f(l.Pixels, d.Width, d.Height), d.Width, d.Height);
        Finish(d, l);
        d.Record(name, before, "⇋");
    }

    void AlignLayer(int ax, int ay)
    {
        if (!EditableLayer()) return;
        var d = _active;
        var l = d.ActiveLayer;
        var b = Transforms.OpaqueBounds(l.Pixels, d.Width, d.Height);
        if (RectUtil.IsEmptyRect(b)) { Toast("Layer is empty"); return; }
        var t = d.HasSelection ? d.SelectionBounds : new Int32Rect(0, 0, d.Width, d.Height);
        int dx = ax switch { 0 => t.X - b.X, 1 => t.X + (t.Width - b.Width) / 2 - b.X, 2 => t.X + t.Width - b.Width - b.X, _ => 0 };
        int dy = ay switch { 0 => t.Y - b.Y, 1 => t.Y + (t.Height - b.Height) / 2 - b.Y, 2 => t.Y + t.Height - b.Height - b.Y, _ => 0 };
        if (dx == 0 && dy == 0) return;
        var before = d.Capture();
        l.SetPixels(Transforms.Canvas(l.Pixels, d.Width, d.Height, d.Width, d.Height, dx, dy, 0), d.Width, d.Height);
        Finish(d, l);
        d.Record("Align Layer", before, "⇤");
    }

    // ───────────────────────────── selection ─────────────────────────────

    void SelectAll()
    {
        if (!RequireDoc()) return;
        var d = _active;
        var before = d.Capture();
        d.SetSelection(SelectionOps.Rect(d.Width, d.Height, new Int32Rect(0, 0, d.Width, d.Height)));
        d.Record("Select All", before, "⬚");
    }

    void InvertSelection()
    {
        if (!RequireDoc()) return;
        var d = _active;
        var before = d.Capture();
        d.SetSelection(d.Selection == null ? null : SelectionOps.Invert(d.Selection, d.Width, d.Height));
        d.Record("Inverse", before, "⬚");
    }

    void Reselect()
    {
        if (!RequireDoc()) return;
        var before = _active.Capture();
        if (!_active.Reselect()) { Toast("No previous selection available"); return; }
        _active.Record("Reselect", before);
    }

    void SelectByColor()
    {
        if (!RequireDoc()) return;
        var d = _active;
        uint c = Px.FromColor(_fg);
        int tol = Ctl.WandTolerance;
        var m = new byte[d.Width * d.Height];
        var src = d.Flat;
        Parallel.For(0, m.Length, i =>
        {
            uint p = src[i];
            int dr = Px.R(p) - Px.R(c), dg = Px.G(p) - Px.G(c), db = Px.B(p) - Px.B(c);
            if (Px.A(p) > 0 && dr * dr + dg * dg + db * db <= tol * tol * 3) m[i] = 255;
        });
        var before = d.Capture();
        d.SetSelection(m);
        d.Record("Select Color", before, "⬚");
    }

    void ModifySelection(string name, string label, int def, Func<byte[], int, int, int, byte[]> f)
    {
        if (!RequireDoc()) return;
        var d = _active;
        if (!d.HasSelection) { Toast("Make a selection first"); return; }
        var s = SkyDialog.Prompt(this, name, label, def.ToString());
        if (!int.TryParse(s, out int v) || v <= 0) return;
        var before = d.Capture();
        d.SetSelection(f(d.Selection, d.Width, d.Height, Math.Min(v, 500)));
        d.Record(name, before, "⬚");
    }

    void ClearSelection()
    {
        if (!EditableLayer()) return;
        var d = _active;
        if (!d.HasSelection) { Toast("Make a selection to clear, or use the Eraser"); return; }
        LayerOp("Clear", (p, w, h) => new uint[p.Length], "⌫");
    }

    void FillSelection(bool useFg)
    {
        if (!EditableLayer()) return;
        uint c = Px.FromColor(useFg ? _fg : _bg);
        LayerOp(useFg ? "Fill Foreground" : "Fill Background", (p, w, h) => { var o = new uint[p.Length]; Array.Fill(o, c); return o; }, "◧");
    }

    void StrokeSelection()
    {
        if (!EditableLayer()) return;
        var d = _active;
        if (!d.HasSelection) { Toast("Make a selection first"); return; }
        var s = SkyDialog.Prompt(this, "Stroke selection", "Width (px) — uses the foreground color", "4");
        if (!int.TryParse(s, out int wpx) || wpx <= 0) return;
        Ctl.FinishPending();
        var l = d.ActiveLayer;
        var sel = d.Selection;
        var outer = SelectionOps.Grow(sel, d.Width, d.Height, Math.Max(1, wpx / 2));
        var inner = SelectionOps.Grow(sel, d.Width, d.Height, -Math.Max(1, wpx - wpx / 2));
        uint c = Px.FromColor(_fg);
        var before = d.Capture();
        var px = l.Pixels;
        var o = new uint[px.Length];
        Parallel.For(0, o.Length, i =>
        {
            int m = inner == null ? outer[i] : Math.Max(0, outer[i] - inner[i]);
            o[i] = m == 0 ? px[i] : Px.Over(px[i], c, m / 255f);
        });
        l.SetPixels(o, d.Width, d.Height);
        Finish(d, l);
        d.Record("Stroke", before, "▢");
    }

    // ───────────────────────────── image ─────────────────────────────

    void DocOp(string name, Action<Document> op, bool fit = true)
    {
        if (!RequireDoc()) return;
        Ctl.FinishPending();
        var d = _active;
        try
        {
            Mouse.OverrideCursor = Cursors.Wait;
            var before = d.Capture();
            op(d);
            Finish(d);
            d.Record(name, before, "▣");
            if (fit) { d.ViewInitialized = false; Canvas.Fit(); }
            if (Ctl.Tool == Tool.Crop) Ctl.CancelCrop();
        }
        finally { Mouse.OverrideCursor = null; }
    }

    void ImageSize()
    {
        if (!RequireDoc()) return;
        var r = ImageSizeDialog.Show(this, _active.Width, _active.Height);
        if (r == null) return;
        var (nw, nh) = r.Value;
        DocOp("Image Size", d =>
        {
            foreach (var l in d.Layers) MapLayer(l, p => Transforms.Resize(p, d.Width, d.Height, nw, nh), nw, nh);
            d.SetSize(nw, nh);
            d.SetSelection(null);
        });
    }

    void CanvasSize()
    {
        if (!RequireDoc()) return;
        var r = CanvasSizeDialog.Show(this, _active.Width, _active.Height);
        if (r == null) return;
        var (nw, nh, ax, ay, fill) = r.Value;
        DocOp("Canvas Size", d =>
        {
            int ox = (nw - d.Width) * ax / 2, oy = (nh - d.Height) * ay / 2;
            uint fc = fill switch { 1 => Px.FromColor(_bg), 2 => 0xFFFFFFFF, 3 => 0xFF000000, _ => 0 };
            var bottom = d.Layers[^1];
            foreach (var l in d.Layers)
            {
                l.SetPixels(Transforms.Canvas(l.Pixels, d.Width, d.Height, nw, nh, ox, oy, l == bottom ? fc : 0), nw, nh);
                if (l.Mask != null) l.SetMask(Transforms.Canvas(l.Mask, d.Width, d.Height, nw, nh, ox, oy, Masks.Gray(Masks.EdgeValue(l.Mask, d.Width, d.Height))));
            }
            if (fc != 0)
            {
                // the old area of the bottom layer must keep its own pixels over the fill
                var bpx = bottom.Pixels;
                Parallel.For(0, bpx.Length, i => { if ((bpx[i] >> 24) < 255) bpx[i] = Px.Over(fc, bpx[i]); });
            }
            d.SetSize(nw, nh);
            d.SetSelection(null);
        });
    }

    void RotateCanvas(int dir)
    {
        DocOp(dir == 2 ? "Rotate 180°" : dir > 0 ? "Rotate 90° CW" : "Rotate 90° CCW", d =>
        {
            int w = d.Width, h = d.Height;
            foreach (var l in d.Layers)
            {
                if (dir == 2) MapLayer(l, p => Transforms.Rotate180(p, w, h), w, h);
                else MapLayer(l, p => dir > 0 ? Transforms.Rotate90(p, w, h) : Transforms.Rotate270(p, w, h), h, w);
            }
            if (dir != 2) d.SetSize(h, w);
            d.SetSelection(null);
        });
    }

    void FlipCanvas(bool horizontal)
    {
        DocOp(horizontal ? "Flip Canvas Horizontal" : "Flip Canvas Vertical", d =>
        {
            foreach (var l in d.Layers) MapLayer(l, p => horizontal ? Transforms.FlipH(p, d.Width, d.Height) : Transforms.FlipV(p, d.Width, d.Height), d.Width, d.Height);
            if (d.Selection != null)
            {
                var m = d.Selection;
                var asPx = m.Select(b => (uint)b << 24).ToArray();
                var f = horizontal ? Transforms.FlipH(asPx, d.Width, d.Height) : Transforms.FlipV(asPx, d.Width, d.Height);
                d.SetSelection(f.Select(p => (byte)(p >> 24)).ToArray());
            }
        }, false);
    }

    void CropToRect(string name, Int32Rect r)
    {
        DocOp(name, d =>
        {
            foreach (var l in d.Layers) MapLayer(l, p => Transforms.Crop(p, d.Width, d.Height, r), r.Width, r.Height);
            d.SetSize(r.Width, r.Height);
            d.SetSelection(null);
        });
    }

    void CropToSelection()
    {
        if (!RequireDoc()) return;
        if (!_active.HasSelection) { Toast("Make a selection first"); return; }
        CropToRect("Crop to Selection", _active.SelectionBounds);
    }

    void Trim()
    {
        if (!RequireDoc()) return;
        var b = Transforms.OpaqueBounds(_active.Flat, _active.Width, _active.Height);
        if (RectUtil.IsEmptyRect(b)) { Toast("The image is fully transparent"); return; }
        if (b.Width == _active.Width && b.Height == _active.Height) { Toast("Nothing to trim"); return; }
        CropToRect("Trim", b);
    }

    // ───────────────────────────── clipboard & placing ─────────────────────────────

    void Copy(bool merged)
    {
        if (!RequireDoc() || (!merged && _active.ActiveLayer == null)) return;
        Ctl.FinishPending();
        var d = _active;
        var px = SelectedPixels(merged ? d.Flat : d.ActiveLayer.Pixels, out var r);
        _clipPx = px; _clipW = r.Width; _clipH = r.Height; _clipX = r.X; _clipY = r.Y;
        try
        {
            ClipboardImage.SetImage(px, r.Width, r.Height);
            Toast(merged ? "Copied merged" : "Copied");
        }
        catch (Exception ex) { Toast("Clipboard busy: " + ex.Message); }
    }

    void Cut()
    {
        if (!EditableLayer()) return;
        Copy(false);
        if (_active.HasSelection) LayerOp("Cut", (p, w, h) => new uint[p.Length], "✂");
        else
        {
            var d = _active;
            var before = d.Capture();
            d.ActiveLayer.SetPixels(new uint[d.Width * d.Height], d.Width, d.Height);
            Finish(d, d.ActiveLayer);
            d.Record("Cut", before, "✂");
        }
    }

    (uint[] px, int w, int h, int x, int y, bool internalClip)? ReadClipboard()
    {
        try
        {
            if (_clipPx != null && ClipboardImage.HasOwnMarker()) return (_clipPx, _clipW, _clipH, _clipX, _clipY, true);
            var img = ClipboardImage.GetImage();
            if (img != null) return (img.Value.px, img.Value.w, img.Value.h, 0, 0, false);
        }
        catch { }
        return null;
    }

    void Paste()
    {
        var clip = ReadClipboard();
        if (clip == null) { Toast("Clipboard doesn't contain an image"); return; }
        var (px, w, h, x, y, internalClip) = clip.Value;
        if (_active == null || HomeHost.Visibility == Visibility.Visible)
        {
            var d = new Document(w, h, "Pasted", "Paste");
            var l = new Layer("Background", w, h, px);
            d.Layers.Add(l);
            d.ActiveLayer = l;
            d.RenderAll();
            AddDocument(d);
            return;
        }
        Ctl.FinishPending();
        var doc = _active;
        int ox = internalClip && x + w <= doc.Width && y + h <= doc.Height ? x : (doc.Width - w) / 2;
        int oy = internalClip && x + w <= doc.Width && y + h <= doc.Height ? y : (doc.Height - h) / 2;
        var before = doc.Capture();
        var layer = new Layer("Pasted", doc.Width, doc.Height, Transforms.Canvas(px, w, h, doc.Width, doc.Height, ox, oy, 0));
        doc.Layers.Insert(Math.Max(0, doc.ActiveIndex), layer);
        doc.ActiveLayer = layer;
        doc.SetSelection(null);
        Finish(doc, layer);
        doc.Record("Paste", before, "⎘");
    }

    void PlaceImage()
    {
        if (!RequireDoc()) return;
        var files = FilePicker.Open(this, "Place image", false, FilePicker.Type("Images", ImageIO.ImageExtensions));
        if (files.Length > 0) PlaceFile(files[0], true);
    }

    void PlaceFile(string path, bool transform)
    {
        if (_active == null) { OpenPath(path); return; }
        try
        {
            Ctl.FinishPending();
            var d = _active;
            var (px, w, h) = ImageIO.LoadPixels(path);
            double s = Math.Min(1, Math.Min(d.Width * 0.9 / w, d.Height * 0.9 / h));
            if (s < 1)
            {
                int nw = Math.Max(1, (int)(w * s)), nh = Math.Max(1, (int)(h * s));
                px = Transforms.Resize(px, w, h, nw, nh);
                w = nw; h = nh;
            }
            var before = d.Capture();
            var layer = new Layer(Path.GetFileNameWithoutExtension(path), d.Width, d.Height, Transforms.Canvas(px, w, h, d.Width, d.Height, (d.Width - w) / 2, (d.Height - h) / 2, 0));
            d.Layers.Insert(Math.Max(0, d.ActiveIndex), layer);
            d.ActiveLayer = layer;
            d.SetSelection(null);
            Finish(d, layer);
            d.Record("Place Image", before, "⎘");
            if (transform) Ctl.BeginFreeTransform();
        }
        catch (Exception ex) { SkyDialog.Alert(this, "Couldn't place image", ex.Message); }
    }
}

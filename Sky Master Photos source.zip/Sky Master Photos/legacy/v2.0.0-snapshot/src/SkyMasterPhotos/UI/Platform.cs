using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Input.Platform;
using Avalonia.Platform.Storage;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

// ─────────────────────────────────────────────────────────────────────────────
//  File pickers and the clipboard, the same on Windows and Linux (X11 / XWayland).
//  Both are async in Avalonia; the editor's commands are synchronous, so they run
//  through UiWait (a nested message loop, like WPF's modal dialogs).
// ─────────────────────────────────────────────────────────────────────────────

public static class FilePicker
{
    public static FilePickerFileType Type(string name, params string[] exts) => new(name)
    {
        Patterns = exts.Select(e => "*" + e).ToList(),
    };

    public static readonly FilePickerFileType AllImages = Type("All supported files", ImageIO.OpenExtensions);

    static async Task<IStorageFolder> StartFolder(IStorageProvider sp)
    {
        var dir = AppStore.Settings.LastFolder;
        if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) dir = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
        if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) return null;
        try { return await sp.TryGetFolderFromPathAsync(dir); } catch { return null; }
    }

    /// <summary>Returns the chosen local file paths (empty if cancelled).</summary>
    public static string[] Open(TopLevel owner, string title, bool multiple, params FilePickerFileType[] types)
    {
        owner ??= App.MainWin;
        var sp = owner?.StorageProvider;
        if (sp == null || !sp.CanOpen) return Array.Empty<string>();
        var files = UiWait.Wait(Run());
        var paths = files.Select(f => f.TryGetLocalPath()).Where(p => p != null).ToArray();
        if (paths.Length > 0) AppStore.Settings.LastFolder = Path.GetDirectoryName(paths[0]);
        return paths;

        async Task<IReadOnlyList<IStorageFile>> Run() => await sp.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = title,
            AllowMultiple = multiple,
            FileTypeFilter = types.Length > 0 ? types : new[] { AllImages },
            SuggestedStartLocation = await StartFolder(sp),
        });
    }

    /// <summary>Returns the chosen local path (null if cancelled). The extension of the selected type is added when missing.</summary>
    public static string Save(TopLevel owner, string title, string suggestedName, params FilePickerFileType[] types)
    {
        owner ??= App.MainWin;
        var sp = owner?.StorageProvider;
        if (sp == null || !sp.CanSave) return null;
        var defExt = types.FirstOrDefault()?.Patterns?.FirstOrDefault()?.TrimStart('*');
        var file = UiWait.Wait(Run());
        var path = file?.TryGetLocalPath();
        if (path == null) return null;
        // GTK / portal pickers don't always append the extension
        if (string.IsNullOrEmpty(Path.GetExtension(path)) && defExt != null) path += defExt;
        AppStore.Settings.LastFolder = Path.GetDirectoryName(path);
        return path;

        async Task<IStorageFile> Run() => await sp.SaveFilePickerAsync(new FilePickerSaveOptions
        {
            Title = title,
            SuggestedFileName = suggestedName,
            DefaultExtension = defExt?.TrimStart('.'),
            FileTypeChoices = types,
            ShowOverwritePrompt = true,
            SuggestedStartLocation = await StartFolder(sp),
        });
    }
}

/// <summary>Image copy / paste through the system clipboard as PNG ("PNG" on Windows, image/png on X11).</summary>
public static class ClipboardImage
{
    static IClipboard Board => App.MainWin?.Clipboard;
    static string PngFormat => OperatingSystem.IsWindows() ? "PNG" : "image/png";
    public const string Marker = "SkyMasterPhotos.Clip";

    public static void SetImage(uint[] px, int w, int h)
    {
        var cb = Board ?? throw new InvalidOperationException("no clipboard");
        var data = new DataObject();
        data.Set(PngFormat, ImageIO.EncodePng(px, w, h));
        data.Set(Marker, System.Text.Encoding.UTF8.GetBytes("1"));
        UiWait.Wait(cb.SetDataObjectAsync(data));
    }

    static string[] Formats()
    {
        var cb = Board;
        if (cb == null) return Array.Empty<string>();
        try { return UiWait.Wait(cb.GetFormatsAsync()) ?? Array.Empty<string>(); } catch { return Array.Empty<string>(); }
    }

    public static bool HasOwnMarker() => Formats().Contains(Marker);

    /// <summary>Image on the clipboard: PNG data, or the first image file of a copied file list.</summary>
    public static (uint[] px, int w, int h)? GetImage()
    {
        var cb = Board;
        if (cb == null) return null;
        var formats = Formats();
        foreach (var f in new[] { PngFormat, "image/png", "PNG", "image/jpeg", "image/bmp", "image/webp" }.Distinct())
        {
            if (!formats.Contains(f)) continue;
            try
            {
                var data = UiWait.Wait(cb.GetDataAsync(f));
                byte[] bytes = data as byte[] ?? (data is Stream st ? ToBytes(st) : null);
                if (bytes is { Length: > 0 }) return ImageIO.LoadPixels(new MemoryStream(bytes));
            }
            catch { }
        }
        foreach (var path in FilePaths())
        {
            if (!ImageIO.OpenExtensions.Contains(Path.GetExtension(path).ToLowerInvariant()) || !File.Exists(path)) continue;
            try { return ImageIO.LoadPixels(path); } catch { }
        }
        return null;
    }

    /// <summary>Size of the clipboard image without keeping it (for the New Document dialog).</summary>
    public static (int w, int h)? ImageSize()
    {
        var img = GetImage();
        return img == null ? null : (img.Value.w, img.Value.h);
    }

    static IEnumerable<string> FilePaths()
    {
        var cb = Board;
        var formats = Formats();
        if (cb == null) yield break;
        object data = null;
        if (formats.Contains(DataFormats.Files)) { try { data = UiWait.Wait(cb.GetDataAsync(DataFormats.Files)); } catch { } }
        if (data is IEnumerable<IStorageItem> items)
            foreach (var i in items) { var p = i.TryGetLocalPath(); if (p != null) yield return p; }
        if (formats.Contains("text/uri-list"))
        {
            string list = null;
            try
            {
                var raw = UiWait.Wait(cb.GetDataAsync("text/uri-list"));
                list = raw as string ?? (raw is byte[] b ? System.Text.Encoding.UTF8.GetString(b) : null);
            }
            catch { }
            if (list != null)
                foreach (var line in list.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                    if (Uri.TryCreate(line, UriKind.Absolute, out var u) && u.IsFile) yield return u.LocalPath;
        }
    }

    static byte[] ToBytes(Stream s)
    {
        using var ms = new MemoryStream();
        s.CopyTo(ms);
        return ms.ToArray();
    }
}

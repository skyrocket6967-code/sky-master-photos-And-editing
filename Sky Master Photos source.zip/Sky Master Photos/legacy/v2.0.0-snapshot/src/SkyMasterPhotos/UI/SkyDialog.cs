using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;

namespace SkyMasterPhotos.UI;

public enum SaveChoice { Save, DontSave, Cancel }

/// <summary>
/// Frameless, rounded dialog shell used by every popup window in the app. ShowDialog() is synchronous
/// (like WPF) and DialogResult closes the window. On Linux the frame is opaque so it renders correctly
/// without a compositor (VMs, tiling window managers).
/// </summary>
public class SkyDialog : Window
{
    readonly ContentControl _body = new();
    readonly DockPanel _footer = new() { LastChildFill = false };
    readonly StackPanel _footerRight = new() { Orientation = Orientation.Horizontal };
    readonly StackPanel _footerLeft = new() { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
    readonly TextBlock _title = new();
    readonly TextBlock _subtitle = new();
    readonly Window _owner;
    bool? _result;
    public Button DefaultButton { get; private set; }

    static bool Transparent => OperatingSystem.IsWindows() || OperatingSystem.IsMacOS();

    public SkyDialog(Window owner, string title, string subtitle = null)
    {
        _owner = owner ?? App.MainWin;
        SystemDecorations = SystemDecorations.None;
        CanResize = false;
        ShowInTaskbar = false;
        SizeToContent = SizeToContent.WidthAndHeight;
        WindowStartupLocation = _owner != null && _owner.IsVisible ? WindowStartupLocation.CenterOwner : WindowStartupLocation.CenterScreen;
        if (Transparent)
        {
            TransparencyLevelHint = new[] { WindowTransparencyLevel.Transparent };
            Background = Brushes.Transparent;
        }
        else Background = R<IBrush>("Bg1");
        FontFamily = R<FontFamily>("UiFont") ?? FontFamily.Default;
        Foreground = R<IBrush>("Text");
        UseLayoutRounding = true;
        Title = title;

        _title.Text = title;
        _title.Classes.Add("H2");
        _subtitle.Text = subtitle ?? "";
        _subtitle.Classes.Add("Muted");
        _subtitle.Margin = new Thickness(0, 3, 0, 0);
        _subtitle.IsVisible = !string.IsNullOrEmpty(subtitle);
        _subtitle.TextWrapping = TextWrapping.Wrap;
        _subtitle.MaxWidth = 520;

        var close = new Button { Content = new Ico("close", 16), HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top };
        close.Classes.Add("IconBtn");
        close.Click += (_, _) => DialogResult = false;

        var header = new Grid { Margin = new Thickness(24, 20, 16, 0), Background = Brushes.Transparent };
        header.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
        header.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
        var titles = new StackPanel();
        titles.Children.Add(_title);
        titles.Children.Add(_subtitle);
        header.Children.Add(titles);
        Grid.SetColumn(close, 1);
        header.Children.Add(close);
        header.PointerPressed += (_, e) => { if (e.GetCurrentPoint(this).Properties.IsLeftButtonPressed) try { BeginMoveDrag(e); } catch { } };

        _body.Margin = new Thickness(24, 16, 24, 0);
        _footer.Margin = new Thickness(24, 20, 24, 22);
        DockPanel.SetDock(_footerLeft, Dock.Left);
        DockPanel.SetDock(_footerRight, Dock.Right);
        _footer.Children.Add(_footerLeft);
        _footer.Children.Add(_footerRight);

        var stack = new DockPanel { LastChildFill = true };
        DockPanel.SetDock(header, Dock.Top);
        DockPanel.SetDock(_footer, Dock.Bottom);
        stack.Children.Add(header);
        stack.Children.Add(_footer);
        stack.Children.Add(_body);

        // accent hairline on top
        var accent = new Border { Height = 2, Background = R<IBrush>("AccentGradH"), VerticalAlignment = VerticalAlignment.Top, CornerRadius = Transparent ? new CornerRadius(16, 16, 0, 0) : default, Opacity = 0.9 };
        var grid = new Grid();
        grid.Children.Add(stack);
        grid.Children.Add(accent);

        Content = new Border
        {
            Margin = Transparent ? new Thickness(28) : new Thickness(0),
            Background = R<IBrush>("Bg1"),
            BorderBrush = R<IBrush>("Line2"),
            BorderThickness = new Thickness(1),
            CornerRadius = Transparent ? new CornerRadius(16) : default,
            BoxShadow = Transparent && Application.Current.TryGetResource("Shadow", null, out var sh) && sh is BoxShadows bs ? bs : default,
            Child = grid,
            ClipToBounds = false,
        };

        AddHandler(KeyDownEvent, (_, e) =>
        {
            if (e.Key == Key.Escape) { DialogResult = false; e.Handled = true; }
            else if (e.Key == Key.Enter && DefaultButton != null && !(FocusManager?.GetFocusedElement() is TextBox tb && tb.AcceptsReturn))
            {
                DefaultButton.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
                e.Handled = true;
            }
        }, RoutingStrategies.Tunnel);
    }

    /// <summary>Setting it closes the dialog (WPF semantics).</summary>
    public bool? DialogResult
    {
        get => _result;
        set { _result = value; Close(); }
    }

    /// <summary>Shows modally and waits (the UI keeps running) — returns DialogResult.</summary>
    public bool? ShowDialog()
    {
        var owner = _owner;
        if (owner != null && owner.IsVisible && owner != this)
            UiWait.Wait(ShowDialog(owner));
        else
        {
            var tcs = new TaskCompletionSource();
            Closed += (_, _) => tcs.TrySetResult();
            Show();
            UiWait.Wait(tcs.Task);
        }
        return _result;
    }

    public object Body { get => _body.Content; set => _body.Content = value; }

    public Button AddButton(string text, bool primary, Action onClick)
    {
        var b = new Button { Content = text, Margin = new Thickness(10, 0, 0, 0), MinWidth = 96, HorizontalContentAlignment = HorizontalAlignment.Center };
        b.Classes.Add(primary ? "Primary" : "Secondary");
        b.Click += (_, _) => onClick?.Invoke();
        _footerRight.Children.Add(b);
        if (primary) DefaultButton = b;
        return b;
    }

    public void AddFooterLeft(Control e) => _footerLeft.Children.Add(e);

    public static T R<T>(string key) where T : class => UIx.R<T>(key);

    // ───────────────────────────── stock dialogs ─────────────────────────────

    public static void Alert(Window owner, string title, string message)
    {
        var d = new SkyDialog(owner, title);
        d.Body = new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap, MaxWidth = 440, Foreground = R<IBrush>("Text2"), FontSize = 13, LineHeight = 20 };
        d.AddButton("OK", true, () => d.DialogResult = true);
        d.ShowDialog();
    }

    public static bool Confirm(Window owner, string title, string message, string yes = "OK", string no = "Cancel")
    {
        var d = new SkyDialog(owner, title);
        d.Body = new TextBlock { Text = message, TextWrapping = TextWrapping.Wrap, MaxWidth = 440, Foreground = R<IBrush>("Text2"), FontSize = 13, LineHeight = 20 };
        d.AddButton(no, false, () => d.DialogResult = false);
        d.AddButton(yes, true, () => d.DialogResult = true);
        return d.ShowDialog() == true;
    }

    public static SaveChoice AskSave(Window owner, string docName)
    {
        var result = SaveChoice.Cancel;
        var d = new SkyDialog(owner, "Save changes?", $"“{docName}” has unsaved changes.");
        d.Body = new TextBlock { Text = "If you don't save, your changes since the last save will be lost.", TextWrapping = TextWrapping.Wrap, MaxWidth = 420, Foreground = R<IBrush>("Text2"), FontSize = 13 };
        d.AddButton("Cancel", false, () => { result = SaveChoice.Cancel; d.DialogResult = false; });
        d.AddButton("Don't save", false, () => { result = SaveChoice.DontSave; d.DialogResult = true; });
        d.AddButton("Save", true, () => { result = SaveChoice.Save; d.DialogResult = true; });
        d.ShowDialog();
        return result;
    }

    public static string Prompt(Window owner, string title, string label, string value)
    {
        var d = new SkyDialog(owner, title);
        var sp = new StackPanel { Width = 360 };
        sp.Children.Add(new TextBlock { Text = label, Foreground = R<IBrush>("Text2"), Margin = new Thickness(0, 0, 0, 6), FontSize = 12 });
        var tb = new TextBox { Text = value };
        sp.Children.Add(tb);
        d.Body = sp;
        string result = null;
        d.AddButton("Cancel", false, () => d.DialogResult = false);
        d.AddButton("OK", true, () => { result = tb.Text; d.DialogResult = true; });
        d.Opened += (_, _) => { tb.Focus(); tb.SelectAll(); };
        return d.ShowDialog() == true ? result : null;
    }
}

using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Documents;
using Avalonia.Media;

namespace SkyMasterPhotos.UI;

/// <summary>Crisp stroke icon drawn from a 24×24 path, colored by the inherited Foreground.</summary>
public sealed class Ico : Control
{
    public static readonly StyledProperty<string> KindProperty = AvaloniaProperty.Register<Ico, string>(nameof(Kind), "");
    public static readonly StyledProperty<IBrush> ForegroundProperty = TextElement.ForegroundProperty.AddOwner<Ico>();
    public static readonly StyledProperty<double> ThicknessProperty = AvaloniaProperty.Register<Ico, double>(nameof(Thickness), 1.6);
    public static readonly StyledProperty<IBrush> FillProperty = AvaloniaProperty.Register<Ico, IBrush>(nameof(Fill));

    static Ico() => AffectsRender<Ico>(KindProperty, ForegroundProperty, ThicknessProperty, FillProperty);

    public string Kind { get => GetValue(KindProperty); set => SetValue(KindProperty, value); }
    public IBrush Foreground { get => GetValue(ForegroundProperty); set => SetValue(ForegroundProperty, value); }
    public double Thickness { get => GetValue(ThicknessProperty); set => SetValue(ThicknessProperty, value); }
    public IBrush Fill { get => GetValue(FillProperty); set => SetValue(FillProperty, value); }

    public Ico()
    {
        Width = 18;
        Height = 18;
    }

    public Ico(string kind, double size = 18) : this()
    {
        Kind = kind;
        Width = size;
        Height = size;
    }

    static readonly Dictionary<string, Geometry> Cache = new();

    public static Geometry Geo(string kind)
    {
        if (string.IsNullOrEmpty(kind) || !Icons.Data.TryGetValue(kind, out var data)) return null;
        if (!Cache.TryGetValue(kind, out var g))
        {
            g = Geometry.Parse(data);
            Cache[kind] = g;
        }
        return g;
    }

    public override void Render(DrawingContext dc)
    {
        var g = Geo(Kind);
        if (g == null) return;
        double w = Bounds.Width, h = Bounds.Height;
        double s = Math.Min(w, h) / 24.0;
        if (s <= 0) return;
        double ox = (w - 24 * s) / 2, oy = (h - 24 * s) / 2;
        var brush = Foreground ?? Brushes.White;
        bool dashed = Icons.Dashed.Contains(Kind);
        // stroke width stays in screen pixels whatever the icon size
        var pen = new Pen(brush, Thickness / s, dashed ? new DashStyle(new double[] { 1.6, 1.6 }, 0) : null,
            dashed ? PenLineCap.Flat : PenLineCap.Round, PenLineJoin.Round);
        using (dc.PushTransform(Matrix.CreateScale(s, s) * Matrix.CreateTranslation(ox, oy)))
            dc.DrawGeometry(Fill ?? (Icons.Filled.Contains(Kind) ? brush : null), pen, g);
    }
}

public static class Icons
{
    public static readonly HashSet<string> Dashed = new() { "marquee", "ellipse-marquee" };
    public static readonly HashSet<string> Filled = new() { };

    public static readonly Dictionary<string, string> Data = new()
    {
        ["move"] = "M12 3v18M3 12h18M12 3l-3 3M12 3l3 3M12 21l-3-3M12 21l3-3M3 12l3-3M3 12l3 3M21 12l-3-3M21 12l-3 3",
        ["marquee"] = "M4 4h16v16H4z",
        ["ellipse-marquee"] = "M12 4a8 8 0 1 0 0 16a8 8 0 1 0 0-16z",
        ["lasso"] = "M7 16.5C3.5 14.8 3 11.5 4.6 9 6.6 5.8 11 4.5 15 5.2c4 .7 6 3.4 5.2 6.2-.9 3.2-5.6 5-10.2 4.6M9.5 16.2c-1.6.5-2.3 1.9-1.4 3 .7.9.4 2-.8 2.6",
        ["polylasso"] = "M5 18L4 8l7-4 9 5-3 9zM5 18h.01",
        ["wand"] = "M4 20L15 9M17 3v3M17 12v3M20 9h2.5M11.5 9h2.5M19.5 6.5l1.5-1.5M14.5 6.5L13 5M19.5 11.5l1.5 1.5",
        ["crop"] = "M6 2v16h16M2 6h16v16",
        ["eyedropper"] = "M16.5 3a2.1 2.1 0 0 1 3 3l-2 2-3-3zM13 6.5l4.5 4.5M14.5 7.5l-9 9L4 20l3.5-1.5 9-9",
        ["heal"] = "M4.5 14.5l10-10a3.5 3.5 0 0 1 5 5l-10 10a3.5 3.5 0 0 1-5-5zM9.5 9.5l5 5M11 13h.01M13 11h.01",
        ["brush"] = "M19 3l2 2-9.5 9.5-2.5-.5-.5-2.5zM9 13c-2.5 0-4 1.5-4 3.5S4 20 2.5 21c3.5.5 9 0 9-4.5",
        ["pencil"] = "M16.5 3.5l4 4L8 20H4v-4zM14 6l4 4",
        ["clone"] = "M9 3h6v5c0 2 4 2 4 5v2H5v-2c0-3 4-3 4-5zM4 18h16v3H4z",
        ["eraser"] = "M8 20h12M5.5 16.5l9-9a2 2 0 0 1 2.8 0l2.2 2.2a2 2 0 0 1 0 2.8L12 20H8.5l-3-3a.7.7 0 0 1 0-1zM10 12l5 5",
        ["gradient"] = "M4 4h16v16H4zM4 20L20 4M8 4l-4 4M12 4l-8 8M16 4L4 16",
        ["bucket"] = "M5 11l7-7 7 7-7 7zM5 11h14M20.5 15s1.5 2 1.5 3a1.5 1.5 0 0 1-3 0c0-1 1.5-3 1.5-3z",
        ["blur"] = "M12 3s-6 7-6 11a6 6 0 0 0 12 0c0-4-6-11-6-11z",
        ["sharpen"] = "M12 3l8 17H4z",
        ["smudge"] = "M8 21v-9.5a1.5 1.5 0 0 1 3 0V14M11 11a1.5 1.5 0 0 1 3 0v3M14 11.5a1.5 1.5 0 0 1 3 0V14M17 12.5a1.5 1.5 0 0 1 3 0V16a5 5 0 0 1-5 5H8M8 7V3",
        ["dodge"] = "M8 7a4 4 0 1 0 8 0a4 4 0 1 0-8 0zM12 11v10",
        ["burn"] = "M7 13c0-3 1-5 5-5s5 2 5 5l-1.5 8h-7zM9 8V5M12 8V3M15 8V5",
        ["sponge"] = "M5 7h14v12H5zM9 11h.01M14 10h.01M11 15h.01M16 15h.01M8 16h.01",
        ["text"] = "M5 6V4h14v2M12 4v16M9 20h6",
        ["rect"] = "M4 6h16v12H4z",
        ["ellipse"] = "M3 12a9 7 0 1 0 18 0a9 7 0 1 0-18 0z",
        ["line"] = "M4 20L20 4",
        ["hand"] = "M8 13V5.5a1.5 1.5 0 0 1 3 0V11M11 5V3.5a1.5 1.5 0 0 1 3 0V11M14 5.5a1.5 1.5 0 0 1 3 0V12M17 8.5a1.5 1.5 0 0 1 3 0V15a7 7 0 0 1-7 7c-3 0-4.5-1.5-6.5-4.5L4 14a1.6 1.6 0 0 1 2.6-1.8L8 14",
        ["zoom"] = "M4 10.5a6.5 6.5 0 1 0 13 0a6.5 6.5 0 1 0-13 0zM15.5 15.5L21 21M8 10.5h5M10.5 8v5",
        ["eye"] = "M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12zM9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0z",
        ["eyeoff"] = "M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-2.6 3.4M6.6 6.6C3.8 8.4 2 12 2 12s3.5 7 10 7c1.9 0 3.5-.6 4.9-1.4M9.9 9.9a3 3 0 0 0 4.2 4.2",
        ["plus"] = "M12 5v14M5 12h14",
        ["minus"] = "M5 12h14",
        ["trash"] = "M4 7h16M10 11v6M14 11v6M5 7l1 13h12l1-13M9 7V4h6v3",
        ["duplicate"] = "M8 8h12v12H8zM16 8V4H4v12h4",
        ["merge"] = "M12 3v8M8 7l4 4 4-4M5 14h14v6H5z",
        ["up"] = "M12 19V5M6 11l6-6 6 6",
        ["down"] = "M12 5v14M6 13l6 6 6-6",
        ["undo"] = "M9 14L4 9l5-5M4 9h11a5 5 0 0 1 0 10h-3",
        ["redo"] = "M15 14l5-5-5-5M20 9H9a5 5 0 0 0 0 10h3",
        ["folder"] = "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
        ["new"] = "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5M12 11v6M9 14h6",
        ["save"] = "M5 3h11l5 5v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zM7 3v6h9V3M7 21v-7h10v7",
        ["export"] = "M12 15V3M7 8l5-5 5 5M5 14v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5",
        ["image"] = "M3 5h18v14H3zM3 16l5-5 4 4 3-3 6 6M15.5 8.5h.01",
        ["sparkle"] = "M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z",
        ["cutout"] = "M12 4a3.5 3.5 0 1 0 0 7a3.5 3.5 0 1 0 0-7zM5 20c0-4 3-6.5 7-6.5s7 2.5 7 6.5M2 2h3M2 2v3M22 2h-3M22 2v3",
        ["home"] = "M3 11l9-7 9 7v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z",
        ["close"] = "M6 6l12 12M18 6L6 18",
        ["win-min"] = "M6 12h12",
        ["win-max"] = "M6 6h12v12H6z",
        ["win-restore"] = "M8 9h10v10H8zM6 15V6h9",
        ["swap"] = "M7 4L4 7l3 3M4 7h11a3 3 0 0 1 3 3v1M17 20l3-3-3-3M20 17H9a3 3 0 0 1-3-3v-1",
        ["lock"] = "M6 11h12v10H6zM8 11V7a4 4 0 0 1 8 0v4",
        ["unlock"] = "M6 11h12v10H6zM8 11V7a4 4 0 0 1 7.7-1.5",
        ["check"] = "M5 12l5 5L20 7",
        ["brightness"] = "M12 8a4 4 0 1 0 0 8a4 4 0 1 0 0-8zM12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4",
        ["levels"] = "M4 20h16M6 20v-6M10 20V8M14 20v-9M18 20v-4",
        ["curves"] = "M4 20C10 20 14 4 20 4M4 4v16h16",
        ["exposure"] = "M4 4h16v16H4zM4 20L20 4M6.5 8h4M8.5 6v4M13.5 16h4",
        ["vibrance"] = "M12 4L3 19h18zM12 10v4M12 16.5h.01",
        ["huesat"] = "M12 3a9 9 0 0 0 0 18c1.5 0 2-1 2-2 0-1.5-1-1.5-1-3s1-2 2.5-2H18a3 3 0 0 0 3-3c0-4.4-4-8-9-8zM7.5 11h.01M10 7h.01M15 7.5h.01",
        ["colorbalance"] = "M12 3v18M5 7h14M5 7l-3 6a3 3 0 0 0 6 0zM19 7l-3 6a3 3 0 0 0 6 0zM8 21h8",
        ["bw"] = "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 3v18M12 8h4.5M12 12h6M12 16h4.5",
        ["photofilter"] = "M12 3a5 5 0 1 0 0 10a5 5 0 1 0 0-10zM8.5 11.5a5 5 0 1 0 3.5 7.5M15.5 11.5a5 5 0 1 1-3.5 7.5",
        ["invert"] = "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 3v18M12 7a5 5 0 0 0 0 10",
        ["posterize"] = "M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z",
        ["threshold"] = "M3 12h6V5h6v14h6",
        ["temp"] = "M14 14.8V5a2 2 0 0 0-4 0v9.8a4 4 0 1 0 4 0zM12 9v7",
        ["shadows"] = "M20 14.5A8 8 0 1 1 9.5 4a6.5 6.5 0 0 0 10.5 10.5z",
        ["gradientmap"] = "M4 7h16M4 12h16M4 17h16M7 4v16",
        ["sepia"] = "M4 8h3l2-3h6l2 3h3v11H4zM12 10a3.5 3.5 0 1 0 0 7a3.5 3.5 0 1 0 0-7z",
        ["layers"] = "M12 3l9 5-9 5-9-5zM3 12.5l9 5 9-5M3 16.5l9 5 9-5",
        ["history"] = "M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l3 3",
        ["navigator"] = "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM15.5 8.5l-2 5-5 2 2-5z",
        ["filter"] = "M4 5h16l-6 8v6l-4 2v-8z",
        ["more"] = "M5 12h.01M12 12h.01M19 12h.01",
        ["chev-down"] = "M7 10l5 5 5-5",
        ["chev-right"] = "M10 7l5 5-5 5",
        ["link"] = "M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7L11.5 6.8M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1.5-1.5",
        ["fliph"] = "M12 3v18M9 7L4 17h5zM15 7l5 10h-5z",
        ["flipv"] = "M3 12h18M7 9l10-5v5zM7 15l10 5v-5z",
        ["rotate"] = "M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7",
        ["rotate-left"] = "M4 11a8 8 0 1 1 2.3 5.7M4 4v7h7",
        ["help"] = "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.5V14M12 17h.01",
        ["info"] = "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 11v6M12 7.5h.01",
        ["keyboard"] = "M3 6h18v12H3zM7 10h.01M11 10h.01M15 10h.01M7 14h10",
        ["fit"] = "M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5",
        ["selectall"] = "M4 4h16v16H4zM8 8h8v8H8z",
        ["deselect"] = "M4 4h16v16H4zM8 8l8 8M16 8l-8 8",
        ["noise"] = "M5 5h.01M9 7h.01M14 5h.01M19 6h.01M6 11h.01M11 10h.01M16 12h.01M19 10h.01M5 17h.01M9 15h.01M13 18h.01M18 17h.01",
        ["paste"] = "M9 4h6v3H9zM8 5H6v16h12V5h-2",
        ["transform"] = "M5 5h14v14H5zM3 3h4v4H3zM17 3h4v4h-4zM3 17h4v4H3zM17 17h4v4h-4z",
        ["sliders"] = "M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4",
        ["spotheal"] = "M4.5 14.5l10-10a3.5 3.5 0 0 1 5 5l-10 10a3.5 3.5 0 0 1-5-5zM9.5 9.5l5 5M19.5 15.5l.6 1.6 1.6.6-1.6.6-.6 1.6-.6-1.6-1.6-.6 1.6-.6z",
        ["mask"] = "M3 5h18v14H3zM12 8a4 4 0 1 0 0 8a4 4 0 1 0 0-8z",
        ["clip"] = "M7 4v7a5 5 0 0 0 5 5h8M16 12l4 4-4 4",
        ["adjlayer"] = "M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 3v18M12 3a9 9 0 0 1 0 18",
        ["contentaware"] = "M4 4h6M4 4v6M20 4h-6M20 4v6M4 20h6M4 20v-6M20 20h-6M20 20v-6M12 8l1.2 2.8L16 12l-2.8 1.2L12 16l-1.2-2.8L8 12l2.8-1.2z",
        ["folder-group"] = "M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z",
        ["drop"] = "M12 3s-6 7-6 11a6 6 0 0 0 12 0c0-4-6-11-6-11z",
    };
}

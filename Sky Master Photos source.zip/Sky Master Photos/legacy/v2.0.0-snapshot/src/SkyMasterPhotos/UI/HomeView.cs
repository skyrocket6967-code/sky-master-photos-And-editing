using Avalonia;
using Avalonia.Animation;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Media.Transformation;
using Avalonia.Controls.Shapes;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

/// <summary>Start screen: hero, quick-start presets, open documents and recent files with thumbnails.</summary>
public sealed class HomeView : Grid
{
    public Action NewDoc;
    public Action<int, int, string> NewPreset;
    public Action Open;
    public Action<string> OpenRecent;
    public Action<Document> ResumeDoc;
    public Action Shortcuts;
    public Action About;
    public Func<IEnumerable<Document>> OpenDocs;

    readonly StackPanel _main = new() { Margin = new Thickness(44, 34, 44, 40) };

    public HomeView()
    {
        ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(258) });
        ColumnDefinitions.Add(new ColumnDefinition());
        Children.Add(BuildSidebar());
        var sv = new ScrollViewer { Content = _main, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        Grid.SetColumn(sv, 1);
        Children.Add(sv);
    }

    static T R<T>(string k) where T : class => UIx.R<T>(k);

    Control BuildSidebar()
    {
        var b = new Border { Background = R<Brush>("Bg1"), BorderBrush = R<Brush>("Line"), BorderThickness = new Thickness(0, 1, 1, 0) };
        var dp = new DockPanel { Margin = new Thickness(20, 26, 20, 20) };
        b.Child = dp;

        var top = new StackPanel();
        DockPanel.SetDock(top, Dock.Top);
        dp.Children.Add(top);
        var brand = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(4, 0, 0, 26) };
        brand.Children.Add(new Image { Source = UIx.Asset("logo.png"), Width = 40, Height = 40 });
        var names = new StackPanel { Margin = new Thickness(12, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
        names.Children.Add(new TextBlock { Text = "Sky Photo", FontFamily = R<FontFamily>("DisplayFont"), FontSize = 19, FontWeight = FontWeights.SemiBold, Foreground = R<Brush>("Text") });
        names.Children.Add(new TextBlock { Text = "Sky Master Photos", FontSize = 11.5, Foreground = R<Brush>("Text3") });
        brand.Children.Add(names);
        top.Children.Add(brand);

        var newBtn = new Button { Style = R<Style>("Primary"), HorizontalAlignment = HorizontalAlignment.Stretch, Padding = new Thickness(14, 11, 14, 11) };
        var nb = new StackPanel { Orientation = Orientation.Horizontal };
        nb.Children.Add(new Ico("plus", 16) { Foreground = Brushes.White, Margin = new Thickness(0, 0, 8, 0) });
        nb.Children.Add(new TextBlock { Text = "New file", FontSize = 13.5 });
        newBtn.Content = nb;
        newBtn.Click += (_, _) => NewDoc?.Invoke();
        top.Children.Add(newBtn);

        var openBtn = new Button { Style = R<Style>("Secondary"), HorizontalAlignment = HorizontalAlignment.Stretch, Padding = new Thickness(14, 10, 14, 10), Margin = new Thickness(0, 10, 0, 22) };
        var ob = new StackPanel { Orientation = Orientation.Horizontal };
        ob.Children.Add(new Ico("folder", 16) { Margin = new Thickness(0, 0, 8, 0) });
        ob.Children.Add(new TextBlock { Text = "Open…", FontSize = 13.5 });
        openBtn.Content = ob;
        openBtn.Click += (_, _) => Open?.Invoke();
        top.Children.Add(openBtn);

        top.Children.Add(NavItem("home", "Home", true, null));
        top.Children.Add(NavItem("keyboard", "Keyboard shortcuts", false, () => Shortcuts?.Invoke()));
        top.Children.Add(NavItem("info", "About Sky Photo", false, () => About?.Invoke()));

        var bottom = new Border
        {
            Background = R<Brush>("Bg2"), CornerRadius = new CornerRadius(14), Padding = new Thickness(14), BorderBrush = R<Brush>("Line"), BorderThickness = new Thickness(1)
        };
        var bs = new StackPanel();
        bs.Children.Add(new TextBlock { Text = "Pro tip", FontWeight = FontWeights.SemiBold, Foreground = R<Brush>("Text"), FontSize = 12.5 });
        bs.Children.Add(new TextBlock { Text = "Drag images or Photoshop PSDs onto the window to open them — layers, masks and adjustment layers stay editable.", TextWrapping = TextWrapping.Wrap, Foreground = R<Brush>("Text3"), FontSize = 11.5, Margin = new Thickness(0, 4, 0, 0), LineHeight = 17 });
        bottom.Child = bs;
        DockPanel.SetDock(bottom, Dock.Bottom);
        var ver = new TextBlock { Text = "Version " + (typeof(HomeView).Assembly.GetName().Version?.ToString(3) ?? "2.0.0") + (OperatingSystem.IsLinux() ? "  ·  Linux" : ""), Foreground = R<Brush>("Text3"), FontSize = 11, Margin = new Thickness(4, 12, 0, 0) };
        DockPanel.SetDock(ver, Dock.Bottom);
        dp.Children.Add(ver);
        dp.Children.Add(bottom);
        dp.Children.Add(new Border());
        return b;
    }

    Control NavItem(string icon, string text, bool selected, Action click)
    {
        var sp = new StackPanel { Orientation = Orientation.Horizontal };
        sp.Children.Add(new Ico(icon, 16) { Margin = new Thickness(0, 0, 12, 0) });
        sp.Children.Add(new TextBlock { Text = text, FontSize = 13 });
        var b = new Avalonia.Controls.Primitives.ToggleButton { Content = sp, Style = R<Style>("Ghost"), HorizontalContentAlignment = HorizontalAlignment.Left, Padding = new Thickness(12, 9, 12, 9), IsChecked = selected, Margin = new Thickness(0, 0, 0, 3) };
        b.Click += (_, _) => { b.IsChecked = selected; click?.Invoke(); };
        return b;
    }

    public void Refresh()
    {
        _main.Children.Clear();
        _main.Children.Add(BuildHero());

        var docs = OpenDocs?.Invoke()?.ToList() ?? new List<Document>();
        if (docs.Count > 0)
        {
            _main.Children.Add(SectionTitle("Continue editing", $"{docs.Count} open"));
            var wp = new WrapPanel();
            foreach (var d in docs) wp.Children.Add(FileCard(d.Thumbnail, d.TabTitle, $"{d.Width} × {d.Height}  ·  {d.Layers.Count} layer{(d.Layers.Count == 1 ? "" : "s")}", "OPEN", () => ResumeDoc?.Invoke(d), null));
            _main.Children.Add(wp);
        }

        _main.Children.Add(SectionTitle("Start something new", null));
        var presets = new WrapPanel();
        foreach (var p in NewDocumentDialog.Presets.Take(8)) presets.Children.Add(PresetCard(p));
        _main.Children.Add(presets);

        var recent = AppStore.GetRecent();
        _main.Children.Add(SectionTitle("Recent", recent.Count > 0 ? $"{recent.Count} file{(recent.Count == 1 ? "" : "s")}" : null));
        if (recent.Count == 0)
        {
            var empty = new Border
            {
                CornerRadius = new CornerRadius(18), BorderBrush = R<Brush>("Line2"), BorderThickness = new Thickness(1.5), Padding = new Thickness(30), Background = R<Brush>("Bg1"),
                Margin = new Thickness(0, 0, 20, 0)
            };
            var es = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            es.Children.Add(new Ico("image", 40) { Foreground = R<Brush>("Text3"), Thickness = 1.3, HorizontalAlignment = HorizontalAlignment.Center });
            es.Children.Add(new TextBlock { Text = "No recent files yet", Style = R<Style>("H2"), FontSize = 15, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0, 12, 0, 4) });
            es.Children.Add(new TextBlock { Text = "Files you open or save will show up here with a preview.", Foreground = R<Brush>("Text3"), HorizontalAlignment = HorizontalAlignment.Center });
            empty.Child = es;
            _main.Children.Add(empty);
        }
        else
        {
            var wp = new WrapPanel();
            foreach (var r in recent)
            {
                var item = r;
                var menu = new ContextMenu();
                menu.Items.Add(UIx.Item("Open", () => OpenRecent?.Invoke(item.Path), null, "folder"));
                menu.Items.Add(UIx.Item(OperatingSystem.IsWindows() ? "Show in Explorer" : "Show in folder", () => UIx.Reveal(item.Path), null, "image"));
                menu.Items.Add(new Separator());
                menu.Items.Add(UIx.Item("Remove from recent", () => { AppStore.RemoveRecent(item.Path); Refresh(); }, null, "close"));
                wp.Children.Add(FileCard(item.Thumb, item.Name, item.Info, item.Kind, () => OpenRecent?.Invoke(item.Path), menu));
            }
            _main.Children.Add(wp);
        }
    }

    Control BuildHero()
    {
        var g = new Grid { Height = 210, Margin = new Thickness(0, 0, 20, 34), ClipToBounds = true };
        var bg = new Border
        {
            CornerRadius = new CornerRadius(24),
            Background = new LinearGradientBrush
            {
                StartPoint = new RelativePoint(0, 0, RelativeUnit.Relative), EndPoint = new RelativePoint(1, 0, RelativeUnit.Relative),
                GradientStops = { new GradientStop(Color.FromRgb(0x16, 0x1B, 0x2E), 0), new GradientStop(Color.FromRgb(0x1C, 0x14, 0x30), 1) },
            }
        };
        g.Children.Add(bg);
        // glow orbs
        var orbs = new Canvas { ClipToBounds = true };
        void Orb(double x, double y, double s, Color c, double op)
        {
            var e = new Ellipse { Width = s, Height = s, Fill = new RadialGradientBrush { GradientStops = { new GradientStop(Color.FromArgb((byte)(op * 255), c.R, c.G, c.B), 0), new GradientStop(Color.FromArgb(0, c.R, c.G, c.B), 1) } } };
            Canvas.SetLeft(e, x); Canvas.SetTop(e, y);
            orbs.Children.Add(e);
        }
        Orb(-80, -120, 420, Color.FromRgb(0x38, 0xBD, 0xF8), 0.35);
        Orb(520, -60, 380, Color.FromRgb(0x5B, 0x8C, 0xFF), 0.35);
        Orb(900, -40, 420, Color.FromRgb(0xA4, 0x6B, 0xFF), 0.4);
        g.Children.Add(orbs);
        g.SizeChanged += (_, _) => g.Clip = new RectangleGeometry(new Rect(0, 0, g.ActualWidth, g.ActualHeight)) { RadiusX = 24, RadiusY = 24 };
        g.Children.Add(new Border { CornerRadius = new CornerRadius(24), BorderBrush = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)), BorderThickness = new Thickness(1) });

        var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(40, 0, 40, 0) };
        sp.Children.Add(new TextBlock { Text = Greeting(), Foreground = new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)), FontSize = 13, Margin = new Thickness(0, 0, 0, 6) });
        sp.Children.Add(new TextBlock { Text = "Create something stunning.", Style = R<Style>("H1"), FontSize = 34 });
        sp.Children.Add(new TextBlock { Text = "Edit photos, design thumbnails and paint — layers, live adjustments and pro tools in one fast editor.", Foreground = new SolidColorBrush(Color.FromArgb(190, 255, 255, 255)), FontSize = 13.5, Margin = new Thickness(0, 8, 0, 18), TextWrapping = TextWrapping.Wrap, MaxWidth = 620, HorizontalAlignment = HorizontalAlignment.Left });
        var btns = new StackPanel { Orientation = Orientation.Horizontal };
        var a = new Button { Content = "New document", Style = R<Style>("Primary") };
        a.Click += (_, _) => NewDoc?.Invoke();
        var b = new Button { Content = "Open image", Style = R<Style>("Secondary"), Margin = new Thickness(10, 0, 0, 0), Background = Brushes.Transparent };
        b.Click += (_, _) => Open?.Invoke();
        btns.Children.Add(a); btns.Children.Add(b);
        sp.Children.Add(btns);
        g.Children.Add(sp);
        return g;
    }

    static string Greeting()
    {
        int h = DateTime.Now.Hour;
        return h < 5 ? "Working late?" : h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
    }

    static Control SectionTitle(string t, string sub)
    {
        var dp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(2, 0, 0, 14) };
        dp.Children.Add(new TextBlock { Text = t, Style = R<Style>("H2") });
        if (sub != null) dp.Children.Add(new TextBlock { Text = sub, Foreground = R<Brush>("Text3"), FontSize = 12, VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(10, 0, 0, 2) });
        return dp;
    }

    Control PresetCard(NewDocumentDialog.Preset p)
    {
        var sp = new StackPanel();
        var area = new Border { Height = 92, CornerRadius = new CornerRadius(12), Background = R<Brush>("Bg0"), Child = NewDocumentDialog.PresetThumb(p.W, p.H, 64) };
        sp.Children.Add(area);
        sp.Children.Add(new TextBlock { Text = p.Name, Foreground = R<Brush>("Text"), FontSize = 12.5, FontWeight = FontWeights.SemiBold, Margin = new Thickness(2, 10, 0, 0), TextTrimming = TextTrimming.CharacterEllipsis });
        sp.Children.Add(new TextBlock { Text = $"{p.W} × {p.H}  ·  {p.Group}", Foreground = R<Brush>("Text3"), FontSize = 11.5, Margin = new Thickness(2, 2, 0, 0) });
        var b = new Button { Content = sp, Style = R<Style>("Secondary"), Width = 170, Margin = new Thickness(0, 0, 14, 14), Padding = new Thickness(10), HorizontalContentAlignment = HorizontalAlignment.Stretch };
        b.Click += (_, _) => NewPreset?.Invoke(p.W, p.H, p.Name);
        Hover(b);
        return b;
    }

    static Control FileCard(IImage thumb, string name, string info, string badge, Action open, ContextMenu menu)
    {
        var sp = new StackPanel();
        var imgArea = new Grid { Height = 150 };
        var bgBorder = new Border { CornerRadius = new CornerRadius(12), Background = UIx.Checker(8, true) };
        imgArea.Children.Add(bgBorder);
        if (thumb != null)
            imgArea.Children.Add(new Border { CornerRadius = new CornerRadius(12), ClipToBounds = true, Child = new Image { Source = thumb, Stretch = Stretch.UniformToFill } });
        else
            imgArea.Children.Add(new Ico("image", 32) { Foreground = R<Brush>("Text3"), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center });
        if (!string.IsNullOrEmpty(badge))
        {
            var bd = new Border { Background = new SolidColorBrush(Color.FromArgb(200, 10, 11, 15)), CornerRadius = new CornerRadius(6), Padding = new Thickness(7, 2, 7, 2), Margin = new Thickness(8), HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top };
            bd.Child = new TextBlock { Text = badge, FontSize = 10, FontWeight = FontWeights.SemiBold, Foreground = R<Brush>("Text2") };
            imgArea.Children.Add(bd);
        }
        sp.Children.Add(imgArea);
        sp.Children.Add(new TextBlock { Text = name, Foreground = R<Brush>("Text"), FontSize = 12.5, FontWeight = FontWeights.SemiBold, Margin = new Thickness(2, 10, 0, 0), TextTrimming = TextTrimming.CharacterEllipsis });
        sp.Children.Add(new TextBlock { Text = info, Foreground = R<Brush>("Text3"), FontSize = 11.5, Margin = new Thickness(2, 2, 0, 2), TextTrimming = TextTrimming.CharacterEllipsis });
        var b = new Button { Content = sp, Style = R<Style>("Secondary"), Width = 236, Margin = new Thickness(0, 0, 16, 16), Padding = new Thickness(8), HorizontalContentAlignment = HorizontalAlignment.Stretch, ContextMenu = menu, ToolTip = name };
        b.Click += (_, _) => open();
        Hover(b);
        return b;
    }

    /// <summary>Cards lift slightly on hover (smooth transform transition).</summary>
    static void Hover(Control e)
    {
        e.RenderTransform = TransformOperations.Parse("translateY(0px)");
        e.Transitions = new Transitions { new TransformOperationsTransition { Property = Visual.RenderTransformProperty, Duration = TimeSpan.FromMilliseconds(160), Easing = new Avalonia.Animation.Easings.CubicEaseOut() } };
        e.PointerEntered += (_, _) => e.RenderTransform = TransformOperations.Parse("translateY(-3px)");
        e.PointerExited += (_, _) => e.RenderTransform = TransformOperations.Parse("translateY(0px)");
    }
}

using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Threading;

namespace SkyMasterPhotos.UI;

// ─────────────────────────────────────────────────────────────────────────────
//  Small WPF-flavoured conveniences on top of Avalonia, so the editor's UI code
//  reads the same as before the cross-platform port (C# 14 extension members).
// ─────────────────────────────────────────────────────────────────────────────

public enum Visibility { Visible, Hidden, Collapsed }

/// <summary>A named look from the theme (applied as a style class: "Primary", "IconBtn", "H2"…).</summary>
public sealed class Style
{
    public readonly string Name;
    public Style(string name) => Name = name;
    public override string ToString() => Name;
}

public static class WpfCompat
{
    extension(Control c)
    {
        /// <summary>WPF visibility on top of IsVisible ("Hidden" keeps layout space and turns the control invisible).</summary>
        public Visibility Visibility
        {
            get => c.IsVisible ? Visibility.Visible : Visibility.Collapsed;
            set
            {
                c.IsVisible = value != Visibility.Collapsed;
                if (value == Visibility.Hidden) c.Opacity = 0;
            }
        }

        public double ActualWidth => c.Bounds.Width;
        public double ActualHeight => c.Bounds.Height;

        public object ToolTip
        {
            get => Avalonia.Controls.ToolTip.GetTip(c);
            set => Avalonia.Controls.ToolTip.SetTip(c, value);
        }

        /// <summary>Applies a theme look by name (replaces any previously applied look).</summary>
        public Style Style
        {
            get => null;
            set
            {
                foreach (var s in KnownStyles) c.Classes.Remove(s);
                if (value != null) c.Classes.Add(value.Name);
            }
        }
    }

    static readonly string[] KnownStyles = { "Ghost", "IconBtn", "ToolBtn", "Primary", "Secondary", "Segment", "WinBtn", "WinCloseBtn", "Danger", "H1", "H2", "PanelTitle", "Muted", "CleanList", "Input" };

    /// <summary>Opens a context menu at its placement target (WPF: IsOpen = true).</summary>
    public static void Show(this ContextMenu m)
    {
        if (m.PlacementTarget is Control t) m.Open(t);
        else if (App.MainWin != null) m.Open(App.MainWin);
    }
}

public static class Cursors
{
    public static readonly Cursor Arrow = new(StandardCursorType.Arrow);
    public static readonly Cursor Hand = new(StandardCursorType.Hand);
    public static readonly Cursor Cross = new(StandardCursorType.Cross);
    public static readonly Cursor IBeam = new(StandardCursorType.Ibeam);
    public static readonly Cursor Wait = new(StandardCursorType.Wait);
    public static readonly Cursor SizeAll = new(StandardCursorType.SizeAll);
    public static readonly Cursor SizeWE = new(StandardCursorType.SizeWestEast);
    public static readonly Cursor SizeNS = new(StandardCursorType.SizeNorthSouth);
    public static readonly Cursor SizeNWSE = new(StandardCursorType.TopLeftCorner);
    public static readonly Cursor SizeNESW = new(StandardCursorType.TopRightCorner);
    public static readonly Cursor ScrollAll = new(StandardCursorType.SizeAll);
    public static readonly Cursor No = new(StandardCursorType.No);
    public static readonly Cursor None = new(StandardCursorType.None);
}

public static class FontWeights
{
    public static readonly FontWeight Normal = FontWeight.Normal, SemiBold = FontWeight.SemiBold, Bold = FontWeight.Bold, Light = FontWeight.Light, Medium = FontWeight.Medium;
}

public static class FontStyles
{
    public static readonly FontStyle Normal = FontStyle.Normal, Italic = FontStyle.Italic;
}

[Flags]
public enum ModifierKeys { None = 0, Alt = 1, Control = 2, Shift = 4, Windows = 8 }

/// <summary>Global keyboard state (the main window feeds modifier changes in).</summary>
public static class Keyboard
{
    public static ModifierKeys Modifiers { get; private set; }

    public static void Update(KeyModifiers m)
    {
        var r = ModifierKeys.None;
        if ((m & KeyModifiers.Alt) != 0) r |= ModifierKeys.Alt;
        if ((m & KeyModifiers.Control) != 0) r |= ModifierKeys.Control;
        // macOS: Cmd acts as Control
        if ((m & KeyModifiers.Meta) != 0 && OperatingSystem.IsMacOS()) r |= ModifierKeys.Control;
        if ((m & KeyModifiers.Shift) != 0) r |= ModifierKeys.Shift;
        Modifiers = r;
    }

    public static ModifierKeys From(KeyModifiers m)
    {
        var r = ModifierKeys.None;
        if ((m & KeyModifiers.Alt) != 0) r |= ModifierKeys.Alt;
        if ((m & KeyModifiers.Control) != 0 || ((m & KeyModifiers.Meta) != 0 && OperatingSystem.IsMacOS())) r |= ModifierKeys.Control;
        if ((m & KeyModifiers.Shift) != 0) r |= ModifierKeys.Shift;
        return r;
    }

    public static IInputElement FocusedElement => (App.ActiveTopLevel)?.FocusManager?.GetFocusedElement();

    public static void ClearFocus() => App.ActiveTopLevel?.FocusManager?.ClearFocus();
}

/// <summary>WPF's Mouse.OverrideCursor: a busy cursor on the main window.</summary>
public static class Mouse
{
    public static Cursor OverrideCursor
    {
        get => App.MainWin?.Cursor;
        set
        {
            if (App.MainWin == null) return;
            App.MainWin.Cursor = value ?? Cursor.Default;
            if (value != null) Dispatcher.UIThread.RunJobs(DispatcherPriority.Render); // show it before the long operation starts
        }
    }
}

/// <summary>Runs async UI work (dialogs, file pickers) to completion while keeping the UI responsive — like WPF's ShowDialog.</summary>
public static class UiWait
{
    public static T Wait<T>(Task<T> task)
    {
        if (!task.IsCompleted)
        {
            using var cts = new CancellationTokenSource();
            task.ContinueWith(_ => Dispatcher.UIThread.Post(cts.Cancel), TaskScheduler.Default);
            Dispatcher.UIThread.MainLoop(cts.Token);
        }
        return task.GetAwaiter().GetResult();
    }

    public static void Wait(Task task)
    {
        if (!task.IsCompleted)
        {
            using var cts = new CancellationTokenSource();
            task.ContinueWith(_ => Dispatcher.UIThread.Post(cts.Cancel), TaskScheduler.Default);
            Dispatcher.UIThread.MainLoop(cts.Token);
        }
        task.GetAwaiter().GetResult();
    }
}

/// <summary>WPF-style mouse button hooks (MouseLeftButtonDown / MouseRightButtonDown / PreviewMouse…).</summary>
public static class PointerHooks
{
    public static void OnLeftDown(this Control c, Action<PointerPressedEventArgs> a, bool preview = false) =>
        c.AddHandler(InputElement.PointerPressedEvent, (_, e) => { if (e.GetCurrentPoint(c).Properties.IsLeftButtonPressed) a(e); },
            preview ? Avalonia.Interactivity.RoutingStrategies.Tunnel : Avalonia.Interactivity.RoutingStrategies.Bubble | Avalonia.Interactivity.RoutingStrategies.Direct);

    public static void OnRightDown(this Control c, Action<PointerPressedEventArgs> a) =>
        c.AddHandler(InputElement.PointerPressedEvent, (_, e) => { if (e.GetCurrentPoint(c).Properties.IsRightButtonPressed) a(e); });

    public static void OnLeftUp(this Control c, Action<PointerReleasedEventArgs> a, bool preview = false) =>
        c.AddHandler(InputElement.PointerReleasedEvent, (_, e) => { if (e.InitialPressMouseButton == MouseButton.Left) a(e); },
            preview ? Avalonia.Interactivity.RoutingStrategies.Tunnel : Avalonia.Interactivity.RoutingStrategies.Bubble | Avalonia.Interactivity.RoutingStrategies.Direct);

    public static void OnRightUp(this Control c, Action<PointerReleasedEventArgs> a, bool preview = false) =>
        c.AddHandler(InputElement.PointerReleasedEvent, (_, e) => { if (e.InitialPressMouseButton == MouseButton.Right) a(e); },
            preview ? Avalonia.Interactivity.RoutingStrategies.Tunnel : Avalonia.Interactivity.RoutingStrategies.Bubble | Avalonia.Interactivity.RoutingStrategies.Direct);

    /// <summary>The list item (data) under an event source.</summary>
    public static T ItemData<T>(object source) where T : class
    {
        for (var v = source as Avalonia.Visual; v != null; v = Avalonia.VisualTree.VisualExtensions.GetVisualParent(v))
            if (v is ListBoxItem li) return li.DataContext as T;
        return null;
    }

    public static bool HasAncestor<T>(object source, Control stopAt = null) where T : class
    {
        for (var v = source as Avalonia.Visual; v != null && v != stopAt; v = Avalonia.VisualTree.VisualExtensions.GetVisualParent(v))
        {
            if (v is T) return true;
            if (v is ListBoxItem) return false;
        }
        return false;
    }
}

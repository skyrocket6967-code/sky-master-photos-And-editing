using System.Globalization;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Media.Imaging;
using Avalonia.Platform;

namespace SkyMasterPhotos.UI;

/// <summary>Small factory helpers for building themed UI from code.</summary>
public static class UIx
{
    /// <summary>Theme resource by key (brushes, fonts…); for <see cref="Style"/> returns the named look.</summary>
    public static T R<T>(string key) where T : class
    {
        if (typeof(T) == typeof(Style)) return new Style(key) as T;
        var app = Application.Current;
        if (app != null && app.TryGetResource(key, app.ActualThemeVariant, out var v)) return v as T;
        return null;
    }

    public static TextBlock Label(string t, double size = 12, string brush = "Text2", FontWeight? weight = null) => new()
    {
        Text = t, FontSize = size, Foreground = R<IBrush>(brush), VerticalAlignment = VerticalAlignment.Center,
        FontWeight = weight ?? FontWeight.Normal
    };

    public static Border VDivider() => new() { Width = 1, Height = 22, Background = R<IBrush>("Line2"), Margin = new Thickness(10, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center };

    /// <summary>Compact "label ─●── 42px" control for the options bar.</summary>
    public static Control OptSlider(string label, double min, double max, double value, Action<double> onChange, string suffix = "", int decimals = 0, double width = 110, Func<double, double> toDisplay = null)
    {
        toDisplay ??= v => v;
        var sp = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 14, 0) };
        sp.Children.Add(Label(label, 12, "Text3"));
        var s = new Slider { Minimum = min, Maximum = max, Value = value, Width = width, Margin = new Thickness(8, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center };
        var box = new TextBox { Width = 56, Padding = new Thickness(6, 3, 6, 3), FontSize = 12, MinHeight = 26, Text = Fmt(toDisplay(value), decimals) + suffix, HorizontalContentAlignment = HorizontalAlignment.Center };
        bool updating = false;
        s.ValueChanged += (_, e) =>
        {
            if (updating) return;
            updating = true;
            box.Text = Fmt(toDisplay(e.NewValue), decimals) + suffix;
            updating = false;
            onChange(e.NewValue);
        };
        void Commit()
        {
            var txt = (box.Text ?? "").Replace(suffix, "").Trim();
            if (double.TryParse(txt, NumberStyles.Float, CultureInfo.InvariantCulture, out double v) || double.TryParse(txt, out v))
            {
                // invert display mapping by search when needed
                double target = v;
                if (toDisplay(1) != 1 || toDisplay(0) != 0)
                {
                    double best = min, bestErr = double.MaxValue;
                    for (int i = 0; i <= 400; i++) { double c = min + (max - min) * i / 400; double err = Math.Abs(toDisplay(c) - v); if (err < bestErr) { bestErr = err; best = c; } }
                    target = best;
                }
                s.Value = Math.Clamp(target, min, max);
            }
            box.Text = Fmt(toDisplay(s.Value), decimals) + suffix;
        }
        box.KeyDown += (_, e) => { if (e.Key == Key.Enter) { Commit(); Keyboard.ClearFocus(); e.Handled = true; } };
        box.LostFocus += (_, _) => Commit();
        sp.Children.Add(s);
        sp.Children.Add(box);
        sp.Tag = s;
        return sp;
    }

    static string Fmt(double v, int decimals) => v.ToString(decimals == 0 ? "0" : "0." + new string('0', decimals), CultureInfo.InvariantCulture);

    /// <summary>Full-width labelled slider row used in dialogs and panels.</summary>
    public static (Control row, Slider slider) SliderRow(string label, double min, double max, double value, Action<double> onChange, int decimals = 0, string suffix = "", double width = 340)
    {
        var g = new Grid { Width = width, Margin = new Thickness(0, 0, 0, 12) };
        g.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
        g.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
        g.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        g.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        var lbl = Label(label, 12.5, "Text2");
        g.Children.Add(lbl);
        var box = new TextBox { Width = 68, Padding = new Thickness(6, 3, 6, 3), FontSize = 12, MinHeight = 26, HorizontalContentAlignment = HorizontalAlignment.Right, Text = Fmt(value, decimals) + suffix, Margin = new Thickness(0, 0, 0, 4) };
        Grid.SetColumn(box, 1);
        g.Children.Add(box);
        var s = new Slider { Minimum = min, Maximum = max, Value = value, Margin = new Thickness(0, 2, 0, 0) };
        if (max - min <= 20 && decimals == 0) { s.TickFrequency = 1; s.IsSnapToTickEnabled = true; }
        Grid.SetRow(s, 1);
        Grid.SetColumnSpan(s, 2);
        g.Children.Add(s);
        bool upd = false;
        s.ValueChanged += (_, e) =>
        {
            if (upd) return;
            upd = true;
            box.Text = Fmt(e.NewValue, decimals) + suffix;
            upd = false;
            onChange(e.NewValue);
        };
        void Commit()
        {
            var txt = (box.Text ?? "").Replace(suffix, "").Trim();
            if (double.TryParse(txt, NumberStyles.Float, CultureInfo.InvariantCulture, out double v) || double.TryParse(txt, out v))
                s.Value = Math.Clamp(v, min, max);
            box.Text = Fmt(s.Value, decimals) + suffix;
        }
        box.KeyDown += (_, e) => { if (e.Key == Key.Enter) { Commit(); e.Handled = true; } };
        box.LostFocus += (_, _) => Commit();
        // double-click label resets
        double def = value;
        lbl.Background = Brushes.Transparent;
        lbl.DoubleTapped += (_, _) => s.Value = def;
        ToolTip.SetTip(lbl, "Double-click to reset");
        return (g, s);
    }

    public static ToggleButton Seg(object content, bool isChecked, Action onClick, string tip = null)
    {
        var t = new ToggleButton { Content = content, IsChecked = isChecked };
        t.Classes.Add("Segment");
        if (tip != null) ToolTip.SetTip(t, tip);
        t.Click += (_, _) => onClick();
        return t;
    }

    /// <summary>A pill containing mutually exclusive segment toggles.</summary>
    public static Border SegGroup(IEnumerable<(object content, string tip)> items, int selected, Action<int> onSelect)
    {
        var sp = new StackPanel { Orientation = Orientation.Horizontal };
        var list = new List<ToggleButton>();
        int i = 0;
        foreach (var (content, tip) in items)
        {
            int idx = i++;
            ToggleButton t = null;
            t = Seg(content, idx == selected, () =>
            {
                foreach (var o in list) o.IsChecked = o == t;
                onSelect(idx);
            }, tip);
            list.Add(t);
            sp.Children.Add(t);
        }
        return new Border { Child = sp, Background = R<IBrush>("Bg0"), CornerRadius = new CornerRadius(9), Padding = new Thickness(2), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 12, 0), Tag = list };
    }

    public static Button DropButton(string text, Func<ContextMenu> build, double minWidth = 120)
    {
        var tb = new TextBlock { Text = text, VerticalAlignment = VerticalAlignment.Center, Foreground = R<IBrush>("Text") };
        var content = new DockPanel { LastChildFill = true, MinWidth = minWidth - 20 };
        var chev = new Ico("chev-down", 14) { Margin = new Thickness(8, 0, 0, 0) };
        DockPanel.SetDock(chev, Dock.Right);
        content.Children.Add(chev);
        content.Children.Add(tb);
        var b = new Button { Content = content, Padding = new Thickness(10, 4, 8, 4), HorizontalContentAlignment = HorizontalAlignment.Stretch, VerticalAlignment = VerticalAlignment.Center, Tag = tb };
        b.Classes.Add("Secondary");
        b.Click += (_, _) =>
        {
            var m = build();
            m.PlacementTarget = b;
            m.Placement = PlacementMode.BottomEdgeAlignedLeft;
            m.Open(b);
        };
        return b;
    }

    public static void SetDropText(Button b, string text) { if (b?.Tag is TextBlock tb) tb.Text = text; }

    /// <summary>Menu item with an optional icon, right-aligned shortcut hint and check mark.</summary>
    public static MenuItem Item(string header, Action click, string gesture = null, string icon = null, bool isChecked = false)
    {
        object head = header;
        if (!string.IsNullOrEmpty(gesture))
        {
            var g = new Grid { MinWidth = 180 };
            g.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            g.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
            g.Children.Add(new TextBlock { Text = header, VerticalAlignment = VerticalAlignment.Center });
            var gt = new TextBlock { Text = gesture, Foreground = R<IBrush>("Text3"), Margin = new Thickness(24, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center, FontSize = 11.5 };
            Grid.SetColumn(gt, 1);
            g.Children.Add(gt);
            head = g;
        }
        var mi = new MenuItem { Header = head };
        if (isChecked) mi.Icon = new Ico("check", 15) { Foreground = R<IBrush>("Accent") };
        else if (icon != null) mi.Icon = new Ico(icon, 15);
        if (click != null) mi.Click += (_, _) => click();
        return mi;
    }

    public static Border Card(Control child, double radius = 12, string bg = "Bg2") => new()
    {
        Child = child, Background = R<IBrush>(bg), CornerRadius = new CornerRadius(radius), BorderBrush = R<IBrush>("Line"), BorderThickness = new Thickness(1)
    };

    static readonly Dictionary<string, Bitmap> _assets = new();

    /// <summary>A bundled image (Assets/…).</summary>
    public static Bitmap Asset(string file)
    {
        if (_assets.TryGetValue(file, out var b)) return b;
        using var s = AssetLoader.Open(new Uri($"avares://SkyMasterPhotos/Assets/{file}"));
        return _assets[file] = new Bitmap(s);
    }

    /// <summary>Shows a file in the system file manager (Explorer on Windows, the default file manager on Linux).</summary>
    public static void Reveal(string path)
    {
        try
        {
            if (OperatingSystem.IsWindows())
                System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{path}\"");
            else if (OperatingSystem.IsMacOS())
                System.Diagnostics.Process.Start("open", new[] { "-R", path });
            else
            {
                // org.freedesktop.FileManager1 highlights the file (Dolphin, Nautilus, Nemo…); fall back to opening the folder
                var psi = new System.Diagnostics.ProcessStartInfo("dbus-send") { UseShellExecute = false };
                foreach (var a in new[] { "--session", "--dest=org.freedesktop.FileManager1", "--type=method_call", "/org/freedesktop/FileManager1",
                                          "org.freedesktop.FileManager1.ShowItems", $"array:string:file://{new Uri(path).AbsolutePath}", "string:" })
                    psi.ArgumentList.Add(a);
                var p = System.Diagnostics.Process.Start(psi);
                p?.WaitForExit(1500);
                if (p == null || p.ExitCode != 0)
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("xdg-open") { ArgumentList = { Path.GetDirectoryName(path) ?? "/" }, UseShellExecute = false });
            }
        }
        catch { }
    }

    /// <summary>Opens a URL or file with the system's default app.</summary>
    public static void OpenExternal(string target)
    {
        try
        {
            if (OperatingSystem.IsWindows()) System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(target) { UseShellExecute = true });
            else System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(OperatingSystem.IsMacOS() ? "open" : "xdg-open") { ArgumentList = { target }, UseShellExecute = false });
        }
        catch { }
    }

    static readonly Dictionary<(double, bool), ImageBrush> _checkers = new();

    /// <summary>Checkerboard (transparency) brush with square cells of <paramref name="cell"/> pixels.</summary>
    public static ImageBrush Checker(double cell = 8, bool dark = true)
    {
        if (_checkers.TryGetValue((cell, dark), out var cached)) return cached;
        int c = Math.Max(1, (int)Math.Round(cell));
        uint a = dark ? 0xFF2A2E38u : 0xFFFFFFFFu, b = dark ? 0xFF20232B : 0xFFD4D8DF;
        var px = new uint[4 * c * c];
        for (int y = 0; y < 2 * c; y++)
            for (int x = 0; x < 2 * c; x++)
                px[y * 2 * c + x] = ((x / c) + (y / c)) % 2 == 0 ? a : b;
        var bmp = App.MakeBitmap(px, 2 * c, 2 * c);
        var br = new ImageBrush(bmp)
        {
            TileMode = TileMode.Tile,
            Stretch = Stretch.None,
            DestinationRect = new RelativeRect(0, 0, 2 * c, 2 * c, RelativeUnit.Absolute),
            AlignmentX = AlignmentX.Left,
            AlignmentY = AlignmentY.Top,
        };
        _checkers[(cell, dark)] = br;
        return br;
    }
}

using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Layout;
using Avalonia.Media;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.UI;

/// <summary>HSV saturation/value square + hue strip + hex/RGB entry.</summary>
public sealed class ColorPicker : Grid
{
    readonly SvSquare _sv = new();
    readonly HueStrip _hue = new();
    readonly TextBox _hex = new() { Width = 78 };
    readonly TextBox _r = new() { Width = 44 }, _g = new() { Width = 44 }, _b = new() { Width = 44 };
    double _h, _s, _v;
    bool _updating;

    public event Action<Color> ColorChanged;

    public ColorPicker()
    {
        RowDefinitions.Add(new RowDefinition(GridLength.Star));
        RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
        ColumnDefinitions.Add(new ColumnDefinition(new GridLength(26)));

        _sv.Margin = new Thickness(0, 0, 8, 0);
        Children.Add(_sv);
        Grid.SetColumn(_hue, 1);
        Children.Add(_hue);

        var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 10, 0, 0) };
        row.Children.Add(Lbl("#"));
        row.Children.Add(_hex);
        row.Children.Add(Lbl("R")); row.Children.Add(_r);
        row.Children.Add(Lbl("G")); row.Children.Add(_g);
        row.Children.Add(Lbl("B")); row.Children.Add(_b);
        foreach (var t in new[] { _hex, _r, _g, _b }) { t.Padding = new Thickness(5, 3, 5, 3); t.FontSize = 11.5; t.MinHeight = 26; }
        Grid.SetRow(row, 1);
        Grid.SetColumnSpan(row, 2);
        Children.Add(row);

        _sv.Changed += (s, v) => { _s = s; _v = v; Push(); };
        _hue.Changed += h => { _h = h; _sv.Hue = h; Push(); };
        _hex.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitHex(); };
        _hex.LostFocus += (_, _) => CommitHex();
        foreach (var t in new[] { _r, _g, _b })
        {
            t.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitRgb(); };
            t.LostFocus += (_, _) => CommitRgb();
        }
    }

    static TextBlock Lbl(string s) => new() { Text = s, Foreground = UIx.R<IBrush>("Text3"), FontSize = 11, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 4, 0) };

    public Color Color
    {
        get { Px.HsvToRgb(_h, _s, _v, out double r, out double g, out double b); return Color.FromRgb((byte)Px.Clamp(r * 255), (byte)Px.Clamp(g * 255), (byte)Px.Clamp(b * 255)); }
    }

    public void SetColor(Color c)
    {
        Px.RgbToHsv(c.R / 255.0, c.G / 255.0, c.B / 255.0, out double h, out double s, out double v);
        if (s > 0.001 && v > 0.001) _h = h; // keep hue for greys
        _s = s; _v = v;
        _updating = true;
        _sv.Hue = _h; _sv.Set(_s, _v); _hue.Set(_h);
        UpdateTexts(c);
        _updating = false;
    }

    void Push()
    {
        var c = Color;
        UpdateTexts(c);
        if (!_updating) ColorChanged?.Invoke(c);
    }

    void UpdateTexts(Color c)
    {
        if (!_hex.IsFocused) _hex.Text = Px.ToHex(c);
        if (!_r.IsFocused) _r.Text = c.R.ToString();
        if (!_g.IsFocused) _g.Text = c.G.ToString();
        if (!_b.IsFocused) _b.Text = c.B.ToString();
    }

    void CommitHex()
    {
        if (Px.TryParseHex(_hex.Text, out var c)) { SetColor(c); ColorChanged?.Invoke(c); }
        else _hex.Text = Px.ToHex(Color);
    }

    void CommitRgb()
    {
        if (byte.TryParse(_r.Text, out var r) && byte.TryParse(_g.Text, out var g) && byte.TryParse(_b.Text, out var b))
        {
            var c = Color.FromRgb(r, g, b);
            SetColor(c);
            ColorChanged?.Invoke(c);
        }
        else UpdateTexts(Color);
    }

    static LinearGradientBrush Gradient(Color a, Color b, bool vertical) => new()
    {
        StartPoint = new RelativePoint(0, 0, RelativeUnit.Relative),
        EndPoint = vertical ? new RelativePoint(0, 1, RelativeUnit.Relative) : new RelativePoint(1, 0, RelativeUnit.Relative),
        GradientStops = { new GradientStop(a, 0), new GradientStop(b, 1) },
    };

    /// <summary>Base for the small draggable pickers (press, drag, release with pointer capture).</summary>
    abstract class DragPick : Control
    {
        bool _down;
        protected abstract void Pick(Point p);
        protected override void OnPointerPressed(PointerPressedEventArgs e) { base.OnPointerPressed(e); _down = true; e.Pointer.Capture(this); Pick(e.GetPosition(this)); e.Handled = true; }
        protected override void OnPointerMoved(PointerEventArgs e) { base.OnPointerMoved(e); if (_down) Pick(e.GetPosition(this)); }
        protected override void OnPointerReleased(PointerReleasedEventArgs e) { base.OnPointerReleased(e); _down = false; e.Pointer.Capture(null); }
        protected override void OnPointerCaptureLost(PointerCaptureLostEventArgs e) { base.OnPointerCaptureLost(e); _down = false; }
    }

    sealed class SvSquare : DragPick
    {
        double _hue, _s = 1, _v = 1;
        public event Action<double, double> Changed;
        public double Hue { get => _hue; set { _hue = value; InvalidateVisual(); } }
        public void Set(double s, double v) { _s = s; _v = v; InvalidateVisual(); }

        public SvSquare() { Cursor = Cursors.Cross; ClipToBounds = false; }

        public override void Render(DrawingContext dc)
        {
            var r = new Rect(Bounds.Size);
            if (r.Width <= 0 || r.Height <= 0) return;
            Px.HsvToRgb(_hue, 1, 1, out double hr, out double hg, out double hb);
            var hueC = Color.FromRgb((byte)(hr * 255), (byte)(hg * 255), (byte)(hb * 255));
            using (dc.PushClip(new RoundedRect(r, 10)))
            {
                dc.DrawRectangle(Gradient(Colors.White, hueC, false), null, r);
                dc.DrawRectangle(Gradient(Color.FromArgb(0, 0, 0, 0), Colors.Black, true), null, r);
            }
            var p = new Point(_s * r.Width, (1 - _v) * r.Height);
            dc.DrawEllipse(null, new Pen(new SolidColorBrush(Color.FromArgb(90, 0, 0, 0)), 3), p, 7.5, 7.5);
            dc.DrawEllipse(null, new Pen(Brushes.White, 2), p, 7, 7);
        }

        protected override void Pick(Point p)
        {
            _s = Math.Clamp(p.X / Math.Max(1, Bounds.Width), 0, 1);
            _v = 1 - Math.Clamp(p.Y / Math.Max(1, Bounds.Height), 0, 1);
            InvalidateVisual();
            Changed?.Invoke(_s, _v);
        }
    }

    sealed class HueStrip : DragPick
    {
        double _h;
        public event Action<double> Changed;
        public void Set(double h) { _h = h; InvalidateVisual(); }
        public HueStrip() { Cursor = Cursors.Hand; }

        public override void Render(DrawingContext dc)
        {
            double w = Bounds.Width, h = Bounds.Height;
            if (w <= 0 || h <= 0) return;
            var r = new Rect(5, 0, Math.Max(0, w - 10), h);
            var lg = new LinearGradientBrush { StartPoint = new RelativePoint(0, 0, RelativeUnit.Relative), EndPoint = new RelativePoint(0, 1, RelativeUnit.Relative) };
            for (int i = 0; i <= 6; i++)
            {
                Px.HsvToRgb(i / 6.0, 1, 1, out double rr, out double gg, out double bb);
                lg.GradientStops.Add(new GradientStop(Color.FromRgb((byte)(rr * 255), (byte)(gg * 255), (byte)(bb * 255)), i / 6.0));
            }
            dc.DrawRectangle(lg, null, r, 7, 7);
            double y = _h * h;
            var knob = new Rect(1, Math.Clamp(y - 4, 0, h - 8), w - 2, 8);
            dc.DrawRectangle(null, new Pen(new SolidColorBrush(Color.FromArgb(120, 0, 0, 0)), 3), knob, 4, 4);
            dc.DrawRectangle(null, new Pen(Brushes.White, 2), knob, 4, 4);
        }

        protected override void Pick(Point p)
        {
            _h = Math.Clamp(p.Y / Math.Max(1, Bounds.Height), 0, 0.9999);
            InvalidateVisual();
            Changed?.Invoke(_h);
        }
    }
}

/// <summary>Interactive tone curve editor (click to add, drag to move, right-click to remove).</summary>
public sealed class CurvesEditor : Control
{
    public List<Point> Points { get; } = new() { new Point(0, 0), new Point(255, 255) };
    public int[] Histogram;
    int _drag = -1;
    public event Action Changed;

    public CurvesEditor() { Width = 300; Height = 300; Cursor = Cursors.Cross; }

    double W => Bounds.Width;
    double H => Bounds.Height;
    Point ToScreen(Point p) => new(p.X / 255 * W, (1 - p.Y / 255) * H);
    Point ToCurve(Point s) => new(Math.Clamp(s.X / W * 255, 0, 255), Math.Clamp((1 - s.Y / H) * 255, 0, 255));

    public override void Render(DrawingContext dc)
    {
        if (W <= 0 || H <= 0) return;
        var r = new Rect(0, 0, W, H);
        dc.DrawRectangle(UIx.R<IBrush>("Bg0"), new Pen(UIx.R<IBrush>("Line2"), 1), r, 8, 8);
        if (Histogram != null)
        {
            double max = Math.Max(1, Histogram.Max());
            var g = new StreamGeometry();
            using (var c = g.Open())
            {
                c.BeginFigure(new Point(0, H), true);
                for (int i = 0; i < 256; i++) c.LineTo(new Point(i / 255.0 * W, H - Math.Sqrt(Histogram[i] / max) * H * 0.9));
                c.LineTo(new Point(W, H));
                c.EndFigure(true);
            }
            dc.DrawGeometry(new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)), null, g);
        }
        var grid = new Pen(new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)), 1);
        for (int i = 1; i < 4; i++)
        {
            dc.DrawLine(grid, new Point(i * W / 4, 0), new Point(i * W / 4, H));
            dc.DrawLine(grid, new Point(0, i * H / 4), new Point(W, i * H / 4));
        }
        dc.DrawLine(new Pen(new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)), 1, DashStyle.Dash), new Point(0, H), new Point(W, 0));
        var lut = Adjustments.CurveLut(Points);
        var curve = new StreamGeometry();
        using (var c = curve.Open())
        {
            c.BeginFigure(ToScreen(new Point(0, lut[0])), false);
            for (int i = 1; i < 256; i++) c.LineTo(ToScreen(new Point(i, lut[i])));
            c.EndFigure(false);
        }
        dc.DrawGeometry(null, new Pen(UIx.R<IBrush>("AccentGradH"), 2.2), curve);
        foreach (var p in Points)
            dc.DrawEllipse(UIx.R<IBrush>("Bg1"), new Pen(Brushes.White, 2), ToScreen(p), 5, 5);
    }

    int Hit(Point s)
    {
        for (int i = 0; i < Points.Count; i++)
        {
            var d = ToScreen(Points[i]) - s;
            if (Math.Sqrt(d.X * d.X + d.Y * d.Y) < 9) return i;
        }
        return -1;
    }

    protected override void OnPointerPressed(PointerPressedEventArgs e)
    {
        base.OnPointerPressed(e);
        var pt = e.GetCurrentPoint(this);
        var s = pt.Position;
        int h = Hit(s);
        if (pt.Properties.PointerUpdateKind == PointerUpdateKind.RightButtonPressed)
        {
            if (h > 0 && h < Points.Count - 1 || (h >= 0 && Points.Count > 2)) { Points.RemoveAt(h); InvalidateVisual(); Changed?.Invoke(); }
            e.Handled = true;
            return;
        }
        if (h < 0)
        {
            Points.Add(ToCurve(s));
            Points.Sort((a, b) => a.X.CompareTo(b.X));
            h = Hit(s);
        }
        _drag = h;
        e.Pointer.Capture(this);
        InvalidateVisual();
        Changed?.Invoke();
        e.Handled = true;
    }

    protected override void OnPointerMoved(PointerEventArgs e)
    {
        base.OnPointerMoved(e);
        if (_drag < 0 || _drag >= Points.Count) return;
        var p = ToCurve(e.GetPosition(this));
        double minX = _drag > 0 ? Points[_drag - 1].X + 1 : 0, maxX = _drag < Points.Count - 1 ? Points[_drag + 1].X - 1 : 255;
        Points[_drag] = new Point(Math.Clamp(p.X, minX, maxX), p.Y);
        InvalidateVisual();
        Changed?.Invoke();
    }

    protected override void OnPointerReleased(PointerReleasedEventArgs e) { base.OnPointerReleased(e); _drag = -1; e.Pointer.Capture(null); }
    protected override void OnPointerCaptureLost(PointerCaptureLostEventArgs e) { base.OnPointerCaptureLost(e); _drag = -1; }

    public void Reset()
    {
        Points.Clear();
        Points.Add(new Point(0, 0));
        Points.Add(new Point(255, 255));
        InvalidateVisual();
        Changed?.Invoke();
    }
}

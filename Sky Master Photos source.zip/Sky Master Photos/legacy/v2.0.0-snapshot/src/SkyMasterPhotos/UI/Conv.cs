using System.Globalization;
using Avalonia;
using Avalonia.Data;
using Avalonia.Data.Converters;
using Avalonia.Media;

namespace SkyMasterPhotos.UI;

public sealed class FuncConverter : IValueConverter
{
    readonly Func<object, object> _f;
    public FuncConverter(Func<object, object> f) => _f = f;
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => _f(value);
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => BindingOperations.DoNothing;
}

/// <summary>Binding converters (visibility ones produce bools for Avalonia's IsVisible).</summary>
public static class Conv
{
    public static readonly IValueConverter TagToVis = new FuncConverter(v => v is true || (v is string s && s.Length > 0));
    public static readonly IValueConverter BoolToVis = new FuncConverter(v => v is true);
    public static readonly IValueConverter NotBoolToVis = new FuncConverter(v => v is not true);
    public static readonly IValueConverter EyeKind = new FuncConverter(v => v is true ? "eye" : "eyeoff");
    public static readonly IValueConverter LockKind = new FuncConverter(v => v is true ? "lock" : "unlock");
    public static readonly IValueConverter HalfOpacity = new FuncConverter(v => v is true ? 0.35 : 1.0);
    public static readonly IValueConverter VisibleOpacity = new FuncConverter(v => v is true ? 1.0 : 0.4);
    public static readonly IValueConverter DepthIndent = new FuncConverter(v => new Thickness(v is int d ? d * 12 : 0, 0, 0, 0));
    public static readonly IValueConverter TargetBorder = new FuncConverter(v => v is true ? Brushes.White : UIx.R<IBrush>("Line2"));
    public static readonly IValueConverter NullToVis = new FuncConverter(v => v != null);
}

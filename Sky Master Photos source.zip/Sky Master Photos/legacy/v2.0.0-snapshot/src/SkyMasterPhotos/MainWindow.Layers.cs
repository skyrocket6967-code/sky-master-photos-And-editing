using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Input;
using Avalonia.Media;
using SkyMasterPhotos.Core;
using SkyMasterPhotos.UI;

namespace SkyMasterPhotos;

/// <summary>Layer masks, clipping masks, adjustment layers, groups and content-aware fill.</summary>
public partial class MainWindow
{
    /// <summary>Apply a geometry change to a layer's pixels and its mask.</summary>
    static void MapLayer(Layer l, Func<uint[], uint[]> f, int nw, int nh)
    {
        l.SetPixels(f(l.Pixels), nw, nh);
        if (l.Mask != null) l.SetMask(f(l.Mask));
    }

    Layer ActiveLayerOrToast()
    {
        if (!RequireDoc()) return null;
        var l = _active.ActiveLayer;
        if (l == null) Toast("Select a layer first");
        return l;
    }

    // ───────────────────────────── masks ─────────────────────────────

    /// <param name="mode">0 reveal all, 1 hide all, 2 from selection</param>
    void AddMask(int mode)
    {
        var l = ActiveLayerOrToast();
        if (l == null) return;
        Ctl.FinishPending();
        var d = _active;
        if (l.HasMask) { Toast("This layer already has a mask"); return; }
        if (mode == 2 && !d.HasSelection) mode = 0;
        var before = d.Capture();
        uint[] m = mode switch
        {
            1 => Layer.NewMask(d.Width, d.Height, 0),
            2 => Masks.FromSelection(d.Selection, d.Width, d.Height),
            _ => Layer.NewMask(d.Width, d.Height, 255),
        };
        l.SetMask(m);
        l.MaskEnabled = true;
        l.EditMask = true;
        if (mode == 2) d.SetSelection(null);
        Finish(d, l);
        d.Record("Add Layer Mask", before, "◐");
        Toast("Mask added — paint black to hide, white to reveal");
    }

    void DeleteMask(bool apply)
    {
        var l = ActiveLayerOrToast();
        if (l == null || !l.HasMask) { Toast("This layer has no mask"); return; }
        Ctl.FinishPending();
        var d = _active;
        var before = d.Capture();
        if (apply && !l.IsAdjustment)
        {
            var px = l.Pixels;
            var m = l.Mask;
            var o = new uint[px.Length];
            Parallel.For(0, px.Length, i => o[i] = Px.WithAlpha(px[i], Px.A(px[i]) * Masks.Value(m[i]) / 255));
            l.SetPixels(o, d.Width, d.Height);
        }
        l.SetMask(null);
        Finish(d, l);
        d.Record(apply ? "Apply Layer Mask" : "Delete Layer Mask", before, "◐");
    }

    void ToggleMaskEnabled()
    {
        var l = ActiveLayerOrToast();
        if (l == null || !l.HasMask) { Toast("This layer has no mask"); return; }
        var before = _active.Capture();
        l.MaskEnabled = !l.MaskEnabled;
        _active.RenderAll();
        _active.Record(l.MaskEnabled ? "Enable Layer Mask" : "Disable Layer Mask", before, "◐");
    }

    void InvertMask()
    {
        var l = ActiveLayerOrToast();
        if (l == null || !l.HasMask) { Toast("This layer has no mask"); return; }
        var d = _active;
        var before = d.Capture();
        var m = l.Mask;
        var o = new uint[m.Length];
        Parallel.For(0, m.Length, i => o[i] = Masks.Gray((byte)(255 - Masks.Value(m[i]))));
        l.SetMask(o);
        Finish(d, l);
        d.Record("Invert Mask", before, "◐");
    }

    void MaskToSelection()
    {
        var l = ActiveLayerOrToast();
        if (l == null || !l.HasMask) return;
        var sel = new byte[l.Mask.Length];
        for (int i = 0; i < sel.Length; i++) sel[i] = Masks.Value(l.Mask[i]);
        var before = _active.Capture();
        _active.SetSelection(sel);
        _active.Record("Load Mask Selection", before, "⬚");
    }

    void SetEditTarget(Layer l, bool mask)
    {
        if (_active == null || l == null) return;
        if (mask && !l.HasMask) return;
        if (!mask && (l.IsAdjustment || l.Psd?.UnrenderedAdjustment == true)) { Toast("Adjustment layers are edited through their mask"); mask = l.HasMask; }
        _active.ActiveLayer = l;
        l.EditMask = mask;
        BuildOptions();
        Toast(mask ? "Editing the mask — black hides, white reveals" : "Editing pixels");
    }

    // ───────────────────────────── clipping ─────────────────────────────

    void ToggleClipping()
    {
        var l = ActiveLayerOrToast();
        if (l == null) return;
        var d = _active;
        int i = d.ActiveIndex;
        if (!l.Clipped && i >= d.Layers.Count - 1) { Toast("A clipping mask needs a layer below"); return; }
        var before = d.Capture();
        l.Clipped = !l.Clipped;
        d.RenderAll();
        d.Record(l.Clipped ? "Create Clipping Mask" : "Release Clipping Mask", before, "↳");
    }

    // ───────────────────────────── adjustment layers ─────────────────────────────

    void NewAdjustmentLayer(string kind)
    {
        if (!RequireDoc()) return;
        Ctl.FinishPending();
        var d = _active;
        var spec = AdjustmentSpec.Default(kind);
        if (kind == "gradientmap") spec = new AdjustmentSpec { Kind = kind, C1 = _fg, C2 = _bg };
        int n = d.Layers.Count(l => l.Adjustment?.Kind == kind) + 1;
        var layer = new Layer($"{spec.Title} {n}", d.Width, d.Height) { Adjustment = spec, Group = d.ActiveLayer?.Group ?? "" };
        layer.SetMask(d.HasSelection ? Masks.FromSelection(d.Selection, d.Width, d.Height) : Layer.NewMask(d.Width, d.Height, 255));
        layer.EditMask = true;
        var before = d.Capture();
        d.Layers.Insert(Math.Max(0, d.ActiveIndex), layer);
        d.ActiveLayer = layer;
        if (d.HasSelection) d.SetSelection(null);
        Finish(d, layer);
        if (kind == "invert") { d.Record("New Invert Layer", before, "◑"); return; }
        // open the controls straight away; cancelling keeps the layer at its defaults (like Photoshop)
        d.Record($"New {spec.Title} Layer", before, "◑");
        EditAdjustmentLayer(layer);
    }

    void EditAdjustmentLayer(Layer l)
    {
        if (l?.Adjustment == null || _active == null) return;
        if (l.Adjustment.Kind == "invert") { Toast("Invert has no settings — toggle visibility or paint its mask"); return; }
        Ctl.FinishPending();
        var spec = l.Adjustment;
        AdjustDialog.ShowLayer(this, _active, l, null, AdjustCatalog.Params(spec), ctx => AdjustCatalog.Build(spec, ctx, _fg, _bg), spec.Curve?.ToList(), false);
        SyncLayerSelection();
    }

    ContextMenu AdjustmentLayerMenu()
    {
        var m = new ContextMenu();
        foreach (var k in AdjustmentSpec.Kinds)
        {
            var s = AdjustmentSpec.Default(k);
            var kind = k;
            m.Items.Add(UIx.Item(s.Title + "…", () => NewAdjustmentLayer(kind), null, s.Icon));
        }
        return m;
    }

    // ───────────────────────────── text / raster ─────────────────────────────

    void RasterizeLayer()
    {
        var l = ActiveLayerOrToast();
        if (l == null) return;
        var d = _active;
        if (l.IsAdjustment) { Toast("Use Merge Down to bake an adjustment into the layer below"); return; }
        if (l.Text == null && l.Psd?.KindLabel == null) { Toast("Layer is already pixels"); return; }
        var before = d.Capture();
        l.Text = null;
        if (l.Psd != null) { l.Psd.KindLabel = null; l.Psd.Blocks.RemoveAll(b => Core.Psd.PsdFormat.ContentBlocks.Contains(b.Key)); l.NotifyInfo(); }
        d.Record("Rasterize Layer", before, "▦");
    }

    // ───────────────────────────── groups ─────────────────────────────

    void GroupActiveLayer()
    {
        var l = ActiveLayerOrToast();
        if (l == null) return;
        var d = _active;
        int n = 1;
        string Name(int k) => string.IsNullOrEmpty(l.Group) ? $"Group {k}" : $"{l.Group}/Group {k}";
        while (d.Groups.ContainsKey(Name(n))) n++;
        var before = d.Capture();
        var path = Name(n);
        d.Groups[path] = new GroupInfo($"Group {n}", true, 1, "pass", true);
        l.Group = path;
        d.Record("Group Layer", before, "▣");
    }

    void UngroupActiveLayer()
    {
        var l = ActiveLayerOrToast();
        if (l == null || string.IsNullOrEmpty(l.Group)) { Toast("Layer is not in a group"); return; }
        var d = _active;
        var before = d.Capture();
        int cut = l.Group.LastIndexOf('/');
        l.Group = cut < 0 ? "" : l.Group[..cut];
        d.RenderAll();
        d.Record("Remove From Group", before, "▣");
    }

    void ToggleGroupVisibility()
    {
        var l = ActiveLayerOrToast();
        if (l == null || string.IsNullOrEmpty(l.Group) || !_active.Groups.TryGetValue(l.Group, out var g)) { Toast("Layer is not in a group"); return; }
        var before = _active.Capture();
        _active.Groups[l.Group] = g with { Visible = !g.Visible };
        _active.RenderAll();
        foreach (var x in _active.Layers) x.NotifyInfo();
        _active.Record(g.Visible ? "Hide Group" : "Show Group", before, "◉");
    }

    // ───────────────────────────── content-aware fill ─────────────────────────────

    void ContentAwareFill()
    {
        if (!EditableLayer()) return;
        var d = _active;
        if (!d.HasSelection) { Toast("Select the area to remove first (e.g. with the Lasso)"); return; }
        var l = d.ActiveLayer;
        if (l.IsAdjustment) { Toast("Select a pixel layer"); return; }
        if (!Ctl.PrepareForPixelEdit(l)) return;
        Ctl.FinishPending();
        try
        {
            Mouse.OverrideCursor = Cursors.Wait;
            var before = d.Capture();
            var sel = SelectionOps.Grow(d.Selection, d.Width, d.Height, 2);
            l.SetPixels(Inpaint.Fill(l.Pixels, d.Width, d.Height, sel), d.Width, d.Height);
            Finish(d, l);
            d.Record("Content-Aware Fill", before, "✦");
            Toast("Content-aware fill ✦");
        }
        finally { Mouse.OverrideCursor = null; }
    }

    // ───────────────────────────── PSD info ─────────────────────────────

    readonly Dictionary<Document, List<string>> _importNotes = new();

    void ShowPsdInfo()
    {
        if (!RequireDoc()) return;
        var d = _active;
        var notes = _importNotes.TryGetValue(d, out var n) ? n : new List<string>();
        var sb = new System.Text.StringBuilder();
        if (d.PsdData?.SourceInfo != null) sb.AppendLine("Source: " + d.PsdData.SourceInfo).AppendLine();
        int adj = d.Layers.Count(l => l.IsAdjustment), masks = d.Layers.Count(l => l.HasMask), text = d.Layers.Count(l => l.IsText), clip = d.Layers.Count(l => l.Clipped);
        sb.AppendLine($"{d.Layers.Count} layers · {d.Groups.Count} groups · {masks} masks · {adj} adjustment layers · {text} editable text · {clip} clipped");
        sb.AppendLine();
        if (notes.Count == 0) sb.AppendLine("Everything in this document is fully editable in Sky Master Photos.");
        else
        {
            sb.AppendLine("Notes:");
            foreach (var x in notes.Distinct().Take(40)) sb.AppendLine("•  " + x);
        }
        SkyDialog.Alert(this, "Photoshop compatibility", sb.ToString());
    }
}

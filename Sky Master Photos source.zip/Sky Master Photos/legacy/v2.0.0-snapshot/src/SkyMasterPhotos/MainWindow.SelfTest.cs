using System.Diagnostics;
using System.IO;
using System.Text;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Layout;
using Avalonia.Media;
using SkyMasterPhotos.Core;
using Transforms = SkyMasterPhotos.Core.Transforms;
using SkyMasterPhotos.Tools;

namespace SkyMasterPhotos;

/// <summary>Headless smoke test of the engine (run with --selftest). Writes selftest.log next to settings.</summary>
public partial class MainWindow
{
    void RunSelfTest()
    {
        var log = new StringBuilder();
        int fails = 0;
        void Check(string name, Func<bool> f)
        {
            var sw = Stopwatch.StartNew();
            try
            {
                bool ok = f();
                log.AppendLine($"{(ok ? "PASS" : "FAIL")}  {name}  ({sw.ElapsedMilliseconds} ms)");
                if (!ok) fails++;
            }
            catch (Exception ex) { fails++; log.AppendLine($"FAIL  {name}: {ex.GetType().Name} {ex.Message}\n{ex.StackTrace}"); }
        }

        var tmp = Path.Combine(Path.GetTempPath(), "SkyMasterPhotosTest");
        Directory.CreateDirectory(tmp);
        Document d = null;

        Check("create document", () =>
        {
            CreateDocument(1200, 800, "Selftest", Colors.White);
            d = _active;
            return d != null && d.Layers.Count == 1 && d.Flat[0] == 0xFFFFFFFF;
        });
        Check("new layer + brush stroke + undo/redo", () =>
        {
            NewLayer();
            var layer = d.ActiveLayer;
            var s = new StrokeSession(d, layer, StrokeKind.Paint, new BrushSettings { Size = 40, Hardness = 0.8 }, 0xFFFF0000, new Vector());
            d.Render(s.MoveTo(new Point(100, 100)));
            d.Render(s.MoveTo(new Point(600, 400)));
            s.Commit("Brush");
            bool painted = (d.Flat[400 * 1200 + 600] & 0x00FF0000) == 0x00FF0000 && Px.G(d.Flat[400 * 1200 + 600]) < 40;
            var after = (uint[])d.Flat.Clone();
            d.Undo();
            bool undone = d.Flat[400 * 1200 + 600] == 0xFFFFFFFF;
            d.Redo();
            bool redone = d.Flat.SequenceEqual(after);
            return painted && undone && redone;
        });
        Check("gradient + bucket via tools", () =>
        {
            NewLayer();
            Ctl.Tool = Tool.Gradient;
            Ctl.MouseDown(new Point(), new Point(0, 0), default, 1);
            Ctl.MouseMove(new Point(), new Point(1200, 0), default, true);
            Ctl.MouseUp(new Point(), new Point(1200, 0), default);
            Ctl.Tool = Tool.Bucket;
            Ctl.MouseDown(new Point(), new Point(5, 790), default, 1);
            return d.Layers.Count == 3;
        });
        Check("all adjustments", () =>
        {
            var p = d.ActiveLayer.Pixels;
            int w = d.Width, h = d.Height;
            var outs = new List<uint[]>
            {
                Adjustments.BrightnessContrast(p, 20, 30), Adjustments.Levels(p, 10, 240, 1.2, 0, 255), Adjustments.Exposure(p, 0.5, 0, 1),
                Adjustments.HueSaturation(p, 40, 20, 5, false), Adjustments.HueSaturation(p, 40, 20, 5, true), Adjustments.Vibrance(p, 30, 10),
                Adjustments.ColorBalance(p, 20, -10, 15, true), Adjustments.BlackWhite(p, 40, 60, 40, 60, 20, 80), Adjustments.PhotoFilter(p, Colors.Orange, 30, true),
                Adjustments.TemperatureTint(p, 30, -10), Adjustments.Invert(p), Adjustments.Desaturate(p), Adjustments.Sepia(p, 80), Adjustments.Posterize(p, 5),
                Adjustments.Threshold(p, 128), Adjustments.GradientMap(p, Colors.Black, Colors.White), Adjustments.ShadowsHighlights(p, w, h, 40, 20),
                Adjustments.AutoTone(p), Adjustments.AutoContrast(p), Adjustments.AutoColor(p), Adjustments.AutoEnhance(p), Adjustments.RemoveBackground(p, w, h, 30),
                Adjustments.ApplyLut(p, Adjustments.CurveLut(new List<Point> { new(0, 0), new(80, 50), new(180, 210), new(255, 255) })),
            };
            return outs.All(o => o.Length == p.Length);
        });
        Check("all filters", () =>
        {
            var p = d.Flat;
            int w = d.Width, h = d.Height;
            var outs = new List<uint[]>
            {
                Filters.GaussianBlur(p, w, h, 8), Filters.BoxBlur(p, w, h, 4), Filters.MotionBlur(p, w, h, 30, 10), Filters.RadialBlur(p, w, h, 20, false),
                Filters.RadialBlur(p, w, h, 20, true), Filters.TiltShift(p, w, h, 10, 50, 20), Filters.UnsharpMask(p, w, h, 100, 2, 1), Filters.Sharpen(p, w, h),
                Filters.AddNoise(p, w, h, 10, true, true), Filters.Median(p, w, h, 2), Filters.Emboss(p, w, h, 135, 150), Filters.FindEdges(p, w, h, true),
                Filters.Pixelate(p, w, h, 10), Filters.Vignette(p, w, h, 50, 40, 60), Filters.OilPaint(p, w, h, 4), Filters.Glow(p, w, h, 10, 40),
                Filters.Twirl(p, w, h, 90), Filters.Bulge(p, w, h, 50), Filters.Wave(p, w, h, 8, 60), Filters.Clouds(w, h, Colors.Blue, Colors.White, 100, 1),
            };
            return outs.All(o => o.Length == p.Length);
        });
        Check("blend modes composite", () =>
        {
            foreach (BlendMode m in Enum.GetValues(typeof(BlendMode))) { d.ActiveLayer.Blend = m; d.RenderAll(); }
            d.ActiveLayer.Blend = BlendMode.Normal;
            d.RenderAll();
            return true;
        });
        Check("selection ops", () =>
        {
            var r = SelectionOps.Rect(d.Width, d.Height, new Int32Rect(100, 100, 300, 200));
            var e = SelectionOps.Ellipse(d.Width, d.Height, new Int32Rect(200, 150, 300, 200));
            var u = SelectionOps.Combine(r, e, SelectMode.Add);
            var f = SelectionOps.Feather(u, d.Width, d.Height, 6);
            var g = SelectionOps.Grow(f, d.Width, d.Height, 3);
            var poly = SelectionOps.Polygon(d.Width, d.Height, new List<Point> { new(10, 10), new(300, 40), new(150, 300) });
            var wand = SelectionOps.MagicWand(d.Flat, d.Width, d.Height, 5, 5, 30, true);
            d.SetSelection(g);
            var b = d.SelectionBounds;
            return b.Width > 300 && SelectionOps.Outline(g, d.Width, d.Height) != null && !SelectionOps.IsEmpty(poly) && !SelectionOps.IsEmpty(wand);
        });
        Check("move transform + undo", () =>
        {
            d.SetSelection(null);
            var before = (uint[])d.Flat.Clone();
            var s = TransformSession.Begin(d, true);
            s.T = new Vector(40, 25);
            s.Angle = 12;
            s.Sx = 0.8; s.Sy = 0.8;
            s.Commit(d, "Free Transform");
            bool changed = !d.Flat.SequenceEqual(before);
            d.Undo();
            return changed && d.Flat.SequenceEqual(before);
        });
        Check("image size / canvas / rotate / crop + undo", () =>
        {
            var before = (uint[])d.Flat.Clone();
            int w0 = d.Width, h0 = d.Height;
            foreach (var l in d.Layers) l.SetPixels(Transforms.Resize(l.Pixels, d.Width, d.Height, 600, 400), 600, 400);
            var st = d.Capture();
            d.SetSize(600, 400); d.RenderAll();
            RotateCanvas(1);
            bool rotated = d.Width == 400 && d.Height == 600;
            d.Undo();
            return rotated && d.Width == 600;
        });
        Check("text + shape rasterize", () =>
        {
            var t = Raster.Text(d.Width, d.Height, "Sky Photo", new Point(20, 20), FontCatalog.Default, 64, true, false, Colors.Black);
            var sh = Raster.Shape(d.Width, d.Height, new ShapeSpec(Tool.ShapeEllipse, new Point(10, 10), new Point(200, 120), 0), Colors.Red, Colors.Blue, 4);
            return t.Any(p => p >> 24 != 0) && sh.Any(p => p >> 24 != 0);
        });
        string proj = Path.Combine(tmp, "test.skyphoto");
        Check("save + load project", () =>
        {
            ImageIO.SaveProject(d, proj);
            var d2 = ImageIO.LoadProject(proj);
            d2.RenderAll();
            return d2.Layers.Count == d.Layers.Count && d2.Width == d.Width && d2.Flat.SequenceEqual(d.Flat);
        });
        Check("export png/jpg/tif/bmp + reload", () =>
        {
            foreach (var ext in new[] { ".png", ".jpg", ".tif", ".bmp", ".gif" })
            {
                var f = Path.Combine(tmp, "out" + ext);
                ImageIO.SaveImage(f, d.Flat, d.Width, d.Height, 90);
                var (p, w, h) = ImageIO.LoadPixels(f);
                if (w != d.Width || h != d.Height) return false;
            }
            return true;
        });
        Check("masks + adjustment layers + PSD round trip", () =>
        {
            var p = Document.CreateBlank(300, 200, "psd", Colors.White);
            var px = new uint[300 * 200];
            for (int i = 0; i < px.Length; i++) px[i] = 0xFF3366CC;
            var l = new Layer("Blue", 300, 200, px);
            var m = Layer.NewMask(300, 200, 255);
            for (int i = 0; i < 300 * 100; i++) m[i] = Masks.Gray(0);
            l.SetMask(m);
            var adj = new Layer("Hue", 300, 200) { Adjustment = new AdjustmentSpec { Kind = "huesat", P = AdjustmentSpec.D(("h", 40), ("s", 0), ("l", 0), ("c", 0)) } };
            p.Layers.Insert(0, l);
            p.Layers.Insert(0, adj);
            p.RenderAll();
            string f = Path.Combine(tmp, "roundtrip.psd");
            Core.Psd.PsdWriter.Save(p, f);
            var back = Core.Psd.PsdReader.Read(f).Doc;
            back.RenderAll();
            return back.Layers.Count == 3 && back.Layers[1].HasMask && back.Layers[0].Adjustment?.Kind == "huesat" && back.Flat.SequenceEqual(p.Flat);
        });
        Check("spot heal / content-aware fill", () =>
        {
            var px = new uint[200 * 200];
            for (int i = 0; i < px.Length; i++) px[i] = Px.Pack(255, 120 + (i % 7), 140, 160);
            for (int y = 90; y < 110; y++) for (int x = 90; x < 110; x++) px[y * 200 + x] = 0xFF000000;
            var sel = SelectionOps.Rect(200, 200, new Int32Rect(88, 88, 24, 24));
            var res = Inpaint.Fill(px, 200, 200, sel);
            return Px.R(res[100 * 200 + 100]) > 100; // the black blemish is gone
        });
        Check("recent files + thumbnail", () =>
        {
            AppStore.AddRecent(proj, d.Width, d.Height, d.Flat);
            var r = AppStore.GetRecent().FirstOrDefault(x => x.Path == proj);
            bool ok = r != null && r.Thumb != null;
            AppStore.RemoveRecent(proj);
            return ok;
        });
        Check("history jump", () =>
        {
            int n = d.History.Entries.Count;
            d.JumpTo(0);
            bool atStart = d.History.Index == 1;
            d.JumpTo(n - 1);
            return atStart && d.History.Index == n;
        });
        Check("merge visible + flatten", () =>
        {
            MergeVisible();
            FlattenImage();
            return d.Layers.Count == 1;
        });
        Check("4K performance (blur + composite)", () =>
        {
            var big = Document.CreateBlank(3840, 2160, "big", Colors.White);
            var sw = Stopwatch.StartNew();
            big.RenderAll();
            var t1 = sw.ElapsedMilliseconds;
            var bl = Filters.GaussianBlur(big.Flat, 3840, 2160, 20);
            log.AppendLine($"      composite 4K: {t1} ms, gaussian 4K: {sw.ElapsedMilliseconds - t1} ms");
            return bl.Length == big.Flat.Length;
        });

        foreach (var doc in Docs) doc.IsDirty = false;
        log.Insert(0, $"Sky Master Photos self-test — {DateTime.Now}\n{(fails == 0 ? "ALL PASSED" : fails + " FAILED")}\n\n");
        Directory.CreateDirectory(AppStore.Dir);
        File.WriteAllText(Path.Combine(AppStore.Dir, "selftest.log"), log.ToString());
        Environment.Exit(fails == 0 ? 0 : 1);
    }
}

using Avalonia;
using Avalonia.Media;
using SkiaSharp;
using SkyMasterPhotos.Core;

namespace SkyMasterPhotos.Tools;

/// <summary>A shape as drawn by the shape tools (document coordinates).</summary>
public readonly record struct ShapeSpec(Tool Kind, Point A, Point B, double Corner);

/// <summary>Rasterizes text and shapes into straight-alpha layer pixels with SkiaSharp (identical on Windows and Linux).</summary>
public static class Raster
{
    /// <summary>Renders with an antialiased Skia canvas and returns straight-alpha BGRA pixels.</summary>
    public static uint[] Render(int w, int h, Action<SKCanvas> draw)
    {
        var info = new SKImageInfo(w, h, SKColorType.Bgra8888, SKAlphaType.Premul);
        var px = new uint[w * h];
        unsafe
        {
            fixed (uint* p = px)
            {
                using var surface = SKSurface.Create(info, (IntPtr)p, w * 4);
                surface.Canvas.Clear(SKColors.Transparent);
                draw(surface.Canvas);
                surface.Canvas.Flush();
            }
        }
        // unpremultiply
        Parallel.For(0, px.Length, i =>
        {
            uint p = px[i];
            uint a = p >> 24;
            if (a == 0 || a == 255) return;
            uint r = Math.Min(255u, ((p >> 16) & 255) * 255 / a), g = Math.Min(255u, ((p >> 8) & 255) * 255 / a), b = Math.Min(255u, (p & 255) * 255 / a);
            px[i] = (a << 24) | (r << 16) | (g << 8) | b;
        });
        return px;
    }

    static SKColor Sk(Color c) => new(c.R, c.G, c.B, c.A);

    public static SKTypeface Typeface(string family, bool bold, bool italic)
    {
        var style = new SKFontStyle(bold ? SKFontStyleWeight.Bold : SKFontStyleWeight.Normal, SKFontStyleWidth.Normal, italic ? SKFontStyleSlant.Italic : SKFontStyleSlant.Upright);
        return SKTypeface.FromFamilyName(FontCatalog.Resolve(family), style) ?? SKTypeface.Default;
    }

    // ───────────────────────────── text ─────────────────────────────

    /// <summary>Line height and ascent for a font (WPF-style line boxes).</summary>
    public static (double lineHeight, double ascent) Metrics(string family, double size, bool bold, bool italic)
    {
        using var tf = Typeface(family, bold, italic);
        using var font = new SKFont(tf, (float)Math.Max(1, size));
        return (font.Spacing, -font.Metrics.Ascent);
    }

    /// <summary>Measures multi-line text (widest line, total height).</summary>
    public static Size MeasureText(string text, string family, double size, bool bold, bool italic)
    {
        using var tf = Typeface(family, bold, italic);
        using var font = new SKFont(tf, (float)Math.Max(1, size));
        using var paint = new SKPaint { Typeface = tf, TextSize = (float)Math.Max(1, size), IsAntialias = true };
        var lines = (text ?? "").Replace("\r\n", "\n").Split('\n');
        double w = lines.Max(l => (double)paint.MeasureText(l));
        return new Size(w, lines.Length * font.Spacing);
    }

    /// <summary>Draws multi-line text with its line box's top-left at <paramref name="pos"/>.</summary>
    public static void DrawText(SKCanvas c, string text, Point pos, string family, double size, bool bold, bool italic, Color color)
    {
        using var tf = Typeface(family, bold, italic);
        using var font = new SKFont(tf, (float)Math.Max(1, size)) { Subpixel = true, Edging = SKFontEdging.Antialias };
        using var paint = new SKPaint { Color = Sk(color), IsAntialias = true };
        float ascent = -font.Metrics.Ascent, spacing = font.Spacing;
        var lines = (text ?? "").Replace("\r\n", "\n").Split('\n');
        for (int i = 0; i < lines.Length; i++)
            c.DrawText(lines[i], (float)pos.X, (float)(pos.Y + ascent + i * spacing), font, paint);
    }

    public static uint[] Text(int w, int h, string text, Point pos, string family, double size, bool bold, bool italic, Color color) =>
        Render(w, h, c => DrawText(c, text, pos, family, size, bold, italic, color));

    // ───────────────────────────── shapes ─────────────────────────────

    public static SKPath ShapePath(ShapeSpec s)
    {
        var path = new SKPath();
        var r = new SKRect((float)Math.Min(s.A.X, s.B.X), (float)Math.Min(s.A.Y, s.B.Y), (float)Math.Max(s.A.X, s.B.X), (float)Math.Max(s.A.Y, s.B.Y));
        switch (s.Kind)
        {
            case Tool.ShapeEllipse: path.AddOval(r); break;
            case Tool.ShapeLine: path.MoveTo((float)s.A.X, (float)s.A.Y); path.LineTo((float)s.B.X, (float)s.B.Y); break;
            default:
                if (s.Corner > 0) path.AddRoundRect(r, (float)s.Corner, (float)s.Corner);
                else path.AddRect(r);
                break;
        }
        return path;
    }

    /// <summary>Rasterizes a shape with an optional fill and stroke.</summary>
    public static uint[] Shape(int w, int h, ShapeSpec s, Color? fill, Color? stroke, double strokeWidth)
    {
        return Render(w, h, c =>
        {
            using var path = ShapePath(s);
            if (fill is Color f && s.Kind != Tool.ShapeLine)
            {
                using var p = new SKPaint { Color = Sk(f), IsAntialias = true, Style = SKPaintStyle.Fill };
                c.DrawPath(path, p);
            }
            if (stroke is Color st && strokeWidth > 0)
            {
                using var p = new SKPaint { Color = Sk(st), IsAntialias = true, Style = SKPaintStyle.Stroke, StrokeWidth = (float)strokeWidth, StrokeCap = SKStrokeCap.Round, StrokeJoin = SKStrokeJoin.Round };
                c.DrawPath(path, p);
            }
        });
    }

    public static uint[] OverAll(uint[] dst, uint[] src, byte[] mask = null)
    {
        var o = new uint[dst.Length];
        Parallel.For(0, dst.Length, i =>
        {
            uint s = src[i];
            if (s >> 24 == 0) { o[i] = dst[i]; return; }
            float op = mask == null ? 1f : mask[i] / 255f;
            o[i] = Px.Over(dst[i], s, op);
        });
        return o;
    }
}

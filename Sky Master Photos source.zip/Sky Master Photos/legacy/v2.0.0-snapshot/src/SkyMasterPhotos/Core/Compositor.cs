using System.Runtime.CompilerServices;
using Avalonia;

namespace SkyMasterPhotos.Core;

public static class Compositor
{
    sealed class Prep
    {
        public uint[] Px, Mask;
        public float Op;
        public BlendMode Blend;
        public bool Clipped;
        public Func<uint, uint> Adj;
    }

    static bool GroupVisible(string path, IReadOnlyDictionary<string, GroupInfo> groups, out double opacity)
    {
        opacity = 1;
        if (string.IsNullOrEmpty(path) || groups == null || groups.Count == 0) return true;
        int idx = -1;
        while (true)
        {
            idx = path.IndexOf('/', idx + 1);
            var prefix = idx < 0 ? path : path[..idx];
            if (groups.TryGetValue(prefix, out var g))
            {
                if (!g.Visible) return false;
                opacity *= g.Opacity;
            }
            if (idx < 0) return true;
        }
    }

    /// <summary>
    /// Composite visible layers (index 0 = top) inside rect r into dst (straight alpha, doc-sized).
    /// Handles layer masks, clipping masks, fill opacity, group visibility/opacity and live adjustment layers.
    /// <paramref name="skip"/> is ignored (used while a layer is floating in a transform).
    /// </summary>
    public static void Composite(IList<Layer> layers, int w, int h, Int32Rect r, uint[] dst, Layer skip = null, int fromIndex = 0, int toIndex = int.MaxValue,
        IReadOnlyDictionary<string, GroupInfo> groups = null)
    {
        r = RectUtil.Clip(r, w, h);
        if (RectUtil.IsEmptyRect(r)) return;
        var list = new List<Prep>();
        int last = Math.Min(layers.Count - 1, toIndex);
        bool baseVisible = true;
        for (int i = last; i >= fromIndex; i--) // bottom → top
        {
            var l = layers[i];
            if (l.Width != w || l.Height != h) continue;
            double gop = 1;
            bool vis = l.Visible && l != skip;
            if (vis) vis = GroupVisible(l.Group, groups, out gop);
            if (!vis) gop = 0;
            if (!l.Clipped) baseVisible = vis;
            else if (!baseVisible) continue;
            bool styled = l.Style?.Enabled == true && !l.IsAdjustment;
            float op = (float)(l.Opacity * (styled ? 1 : l.Fill) * gop);
            if (!vis || op <= 0 || l.Psd?.UnrenderedAdjustment == true)
            {
                // an invisible clip base still clips: keep a zero-alpha placeholder so clipped layers vanish
                if (!l.Clipped && vis) list.Add(new Prep { Px = l.Pixels, Mask = l.MaskEnabled ? l.Mask : null, Op = 0, Blend = l.Blend });
                continue;
            }
            list.Add(new Prep
            {
                Px = styled ? l.Style.Render(l.Pixels, l.MaskEnabled ? l.Mask : null, w, h, l.Fill) : l.Pixels,
                Mask = !styled && l.MaskEnabled ? l.Mask : null,
                Op = op,
                Blend = l.Blend,
                Clipped = l.Clipped,
                Adj = l.Adjustment?.Build(),
            });
        }
        var arr = list.ToArray();
        int x0 = r.X, x1 = r.X + r.Width;
        Parallel.For(r.Y, r.Y + r.Height, y =>
        {
            int row = y * w;
            for (int x = x0; x < x1; x++)
            {
                int idx = row + x;
                dst[idx] = CompositePixel(arr, idx);
            }
        });
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    static uint CompositePixel(Prep[] arr, int idx)
    {
        float cr = 0, cg = 0, cb = 0, ca = 0, baseA = 1;
        for (int i = 0; i < arr.Length; i++)
        {
            var L = arr[i];
            float m = L.Mask != null ? (L.Mask[idx] & 255) * (1f / 255f) : 1f;
            if (L.Adj != null)
            {
                float aa = L.Op * m;
                if (L.Clipped) aa *= baseA; else baseA = m;
                if (aa <= 0 || ca <= 0) continue;
                uint c = Px.Pack(255, (int)(cr * 255f + 0.5f), (int)(cg * 255f + 0.5f), (int)(cb * 255f + 0.5f));
                uint o = L.Adj(c);
                float ar = ((o >> 16) & 255) * (1f / 255f), ag = ((o >> 8) & 255) * (1f / 255f), ab = (o & 255) * (1f / 255f);
                if (L.Blend != BlendMode.Normal) { Blend(L.Blend, cr, cg, cb, ar, ag, ab, out ar, out ag, out ab); }
                cr += (ar - cr) * aa; cg += (ag - cg) * aa; cb += (ab - cb) * aa;
                continue;
            }
            uint s = L.Px[idx];
            float sAlpha = (s >> 24) * (1f / 255f) * m;
            if (L.Clipped) sAlpha *= baseA; else baseA = sAlpha;
            float sa = sAlpha * L.Op;
            if (sa <= 0) continue;
            float sr = ((s >> 16) & 255) * (1f / 255f);
            float sg = ((s >> 8) & 255) * (1f / 255f);
            float sb = (s & 255) * (1f / 255f);
            if (L.Blend != BlendMode.Normal && ca > 0)
            {
                Blend(L.Blend, cr, cg, cb, sr, sg, sb, out float br, out float bg, out float bb);
                sr = (1 - ca) * sr + ca * br;
                sg = (1 - ca) * sg + ca * bg;
                sb = (1 - ca) * sb + ca * bb;
            }
            if (sa >= 0.999f) { cr = sr; cg = sg; cb = sb; ca = 1; continue; }
            float oa = sa + ca * (1 - sa);
            float k = ca * (1 - sa);
            cr = (sr * sa + cr * k) / oa;
            cg = (sg * sa + cg * k) / oa;
            cb = (sb * sa + cb * k) / oa;
            ca = oa;
        }
        if (ca <= 0) return 0;
        return Px.Pack((int)(ca * 255f + 0.5f), Math.Clamp((int)(cr * 255f + 0.5f), 0, 255), Math.Clamp((int)(cg * 255f + 0.5f), 0, 255), Math.Clamp((int)(cb * 255f + 0.5f), 0, 255));
    }
    public static void Blend(BlendMode m, float br, float bg, float bb, float sr, float sg, float sb, out float r, out float g, out float b)
    {
        switch (m)
        {
            case BlendMode.Hue:
                SetLum(SetSatOf(sr, sg, sb, Sat(br, bg, bb)), Lum(br, bg, bb), out r, out g, out b); return;
            case BlendMode.Saturation:
                SetLum(SetSatOf(br, bg, bb, Sat(sr, sg, sb)), Lum(br, bg, bb), out r, out g, out b); return;
            case BlendMode.Color:
                SetLum((sr, sg, sb), Lum(br, bg, bb), out r, out g, out b); return;
            case BlendMode.Luminosity:
                SetLum((br, bg, bb), Lum(sr, sg, sb), out r, out g, out b); return;
        }
        r = Ch(m, br, sr);
        g = Ch(m, bg, sg);
        b = Ch(m, bb, sb);
    }

    [MethodImpl(MethodImplOptions.AggressiveInlining)]
    static float Ch(BlendMode m, float b, float s)
    {
        switch (m)
        {
            case BlendMode.Multiply: return b * s;
            case BlendMode.Screen: return b + s - b * s;
            case BlendMode.Overlay: return HardLight(s, b);
            case BlendMode.Darken: return Math.Min(b, s);
            case BlendMode.Lighten: return Math.Max(b, s);
            case BlendMode.ColorDodge: return Dodge(b, s);
            case BlendMode.ColorBurn: return Burn(b, s);
            case BlendMode.LinearBurn: return Math.Max(0, b + s - 1);
            case BlendMode.LinearDodge: return Math.Min(1, b + s);
            case BlendMode.HardLight: return HardLight(b, s);
            case BlendMode.SoftLight:
                if (s <= 0.5f) return b - (1 - 2 * s) * b * (1 - b);
                float d = b <= 0.25f ? ((16 * b - 12) * b + 4) * b : MathF.Sqrt(b);
                return b + (2 * s - 1) * (d - b);
            case BlendMode.VividLight: return s <= 0.5f ? Burn(b, 2 * s) : Dodge(b, 2 * (s - 0.5f));
            case BlendMode.LinearLight: return Math.Clamp(b + 2 * s - 1, 0, 1);
            case BlendMode.PinLight: return s <= 0.5f ? Math.Min(b, 2 * s) : Math.Max(b, 2 * s - 1);
            case BlendMode.Difference: return Math.Abs(b - s);
            case BlendMode.Exclusion: return b + s - 2 * b * s;
            case BlendMode.Subtract: return Math.Max(0, b - s);
            case BlendMode.Divide: return s <= 0 ? 1 : Math.Min(1, b / s);
            default: return s;
        }
    }

    static float HardLight(float b, float s) => s <= 0.5f ? b * 2 * s : b + (2 * s - 1) - b * (2 * s - 1);
    static float Dodge(float b, float s) => b <= 0 ? 0 : s >= 1 ? 1 : Math.Min(1, b / (1 - s));
    static float Burn(float b, float s) => b >= 1 ? 1 : s <= 0 ? 0 : 1 - Math.Min(1, (1 - b) / s);

    static float Lum(float r, float g, float b) => 0.3f * r + 0.59f * g + 0.11f * b;
    static float Sat(float r, float g, float b) => Math.Max(r, Math.Max(g, b)) - Math.Min(r, Math.Min(g, b));

    static void SetLum((float r, float g, float b) c, float l, out float r, out float g, out float b)
    {
        float d = l - Lum(c.r, c.g, c.b);
        r = c.r + d; g = c.g + d; b = c.b + d;
        float L = Lum(r, g, b);
        float n = Math.Min(r, Math.Min(g, b)), x = Math.Max(r, Math.Max(g, b));
        if (n < 0)
        {
            r = L + (r - L) * L / (L - n); g = L + (g - L) * L / (L - n); b = L + (b - L) * L / (L - n);
        }
        if (x > 1)
        {
            r = L + (r - L) * (1 - L) / (x - L); g = L + (g - L) * (1 - L) / (x - L); b = L + (b - L) * (1 - L) / (x - L);
        }
    }

    static (float, float, float) SetSatOf(float r, float g, float b, float s)
    {
        float mx = Math.Max(r, Math.Max(g, b)), mn = Math.Min(r, Math.Min(g, b));
        if (mx <= mn) return (0, 0, 0);
        float f(float c) => (c - mn) * s / (mx - mn);
        return (f(r), f(g), f(b));
    }

    /// <summary>Write straight-alpha pixels in rect into a premultiplied BGRA back buffer.</summary>
    public static unsafe void WritePremul(uint[] src, int w, Int32Rect r, IntPtr backBuffer, int stride)
    {
        int x0 = r.X, x1 = r.X + r.Width;
        Parallel.For(r.Y, r.Y + r.Height, y =>
        {
            uint* row = (uint*)((byte*)backBuffer + (long)y * stride);
            int srow = y * w;
            for (int x = x0; x < x1; x++)
            {
                uint p = src[srow + x];
                uint a = p >> 24;
                if (a == 255) row[x] = p;
                else if (a == 0) row[x] = 0;
                else
                {
                    uint rr = ((p >> 16) & 255) * a / 255, gg = ((p >> 8) & 255) * a / 255, bb = (p & 255) * a / 255;
                    row[x] = (a << 24) | (rr << 16) | (gg << 8) | bb;
                }
            }
        });
    }
}

using SkiaSharp;

namespace SkyMasterPhotos.Core;

/// <summary>Installed fonts (via Skia, so it works the same on Windows and Linux) and a sensible default.</summary>
public static class FontCatalog
{
    static string _default;
    static HashSet<string> _set;
    static List<string> _sorted;

    static readonly string[] Preferred = { "Segoe UI", "Inter", "Noto Sans", "Cantarell", "Ubuntu", "DejaVu Sans", "Liberation Sans", "Arial", "Helvetica" };

    public static HashSet<string> Set => _set ??= new HashSet<string>(SKFontManager.Default.FontFamilies, StringComparer.OrdinalIgnoreCase);

    public static IReadOnlyList<string> Families => _sorted ??= Set.OrderBy(f => f, StringComparer.OrdinalIgnoreCase).ToList();

    /// <summary>Segoe UI on Windows; Noto Sans / Cantarell / DejaVu Sans… on Linux.</summary>
    public static string Default => _default ??= Preferred.FirstOrDefault(Set.Contains) ?? SKTypeface.Default.FamilyName ?? "sans-serif";

    public static bool Has(string family) => !string.IsNullOrWhiteSpace(family) && Set.Contains(family);

    /// <summary>The family itself when installed, otherwise the default (keeps old projects readable on any machine).</summary>
    public static string Resolve(string family) => Has(family) ? family : Default;
}

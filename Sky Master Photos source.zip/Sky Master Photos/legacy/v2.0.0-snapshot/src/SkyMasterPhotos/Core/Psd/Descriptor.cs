using System.IO;

namespace SkyMasterPhotos.Core.Psd;

public sealed record UnitFloat(string Unit, double Value);
public sealed record EnumValue(string Type, string Value);
public sealed record ClassRef(string Name, string ClassId);

/// <summary>Photoshop Action Descriptor ("Objc"): an ordered key → value map.</summary>
public sealed class Descriptor
{
    public string Name = "";
    public string ClassId = "null";
    public readonly List<KeyValuePair<string, object>> Items = new();

    public object this[string key]
    {
        get { foreach (var kv in Items) if (kv.Key == key) return kv.Value; return null; }
        set
        {
            for (int i = 0; i < Items.Count; i++) if (Items[i].Key == key) { Items[i] = new(key, value); return; }
            Items.Add(new(key, value));
        }
    }

    public double Num(string key, double def = 0) => this[key] switch
    {
        int i => i,
        double d => d,
        UnitFloat u => u.Value,
        long l => l,
        _ => def
    };

    public Descriptor Obj(string key) => this[key] as Descriptor;
    public string Str(string key) => this[key] as string;

    // ───────────────────────────── reading ─────────────────────────────

    static string Id(BeReader r)
    {
        uint n = r.U32();
        if (n == 0) return r.Sig();
        if (n > 4096) throw new InvalidDataException("Descriptor key too long.");
        return System.Text.Encoding.ASCII.GetString(r.Bytes(n));
    }

    public static Descriptor Read(BeReader r)
    {
        var d = new Descriptor { Name = r.Unicode(), ClassId = Id(r) };
        uint count = r.U32();
        if (count > 100000) throw new InvalidDataException("Descriptor too large.");
        for (uint i = 0; i < count; i++)
        {
            var key = Id(r);
            var type = r.Sig();
            d.Items.Add(new(key, ReadValue(r, type)));
        }
        return d;
    }

    static object ReadValue(BeReader r, string type)
    {
        switch (type)
        {
            case "Objc":
            case "GlbO":
                return Read(r);
            case "VlLs":
            {
                uint n = r.U32();
                var list = new List<object>((int)Math.Min(n, 4096));
                for (uint i = 0; i < n; i++) list.Add(ReadValue(r, r.Sig()));
                return list;
            }
            case "doub": return r.F64();
            case "UntF": { var u = r.Sig(); return new UnitFloat(u, r.F64()); }
            case "UnFl":
            {
                var u = r.Sig();
                uint n = r.U32();
                var a = new double[n];
                for (int i = 0; i < n; i++) a[i] = r.F64();
                return a;
            }
            case "TEXT": return r.Unicode();
            case "enum": return new EnumValue(Id(r), Id(r));
            case "long": return r.I32();
            case "comp": return r.I64();
            case "bool": return r.U8() != 0;
            case "type":
            case "GlbC": return new ClassRef(r.Unicode(), Id(r));
            case "alis":
            case "tdta":
            case "Pth ": return r.Bytes(r.U32());
            case "obj ":
            {
                uint n = r.U32();
                var items = new List<object>();
                for (uint i = 0; i < n; i++)
                {
                    var t = r.Sig();
                    switch (t)
                    {
                        case "prop": items.Add((r.Unicode(), Id(r), Id(r))); break;
                        case "Clss": items.Add(new ClassRef(r.Unicode(), Id(r))); break;
                        case "Enmr": items.Add((r.Unicode(), Id(r), Id(r), Id(r))); break;
                        case "rele": items.Add((r.Unicode(), Id(r), r.I32())); break;
                        case "Idnt":
                        case "indx": items.Add(r.I32()); break;
                        case "name": items.Add((r.Unicode(), Id(r), r.Unicode())); break;
                        default: throw new InvalidDataException($"Unknown reference type {t}");
                    }
                }
                return items;
            }
            case "ObAr":
            {
                // object array: version + descriptor-like header whose items are unit-float arrays
                r.U32();
                var d = new Descriptor { Name = r.Unicode(), ClassId = Id(r) };
                uint n = r.U32();
                for (uint i = 0; i < n; i++)
                {
                    var key = Id(r);
                    var t = r.Sig();
                    d.Items.Add(new(key, ReadValue(r, t)));
                }
                return d;
            }
            default:
                throw new InvalidDataException($"Unknown descriptor type '{type}'");
        }
    }

    // ───────────────────────────── writing (subset) ─────────────────────────────

    static void WriteId(BeWriter w, string id)
    {
        if (id.Length == 4) { w.U32(0); w.Sig(id); }
        else { var b = System.Text.Encoding.ASCII.GetBytes(id); w.U32((uint)b.Length); w.Bytes(b); }
    }

    public void Write(BeWriter w)
    {
        w.Unicode(Name);
        WriteId(w, ClassId);
        w.U32((uint)Items.Count);
        foreach (var (k, v) in Items)
        {
            WriteId(w, k);
            WriteValue(w, v);
        }
    }

    static void WriteValue(BeWriter w, object v)
    {
        switch (v)
        {
            case Descriptor d: w.Sig("Objc"); d.Write(w); break;
            case double dd: w.Sig("doub"); w.F64(dd); break;
            case UnitFloat u: w.Sig("UntF"); w.Sig(u.Unit); w.F64(u.Value); break;
            case string s: w.Sig("TEXT"); w.Unicode(s); break;
            case EnumValue e: w.Sig("enum"); WriteId(w, e.Type); WriteId(w, e.Value); break;
            case int i: w.Sig("long"); w.I32(i); break;
            case bool b: w.Sig("bool"); w.U8(b ? 1 : 0); break;
            case byte[] raw: w.Sig("tdta"); w.U32((uint)raw.Length); w.Bytes(raw); break;
            case List<object> list:
                w.Sig("VlLs");
                w.U32((uint)list.Count);
                foreach (var o in list) WriteValue(w, o);
                break;
            default: throw new NotSupportedException($"Cannot write descriptor value {v?.GetType().Name}");
        }
    }
}

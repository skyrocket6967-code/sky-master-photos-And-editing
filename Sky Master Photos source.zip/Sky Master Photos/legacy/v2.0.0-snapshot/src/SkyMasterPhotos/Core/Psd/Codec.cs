using System.IO;
using System.IO.Compression;

namespace SkyMasterPhotos.Core.Psd;

/// <summary>PSD channel compression: raw, PackBits RLE, ZIP and ZIP-with-prediction.</summary>
public static class Codec
{
    public static void UnpackBits(ReadOnlySpan<byte> src, Span<byte> dst)
    {
        int i = 0, o = 0;
        while (i < src.Length && o < dst.Length)
        {
            int n = (sbyte)src[i++];
            if (n >= 0)
            {
                int cnt = Math.Min(n + 1, Math.Min(dst.Length - o, src.Length - i));
                src.Slice(i, cnt).CopyTo(dst.Slice(o));
                i += n + 1;
                o += cnt;
            }
            else if (n != -128)
            {
                if (i >= src.Length) break;
                byte b = src[i++];
                int cnt = Math.Min(1 - n, dst.Length - o);
                dst.Slice(o, cnt).Fill(b);
                o += cnt;
            }
        }
    }

    public static byte[] PackBits(ReadOnlySpan<byte> src)
    {
        var o = new List<byte>(src.Length / 2 + 16);
        int i = 0;
        while (i < src.Length)
        {
            // run?
            int run = 1;
            while (i + run < src.Length && run < 128 && src[i + run] == src[i]) run++;
            if (run >= 2)
            {
                o.Add((byte)(sbyte)(1 - run));
                o.Add(src[i]);
                i += run;
                continue;
            }
            // literal span until a run of >= 3 begins
            int start = i;
            int lit = 0;
            while (i < src.Length && lit < 128)
            {
                if (i + 2 < src.Length && src[i] == src[i + 1] && src[i] == src[i + 2]) break;
                i++; lit++;
            }
            o.Add((byte)(lit - 1));
            for (int k = start; k < start + lit; k++) o.Add(src[k]);
        }
        return o.ToArray();
    }

    /// <summary>Decode one channel's pixel data into planar bytes (depth/8 bytes per sample).</summary>
    public static byte[] Decode(BeReader r, int compression, long dataLength, int w, int h, int depth, bool psb)
    {
        int bpp = Math.Max(1, depth / 8);
        int rowBytes = depth == 1 ? (w + 7) / 8 : w * bpp;
        var plane = new byte[(long)rowBytes * h];
        long end = r.Pos + dataLength;
        if (w <= 0 || h <= 0) { r.Pos = end; return plane; }
        switch (compression)
        {
            case 0:
            {
                long n = Math.Min(plane.Length, dataLength);
                r.Span(n).CopyTo(plane);
                break;
            }
            case 1:
            {
                var counts = new int[h];
                for (int y = 0; y < h; y++) counts[y] = psb ? (int)r.U32() : r.U16();
                for (int y = 0; y < h; y++)
                {
                    int c = Math.Min(counts[y], (int)Math.Max(0, end - r.Pos));
                    UnpackBits(r.Span(c), plane.AsSpan(y * rowBytes, rowBytes));
                }
                break;
            }
            case 2:
            case 3:
            {
                var comp = r.Bytes(dataLength);
                using (var zs = new ZLibStream(new MemoryStream(comp), CompressionMode.Decompress))
                {
                    int read = 0, n;
                    while (read < plane.Length && (n = zs.Read(plane, read, plane.Length - read)) > 0) read += n;
                }
                if (compression == 3) Unpredict(plane, w, h, depth);
                break;
            }
            default:
                throw new InvalidDataException($"Unknown PSD compression {compression}");
        }
        r.Pos = end;
        return plane;
    }

    static void Unpredict(byte[] p, int w, int h, int depth)
    {
        if (depth == 8)
        {
            for (int y = 0; y < h; y++) { int o = y * w; for (int x = 1; x < w; x++) p[o + x] = (byte)(p[o + x] + p[o + x - 1]); }
        }
        else if (depth == 16)
        {
            for (int y = 0; y < h; y++)
            {
                int o = y * w * 2;
                for (int x = 1; x < w; x++)
                {
                    int i = o + x * 2;
                    int prev = p[i - 2] << 8 | p[i - 1];
                    int cur = (p[i] << 8 | p[i + 1]) + prev;
                    p[i] = (byte)(cur >> 8); p[i + 1] = (byte)cur;
                }
            }
        }
        else if (depth == 32)
        {
            // byte-wise delta over the row, then de-interleave the four byte planes
            int row = w * 4;
            var tmp = new byte[row];
            for (int y = 0; y < h; y++)
            {
                int o = y * row;
                for (int i = 1; i < row; i++) p[o + i] = (byte)(p[o + i] + p[o + i - 1]);
                for (int x = 0; x < w; x++)
                {
                    tmp[x * 4] = p[o + x];
                    tmp[x * 4 + 1] = p[o + w + x];
                    tmp[x * 4 + 2] = p[o + 2 * w + x];
                    tmp[x * 4 + 3] = p[o + 3 * w + x];
                }
                Array.Copy(tmp, 0, p, o, row);
            }
        }
    }

    /// <summary>Convert a planar channel at any depth into 8-bit samples.</summary>
    public static byte[] To8(byte[] plane, int w, int h, int depth, bool isColor = true)
    {
        if (depth == 8) return plane;
        var o = new byte[w * h];
        if (depth == 16)
        {
            for (int i = 0; i < o.Length; i++) o[i] = (byte)(((plane[i * 2] << 8) | plane[i * 2 + 1]) * 255 / 65535);
        }
        else if (depth == 32)
        {
            for (int i = 0; i < o.Length; i++)
            {
                int bits = plane[i * 4] << 24 | plane[i * 4 + 1] << 16 | plane[i * 4 + 2] << 8 | plane[i * 4 + 3];
                float f = BitConverter.Int32BitsToSingle(bits);
                // 32-bit documents are linear; convert to display gamma
                double v = isColor ? Math.Pow(Math.Clamp(f, 0, 1), 1 / 2.2) : Math.Clamp(f, 0, 1);
                o[i] = (byte)Math.Round(v * 255);
            }
        }
        else if (depth == 1)
        {
            int rb = (w + 7) / 8;
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++)
                    o[y * w + x] = (plane[y * rb + x / 8] & (0x80 >> (x % 8))) != 0 ? (byte)0 : (byte)255;
        }
        return o;
    }
}

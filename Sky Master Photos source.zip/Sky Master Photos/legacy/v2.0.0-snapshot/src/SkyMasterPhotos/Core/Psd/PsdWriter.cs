using System.IO;
using Avalonia;

namespace SkyMasterPhotos.Core.Psd;

/// <summary>
/// Writes a layered 8-bit RGB Photoshop document. Layers are never flattened: each layer keeps its own
/// pixels, mask, blend mode, opacity, fill, visibility, lock, clipping and group. Adjustment layers are
/// written as real Photoshop adjustment layers, and unedited Photoshop features (text, smart objects,
/// effects, vector masks…) are written back from their original data.
/// </summary>
public static class PsdWriter
{
    sealed class OutRec
    {
        public int Top, Left, Bottom, Right;
        public readonly List<(short id, byte[] data)> Channels = new();
        public string Blend = "norm";
        public byte Opacity = 255, Clipping, Flags = 0x08;
        public byte[] MaskData = Array.Empty<byte>();
        public string Name = "";
        public readonly List<PsdBlock> Blocks = new();
    }

    public static void Save(Document doc, string path)
    {
        var bytes = Write(doc);
        string tmp = path + ".tmp";
        File.WriteAllBytes(tmp, bytes);
        File.Move(tmp, path, true);
    }

    public static byte[] Write(Document doc)
    {
        // Native styles are baked per layer for PSD, never into the entire document.
        if (doc.Layers.Any(l => l.Style?.Enabled == true))
        {
            var export = new Document(doc.Width, doc.Height, doc.Title) { Groups = new(doc.Groups), PsdData = doc.PsdData };
            foreach (var source in doc.Layers)
            {
                var copy = source.CloneDeep();
                if (source.Style?.Enabled == true)
                {
                    copy.SetPixels(source.Style.Render(source.Pixels, source.MaskEnabled ? source.Mask : null,
                        doc.Width, doc.Height, source.Fill), doc.Width, doc.Height);
                    copy.SetMask(null); copy.Fill = 1; copy.Style = null; copy.Text = null; copy.Psd = null;
                }
                export.Layers.Add(copy);
            }
            export.RenderAll();
            return Write(export);
        }
        int w = doc.Width, h = doc.Height;
        if (w > 30000 || h > 30000) throw new InvalidOperationException("PSD files are limited to 30,000 × 30,000 pixels.");
        var flat = doc.Flat;
        bool anyAlpha = false;
        for (int i = 0; i < flat.Length; i += 1) if ((flat[i] >> 24) != 255) { anyAlpha = true; break; }

        var recs = BuildRecords(doc);
        var bw = new BeWriter(w * h * 4 + (1 << 20));

        // header
        bw.Sig("8BPS");
        bw.U16(1);
        bw.Zeros(6);
        bw.U16(anyAlpha ? 4 : 3);
        bw.U32((uint)h);
        bw.U32((uint)w);
        bw.U16(8);
        bw.U16(PsdFormat.ModeRgb);

        // color mode data
        bw.U32(0);

        // image resources
        long resLen = bw.BeginLen();
        var resources = doc.PsdData?.Resources.ToList() ?? new List<(ushort, byte[])>();
        if (!resources.Any(r => r.Item1 == 1005)) resources.Insert(0, (1005, ResolutionInfo(72)));
        foreach (var (id, data) in resources)
        {
            bw.Sig("8BIM");
            bw.U16(id);
            bw.U16(0); // empty pascal name, padded to even
            bw.U32((uint)data.Length);
            bw.Bytes(data);
            if ((data.Length & 1) == 1) bw.U8(0);
        }
        bw.EndLen(resLen);

        // layer and mask information
        long lmLen = bw.BeginLen();
        long liLen = bw.BeginLen();
        bw.I16(anyAlpha ? -recs.Count : recs.Count);
        foreach (var r in recs) WriteRecord(bw, r);
        foreach (var r in recs)
            foreach (var (_, data) in r.Channels) bw.Bytes(data);
        bw.EndLen(liLen, 4);
        bw.U32(0); // global layer mask info
        if (doc.PsdData != null)
            foreach (var b in doc.PsdData.GlobalBlocks)
            {
                if (PsdFormat.DroppedGlobals.Contains(b.Key)) continue;
                WriteBlock(bw, b, 4);
            }
        bw.EndLen(lmLen);

        // merged image (RLE) for compatibility with readers that ignore layers
        WriteComposite(bw, flat, w, h, anyAlpha);
        return bw.ToArray();
    }

    static byte[] ResolutionInfo(int dpi)
    {
        var w = new BeWriter(16);
        w.U32((uint)(dpi << 16)); w.U16(1); w.U16(1);
        w.U32((uint)(dpi << 16)); w.U16(1); w.U16(1);
        return w.ToArray();
    }

    // ───────────────────────────── records ─────────────────────────────

    static List<OutRec> BuildRecords(Document doc)
    {
        var recs = new List<OutRec>();
        var open = new List<string>(); // current group segments
        var ordered = doc.Layers.Reverse().ToList(); // bottom → top
        foreach (var l in ordered)
        {
            var target = string.IsNullOrEmpty(l.Group) ? Array.Empty<string>() : l.Group.Split('/');
            int common = 0;
            while (common < open.Count && common < target.Length && open[common] == target[common]) common++;
            while (open.Count > common) { recs.Add(GroupRecord(doc, string.Join("/", open))); open.RemoveAt(open.Count - 1); }
            while (open.Count < target.Length) { open.Add(target[open.Count]); recs.Add(DividerRecord()); }
            recs.Add(LayerRecord(doc, l));
        }
        while (open.Count > 0) { recs.Add(GroupRecord(doc, string.Join("/", open))); open.RemoveAt(open.Count - 1); }
        return recs;
    }

    static OutRec DividerRecord()
    {
        var r = new OutRec { Name = "</Layer group>", Flags = 0x18 };
        EmptyChannels(r);
        var lw = new BeWriter(16);
        lw.U32(3);
        r.Blocks.Add(new PsdBlock("lsct", lw.ToArray()));
        r.Blocks.Add(new PsdBlock("luni", Uni("</Layer group>")));
        return r;
    }

    static OutRec GroupRecord(Document doc, string path)
    {
        doc.Groups.TryGetValue(path, out var g);
        string name = g?.Name ?? path.Split('/').Last();
        var r = new OutRec
        {
            Name = name,
            Opacity = (byte)Math.Round((g?.Opacity ?? 1) * 255),
            Flags = (byte)(0x08 | ((g?.Visible ?? true) ? 0 : 0x02)),
            Blend = g?.BlendKey ?? "pass",
        };
        EmptyChannels(r);
        var lw = new BeWriter(16);
        lw.U32((g?.Open ?? true) ? 1u : 2u);
        lw.Sig("8BIM");
        lw.Sig(r.Blend.Length == 4 ? r.Blend : "pass");
        r.Blocks.Add(new PsdBlock("lsct", lw.ToArray()));
        r.Blocks.Add(new PsdBlock("luni", Uni(name)));
        if (g != null) r.Blocks.AddRange(g.Blocks.Where(b => !PsdFormat.Regenerated.Contains(b.Key)));
        return r;
    }

    static void EmptyChannels(OutRec r)
    {
        foreach (short id in new short[] { -1, 0, 1, 2 }) r.Channels.Add((id, new byte[] { 0, 0 }));
    }

    static byte[] Uni(string s)
    {
        var w = new BeWriter(s.Length * 2 + 8);
        w.UnicodeName(s);
        return w.ToArray();
    }

    static OutRec LayerRecord(Document doc, Layer l)
    {
        int w = doc.Width, h = doc.Height;
        var r = new OutRec
        {
            Name = l.Name ?? "",
            Opacity = (byte)Math.Round(l.Opacity * 255),
            Clipping = (byte)(l.Clipped ? 1 : 0),
            Flags = (byte)(0x08 | (l.Visible ? 0 : 0x02)),
        };
        var psd = l.Psd;
        r.Blend = psd?.BlendKey != null && psd.BlendAtImport == l.Blend ? psd.BlendKey : PsdFormat.ToKey(l.Blend);

        bool contentUnchanged = psd != null && psd.SourceHash == PsdLayerData.Hash(l.Pixels, l.Mask);
        bool textUnchanged = psd?.ImportedText != null && ReferenceEquals(psd.ImportedText, l.Text);
        bool adjUnchanged = psd?.ImportedAdjustment != null && ReferenceEquals(psd.ImportedAdjustment, l.Adjustment);
        if (psd != null)
        {
            // keep transparency-lock and Photoshop 5+ bits; 'pixel data irrelevant' (vector layers) only while unedited
            int f = psd.RecordFlags & (contentUnchanged ? 0x19 : 0x09);
            r.Flags = (byte)(f | 0x08 | (l.Visible ? 0 : 0x02));
        }

        // pixels
        bool isAdj = l.IsAdjustment || psd?.UnrenderedAdjustment == true;
        if (isAdj) EmptyChannels(r);
        else
        {
            var b = Transforms.OpaqueBounds(l.Pixels, w, h);
            if (RectUtil.IsEmptyRect(b)) EmptyChannels(r);
            else
            {
                r.Top = b.Y; r.Left = b.X; r.Bottom = b.Y + b.Height; r.Right = b.X + b.Width;
                var planes = new byte[4][];
                for (int c = 0; c < 4; c++) planes[c] = new byte[b.Width * b.Height];
                var px = l.Pixels;
                for (int y = 0; y < b.Height; y++)
                    for (int x = 0; x < b.Width; x++)
                    {
                        uint p = px[(b.Y + y) * w + b.X + x];
                        int i = y * b.Width + x;
                        planes[0][i] = (byte)(p >> 24);
                        planes[1][i] = (byte)(p >> 16);
                        planes[2][i] = (byte)(p >> 8);
                        planes[3][i] = (byte)p;
                    }
                r.Channels.Add((-1, Rle(planes[0], b.Width, b.Height)));
                r.Channels.Add((0, Rle(planes[1], b.Width, b.Height)));
                r.Channels.Add((1, Rle(planes[2], b.Width, b.Height)));
                r.Channels.Add((2, Rle(planes[3], b.Width, b.Height)));
            }
        }

        // mask
        if (l.Mask != null)
        {
            byte def = Masks.EdgeValue(l.Mask, w, h);
            int minX = w, minY = h, maxX = -1, maxY = -1;
            for (int y = 0; y < h; y++)
            {
                int row = y * w;
                for (int x = 0; x < w; x++)
                {
                    if (Masks.Value(l.Mask[row + x]) == def) continue;
                    if (x < minX) minX = x;
                    if (x > maxX) maxX = x;
                    if (y < minY) minY = y;
                    maxY = y;
                }
            }
            var mw = new BeWriter(24);
            if (maxX >= 0)
            {
                int bw2 = maxX - minX + 1, bh = maxY - minY + 1;
                mw.I32(minY); mw.I32(minX); mw.I32(maxY + 1); mw.I32(maxX + 1);
                var plane = new byte[bw2 * bh];
                for (int y = 0; y < bh; y++)
                    for (int x = 0; x < bw2; x++) plane[y * bw2 + x] = Masks.Value(l.Mask[(minY + y) * w + minX + x]);
                r.Channels.Add((-2, Rle(plane, bw2, bh)));
            }
            else
            {
                mw.I32(0); mw.I32(0); mw.I32(0); mw.I32(0);
                r.Channels.Add((-2, new byte[] { 0, 0 }));
            }
            mw.U8(def);
            mw.U8(l.MaskEnabled ? 0 : 2);
            mw.U16(0);
            r.MaskData = mw.ToArray();
        }

        // tagged blocks — keep Photoshop's original order (readers infer layer kind from it),
        // refreshing name / fill / lock blocks in place
        byte[] Lspf(byte[] orig)
        {
            uint f = orig != null && orig.Length >= 4 ? (uint)(orig[0] << 24 | orig[1] << 16 | orig[2] << 8 | orig[3]) : 0;
            f = l.Locked ? f | 0x80000000 : f & 0x7FFFFFFF;
            return new[] { (byte)(f >> 24), (byte)(f >> 16), (byte)(f >> 8), (byte)f };
        }
        var fresh = l.Adjustment != null && !adjUnchanged ? PsdAdjust.Encode(l.Adjustment) : new List<PsdBlock>();
        bool luni = false, iopa = false, lspf = false;
        if (psd != null)
        {
            foreach (var b in psd.Blocks)
            {
                switch (b.Key)
                {
                    case "luni": r.Blocks.Add(new PsdBlock("luni", Uni(r.Name))); luni = true; continue;
                    case "iOpa": r.Blocks.Add(new PsdBlock("iOpa", new byte[] { (byte)Math.Round(l.Fill * 255), 0, 0, 0 })); iopa = true; continue;
                    case "lspf": r.Blocks.Add(new PsdBlock("lspf", Lspf(b.Data))); lspf = true; continue;
                    case "lsct":
                    case "lsdk": continue;
                }
                if (b.Key is "TySh" or "tySh") { if (textUnchanged && contentUnchanged) r.Blocks.Add(b); continue; }
                if (PsdAdjust.IsAdjustmentKey(b.Key))
                {
                    if (psd.UnrenderedAdjustment || adjUnchanged) r.Blocks.Add(b);
                    else if (fresh.Count > 0) { r.Blocks.AddRange(fresh); fresh.Clear(); }
                    continue;
                }
                if (PsdFormat.ContentBlocks.Contains(b.Key)) { if (contentUnchanged && (l.Text == null || textUnchanged)) r.Blocks.Add(b); continue; }
                r.Blocks.Add(b);
            }
        }
        // new adjustment data goes first, like Photoshop writes it
        if (fresh.Count > 0) r.Blocks.InsertRange(0, fresh);
        if (!luni) r.Blocks.Insert(fresh.Count, new PsdBlock("luni", Uni(r.Name)));
        if (!iopa && l.Fill < 1) r.Blocks.Add(new PsdBlock("iOpa", new byte[] { (byte)Math.Round(l.Fill * 255), 0, 0, 0 }));
        if (!lspf && l.Locked) r.Blocks.Add(new PsdBlock("lspf", Lspf(null)));        return r;
    }

    static void WriteRecord(BeWriter w, OutRec r)
    {
        w.I32(r.Top); w.I32(r.Left); w.I32(r.Bottom); w.I32(r.Right);
        w.U16(r.Channels.Count);
        foreach (var (id, data) in r.Channels) { w.I16(id); w.U32((uint)data.Length); }
        w.Sig("8BIM");
        w.Sig(r.Blend.Length == 4 ? r.Blend : "norm");
        w.U8(r.Opacity);
        w.U8(r.Clipping);
        w.U8(r.Flags);
        w.U8(0);
        long extra = w.BeginLen();
        w.U32((uint)r.MaskData.Length);
        w.Bytes(r.MaskData);
        // blending ranges: composite gray + 3 channels, all fully open
        w.U32(40);
        for (int i = 0; i < 5; i++) { w.U8(0); w.U8(0); w.U8(255); w.U8(255); w.U8(0); w.U8(0); w.U8(255); w.U8(255); }
        w.Pascal(r.Name, 4);
        foreach (var b in r.Blocks) WriteBlock(w, b, 2);
        w.EndLen(extra);
    }

    static void WriteBlock(BeWriter w, PsdBlock b, int pad)
    {
        w.Sig("8BIM");
        w.Sig(b.Key);
        long len = w.BeginLen();
        w.Bytes(b.Data);
        w.EndLen(len, pad);
    }

    /// <summary>Channel data: compression (1 = RLE), per-row byte counts, packed rows.</summary>
    static byte[] Rle(byte[] plane, int w, int h)
    {
        var rows = new byte[h][];
        long total = 2 + h * 2;
        for (int y = 0; y < h; y++) { rows[y] = Codec.PackBits(plane.AsSpan(y * w, w)); total += rows[y].Length; }
        var o = new BeWriter((int)Math.Min(int.MaxValue, total));
        o.U16(1);
        for (int y = 0; y < h; y++) o.U16(rows[y].Length);
        for (int y = 0; y < h; y++) o.Bytes(rows[y]);
        return o.ToArray();
    }

    static void WriteComposite(BeWriter bw, uint[] flat, int w, int h, bool alpha)
    {
        int nch = alpha ? 4 : 3;
        var rows = new byte[nch * h][];
        Parallel.For(0, nch * h, idx =>
        {
            int c = idx / h, y = idx % h;
            var line = new byte[w];
            int shift = c switch { 0 => 16, 1 => 8, 2 => 0, _ => 24 };
            for (int x = 0; x < w; x++)
            {
                uint p = flat[y * w + x];
                // without an alpha channel, readers expect the merge flattened on white
                line[x] = alpha || c == 3 ? (byte)(p >> shift) : (byte)((((p >> shift) & 255) * (p >> 24) + 255 * (255 - (p >> 24))) / 255);
            }
            rows[idx] = Codec.PackBits(line);
        });
        bw.U16(1);
        foreach (var r in rows) bw.U16(r.Length);
        foreach (var r in rows) bw.Bytes(r);
    }
}

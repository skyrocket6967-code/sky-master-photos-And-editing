namespace SkyMasterPhotos.Core.Psd;

/// <summary>Shared PSD constants and blend-mode key mapping.</summary>
public static class PsdFormat
{
    public const int ModeBitmap = 0, ModeGray = 1, ModeIndexed = 2, ModeRgb = 3, ModeCmyk = 4, ModeMultichannel = 7, ModeDuotone = 8, ModeLab = 9;

    public static string ModeName(int m) => m switch
    {
        ModeBitmap => "Bitmap", ModeGray => "Grayscale", ModeIndexed => "Indexed", ModeRgb => "RGB", ModeCmyk => "CMYK",
        ModeMultichannel => "Multichannel", ModeDuotone => "Duotone", ModeLab => "Lab", _ => $"mode {m}"
    };

    /// <summary>Keys whose length field is 8 bytes in PSB files.</summary>
    public static readonly HashSet<string> BigKeys = new() { "LMsk", "Lr16", "Lr32", "Layr", "Mt16", "Mt32", "Mtrn", "Alph", "FMsk", "lnk2", "FEid", "FXid", "PxSD" };

    /// <summary>Blocks rebuilt by the writer from the layer model (never copied verbatim).</summary>
    public static readonly HashSet<string> Regenerated = new() { "luni", "lsct", "lsdk", "iOpa", "lspf" };

    /// <summary>Blocks that define the layer's content and are only valid while pixels / spec are unchanged.</summary>
    public static readonly HashSet<string> ContentBlocks = new()
    {
        "TySh", "tySh", "SoLd", "PlLd", "SoLE", "vmsk", "vsms", "vscg", "vogk", "vstk", "vmgm", "SoCo", "GdFl", "PtFl", "plLd", "lnsr",
    };

    /// <summary>Global blocks that must not be copied into an 8-bit PSD.</summary>
    public static readonly HashSet<string> DroppedGlobals = new() { "Lr16", "Lr32", "Layr", "Mt16", "Mt32", "Mtrn", "Alph", "FMsk", "LMsk" };

    /// <summary>Image resources that remain valid after editing.</summary>
    public static readonly HashSet<ushort> SafeResources = new() { 1005, 1032, 1037, 1049, 1060, 1062, 1064, 1050, 1065 };

    public static BlendMode FromKey(string key, out bool exact)
    {
        exact = true;
        switch (key)
        {
            case "norm": return BlendMode.Normal;
            case "pass": return BlendMode.Normal;
            case "dark": return BlendMode.Darken;
            case "mul ": return BlendMode.Multiply;
            case "idiv": return BlendMode.ColorBurn;
            case "lbrn": return BlendMode.LinearBurn;
            case "lite": return BlendMode.Lighten;
            case "scrn": return BlendMode.Screen;
            case "div ": return BlendMode.ColorDodge;
            case "lddg": return BlendMode.LinearDodge;
            case "over": return BlendMode.Overlay;
            case "sLit": return BlendMode.SoftLight;
            case "hLit": return BlendMode.HardLight;
            case "vLit": return BlendMode.VividLight;
            case "lLit": return BlendMode.LinearLight;
            case "pLit": return BlendMode.PinLight;
            case "diff": return BlendMode.Difference;
            case "smud": return BlendMode.Exclusion;
            case "fsub": return BlendMode.Subtract;
            case "fdiv": return BlendMode.Divide;
            case "hue ": return BlendMode.Hue;
            case "sat ": return BlendMode.Saturation;
            case "colr": return BlendMode.Color;
            case "lum ": return BlendMode.Luminosity;
            // approximations
            case "diss": exact = false; return BlendMode.Normal;
            case "dkCl": exact = false; return BlendMode.Darken;
            case "lgCl": exact = false; return BlendMode.Lighten;
            case "hMix": exact = false; return BlendMode.VividLight;
            default: exact = false; return BlendMode.Normal;
        }
    }

    public static string ToKey(BlendMode m) => m switch
    {
        BlendMode.Normal => "norm",
        BlendMode.Darken => "dark",
        BlendMode.Multiply => "mul ",
        BlendMode.ColorBurn => "idiv",
        BlendMode.LinearBurn => "lbrn",
        BlendMode.Lighten => "lite",
        BlendMode.Screen => "scrn",
        BlendMode.ColorDodge => "div ",
        BlendMode.LinearDodge => "lddg",
        BlendMode.Overlay => "over",
        BlendMode.SoftLight => "sLit",
        BlendMode.HardLight => "hLit",
        BlendMode.VividLight => "vLit",
        BlendMode.LinearLight => "lLit",
        BlendMode.PinLight => "pLit",
        BlendMode.Difference => "diff",
        BlendMode.Exclusion => "smud",
        BlendMode.Subtract => "fsub",
        BlendMode.Divide => "fdiv",
        BlendMode.Hue => "hue ",
        BlendMode.Saturation => "sat ",
        BlendMode.Color => "colr",
        BlendMode.Luminosity => "lum ",
        _ => "norm"
    };
}

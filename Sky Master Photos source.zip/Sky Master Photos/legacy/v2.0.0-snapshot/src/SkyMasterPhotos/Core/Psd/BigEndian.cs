using System.IO;
using System.Text;

namespace SkyMasterPhotos.Core.Psd;

/// <summary>Big-endian reader over an in-memory PSD.</summary>
public sealed class BeReader
{
    readonly byte[] _b;
    public long Pos;
    public long Length => _b.Length;

    public BeReader(byte[] b, long pos = 0) { _b = b; Pos = pos; }

    void Need(long n)
    {
        if (n < 0 || Pos + n > _b.Length) throw new InvalidDataException($"Unexpected end of PSD data at {Pos} (needed {n} bytes).");
    }

    public byte U8() { Need(1); return _b[Pos++]; }
    public sbyte I8() => (sbyte)U8();
    public ushort U16() { Need(2); ushort v = (ushort)(_b[Pos] << 8 | _b[Pos + 1]); Pos += 2; return v; }
    public short I16() => (short)U16();
    public uint U32() { Need(4); uint v = (uint)(_b[Pos] << 24 | _b[Pos + 1] << 16 | _b[Pos + 2] << 8 | _b[Pos + 3]); Pos += 4; return v; }
    public int I32() => (int)U32();
    public ulong U64() { ulong hi = U32(); return hi << 32 | U32(); }
    public long I64() => (long)U64();
    public float F32() => BitConverter.Int32BitsToSingle(I32());
    public double F64() => BitConverter.Int64BitsToDouble(I64());
    /// <summary>A length field that is 8 bytes in PSB (when <paramref name="big"/>), otherwise 4.</summary>
    public long Len(bool big) => big ? (long)U64() : U32();

    public string Sig() { Need(4); var s = Encoding.ASCII.GetString(_b, (int)Pos, 4); Pos += 4; return s; }
    public string PeekSig() => Pos + 4 <= _b.Length ? Encoding.ASCII.GetString(_b, (int)Pos, 4) : "";

    public byte[] Bytes(long n) { Need(n); var o = new byte[n]; Array.Copy(_b, Pos, o, 0, n); Pos += n; return o; }
    public void Skip(long n) { Need(n); Pos += n; }

    public ReadOnlySpan<byte> Span(long n) { Need(n); var s = new ReadOnlySpan<byte>(_b, (int)Pos, (int)n); Pos += n; return s; }

    /// <summary>Pascal string; total length (incl. length byte) padded to <paramref name="pad"/>.</summary>
    public string Pascal(int pad)
    {
        int n = U8();
        var s = Encoding.GetEncoding("ISO-8859-1").GetString(Bytes(n));
        int total = n + 1;
        int rem = total % pad;
        if (rem != 0) Skip(pad - rem);
        return s;
    }

    public string Unicode()
    {
        uint n = U32();
        if (n > 1 << 20) throw new InvalidDataException("Unicode string too long.");
        var sb = new StringBuilder((int)n);
        for (uint i = 0; i < n; i++) sb.Append((char)U16());
        return sb.ToString().TrimEnd('\0');
    }
}

/// <summary>Big-endian writer used to build PSD files.</summary>
public sealed class BeWriter
{
    readonly MemoryStream _ms;
    public BeWriter(int capacity = 1 << 16) { _ms = new MemoryStream(capacity); }
    public long Pos => _ms.Position;

    public void U8(int v) => _ms.WriteByte((byte)v);
    public void U16(int v) { _ms.WriteByte((byte)(v >> 8)); _ms.WriteByte((byte)v); }
    public void I16(int v) => U16((ushort)(short)v);
    public void U32(uint v) { _ms.WriteByte((byte)(v >> 24)); _ms.WriteByte((byte)(v >> 16)); _ms.WriteByte((byte)(v >> 8)); _ms.WriteByte((byte)v); }
    public void I32(int v) => U32((uint)v);
    public void U64(ulong v) { U32((uint)(v >> 32)); U32((uint)v); }
    public void F32(float v) => I32(BitConverter.SingleToInt32Bits(v));
    public void F64(double v) => U64((ulong)BitConverter.DoubleToInt64Bits(v));
    public void Sig(string s) { var b = Encoding.ASCII.GetBytes(s); if (b.Length != 4) throw new ArgumentException(s); _ms.Write(b, 0, 4); }
    public void Bytes(byte[] b) => _ms.Write(b, 0, b.Length);
    public void Bytes(ReadOnlySpan<byte> b) => _ms.Write(b);
    public void Zeros(int n) { for (int i = 0; i < n; i++) _ms.WriteByte(0); }

    public void Pascal(string s, int pad)
    {
        var b = Encoding.GetEncoding("ISO-8859-1").GetBytes(s ?? "");
        if (b.Length > 255) Array.Resize(ref b, 255);
        U8(b.Length);
        Bytes(b);
        int total = b.Length + 1;
        int rem = total % pad;
        if (rem != 0) Zeros(pad - rem);
    }

    public void Unicode(string s)
    {
        s ??= "";
        U32((uint)s.Length + 1);
        foreach (var c in s) U16(c);
        U16(0);
    }

    /// <summary>Unicode string without the trailing null (layer 'luni' names).</summary>
    public void UnicodeName(string s)
    {
        s ??= "";
        U32((uint)s.Length);
        foreach (var c in s) U16(c);
    }

    /// <summary>Reserve a 4-byte length and return its position.</summary>
    public long BeginLen() { long p = Pos; U32(0); return p; }

    /// <summary>Back-patch the length reserved at <paramref name="lenPos"/>; pads the payload to <paramref name="padTo"/>.</summary>
    public void EndLen(long lenPos, int padTo = 1)
    {
        long len = Pos - lenPos - 4;
        if (padTo > 1) { long rem = len % padTo; if (rem != 0) { Zeros((int)(padTo - rem)); len += padTo - rem; } }
        long end = Pos;
        _ms.Position = lenPos;
        U32((uint)len);
        _ms.Position = end;
    }

    public byte[] ToArray() => _ms.ToArray();
    public void CopyTo(Stream s) { _ms.Position = 0; _ms.CopyTo(s); }
}

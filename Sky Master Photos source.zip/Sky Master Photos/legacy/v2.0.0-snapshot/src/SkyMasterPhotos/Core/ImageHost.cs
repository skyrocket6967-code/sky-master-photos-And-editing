using Avalonia;
using Avalonia.Media;

namespace SkyMasterPhotos.Core;

/// <summary>
/// Bridge from engine pixels to on-screen images. The app installs a factory at startup (Avalonia bitmaps);
/// the engine itself never needs a display, so it runs headless in tests and tools.
/// </summary>
public static class ImageHost
{
    public static Func<uint[], int, int, IImage> Create;
    public static IImage Make(uint[] px, int w, int h) => px == null || w <= 0 || h <= 0 ? null : Create?.Invoke(px, w, h);
}

/// <summary>Marching-ants outline as pixel-edge segments in document coordinates.</summary>
public sealed class SelectionPath
{
    public readonly List<(Point a, Point b)> Segments = new();
    public bool IsEmpty => Segments.Count == 0;
}

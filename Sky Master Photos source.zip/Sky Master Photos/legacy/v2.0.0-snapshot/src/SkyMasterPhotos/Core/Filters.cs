using Avalonia.Media;

namespace SkyMasterPhotos.Core;

/// <summary>Whole-image filters. All return a new buffer; inputs are never modified.</summary>
public static class Filters
{
    // ───────────────────────────── plane helpers ─────────────────────────────

    sealed class Planes
    {
        public float[] A, R, G, B;
        public Planes(int n) { A = new float[n]; R = new float[n]; G = new float[n]; B = new float[n]; }
    }

    static Planes ToPlanes(uint[] src)
    {
        var p = new Planes(src.Length);
        Parallel.For(0, src.Length / 4096 + 1, chunk =>
        {
            int s = chunk * 4096, e = Math.Min(src.Length, s + 4096);
            for (int i = s; i < e; i++)
            {
                uint c = src[i];
                float a = c >> 24;
                float k = a / 255f;
                p.A[i] = a;
                p.R[i] = ((c >> 16) & 255) * k;
                p.G[i] = ((c >> 8) & 255) * k;
                p.B[i] = (c & 255) * k;
            }
        });
        return p;
    }

    static uint[] FromPlanes(Planes p)
    {
        int n = p.A.Length;
        var o = new uint[n];
        Parallel.For(0, n / 4096 + 1, chunk =>
        {
            int s = chunk * 4096, e = Math.Min(n, s + 4096);
            for (int i = s; i < e; i++)
            {
                float a = p.A[i];
                if (a < 0.5f) { o[i] = 0; continue; }
                float k = 255f / a;
                o[i] = Px.Pack(Px.Clamp(a), Px.Clamp(p.R[i] * k), Px.Clamp(p.G[i] * k), Px.Clamp(p.B[i] * k));
            }
        });
        return o;
    }

    public static void BoxBlurFloat(float[] f, int w, int h, int r)
    {
        if (r < 1) return;
        var tmp = new float[f.Length];
        float inv = 1f / (2 * r + 1);
        Parallel.For(0, h, y =>
        {
            int row = y * w;
            float sum = 0;
            for (int k = -r; k <= r; k++) sum += f[row + Math.Clamp(k, 0, w - 1)];
            for (int x = 0; x < w; x++)
            {
                tmp[row + x] = sum * inv;
                sum += f[row + Math.Min(w - 1, x + r + 1)] - f[row + Math.Max(0, x - r)];
            }
        });
        Parallel.For(0, w, x =>
        {
            float sum = 0;
            for (int k = -r; k <= r; k++) sum += tmp[Math.Clamp(k, 0, h - 1) * w + x];
            for (int y = 0; y < h; y++)
            {
                f[y * w + x] = sum * inv;
                sum += tmp[Math.Min(h - 1, y + r + 1) * w + x] - tmp[Math.Max(0, y - r) * w + x];
            }
        });
    }

    static int[] BoxesForGauss(double sigma, int n)
    {
        double wIdeal = Math.Sqrt(12 * sigma * sigma / n + 1);
        int wl = (int)Math.Floor(wIdeal);
        if (wl % 2 == 0) wl--;
        int wu = wl + 2;
        double mIdeal = (12 * sigma * sigma - n * wl * wl - 4 * n * wl - 3 * n) / (-4 * wl - 4);
        int m = (int)Math.Round(mIdeal);
        var sizes = new int[n];
        for (int i = 0; i < n; i++) sizes[i] = Math.Max(0, ((i < m ? wl : wu) - 1) / 2);
        return sizes;
    }

    static void GaussPlane(float[] f, int w, int h, double radius)
    {
        foreach (var r in BoxesForGauss(Math.Max(0.5, radius / 2.0), 3)) BoxBlurFloat(f, w, h, r);
    }

    // ───────────────────────────── blur ─────────────────────────────

    public static uint[] GaussianBlur(uint[] src, int w, int h, double radius)
    {
        if (radius < 0.5) return (uint[])src.Clone();
        var p = ToPlanes(src);
        Parallel.Invoke(
            () => GaussPlane(p.A, w, h, radius), () => GaussPlane(p.R, w, h, radius),
            () => GaussPlane(p.G, w, h, radius), () => GaussPlane(p.B, w, h, radius));
        return FromPlanes(p);
    }

    public static uint[] BoxBlur(uint[] src, int w, int h, int radius)
    {
        var p = ToPlanes(src);
        Parallel.Invoke(
            () => BoxBlurFloat(p.A, w, h, radius), () => BoxBlurFloat(p.R, w, h, radius),
            () => BoxBlurFloat(p.G, w, h, radius), () => BoxBlurFloat(p.B, w, h, radius));
        return FromPlanes(p);
    }

    public static uint[] MotionBlur(uint[] src, int w, int h, double angleDeg, int distance)
    {
        if (distance < 1) return (uint[])src.Clone();
        double a = angleDeg * Math.PI / 180;
        double dx = Math.Cos(a), dy = -Math.Sin(a);
        int n = distance * 2 + 1;
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                float sa = 0, sr = 0, sg = 0, sb = 0;
                for (int k = -distance; k <= distance; k++)
                {
                    int sx = Math.Clamp((int)Math.Round(x + dx * k), 0, w - 1);
                    int sy = Math.Clamp((int)Math.Round(y + dy * k), 0, h - 1);
                    uint c = src[sy * w + sx];
                    float ca = c >> 24;
                    sa += ca; sr += ((c >> 16) & 255) * ca; sg += ((c >> 8) & 255) * ca; sb += (c & 255) * ca;
                }
                o[y * w + x] = sa <= 0 ? 0 : Px.Pack(Px.Clamp(sa / n), Px.Clamp(sr / sa), Px.Clamp(sg / sa), Px.Clamp(sb / sa));
            }
        });
        return o;
    }

    public static uint[] RadialBlur(uint[] src, int w, int h, double amount, bool zoom)
    {
        double cx = w / 2.0, cy = h / 2.0;
        int samples = 24;
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                float sa = 0, sr = 0, sg = 0, sb = 0;
                double vx = x - cx, vy = y - cy;
                double ang = Math.Atan2(vy, vx), dist = Math.Sqrt(vx * vx + vy * vy);
                for (int k = 0; k < samples; k++)
                {
                    double t = (k / (double)(samples - 1) - 0.5) * amount / 100.0;
                    double px, py;
                    if (zoom) { px = cx + vx * (1 + t * 0.5); py = cy + vy * (1 + t * 0.5); }
                    else { double aa = ang + t * 0.6; px = cx + Math.Cos(aa) * dist; py = cy + Math.Sin(aa) * dist; }
                    int sx = Math.Clamp((int)px, 0, w - 1), sy = Math.Clamp((int)py, 0, h - 1);
                    uint c = src[sy * w + sx];
                    float ca = c >> 24;
                    sa += ca; sr += ((c >> 16) & 255) * ca; sg += ((c >> 8) & 255) * ca; sb += (c & 255) * ca;
                }
                o[y * w + x] = sa <= 0 ? 0 : Px.Pack(Px.Clamp(sa / samples), Px.Clamp(sr / sa), Px.Clamp(sg / sa), Px.Clamp(sb / sa));
            }
        });
        return o;
    }

    public static uint[] TiltShift(uint[] src, int w, int h, double radius, double focusPct, double bandPct)
    {
        var blurred = GaussianBlur(src, w, h, radius);
        double fc = focusPct / 100.0 * h, band = Math.Max(1, bandPct / 100.0 * h / 2);
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            double d = Math.Abs(y - fc);
            float t = (float)Math.Clamp((d - band) / (band * 1.5), 0, 1);
            t = t * t * (3 - 2 * t);
            for (int x = 0; x < w; x++) o[y * w + x] = Px.Lerp(src[y * w + x], blurred[y * w + x], t);
        });
        return o;
    }

    // ───────────────────────────── sharpen ─────────────────────────────

    public static uint[] UnsharpMask(uint[] src, int w, int h, double amountPct, double radius, int threshold)
    {
        var bl = GaussianBlur(src, w, h, radius);
        double amt = amountPct / 100.0;
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                int i = y * w + x;
                uint s = src[i], b = bl[i];
                int dr = Px.R(s) - Px.R(b), dg = Px.G(s) - Px.G(b), db = Px.B(s) - Px.B(b);
                if (Math.Abs(dr) + Math.Abs(dg) + Math.Abs(db) < threshold * 3) { o[i] = s; continue; }
                o[i] = Px.Pack(Px.A(s), Px.Clamp(Px.R(s) + dr * amt), Px.Clamp(Px.G(s) + dg * amt), Px.Clamp(Px.B(s) + db * amt));
            }
        });
        return o;
    }

    public static uint[] Sharpen(uint[] src, int w, int h) => UnsharpMask(src, w, h, 80, 1.5, 0);

    // ───────────────────────────── noise ─────────────────────────────

    public static uint[] AddNoise(uint[] src, int w, int h, double amountPct, bool mono, bool gaussian)
    {
        var o = new uint[src.Length];
        double amt = amountPct / 100.0 * 255;
        int seed = Environment.TickCount;
        Parallel.For(0, h, y =>
        {
            var rnd = new Random(seed + y * 7919);
            double N() => gaussian ? (rnd.NextDouble() + rnd.NextDouble() + rnd.NextDouble() - 1.5) / 1.5 : rnd.NextDouble() * 2 - 1;
            for (int x = 0; x < w; x++)
            {
                int i = y * w + x;
                uint s = src[i];
                double nr = N() * amt, ng = mono ? nr : N() * amt, nb = mono ? nr : N() * amt;
                o[i] = Px.Pack(Px.A(s), Px.Clamp(Px.R(s) + nr), Px.Clamp(Px.G(s) + ng), Px.Clamp(Px.B(s) + nb));
            }
        });
        return o;
    }

    public static uint[] Median(uint[] src, int w, int h, int radius)
    {
        if (radius < 1) return (uint[])src.Clone();
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            var hr = new int[256]; var hg = new int[256]; var hb = new int[256];
            int y0 = Math.Max(0, y - radius), y1 = Math.Min(h - 1, y + radius);
            for (int x = 0; x < w; x++)
            {
                if (x == 0)
                {
                    Array.Clear(hr); Array.Clear(hg); Array.Clear(hb);
                    for (int yy = y0; yy <= y1; yy++)
                        for (int xx = 0; xx <= Math.Min(w - 1, radius); xx++)
                        { uint c = src[yy * w + xx]; hr[Px.R(c)]++; hg[Px.G(c)]++; hb[Px.B(c)]++; }
                }
                else
                {
                    int rem = x - radius - 1, add = x + radius;
                    for (int yy = y0; yy <= y1; yy++)
                    {
                        if (rem >= 0) { uint c = src[yy * w + rem]; hr[Px.R(c)]--; hg[Px.G(c)]--; hb[Px.B(c)]--; }
                        if (add < w) { uint c = src[yy * w + add]; hr[Px.R(c)]++; hg[Px.G(c)]++; hb[Px.B(c)]++; }
                    }
                }
                int cnt = (y1 - y0 + 1) * (Math.Min(w - 1, x + radius) - Math.Max(0, x - radius) + 1);
                int half = cnt / 2;
                o[y * w + x] = Px.Pack(Px.A(src[y * w + x]), Med(hr, half), Med(hg, half), Med(hb, half));
            }
        });
        return o;
    }

    static int Med(int[] hist, int half)
    {
        int acc = 0;
        for (int i = 0; i < 256; i++) { acc += hist[i]; if (acc > half) return i; }
        return 255;
    }

    // ───────────────────────────── stylize ─────────────────────────────

    public static uint[] Emboss(uint[] src, int w, int h, double angleDeg, double strength)
    {
        double a = angleDeg * Math.PI / 180;
        int ox = (int)Math.Round(Math.Cos(a)), oy = (int)Math.Round(-Math.Sin(a));
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                uint p1 = src[Math.Clamp(y - oy, 0, h - 1) * w + Math.Clamp(x - ox, 0, w - 1)];
                uint p2 = src[Math.Clamp(y + oy, 0, h - 1) * w + Math.Clamp(x + ox, 0, w - 1)];
                double d = (Px.Luma(p2) - Px.Luma(p1)) * strength / 100.0;
                int v = Px.Clamp(128 + d);
                o[y * w + x] = Px.Pack(Px.A(src[y * w + x]), v, v, v);
            }
        });
        return o;
    }

    public static uint[] FindEdges(uint[] src, int w, int h, bool invert)
    {
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                double gx = 0, gy = 0;
                for (int ky = -1; ky <= 1; ky++)
                    for (int kx = -1; kx <= 1; kx++)
                    {
                        double l = Px.Luma(src[Math.Clamp(y + ky, 0, h - 1) * w + Math.Clamp(x + kx, 0, w - 1)]);
                        int wx = kx * (ky == 0 ? 2 : 1), wy = ky * (kx == 0 ? 2 : 1);
                        gx += l * wx; gy += l * wy;
                    }
                int v = Px.Clamp(Math.Sqrt(gx * gx + gy * gy));
                if (invert) v = 255 - v;
                o[y * w + x] = Px.Pack(Px.A(src[y * w + x]), v, v, v);
            }
        });
        return o;
    }

    public static uint[] Pixelate(uint[] src, int w, int h, int cell)
    {
        cell = Math.Max(2, cell);
        var o = new uint[src.Length];
        int cy = (h + cell - 1) / cell;
        Parallel.For(0, cy, by =>
        {
            int y0 = by * cell, y1 = Math.Min(h, y0 + cell);
            for (int x0 = 0; x0 < w; x0 += cell)
            {
                int x1 = Math.Min(w, x0 + cell);
                double sa = 0, sr = 0, sg = 0, sb = 0; int n = 0;
                for (int y = y0; y < y1; y++)
                    for (int x = x0; x < x1; x++)
                    { uint c = src[y * w + x]; double a = Px.A(c); sa += a; sr += Px.R(c) * a; sg += Px.G(c) * a; sb += Px.B(c) * a; n++; }
                uint res = sa <= 0 ? 0 : Px.Pack(Px.Clamp(sa / n), Px.Clamp(sr / sa), Px.Clamp(sg / sa), Px.Clamp(sb / sa));
                for (int y = y0; y < y1; y++) Array.Fill(o, res, y * w + x0, x1 - x0);
            }
        });
        return o;
    }

    public static uint[] Vignette(uint[] src, int w, int h, double amountPct, double sizePct, double softnessPct)
    {
        var o = new uint[src.Length];
        double cx = w / 2.0, cy = h / 2.0;
        double inner = sizePct / 100.0, soft = Math.Max(0.01, softnessPct / 100.0);
        double amt = amountPct / 100.0;
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                double dx = (x - cx) / cx, dy = (y - cy) / cy;
                double d = Math.Sqrt(dx * dx + dy * dy) / Math.Sqrt(2) * 1.25;
                double t = Math.Clamp((d - inner) / soft, 0, 1);
                t = t * t * (3 - 2 * t);
                double f = 1 - amt * t;   // amount < 0 lightens
                uint s = src[y * w + x];
                if (amt >= 0) o[y * w + x] = Px.Pack(Px.A(s), Px.Clamp(Px.R(s) * f), Px.Clamp(Px.G(s) * f), Px.Clamp(Px.B(s) * f));
                else
                {
                    double k = -amt * t;
                    o[y * w + x] = Px.Pack(Px.A(s), Px.Clamp(Px.R(s) + (255 - Px.R(s)) * k), Px.Clamp(Px.G(s) + (255 - Px.G(s)) * k), Px.Clamp(Px.B(s) + (255 - Px.B(s)) * k));
                }
            }
        });
        return o;
    }

    /// <summary>Kuwahara filter — painterly "oil paint" look.</summary>
    public static uint[] OilPaint(uint[] src, int w, int h, int radius)
    {
        radius = Math.Clamp(radius, 1, 12);
        // integral images of luma and luma^2 and colors
        int W1 = w + 1;
        var sl = new double[W1 * (h + 1)]; var sl2 = new double[W1 * (h + 1)];
        var sr = new double[W1 * (h + 1)]; var sg = new double[W1 * (h + 1)]; var sb = new double[W1 * (h + 1)];
        for (int y = 0; y < h; y++)
        {
            double rl = 0, rl2 = 0, rr = 0, rg = 0, rb = 0;
            for (int x = 0; x < w; x++)
            {
                uint c = src[y * w + x];
                double l = Px.Luma(c);
                rl += l; rl2 += l * l; rr += Px.R(c); rg += Px.G(c); rb += Px.B(c);
                int i = (y + 1) * W1 + x + 1, up = y * W1 + x + 1;
                sl[i] = sl[up] + rl; sl2[i] = sl2[up] + rl2; sr[i] = sr[up] + rr; sg[i] = sg[up] + rg; sb[i] = sb[up] + rb;
            }
        }
        double Sum(double[] s, int x0, int y0, int x1, int y1) => s[y1 * W1 + x1] - s[y0 * W1 + x1] - s[y1 * W1 + x0] + s[y0 * W1 + x0];
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                double best = double.MaxValue; int bx0 = 0, by0 = 0, bx1 = 1, by1 = 1;
                for (int q = 0; q < 4; q++)
                {
                    int x0 = q % 2 == 0 ? x - radius : x, x1 = q % 2 == 0 ? x + 1 : x + radius + 1;
                    int y0 = q < 2 ? y - radius : y, y1 = q < 2 ? y + 1 : y + radius + 1;
                    x0 = Math.Max(0, x0); y0 = Math.Max(0, y0); x1 = Math.Min(w, x1); y1 = Math.Min(h, y1);
                    double n = (x1 - x0) * (y1 - y0);
                    if (n <= 0) continue;
                    double m = Sum(sl, x0, y0, x1, y1) / n;
                    double v = Sum(sl2, x0, y0, x1, y1) / n - m * m;
                    if (v < best) { best = v; bx0 = x0; by0 = y0; bx1 = x1; by1 = y1; }
                }
                double nn = (bx1 - bx0) * (by1 - by0);
                o[y * w + x] = Px.Pack(Px.A(src[y * w + x]), Px.Clamp(Sum(sr, bx0, by0, bx1, by1) / nn), Px.Clamp(Sum(sg, bx0, by0, bx1, by1) / nn), Px.Clamp(Sum(sb, bx0, by0, bx1, by1) / nn));
            }
        });
        return o;
    }

    public static uint[] Glow(uint[] src, int w, int h, double radius, double strengthPct)
    {
        var bl = GaussianBlur(src, w, h, radius);
        double k = strengthPct / 100.0;
        var o = new uint[src.Length];
        Parallel.For(0, src.Length / 4096 + 1, chunk =>
        {
            int s = chunk * 4096, e = Math.Min(src.Length, s + 4096);
            for (int i = s; i < e; i++)
            {
                uint a = src[i], b = bl[i];
                int Sc(int x, int y) => Px.Clamp(x + (255 - x) * (y / 255.0) * k);
                o[i] = Px.Pack(Px.A(a), Sc(Px.R(a), Px.R(b)), Sc(Px.G(a), Px.G(b)), Sc(Px.B(a), Px.B(b)));
            }
        });
        return o;
    }

    // ───────────────────────────── distort ─────────────────────────────

    public static uint SampleBilinear(uint[] src, int w, int h, double x, double y)
    {
        x -= 0.5; y -= 0.5;
        int x0 = (int)Math.Floor(x), y0 = (int)Math.Floor(y);
        float fx = (float)(x - x0), fy = (float)(y - y0);
        uint P(int xx, int yy) => (xx < 0 || yy < 0 || xx >= w || yy >= h) ? 0u : src[yy * w + xx];
        uint a = P(x0, y0), b = P(x0 + 1, y0), c = P(x0, y0 + 1), d = P(x0 + 1, y0 + 1);
        if (a == b && b == c && c == d) return a;
        float w00 = (1 - fx) * (1 - fy), w10 = fx * (1 - fy), w01 = (1 - fx) * fy, w11 = fx * fy;
        float aa = Px.A(a) * w00, ab = Px.A(b) * w10, ac = Px.A(c) * w01, ad = Px.A(d) * w11;
        float A = aa + ab + ac + ad;
        if (A < 0.5f) return 0;
        float R = (Px.R(a) * aa + Px.R(b) * ab + Px.R(c) * ac + Px.R(d) * ad) / A;
        float G = (Px.G(a) * aa + Px.G(b) * ab + Px.G(c) * ac + Px.G(d) * ad) / A;
        float B = (Px.B(a) * aa + Px.B(b) * ab + Px.B(c) * ac + Px.B(d) * ad) / A;
        return Px.Pack(Px.Clamp(A), Px.Clamp(R), Px.Clamp(G), Px.Clamp(B));
    }

    public static uint SampleClamped(uint[] src, int w, int h, double x, double y)
        => SampleBilinear(src, w, h, Math.Clamp(x, 0.5, w - 0.5), Math.Clamp(y, 0.5, h - 0.5));

    public static uint[] Twirl(uint[] src, int w, int h, double angleDeg)
    {
        double cx = w / 2.0, cy = h / 2.0, R = Math.Min(cx, cy);
        double ang = angleDeg * Math.PI / 180;
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                double dx = x + 0.5 - cx, dy = y + 0.5 - cy, d = Math.Sqrt(dx * dx + dy * dy);
                if (d >= R) { o[y * w + x] = src[y * w + x]; continue; }
                double t = 1 - d / R;
                double a = Math.Atan2(dy, dx) + ang * t * t;
                o[y * w + x] = SampleClamped(src, w, h, cx + Math.Cos(a) * d, cy + Math.Sin(a) * d);
            }
        });
        return o;
    }

    public static uint[] Bulge(uint[] src, int w, int h, double amountPct)
    {
        double cx = w / 2.0, cy = h / 2.0, R = Math.Min(cx, cy);
        double k = amountPct / 100.0;
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                double dx = x + 0.5 - cx, dy = y + 0.5 - cy, d = Math.Sqrt(dx * dx + dy * dy);
                if (d >= R || d < 1e-6) { o[y * w + x] = src[y * w + x]; continue; }
                double r = d / R;
                double nr = k >= 0 ? Math.Pow(r, 1 + k) : Math.Pow(r, 1 / (1 - k));
                double s = nr / r;
                o[y * w + x] = SampleClamped(src, w, h, cx + dx * s, cy + dy * s);
            }
        });
        return o;
    }

    public static uint[] Wave(uint[] src, int w, int h, double amplitude, double wavelength)
    {
        wavelength = Math.Max(2, wavelength);
        var o = new uint[src.Length];
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                double sx = x + 0.5 + amplitude * Math.Sin(2 * Math.PI * y / wavelength);
                double sy = y + 0.5 + amplitude * Math.Sin(2 * Math.PI * x / wavelength);
                o[y * w + x] = SampleClamped(src, w, h, sx, sy);
            }
        });
        return o;
    }

    // ───────────────────────────── render ─────────────────────────────

    public static uint[] Clouds(int w, int h, Color fg, Color bg, double scale, int seed)
    {
        var rnd = new Random(seed);
        int G = 256;
        var grid = new float[G * G];
        for (int i = 0; i < grid.Length; i++) grid[i] = (float)rnd.NextDouble();
        float Noise(double x, double y)
        {
            int x0 = (int)Math.Floor(x), y0 = (int)Math.Floor(y);
            double fx = x - x0, fy = y - y0;
            fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
            float V(int a, int b) => grid[((b & (G - 1)) * G) + (a & (G - 1))];
            double top = V(x0, y0) + (V(x0 + 1, y0) - V(x0, y0)) * fx;
            double bot = V(x0, y0 + 1) + (V(x0 + 1, y0 + 1) - V(x0, y0 + 1)) * fx;
            return (float)(top + (bot - top) * fy);
        }
        var o = new uint[w * h];
        double baseF = 1.0 / Math.Max(4, scale);
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                double v = 0, amp = 0.5, f = baseF, tot = 0;
                for (int oct = 0; oct < 6; oct++) { v += Noise(x * f, y * f) * amp; tot += amp; amp *= 0.5; f *= 2; }
                double t = v / tot;
                o[y * w + x] = Px.Pack(255, Px.Clamp(bg.R + (fg.R - bg.R) * t), Px.Clamp(bg.G + (fg.G - bg.G) * t), Px.Clamp(bg.B + (fg.B - bg.B) * t));
            }
        });
        return o;
    }

    // ───────────────────────────── utilities ─────────────────────────────

    /// <summary>Blend a filtered result back over the original through a selection mask.</summary>
    public static uint[] Masked(uint[] original, uint[] result, byte[] mask)
    {
        if (mask == null) return result;
        var o = new uint[original.Length];
        Parallel.For(0, original.Length / 4096 + 1, chunk =>
        {
            int s = chunk * 4096, e = Math.Min(original.Length, s + 4096);
            for (int i = s; i < e; i++)
            {
                byte m = mask[i];
                o[i] = m == 0 ? original[i] : m == 255 ? result[i] : Px.Lerp(original[i], result[i], m / 255f);
            }
        });
        return o;
    }
}

using Avalonia;

namespace SkyMasterPhotos.Core;

public enum StrokeKind { Paint, Pencil, Erase, Clone, Heal, SpotHeal, Blur, Sharpen, Smudge, Dodge, Burn, Sponge }

public sealed class BrushSettings
{
    public double Size = 40;
    public double Hardness = 0.75;
    public double Opacity = 1.0;
    public double Flow = 1.0;
    public double Spacing = 0.12;
    public double Strength = 0.5;   // for effect tools
    public bool SpongeSaturate = false;
}

/// <summary>
/// A single brush stroke. Coverage-based tools (paint, erase, clone) accumulate a stroke mask so a stroke
/// never builds past its opacity; effect tools (blur, dodge, smudge...) modify pixels dab by dab.
/// </summary>
public sealed class StrokeSession
{
    readonly Document _doc;
    public readonly Layer Layer;
    readonly uint[] _backup;
    readonly uint[] _px;
    readonly bool _isMask;
    readonly ushort[] _cov;
    readonly int _w, _h;
    readonly StrokeKind _kind;
    readonly BrushSettings _b;
    readonly uint _color;
    readonly byte[] _sel;
    readonly Vector _cloneOffset;
    uint[] _smudge;
    int _smudgeR;
    Point _last;
    double _carry;
    bool _started;
    public Int32Rect Total { get; private set; } = Int32Rect.Empty;

    public StrokeSession(Document doc, Layer layer, StrokeKind kind, BrushSettings b, uint color, Vector cloneOffset)
    {
        _doc = doc;
        Layer = layer;
        _isMask = layer.EditMask;
        _px = layer.Target;
        // masks are grayscale: paint luminance, and the eraser paints black (hide)
        if (_isMask)
        {
            if (kind == StrokeKind.Erase) { kind = StrokeKind.Paint; color = 0xFF000000; }
            int g = Px.Clamp(Px.Luma(color));
            color = Masks.Gray((byte)g);
        }
        _kind = kind;
        _b = b;
        _color = color;
        _w = layer.Width;
        _h = layer.Height;
        _sel = doc.Selection;
        _cloneOffset = cloneOffset;
        _backup = (uint[])_px.Clone();
        if (IsCoverage) _cov = new ushort[_w * _h];
    }

    bool IsCoverage => _kind is StrokeKind.Paint or StrokeKind.Pencil or StrokeKind.Erase or StrokeKind.Clone or StrokeKind.SpotHeal;

    double Radius => Math.Max(0.5, _b.Size / 2);

    /// <summary>Adds the stroke segment to p, returns the dirty rect in doc space.</summary>
    public Int32Rect MoveTo(Point p)
    {
        if (!_started)
        {
            _started = true;
            _last = p;
            if (_kind == StrokeKind.Smudge) InitSmudge(p);
            return Dab(p);
        }
        double step = Math.Max(1, _b.Size * _b.Spacing);
        if (_kind == StrokeKind.Smudge) step = Math.Max(1, _b.Size * 0.08);
        Vector d = p - _last;   // (Avalonia: Point − Point is a Point)
        double len = d.Length;
        Int32Rect dirty = Int32Rect.Empty;
        if (len < 1e-6) return dirty;
        var dir = d / len;
        double t = step - _carry;
        while (t <= len)
        {
            var q = _last + dir * t;
            dirty = RectUtil.Union(dirty, Dab(q));
            t += step;
        }
        _carry = len - (t - step);
        _last = p;
        return dirty;
    }

    float DabAlpha(double dist)
    {
        double r = Radius;
        if (_kind == StrokeKind.Pencil) return dist <= r ? 1f : 0f;
        double d = dist / r;
        if (d >= 1) return 0;
        double h = Math.Clamp(_b.Hardness, 0, 0.99);
        if (d <= h) return 1;
        double t = (d - h) / (1 - h);
        return (float)(1 - t * t * (3 - 2 * t));
    }

    Int32Rect Dab(Point c)
    {
        double r = Radius + 1;
        var rect = RectUtil.Clip(RectUtil.FromPoints(c.X - r, c.Y - r, c.X + r, c.Y + r), _w, _h);
        if (RectUtil.IsEmptyRect(rect)) return Int32Rect.Empty;
        Total = RectUtil.Union(Total, rect);

        if (IsCoverage)
        {
            float flow = (float)(_kind == StrokeKind.Pencil ? 1 : _b.Flow);
            for (int y = rect.Y; y < rect.Y + rect.Height; y++)
            {
                for (int x = rect.X; x < rect.X + rect.Width; x++)
                {
                    double dx = x + 0.5 - c.X, dy = y + 0.5 - c.Y;
                    float a = DabAlpha(Math.Sqrt(dx * dx + dy * dy)) * flow;
                    if (a <= 0) continue;
                    int i = y * _w + x;
                    int cov = _cov[i];
                    _cov[i] = (ushort)Math.Min(65535, cov + (65535 - cov) * a);
                }
            }
            ApplyCoverage(rect);
            return rect;
        }

        ApplyEffect(c, rect);
        return rect;
    }

    void ApplyCoverage(Int32Rect rect)
    {
        var px = _px;
        float op = (float)_b.Opacity;
        for (int y = rect.Y; y < rect.Y + rect.Height; y++)
        {
            for (int x = rect.X; x < rect.X + rect.Width; x++)
            {
                int i = y * _w + x;
                float m = _cov[i] / 65535f * op;
                if (_sel != null) m *= _sel[i] / 255f;
                uint orig = _backup[i];
                if (m <= 0) { px[i] = orig; continue; }
                switch (_kind)
                {
                    case StrokeKind.Erase:
                        px[i] = Px.WithAlpha(orig, (int)(Px.A(orig) * (1 - m) + 0.5f));
                        break;
                    case StrokeKind.SpotHeal:
                        px[i] = Px.Over(orig, 0xFF1A1C22u, Math.Min(1f, m) * 0.6f);
                        break;
                    case StrokeKind.Clone:
                        int sx = (int)Math.Round(x + _cloneOffset.X), sy = (int)Math.Round(y + _cloneOffset.Y);
                        if (sx < 0 || sy < 0 || sx >= _w || sy >= _h) { px[i] = orig; break; }
                        px[i] = Px.Lerp(orig, _backup[sy * _w + sx], m);
                        break;
                    default:
                        px[i] = Px.Over(orig, _color, m);
                        break;
                }
            }
        }
    }

    void InitSmudge(Point c)
    {
        _smudgeR = (int)Math.Ceiling(Radius);
        int d = _smudgeR * 2 + 1;
        _smudge = new uint[d * d];
        for (int y = 0; y < d; y++)
            for (int x = 0; x < d; x++)
            {
                int sx = Math.Clamp((int)c.X - _smudgeR + x, 0, _w - 1), sy = Math.Clamp((int)c.Y - _smudgeR + y, 0, _h - 1);
                _smudge[y * d + x] = _px[sy * _w + sx];
            }
    }

    void ApplyEffect(Point c, Int32Rect rect)
    {
        var px = _px;
        float k = (float)_b.Strength;
        uint[] src = null;
        if (_kind is StrokeKind.Blur or StrokeKind.Sharpen)
        {
            // snapshot the neighbourhood so the kernel reads unmodified pixels
            src = new uint[rect.Width * rect.Height];
            for (int y = 0; y < rect.Height; y++) Array.Copy(px, (rect.Y + y) * _w + rect.X, src, y * rect.Width, rect.Width);
        }

        // healing: match the mean color of the destination ring to the source
        double hr = 0, hg = 0, hb = 0;
        if (_kind == StrokeKind.Heal)
        {
            double sr = 0, sg = 0, sb = 0, dr = 0, dg = 0, db = 0; int n = 0;
            for (int y = rect.Y; y < rect.Y + rect.Height; y++)
                for (int x = rect.X; x < rect.X + rect.Width; x++)
                {
                    int sx = (int)Math.Round(x + _cloneOffset.X), sy = (int)Math.Round(y + _cloneOffset.Y);
                    if (sx < 0 || sy < 0 || sx >= _w || sy >= _h) continue;
                    uint s = _backup[sy * _w + sx], d = px[y * _w + x];
                    sr += Px.R(s); sg += Px.G(s); sb += Px.B(s); dr += Px.R(d); dg += Px.G(d); db += Px.B(d); n++;
                }
            if (n > 0) { hr = (dr - sr) / n; hg = (dg - sg) / n; hb = (db - sb) / n; }
        }

        int sd = _smudgeR * 2 + 1;
        for (int y = rect.Y; y < rect.Y + rect.Height; y++)
        {
            for (int x = rect.X; x < rect.X + rect.Width; x++)
            {
                double dx = x + 0.5 - c.X, dy = y + 0.5 - c.Y;
                float a = DabAlpha(Math.Sqrt(dx * dx + dy * dy));
                if (a <= 0) continue;
                int i = y * _w + x;
                if (_sel != null) a *= _sel[i] / 255f;
                if (a <= 0) continue;
                uint p = px[i];
                switch (_kind)
                {
                    case StrokeKind.Blur:
                    case StrokeKind.Sharpen:
                    {
                        int lx = x - rect.X, ly = y - rect.Y;
                        double sa = 0, sr = 0, sg = 0, sb = 0; int n = 0;
                        for (int ky = -1; ky <= 1; ky++)
                            for (int kx = -1; kx <= 1; kx++)
                            {
                                int xx = Math.Clamp(lx + kx, 0, rect.Width - 1), yy = Math.Clamp(ly + ky, 0, rect.Height - 1);
                                uint q = src[yy * rect.Width + xx];
                                double qa = Px.A(q);
                                sa += qa; sr += Px.R(q) * qa; sg += Px.G(q) * qa; sb += Px.B(q) * qa; n++;
                            }
                        if (sa <= 0) break;
                        uint avg = Px.Pack(Px.Clamp(sa / n), Px.Clamp(sr / sa), Px.Clamp(sg / sa), Px.Clamp(sb / sa));
                        if (_kind == StrokeKind.Blur) px[i] = Px.Lerp(p, avg, a * k);
                        else
                        {
                            double s = a * k * 1.2;
                            px[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) + (Px.R(p) - Px.R(avg)) * s), Px.Clamp(Px.G(p) + (Px.G(p) - Px.G(avg)) * s), Px.Clamp(Px.B(p) + (Px.B(p) - Px.B(avg)) * s));
                        }
                        break;
                    }
                    case StrokeKind.Smudge:
                    {
                        int bx = x - ((int)c.X - _smudgeR), by = y - ((int)c.Y - _smudgeR);
                        if (bx < 0 || by < 0 || bx >= sd || by >= sd) break;
                        int bi = by * sd + bx;
                        uint carried = _smudge[bi];
                        uint np = Px.Lerp(p, carried, a * k);
                        px[i] = np;
                        _smudge[bi] = Px.Lerp(carried, np, 0.2f + (1 - k) * 0.3f);
                        break;
                    }
                    case StrokeKind.Dodge:
                    {
                        double f = a * k * 0.25;
                        px[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) + (255 - Px.R(p)) * f), Px.Clamp(Px.G(p) + (255 - Px.G(p)) * f), Px.Clamp(Px.B(p) + (255 - Px.B(p)) * f));
                        break;
                    }
                    case StrokeKind.Burn:
                    {
                        double f = 1 - a * k * 0.25;
                        px[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) * f), Px.Clamp(Px.G(p) * f), Px.Clamp(Px.B(p) * f));
                        break;
                    }
                    case StrokeKind.Sponge:
                    {
                        double l = Px.Luma(p);
                        double f = (_b.SpongeSaturate ? 1 : -1) * a * k * 0.2;
                        px[i] = Px.Pack(Px.A(p), Px.Clamp(Px.R(p) + (Px.R(p) - l) * f), Px.Clamp(Px.G(p) + (Px.G(p) - l) * f), Px.Clamp(Px.B(p) + (Px.B(p) - l) * f));
                        break;
                    }
                    case StrokeKind.Heal:
                    {
                        int sx = (int)Math.Round(x + _cloneOffset.X), sy = (int)Math.Round(y + _cloneOffset.Y);
                        if (sx < 0 || sy < 0 || sx >= _w || sy >= _h) break;
                        uint s = _backup[sy * _w + sx];
                        uint corrected = Px.Pack(Px.A(s), Px.Clamp(Px.R(s) + hr), Px.Clamp(Px.G(s) + hg), Px.Clamp(Px.B(s) + hb));
                        px[i] = Px.Lerp(p, corrected, a * 0.85f);
                        break;
                    }
                }
            }
        }
    }

    /// <summary>Finishes the stroke and records an undoable patch.</summary>
    public void Commit(string name)
    {
        if (RectUtil.IsEmptyRect(Total)) return;
        if (_kind == StrokeKind.SpotHeal) HealSpot();
        var before = PixelPatch.Extract(_backup, _w, Total);
        var after = PixelPatch.Extract(_px, _w, Total);
        _doc.RecordPatch(_isMask ? name + " (mask)" : name, Layer, Total, before, after, "✎", _isMask);
        Layer.RefreshThumbnail();
        _doc.RefreshThumbnail();
    }

    /// <summary>Replace the painted area with content-aware fill (Spot Healing Brush).</summary>
    void HealSpot()
    {
        var mask = new byte[_w * _h];
        for (int y = Total.Y; y < Total.Y + Total.Height; y++)
            for (int x = Total.X; x < Total.X + Total.Width; x++)
            {
                int i = y * _w + x;
                if (_cov[i] > 0) mask[i] = (byte)Math.Min(255, _cov[i] / 128);
            }
        mask = SelectionOps.Grow(mask, _w, _h, 2);
        var healed = Inpaint.Fill(_backup, _w, _h, mask);
        var area = RectUtil.Clip(new Int32Rect(Total.X - 3, Total.Y - 3, Total.Width + 6, Total.Height + 6), _w, _h);
        for (int y = area.Y; y < area.Y + area.Height; y++)
            for (int x = area.X; x < area.X + area.Width; x++)
            {
                int i = y * _w + x;
                _px[i] = _sel == null ? healed[i] : Px.Lerp(_backup[i], healed[i], _sel[i] / 255f);
            }
        Total = area;
        _doc.Render(area);
    }

    public void Cancel()
    {
        Array.Copy(_backup, _px, _backup.Length);
        _doc.RenderAll();
    }
}

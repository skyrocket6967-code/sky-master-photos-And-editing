using Avalonia;
using Avalonia.Media;

namespace SkyMasterPhotos.Core;

public enum SelectMode { New, Add, Subtract, Intersect }

/// <summary>Selections are byte masks (0..255) the size of the document. Masks are treated as immutable once stored.</summary>
public static class SelectionOps
{
    public static byte[] Rect(int w, int h, Int32Rect r)
    {
        var m = new byte[w * h];
        r = RectUtil.Clip(r, w, h);
        if (RectUtil.IsEmptyRect(r)) return m;
        for (int y = r.Y; y < r.Y + r.Height; y++)
            Array.Fill(m, (byte)255, y * w + r.X, r.Width);
        return m;
    }

    public static byte[] Ellipse(int w, int h, Int32Rect r)
    {
        var m = new byte[w * h];
        double cx = r.X + r.Width / 2.0, cy = r.Y + r.Height / 2.0, rx = r.Width / 2.0, ry = r.Height / 2.0;
        if (rx < 0.5 || ry < 0.5) return m;
        var c = RectUtil.Clip(r, w, h);
        if (RectUtil.IsEmptyRect(c)) return m;
        Parallel.For(c.Y, c.Y + c.Height, y =>
        {
            for (int x = c.X; x < c.X + c.Width; x++)
            {
                // 4x supersampled edge for smooth selections
                int inside = 0;
                for (int sy = 0; sy < 2; sy++)
                    for (int sx = 0; sx < 2; sx++)
                    {
                        double dx = (x + 0.25 + sx * 0.5 - cx) / rx, dy = (y + 0.25 + sy * 0.5 - cy) / ry;
                        if (dx * dx + dy * dy <= 1) inside++;
                    }
                m[y * w + x] = (byte)(inside * 255 / 4);
            }
        });
        return m;
    }

    /// <summary>Even-odd scanline fill of a polygon.</summary>
    public static byte[] Polygon(int w, int h, IList<Point> pts)
    {
        var m = new byte[w * h];
        if (pts.Count < 3) return m;
        double minY = pts.Min(p => p.Y), maxY = pts.Max(p => p.Y);
        int y0 = Math.Max(0, (int)Math.Floor(minY)), y1 = Math.Min(h - 1, (int)Math.Ceiling(maxY));
        var xs = new List<double>();
        for (int y = y0; y <= y1; y++)
        {
            double sy = y + 0.5;
            xs.Clear();
            for (int i = 0, j = pts.Count - 1; i < pts.Count; j = i++)
            {
                var a = pts[i]; var b = pts[j];
                if ((a.Y <= sy && b.Y > sy) || (b.Y <= sy && a.Y > sy))
                    xs.Add(a.X + (sy - a.Y) / (b.Y - a.Y) * (b.X - a.X));
            }
            xs.Sort();
            for (int k = 0; k + 1 < xs.Count; k += 2)
            {
                int xa = Math.Max(0, (int)Math.Round(xs[k])), xb = Math.Min(w, (int)Math.Round(xs[k + 1]));
                if (xb > xa) Array.Fill(m, (byte)255, y * w + xa, xb - xa);
            }
        }
        return m;
    }

    public static byte[] Combine(byte[] existing, byte[] add, SelectMode mode)
    {
        if (mode == SelectMode.New) return add;
        if (existing == null) return mode == SelectMode.Subtract ? null : add;
        var r = new byte[existing.Length];
        switch (mode)
        {
            case SelectMode.Add: for (int i = 0; i < r.Length; i++) r[i] = Math.Max(existing[i], add[i]); break;
            case SelectMode.Subtract: for (int i = 0; i < r.Length; i++) r[i] = (byte)(existing[i] * (255 - add[i]) / 255); break;
            case SelectMode.Intersect: for (int i = 0; i < r.Length; i++) r[i] = (byte)(existing[i] * add[i] / 255); break;
        }
        return r;
    }

    public static bool IsEmpty(byte[] m)
    {
        if (m == null) return true;
        foreach (var b in m) if (b != 0) return false;
        return true;
    }

    public static Int32Rect Bounds(byte[] m, int w, int h)
    {
        if (m == null) return new Int32Rect(0, 0, w, h);
        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int y = 0; y < h; y++)
        {
            int row = y * w;
            for (int x = 0; x < w; x++)
            {
                if (m[row + x] == 0) continue;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                maxY = y;
            }
        }
        if (maxX < 0) return Int32Rect.Empty;
        return new Int32Rect(minX, minY, maxX - minX + 1, maxY - minY + 1);
    }

    public static byte[] Invert(byte[] m, int w, int h)
    {
        var r = new byte[w * h];
        if (m == null) return r;
        for (int i = 0; i < r.Length; i++) r[i] = (byte)(255 - m[i]);
        return r;
    }

    public static byte[] Feather(byte[] m, int w, int h, int radius)
    {
        if (m == null || radius <= 0) return m;
        var f = new float[m.Length];
        for (int i = 0; i < m.Length; i++) f[i] = m[i];
        for (int pass = 0; pass < 3; pass++) Filters.BoxBlurFloat(f, w, h, Math.Max(1, radius / 2));
        var r = new byte[m.Length];
        for (int i = 0; i < r.Length; i++) r[i] = (byte)Math.Clamp((int)(f[i] + 0.5f), 0, 255);
        return r;
    }

    /// <summary>Grow (positive) or shrink (negative) using a square structuring element.</summary>
    public static byte[] Grow(byte[] m, int w, int h, int amount)
    {
        if (m == null || amount == 0) return m;
        bool grow = amount > 0;
        int rad = Math.Abs(amount);
        var tmp = new byte[m.Length];
        var res = new byte[m.Length];
        // separable min/max
        Parallel.For(0, h, y =>
        {
            int row = y * w;
            for (int x = 0; x < w; x++)
            {
                byte v = grow ? (byte)0 : (byte)255;
                int a = Math.Max(0, x - rad), b = Math.Min(w - 1, x + rad);
                for (int k = a; k <= b; k++) { byte c = m[row + k]; v = grow ? Math.Max(v, c) : Math.Min(v, c); }
                if (!grow && (x - rad < 0 || x + rad >= w)) v = 0;
                tmp[row + x] = v;
            }
        });
        Parallel.For(0, w, x =>
        {
            for (int y = 0; y < h; y++)
            {
                byte v = grow ? (byte)0 : (byte)255;
                int a = Math.Max(0, y - rad), b = Math.Min(h - 1, y + rad);
                for (int k = a; k <= b; k++) { byte c = tmp[k * w + x]; v = grow ? Math.Max(v, c) : Math.Min(v, c); }
                if (!grow && (y - rad < 0 || y + rad >= h)) v = 0;
                res[y * w + x] = v;
            }
        });
        return res;
    }

    public static byte[] Border(byte[] m, int w, int h, int radius)
    {
        if (m == null || radius <= 0) return m;
        var outer = Grow(m, w, h, radius);
        var inner = Grow(m, w, h, -radius);
        for (int i = 0; i < outer.Length; i++) outer[i] = (byte)(outer[i] - inner[i]);
        return outer;
    }

    // Summed-area counts keep large-radius cleanup linear in the image size.
    public static byte[] Smooth(byte[] m, int w, int h, int radius)
    {
        if (m == null || radius <= 0) return m;
        int stride = w + 1;
        var sums = new int[checked(stride * (h + 1))];
        for (int y = 0; y < h; y++)
        {
            int row = 0;
            for (int x = 0; x < w; x++)
            {
                row += m[y * w + x] >= 128 ? 1 : 0;
                sums[(y + 1) * stride + x + 1] = sums[y * stride + x + 1] + row;
            }
        }
        var result = new byte[m.Length];
        Parallel.For(0, h, y =>
        {
            int top = Math.Max(0, y - radius), bottom = Math.Min(h, y + radius + 1);
            for (int x = 0; x < w; x++)
            {
                int left = Math.Max(0, x - radius), right = Math.Min(w, x + radius + 1);
                int count = sums[bottom * stride + right] - sums[top * stride + right]
                    - sums[bottom * stride + left] + sums[top * stride + left];
                if (count * 2 >= (right - left) * (bottom - top)) result[y * w + x] = 255;
            }
        });
        return result;
    }

    /// <summary>Flood or global color selection on a pixel buffer.</summary>
    public static byte[] MagicWand(uint[] px, int w, int h, int sx, int sy, int tolerance, bool contiguous)
    {
        var m = new byte[w * h];
        if (sx < 0 || sy < 0 || sx >= w || sy >= h) return m;
        uint seed = px[sy * w + sx];
        int tol2 = tolerance * tolerance * 3;
        bool Match(uint p)
        {
            int da = Px.A(p) - Px.A(seed);
            if (Px.A(seed) == 0 && Px.A(p) == 0) return true;
            int dr = Px.R(p) - Px.R(seed), dg = Px.G(p) - Px.G(seed), db = Px.B(p) - Px.B(seed);
            return dr * dr + dg * dg + db * db + da * da <= tol2;
        }
        if (!contiguous)
        {
            Parallel.For(0, h, y => { for (int x = 0; x < w; x++) if (Match(px[y * w + x])) m[y * w + x] = 255; });
            return m;
        }
        var stack = new Stack<(int, int)>();
        stack.Push((sx, sy));
        while (stack.Count > 0)
        {
            var (x, y) = stack.Pop();
            int row = y * w;
            int xl = x;
            while (xl >= 0 && m[row + xl] == 0 && Match(px[row + xl])) xl--;
            xl++;
            int xr = x;
            while (xr < w && m[row + xr] == 0 && Match(px[row + xr])) xr++;
            xr--;
            if (xr < xl) continue;
            for (int i = xl; i <= xr; i++) m[row + i] = 255;
            for (int ny = y - 1; ny <= y + 1; ny += 2)
            {
                if (ny < 0 || ny >= h) continue;
                int nrow = ny * w;
                bool inRun = false;
                for (int i = xl; i <= xr; i++)
                {
                    bool ok = m[nrow + i] == 0 && Match(px[nrow + i]);
                    if (ok && !inRun) { stack.Push((i, ny)); inRun = true; }
                    else if (!ok) inRun = false;
                }
            }
        }
        return m;
    }

    /// <summary>Builds a pixel-edge outline (marching ants) in document coordinates.</summary>
    public static SelectionPath Outline(byte[] m, int w, int h)
    {
        var g = new SelectionPath();
        if (m == null) return g;
        // horizontal edges between rows y-1 and y
        for (int y = 0; y <= h; y++)
        {
            int runStart = -1;
            for (int x = 0; x <= w; x++)
            {
                bool edge = false;
                if (x < w)
                {
                    bool a = y > 0 && m[(y - 1) * w + x] >= 128;
                    bool b = y < h && m[y * w + x] >= 128;
                    edge = a != b;
                }
                if (edge && runStart < 0) runStart = x;
                else if (!edge && runStart >= 0) { g.Segments.Add((new Point(runStart, y), new Point(x, y))); runStart = -1; }
            }
        }
        for (int x = 0; x <= w; x++)
        {
            int runStart = -1;
            for (int y = 0; y <= h; y++)
            {
                bool edge = false;
                if (y < h)
                {
                    bool a = x > 0 && m[y * w + x - 1] >= 128;
                    bool b = x < w && m[y * w + x] >= 128;
                    edge = a != b;
                }
                if (edge && runStart < 0) runStart = y;
                else if (!edge && runStart >= 0) { g.Segments.Add((new Point(x, runStart), new Point(x, y))); runStart = -1; }
            }
        }
        return g;
    }
}

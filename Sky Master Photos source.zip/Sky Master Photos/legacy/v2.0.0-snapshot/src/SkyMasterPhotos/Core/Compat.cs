using Avalonia;

namespace SkyMasterPhotos.Core;

/// <summary>Integer pixel rectangle (same shape as WPF's Int32Rect, which the engine was written against).</summary>
public struct Int32Rect : IEquatable<Int32Rect>
{
    public int X, Y, Width, Height;

    public Int32Rect(int x, int y, int width, int height) { X = x; Y = y; Width = width; Height = height; }

    public static Int32Rect Empty => default;
    public readonly bool IsEmpty => Width == 0 && Height == 0 && X == 0 && Y == 0;
    public readonly bool HasArea => Width > 0 && Height > 0;

    public readonly bool Equals(Int32Rect o) => X == o.X && Y == o.Y && Width == o.Width && Height == o.Height;
    public override readonly bool Equals(object obj) => obj is Int32Rect r && Equals(r);
    public override readonly int GetHashCode() => HashCode.Combine(X, Y, Width, Height);
    public static bool operator ==(Int32Rect a, Int32Rect b) => a.Equals(b);
    public static bool operator !=(Int32Rect a, Int32Rect b) => !a.Equals(b);
    public override readonly string ToString() => $"{X},{Y},{Width},{Height}";
}

/// <summary>
/// Mutable 2-D affine matrix with WPF's Matrix API (Translate / Scale / Rotate / Append / Invert / Transform),
/// row-vector convention: p' = p · M.
/// </summary>
public struct Affine
{
    public double M11, M12, M21, M22, OffsetX, OffsetY;

    public Affine(double m11, double m12, double m21, double m22, double ox, double oy)
    { M11 = m11; M12 = m12; M21 = m21; M22 = m22; OffsetX = ox; OffsetY = oy; }

    public static Affine Identity => new(1, 0, 0, 1, 0, 0);

    public readonly double Determinant => M11 * M22 - M12 * M21;
    public readonly bool HasInverse => Math.Abs(Determinant) > 1e-12;

    /// <summary>this = this · other</summary>
    public void Append(Affine o)
    {
        this = new Affine(
            M11 * o.M11 + M12 * o.M21, M11 * o.M12 + M12 * o.M22,
            M21 * o.M11 + M22 * o.M21, M21 * o.M12 + M22 * o.M22,
            OffsetX * o.M11 + OffsetY * o.M21 + o.OffsetX, OffsetX * o.M12 + OffsetY * o.M22 + o.OffsetY);
    }

    public void Prepend(Affine o) { var t = o; t.Append(this); this = t; }

    public void Translate(double x, double y) { OffsetX += x; OffsetY += y; }
    public void Scale(double sx, double sy) => Append(new Affine(sx, 0, 0, sy, 0, 0));

    public void Rotate(double degrees)
    {
        double a = degrees * Math.PI / 180, c = Math.Cos(a), s = Math.Sin(a);
        Append(new Affine(c, s, -s, c, 0, 0));
    }

    public void RotateAt(double degrees, double cx, double cy) { Translate(-cx, -cy); Rotate(degrees); Translate(cx, cy); }
    public void ScaleAt(double sx, double sy, double cx, double cy) { Translate(-cx, -cy); Scale(sx, sy); Translate(cx, cy); }

    public void Invert()
    {
        double d = Determinant;
        if (Math.Abs(d) < 1e-12) throw new InvalidOperationException("Matrix is not invertible.");
        this = new Affine(M22 / d, -M12 / d, -M21 / d, M11 / d,
            (M21 * OffsetY - M22 * OffsetX) / d, (M12 * OffsetX - M11 * OffsetY) / d);
    }

    public readonly Point Transform(Point p) => new(p.X * M11 + p.Y * M21 + OffsetX, p.X * M12 + p.Y * M22 + OffsetY);
    public readonly Vector Transform(Vector v) => new(v.X * M11 + v.Y * M21, v.X * M12 + v.Y * M22);

    /// <summary>The same transform as an Avalonia matrix (for drawing).</summary>
    public readonly Matrix ToAvalonia() => new(M11, M12, M21, M22, OffsetX, OffsetY);
}

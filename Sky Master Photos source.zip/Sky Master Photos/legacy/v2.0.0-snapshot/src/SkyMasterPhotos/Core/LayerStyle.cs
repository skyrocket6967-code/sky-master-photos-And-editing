namespace SkyMasterPhotos.Core;

public sealed record LayerStyle
{
    public bool Shadow { get; init; }
    public bool OuterGlow { get; init; }
    public bool InnerGlow { get; init; }
    public bool Bevel { get; init; }
    public bool Stroke { get; init; }
    public int Size { get; init; } = 8;
    public int Distance { get; init; } = 8;
    public double Angle { get; init; } = 135;
    public double Strength { get; init; } = 0.65;
    public uint Color { get; init; } = 0xFF70BFFF;
    public bool Enabled => Shadow || OuterGlow || InnerGlow || Bevel || Stroke;

    public uint[] Render(uint[] pixels, uint[] mask, int w, int h, double fill)
    {
        int size = Math.Clamp(Size, 1, 100);
        double strength = Math.Clamp(Strength, 0, 1);
        var alpha = new byte[pixels.Length];
        for (int i = 0; i < alpha.Length; i++)
            alpha[i] = (byte)(Px.A(pixels[i]) * (mask == null ? 255 : mask[i] & 255) / 255);
        var soft = SelectionOps.Feather(alpha, w, h, size);
        var expanded = Stroke ? SelectionOps.Grow(alpha, w, h, size) : null;
        var result = new uint[pixels.Length];
        double radians = Angle * Math.PI / 180;
        int dx = (int)Math.Round(Math.Cos(radians) * Distance);
        int dy = (int)Math.Round(Math.Sin(radians) * Distance);
        int bx = (int)Math.Round(Math.Cos(radians) * size);
        int by = (int)Math.Round(Math.Sin(radians) * size);
        double At(byte[] a, int x, int y) => x < 0 || y < 0 || x >= w || y >= h ? 0 : a[y * w + x] / 255.0;
        Parallel.For(0, h, y =>
        {
            for (int x = 0; x < w; x++)
            {
                int i = y * w + x;
                uint p = 0;
                double a = alpha[i] / 255.0;
                if (Shadow) p = Over(p, 0xFF000000, At(soft, x - dx, y - dy) * strength);
                if (OuterGlow) p = Over(p, Color, soft[i] / 255.0 * strength * 2);
                if (Stroke) p = Over(p, Color, expanded[i] / 255.0 * strength);
                uint content = (pixels[i] & 0xFFFFFF) | ((uint)Math.Round(alpha[i] * Math.Clamp(fill, 0, 1)) << 24);
                p = Over(p, content, 1);
                if (InnerGlow) p = Over(p, Color, a * (1 - soft[i] / 255.0) * strength * 2);
                if (Bevel)
                {
                    double light = At(alpha, x + bx, y + by) - At(alpha, x - bx, y - by);
                    p = Over(p, light > 0 ? 0xFFFFFFFF : 0xFF000000, Math.Abs(light) * a * strength);
                }
                result[i] = p;
            }
        });
        return result;
    }

    static uint Over(uint dst, uint src, double amount)
    {
        double a = Px.A(src) / 255.0 * Math.Clamp(amount, 0, 1), b = Px.A(dst) / 255.0 * (1 - a), total = a + b;
        if (total <= 0) return 0;
        return Px.Pack((int)Math.Round(total * 255),
            (int)Math.Round((Px.R(src) * a + Px.R(dst) * b) / total),
            (int)Math.Round((Px.G(src) * a + Px.G(dst) * b) / total),
            (int)Math.Round((Px.B(src) * a + Px.B(dst) * b) / total));
    }
}

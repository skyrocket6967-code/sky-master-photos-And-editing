using Avalonia;

namespace SkyMasterPhotos;

static class Program
{
    [STAThread]
    public static int Main(string[] args)
    {
        try
        {
            return BuildAvaloniaApp().StartWithClassicDesktopLifetime(args);
        }
        catch (Exception ex)
        {
            App.LogCrash(ex);
            Console.Error.WriteLine(ex);
            return 1;
        }
    }

    public static AppBuilder BuildAvaloniaApp()
    {
        // SKY_SOFTWARE_RENDER=1 forces CPU rendering, =0 forces OpenGL. By default virtual machines
        // (VirtualBox, VMware, QEMU) render on the CPU: their 3D drivers often "work" but draw black or flicker.
        var env = Environment.GetEnvironmentVariable("SKY_SOFTWARE_RENDER");
        bool software = env == "1" || (env != "0" && OperatingSystem.IsLinux() && IsVirtualMachine());
        return AppBuilder.Configure<App>()
            .UsePlatformDetect()
            .With(new X11PlatformOptions
            {
                // try OpenGL, fall back to software (VirtualBox / VMware / remote desktops)
                RenderingMode = software ? new[] { X11RenderingMode.Software } : new[] { X11RenderingMode.Glx, X11RenderingMode.Egl, X11RenderingMode.Software },
                WmClass = "sky-master-photos",
            })
            .With(new Win32PlatformOptions
            {
                RenderingMode = software ? new[] { Win32RenderingMode.Software } : new[] { Win32RenderingMode.AngleEgl, Win32RenderingMode.Software },
            })
            .WithInterFont()
            .LogToTrace();
    }

    static bool IsVirtualMachine()
    {
        try
        {
            foreach (var f in new[] { "/sys/class/dmi/id/product_name", "/sys/class/dmi/id/sys_vendor" })
            {
                if (!File.Exists(f)) continue;
                var v = File.ReadAllText(f);
                if (v.Contains("VirtualBox", StringComparison.OrdinalIgnoreCase) || v.Contains("VMware", StringComparison.OrdinalIgnoreCase)
                    || v.Contains("QEMU", StringComparison.OrdinalIgnoreCase) || v.Contains("innotek", StringComparison.OrdinalIgnoreCase)) return true;
            }
        }
        catch { }
        return false;
    }
}

using System;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Effects;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SkySetup
{
    public static class Program
    {
        [STAThread]
        public static int Main(string[] args)
        {
            bool silent = Array.Exists(args, a => a.Equals("/S", StringComparison.OrdinalIgnoreCase) || a.Equals("--silent", StringComparison.OrdinalIgnoreCase));
            string dirArg = Array.Find(args, a => a.StartsWith("/D=", StringComparison.OrdinalIgnoreCase));
#if UNINSTALLER
            const bool uninstall = true;
#else
            bool uninstall = Array.Exists(args, a => a.Equals("/uninstall", StringComparison.OrdinalIgnoreCase));
#endif
            if (silent)
            {
                try
                {
                    if (uninstall) Installer.Uninstall((p, s) => { });
                    else Installer.Install(new InstallOptions { Dir = dirArg != null ? dirArg.Substring(3).Trim('"') : (Installer.InstalledDir() ?? Installer.DefaultDir) }, (p, s) => { });
                    return 0;
                }
                catch (Exception ex)
                {
                    try { File.WriteAllText(System.IO.Path.Combine(System.IO.Path.GetTempPath(), "SkyMasterPhotosSetup.log"), ex.ToString()); } catch { }
                    return 1;
                }
            }
            var app = new Application { ShutdownMode = ShutdownMode.OnMainWindowClose };
            var w = new SetupWindow(uninstall);
            app.Run(w);
            return 0;
        }
    }

    public sealed class SetupWindow : Window
    {
        readonly bool _uninstall;
        readonly ContentControl _page = new ContentControl();
        readonly InstallOptions _opt = new InstallOptions();
        static ResourceDictionary _res;

        static readonly Color Accent1 = Color.FromRgb(0x38, 0xBD, 0xF8), Accent2 = Color.FromRgb(0x5B, 0x8C, 0xFF), Accent3 = Color.FromRgb(0xA4, 0x6B, 0xFF);
        static readonly Brush Bg1 = new SolidColorBrush(Color.FromRgb(0x11, 0x13, 0x18));
        static readonly Brush Bg0 = new SolidColorBrush(Color.FromRgb(0x0A, 0x0B, 0x0F));
        static readonly Brush Text = new SolidColorBrush(Color.FromRgb(0xEC, 0xEE, 0xF4));
        static readonly Brush Text2 = new SolidColorBrush(Color.FromRgb(0xA3, 0xAA, 0xBB));
        static readonly Brush Text3 = new SolidColorBrush(Color.FromRgb(0x6C, 0x73, 0x85));
        static readonly Brush Line2 = new SolidColorBrush(Color.FromRgb(0x2E, 0x34, 0x40));

        static Brush Grad(double angle = 45)
        {
            var g = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = angle == 0 ? new Point(1, 0) : new Point(1, 1) };
            g.GradientStops.Add(new GradientStop(Accent1, 0));
            g.GradientStops.Add(new GradientStop(Accent2, 0.5));
            g.GradientStops.Add(new GradientStop(Accent3, 1));
            return g;
        }

        public SetupWindow(bool uninstall)
        {
            _uninstall = uninstall;
            _opt.Dir = Installer.InstalledDir() ?? Installer.DefaultDir;
            Title = uninstall ? "Uninstall Sky Master Photos" : "Sky Master Photos Setup";
            Width = 820; Height = 540;
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ResizeMode = ResizeMode.NoResize;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            FontFamily = new FontFamily("Segoe UI Variable Text, Segoe UI");
            Foreground = Text;
            UseLayoutRounding = true;
            TextOptions.SetTextFormattingMode(this, TextFormattingMode.Display);
            try { Icon = BitmapFrame.Create(new Uri("pack://application:,,,/logo.png")); } catch { }
            Resources.MergedDictionaries.Add(Res());

            var root = new Grid();
            root.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(290) });
            root.ColumnDefinitions.Add(new ColumnDefinition());
            root.Children.Add(BuildBrand());
            var right = new Grid { Background = Bg1 };
            Grid.SetColumn(right, 1);
            root.Children.Add(right);
            _page.Margin = new Thickness(40, 36, 40, 32);
            right.Children.Add(_page);
            var close = new Button { Style = (Style)Resources["Ghost"], Width = 34, Height = 34, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 10, 10, 0), Content = new System.Windows.Shapes.Path { Data = Geometry.Parse("M0 0 L10 10 M10 0 L0 10"), Stroke = Text2, StrokeThickness = 1.4 } };
            close.Click += (_, __) => { if (_busy) return; Close(); };
            right.Children.Add(close);

            var shell = new Border
            {
                Margin = new Thickness(24),
                CornerRadius = new CornerRadius(20),
                Background = Bg1,
                BorderBrush = Line2,
                BorderThickness = new Thickness(1),
                Effect = new DropShadowEffect { BlurRadius = 30, ShadowDepth = 6, Direction = 270, Opacity = 0.5 },
                Child = root,
            };
            // round the inner content
            root.Loaded += (_, __) => root.Clip = new RectangleGeometry(new Rect(0, 0, root.ActualWidth, root.ActualHeight), 19, 19);
            Content = shell;
            MouseLeftButtonDown += (_, e) => { if (e.ButtonState == MouseButtonState.Pressed) try { DragMove(); } catch { } };
            KeyDown += (_, e) => { if (e.Key == Key.Escape && !_busy) Close(); };

            ShowWelcome();
        }

        bool _busy;

        UIElement BuildBrand()
        {
            var g = new Grid { Background = new LinearGradientBrush(Color.FromRgb(0x14, 0x1B, 0x33), Color.FromRgb(0x24, 0x15, 0x3D), 60), ClipToBounds = true };
            var orbs = new Canvas();
            void Orb(double x, double y, double s, Color c, double op)
            {
                var e = new Ellipse { Width = s, Height = s, Fill = new RadialGradientBrush(Color.FromArgb((byte)(op * 255), c.R, c.G, c.B), Color.FromArgb(0, c.R, c.G, c.B)) };
                Canvas.SetLeft(e, x); Canvas.SetTop(e, y);
                orbs.Children.Add(e);
            }
            Orb(-120, -120, 380, Accent1, 0.5);
            Orb(60, 180, 360, Accent2, 0.45);
            Orb(-60, 320, 380, Accent3, 0.5);
            g.Children.Add(orbs);

            var sp = new StackPanel { Margin = new Thickness(34, 44, 30, 30) };
            sp.Children.Add(new Image { Source = new BitmapImage(new Uri("pack://application:,,,/logo.png")), Width = 76, Height = 76, HorizontalAlignment = HorizontalAlignment.Left, Effect = new DropShadowEffect { BlurRadius = 24, ShadowDepth = 4, Opacity = 0.45 } });
            sp.Children.Add(new TextBlock { Text = "Sky Master", FontSize = 30, FontWeight = FontWeights.SemiBold, FontFamily = new FontFamily("Segoe UI Variable Display, Segoe UI"), Margin = new Thickness(0, 22, 0, 0), Foreground = Brushes.White });
            sp.Children.Add(new TextBlock { Text = "Photos", FontSize = 30, FontWeight = FontWeights.SemiBold, FontFamily = new FontFamily("Segoe UI Variable Display, Segoe UI"), Margin = new Thickness(0, -6, 0, 0), Foreground = Grad(0) });
            sp.Children.Add(new TextBlock { Text = "Sky Photo editor  ·  v" + Installer.Version, FontSize = 12.5, Foreground = new SolidColorBrush(Color.FromArgb(190, 255, 255, 255)), Margin = new Thickness(0, 8, 0, 0) });
            g.Children.Add(sp);

            var feats = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(34, 0, 24, 34) };
            foreach (var f in new[] { "27 pro tools — brush, heal, clone", "Opens & saves layered Photoshop PSD", "Live adjustments, curves & filters", "Ultra-fast native engine" })
            {
                var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 9) };
                row.Children.Add(new Ellipse { Width = 7, Height = 7, Fill = Grad(), Margin = new Thickness(0, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center });
                row.Children.Add(new TextBlock { Text = f, FontSize = 12.5, Foreground = new SolidColorBrush(Color.FromArgb(220, 255, 255, 255)) });
                feats.Children.Add(row);
            }
            g.Children.Add(feats);
            return g;
        }

        static TextBlock H(string t) => new TextBlock { Text = t, FontSize = 25, FontWeight = FontWeights.SemiBold, FontFamily = new FontFamily("Segoe UI Variable Display, Segoe UI"), Foreground = Text };
        static TextBlock P(string t, Brush b = null) => new TextBlock { Text = t, FontSize = 13, Foreground = b ?? Text2, TextWrapping = TextWrapping.Wrap, LineHeight = 20, Margin = new Thickness(0, 8, 0, 0) };

        CheckBox Toggle(string text, bool value, Action<bool> set)
        {
            var c = new CheckBox { Content = text, IsChecked = value, Style = (Style)Resources["Switch"], Margin = new Thickness(0, 0, 0, 12) };
            c.Click += (_, __) => set(c.IsChecked == true);
            return c;
        }

        Button Primary(string text, Action a, bool danger = false)
        {
            var b = new Button { Content = text, Style = (Style)Resources[danger ? "Danger" : "Primary"], MinWidth = 140 };
            b.Click += (_, __) => a();
            return b;
        }

        void ShowWelcome()
        {
            var dp = new DockPanel { LastChildFill = true };
            var footer = new DockPanel { LastChildFill = false };
            DockPanel.SetDock(footer, Dock.Bottom);
            dp.Children.Add(footer);
            var body = new StackPanel();
            dp.Children.Add(body);

            if (_uninstall)
            {
                body.Children.Add(H("Uninstall Sky Master Photos"));
                body.Children.Add(P("This removes the app, its shortcuts and file associations from this PC."));
                body.Children.Add(P("Your images and .skyphoto projects are never touched.", Text3));
                var b = Primary("Uninstall", Start, true);
                DockPanel.SetDock(b, Dock.Right);
                footer.Children.Add(b);
                var cancel = new Button { Content = "Cancel", Style = (Style)Resources["Secondary"], Margin = new Thickness(0, 0, 10, 0) };
                cancel.Click += (_, __) => Close();
                DockPanel.SetDock(cancel, Dock.Right);
                footer.Children.Add(cancel);
            }
            else
            {
                bool upgrade = Installer.InstalledDir() != null;
                body.Children.Add(H(upgrade ? "Update Sky Master Photos" : "Install Sky Master Photos"));
                body.Children.Add(P(upgrade ? "A previous version was found — it will be updated in place. Your settings are kept." : "Everything you need to edit photos like a pro. Installs just for you — no admin rights needed."));
                body.Children.Add(new TextBlock { Text = "INSTALL LOCATION", FontSize = 11, FontWeight = FontWeights.SemiBold, Foreground = Text3, Margin = new Thickness(0, 26, 0, 8) });
                var row = new DockPanel();
                var browse = new Button { Content = "Browse…", Style = (Style)Resources["Secondary"], Margin = new Thickness(10, 0, 0, 0) };
                DockPanel.SetDock(browse, Dock.Right);
                var tb = new TextBox { Text = _opt.Dir, Style = (Style)Resources["Input"] };
                tb.TextChanged += (_, __) => _opt.Dir = tb.Text;
                browse.Click += (_, __) =>
                {
                    using (var fb = new System.Windows.Forms.FolderBrowserDialog { Description = "Choose where to install Sky Master Photos", SelectedPath = Directory.Exists(_opt.Dir) ? _opt.Dir : Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) })
                        if (fb.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                            tb.Text = fb.SelectedPath.EndsWith(Installer.AppName, StringComparison.OrdinalIgnoreCase) ? fb.SelectedPath : System.IO.Path.Combine(fb.SelectedPath, Installer.AppName);
                };
                row.Children.Add(browse);
                row.Children.Add(tb);
                body.Children.Add(row);
                body.Children.Add(new Border { Height = 24 });
                body.Children.Add(Toggle("Create a desktop shortcut", _opt.DesktopShortcut, v => _opt.DesktopShortcut = v));
                body.Children.Add(Toggle("Add to the Start menu", _opt.StartMenuShortcut, v => _opt.StartMenuShortcut = v));
                body.Children.Add(Toggle("Open .skyphoto projects with Sky Master Photos", _opt.AssociateProject, v => _opt.AssociateProject = v));
                body.Children.Add(Toggle("Add “Edit with Sky Master Photos” to images", _opt.OpenWithImages, v => _opt.OpenWithImages = v));

                long size = 0;
                try { using (var s = typeof(SetupWindow).Assembly.GetManifestResourceStream("payload.zip")) size = s?.Length ?? 0; } catch { }
                var info = new TextBlock { Text = $"Download size {size / 1048576.0:0} MB  ·  Windows 10 / 11 (64-bit)", Foreground = Text3, FontSize = 12, VerticalAlignment = VerticalAlignment.Center };
                DockPanel.SetDock(info, Dock.Left);
                footer.Children.Add(info);
                var b = Primary(upgrade ? "Update" : "Install", Start);
                DockPanel.SetDock(b, Dock.Right);
                footer.Children.Add(b);
            }
            SetPage(dp);
        }

        void SetPage(UIElement e)
        {
            _page.Content = e;
            e.Opacity = 0;
            var tt = new TranslateTransform(14, 0);
            ((FrameworkElement)e).RenderTransform = tt;
            e.BeginAnimation(OpacityProperty, new DoubleAnimation(1, TimeSpan.FromMilliseconds(260)));
            tt.BeginAnimation(TranslateTransform.XProperty, new DoubleAnimation(0, TimeSpan.FromMilliseconds(320)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
        }

        async void Start()
        {
            if (!_uninstall)
            {
                try
                {
                    _opt.Dir = System.IO.Path.GetFullPath(_opt.Dir.Trim());
                }
                catch { MessageBox.Show(this, "Please choose a valid install folder.", Title); return; }
            }
            _busy = true;
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            sp.Children.Add(H(_uninstall ? "Uninstalling…" : "Installing…"));
            var status = P("Preparing…");
            sp.Children.Add(status);
            var track = new Border { Height = 8, CornerRadius = new CornerRadius(4), Background = new SolidColorBrush(Color.FromRgb(0x26, 0x2B, 0x36)), Margin = new Thickness(0, 30, 0, 0) };
            var fill = new Border { Height = 8, CornerRadius = new CornerRadius(4), Background = Grad(0), HorizontalAlignment = HorizontalAlignment.Left, Width = 0 };
            var bar = new Grid();
            bar.Children.Add(track);
            bar.Children.Add(fill);
            fill.Margin = new Thickness(0, 30, 0, 0);
            sp.Children.Add(bar);
            var pct = new TextBlock { Text = "0%", Foreground = Text3, FontSize = 12, Margin = new Thickness(0, 10, 0, 0), HorizontalAlignment = HorizontalAlignment.Right };
            sp.Children.Add(pct);
            SetPage(sp);

            var prog = new Progress<(double p, string s)>(v =>
            {
                status.Text = v.s;
                double w = Math.Max(0, track.ActualWidth * v.p);
                fill.BeginAnimation(WidthProperty, new DoubleAnimation(w, TimeSpan.FromMilliseconds(180)));
                pct.Text = $"{(int)(v.p * 100)}%";
            });
            IProgress<(double, string)> ip = prog;
            Exception error = null;
            await Task.Run(() =>
            {
                try
                {
                    if (_uninstall) Installer.Uninstall((p, s) => ip.Report((p, s)));
                    else Installer.Install(_opt, (p, s) => ip.Report((p, s)));
                }
                catch (Exception ex) { error = ex; }
            });
            await Task.Delay(350);
            _busy = false;
            if (error != null) ShowError(error); else ShowDone();
        }

        void ShowError(Exception ex)
        {
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            sp.Children.Add(H("Something went wrong"));
            sp.Children.Add(P(ex.Message));
            sp.Children.Add(P("Close Sky Master Photos if it's open, then try again.", Text3));
            var b = Primary("Try again", ShowWelcome);
            b.HorizontalAlignment = HorizontalAlignment.Left;
            b.Margin = new Thickness(0, 26, 0, 0);
            sp.Children.Add(b);
            SetPage(sp);
        }

        void ShowDone()
        {
            var dp = new DockPanel();
            var footer = new DockPanel { LastChildFill = false };
            DockPanel.SetDock(footer, Dock.Bottom);
            dp.Children.Add(footer);
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            dp.Children.Add(sp);
            var circle = new Grid { Width = 74, Height = 74, HorizontalAlignment = HorizontalAlignment.Left };
            circle.Children.Add(new Ellipse { Fill = Grad() });
            circle.Children.Add(new System.Windows.Shapes.Path { Data = Geometry.Parse("M0 9 L8 17 L24 0"), Stroke = Brushes.White, StrokeThickness = 4, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round, StrokeLineJoin = PenLineJoin.Round, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(2, 4, 0, 0) });
            circle.RenderTransformOrigin = new Point(0.5, 0.5);
            var sc = new ScaleTransform(0.6, 0.6);
            circle.RenderTransform = sc;
            var pop = new DoubleAnimation(1, TimeSpan.FromMilliseconds(420)) { EasingFunction = new BackEase { Amplitude = 0.5, EasingMode = EasingMode.EaseOut } };
            sc.BeginAnimation(ScaleTransform.ScaleXProperty, pop);
            sc.BeginAnimation(ScaleTransform.ScaleYProperty, pop);
            sp.Children.Add(circle);
            var h = H(_uninstall ? "Uninstalled" : "You're all set!");
            h.Margin = new Thickness(0, 22, 0, 0);
            sp.Children.Add(h);
            sp.Children.Add(P(_uninstall ? "Sky Master Photos has been removed from this PC. Thanks for creating with us." : "Sky Master Photos is installed. Find it on your desktop and in the Start menu."));

            CheckBox launch = null;
            if (!_uninstall)
            {
                launch = new CheckBox { Content = "Launch Sky Master Photos", IsChecked = true, Style = (Style)Resources["Switch"], Margin = new Thickness(0, 24, 0, 0) };
                sp.Children.Add(launch);
            }
            var b = Primary(_uninstall ? "Close" : "Finish", () =>
            {
                if (launch?.IsChecked == true)
                {
                    try { Process.Start(new ProcessStartInfo(System.IO.Path.Combine(_opt.Dir, Installer.ExeName)) { UseShellExecute = true, WorkingDirectory = _opt.Dir }); } catch { }
                }
                Close();
            });
            DockPanel.SetDock(b, Dock.Right);
            footer.Children.Add(b);
            SetPage(dp);
        }

        static ResourceDictionary Res()
        {
            if (_res != null) return _res;
            const string xaml = @"
<ResourceDictionary xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation' xmlns:x='http://schemas.microsoft.com/winfx/2006/xaml'>
  <LinearGradientBrush x:Key='G' StartPoint='0,0' EndPoint='1,1'>
    <GradientStop Color='#38BDF8' Offset='0'/><GradientStop Color='#5B8CFF' Offset='0.5'/><GradientStop Color='#A46BFF' Offset='1'/>
  </LinearGradientBrush>
  <Style x:Key='Primary' TargetType='Button'>
    <Setter Property='Foreground' Value='White'/><Setter Property='FontWeight' Value='SemiBold'/><Setter Property='FontSize' Value='13.5'/>
    <Setter Property='Cursor' Value='Hand'/><Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Button'>
      <Grid><Border CornerRadius='11' Background='{StaticResource G}'/><Border x:Name='h' CornerRadius='11' Background='White' Opacity='0'/>
      <ContentPresenter Margin='22,11' HorizontalAlignment='Center' VerticalAlignment='Center'/></Grid>
      <ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='h' Property='Opacity' Value='0.12'/></Trigger>
      <Trigger Property='IsPressed' Value='True'><Setter TargetName='h' Property='Opacity' Value='0.22'/></Trigger></ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key='Danger' TargetType='Button' BasedOn='{StaticResource Primary}'>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Button'>
      <Grid><Border CornerRadius='11' Background='#E5484D'/><Border x:Name='h' CornerRadius='11' Background='White' Opacity='0'/>
      <ContentPresenter Margin='22,11' HorizontalAlignment='Center' VerticalAlignment='Center'/></Grid>
      <ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='h' Property='Opacity' Value='0.12'/></Trigger></ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key='Secondary' TargetType='Button'>
    <Setter Property='Foreground' Value='#ECEEF4'/><Setter Property='FontSize' Value='13'/><Setter Property='Cursor' Value='Hand'/><Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Button'>
      <Border x:Name='b' CornerRadius='10' Background='#1E222B' BorderBrush='#2E3440' BorderThickness='1' Padding='16,9'><ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/></Border>
      <ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='b' Property='Background' Value='#262B36'/></Trigger></ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key='Ghost' TargetType='Button'>
    <Setter Property='Cursor' Value='Hand'/><Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='Button'>
      <Border x:Name='b' CornerRadius='9' Background='Transparent'><ContentPresenter HorizontalAlignment='Center' VerticalAlignment='Center'/></Border>
      <ControlTemplate.Triggers><Trigger Property='IsMouseOver' Value='True'><Setter TargetName='b' Property='Background' Value='#18FFFFFF'/></Trigger></ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key='Input' TargetType='TextBox'>
    <Setter Property='Foreground' Value='#ECEEF4'/><Setter Property='CaretBrush' Value='#ECEEF4'/><Setter Property='FontSize' Value='13'/><Setter Property='VerticalContentAlignment' Value='Center'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='TextBox'>
      <Border x:Name='b' CornerRadius='10' Background='#0A0B0F' BorderBrush='#2E3440' BorderThickness='1' Padding='12,9'>
        <ScrollViewer x:Name='PART_ContentHost' Focusable='False' HorizontalScrollBarVisibility='Hidden' VerticalScrollBarVisibility='Hidden'/></Border>
      <ControlTemplate.Triggers><Trigger Property='IsKeyboardFocused' Value='True'><Setter TargetName='b' Property='BorderBrush' Value='#5B8CFF'/></Trigger></ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
  <Style x:Key='Switch' TargetType='CheckBox'>
    <Setter Property='Foreground' Value='#A3AABB'/><Setter Property='FontSize' Value='13'/><Setter Property='Cursor' Value='Hand'/><Setter Property='FocusVisualStyle' Value='{x:Null}'/>
    <Setter Property='Template'><Setter.Value><ControlTemplate TargetType='CheckBox'>
      <StackPanel Orientation='Horizontal' Background='Transparent'>
        <Border x:Name='t' Width='36' Height='20' CornerRadius='10' Background='#262B36' VerticalAlignment='Center'>
          <Ellipse x:Name='k' Width='14' Height='14' Fill='#A3AABB' HorizontalAlignment='Left' Margin='3,0'/></Border>
        <ContentPresenter Margin='12,0,0,0' VerticalAlignment='Center'/></StackPanel>
      <ControlTemplate.Triggers>
        <Trigger Property='IsChecked' Value='True'><Setter TargetName='t' Property='Background' Value='{StaticResource G}'/><Setter TargetName='k' Property='HorizontalAlignment' Value='Right'/><Setter TargetName='k' Property='Fill' Value='White'/><Setter Property='Foreground' Value='#ECEEF4'/></Trigger>
      </ControlTemplate.Triggers>
    </ControlTemplate></Setter.Value></Setter>
  </Style>
</ResourceDictionary>";
            _res = (ResourceDictionary)XamlReader.Parse(xaml);
            return _res;
        }
    }
}

using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace SkySetup
{
    public sealed class InstallOptions
    {
        public string Dir = Installer.DefaultDir;
        public bool DesktopShortcut = true;
        public bool StartMenuShortcut = true;
        public bool AssociateProject = true;
        public bool OpenWithImages = true;
    }

    /// <summary>Per-user install (no admin needed): files, shortcuts, Apps &amp; Features entry, file associations.</summary>
    public static class Installer
    {
        public const string AppName = "Sky Master Photos";
        public const string Version = "2.0.0";
        public const string Publisher = "Sky";
        public const string ExeName = "Sky Master Photos.exe";
        public const string UninstallExeName = "Uninstall Sky Master Photos.exe";
        const string UninstallKey = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\SkyMasterPhotos";
        const string ProjectProgId = "SkyMasterPhotos.Project";
        const string ImageProgId = "SkyMasterPhotos.Image";
        static readonly string[] ImageExts = { ".psd", ".psb", ".png", ".jpg", ".jpeg", ".jfif", ".bmp", ".gif", ".tif", ".tiff", ".webp", ".heic" };

        public static string DefaultDir => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", AppName);
        static string DesktopLnk => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), AppName + ".lnk");
        static string StartMenuLnk => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), AppName + ".lnk");

        public static string InstalledDir()
        {
            using (var k = Registry.CurrentUser.OpenSubKey(UninstallKey))
                return k?.GetValue("InstallLocation") as string;
        }

        public static bool IsRunning() => Process.GetProcessesByName(Path.GetFileNameWithoutExtension(ExeName)).Any();

        public static void CloseRunning()
        {
            foreach (var p in Process.GetProcessesByName(Path.GetFileNameWithoutExtension(ExeName)))
            {
                try { p.CloseMainWindow(); if (!p.WaitForExit(4000)) p.Kill(); } catch { }
            }
        }

        /// <param name="progress">0..1 with a status line</param>
        public static void Install(InstallOptions o, Action<double, string> progress)
        {
            progress(0.02, "Preparing…");
            if (IsRunning()) { progress(0.04, "Closing Sky Master Photos…"); CloseRunning(); }
            Directory.CreateDirectory(o.Dir);

            progress(0.06, "Unpacking files…");
            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("payload.zip"))
            {
                if (s == null) throw new InvalidOperationException("Installer payload is missing.");
                using (var zip = new ZipArchive(s, ZipArchiveMode.Read))
                {
                    long total = Math.Max(1, zip.Entries.Sum(e => e.Length));
                    long done = 0;
                    foreach (var e in zip.Entries)
                    {
                        var dest = Path.GetFullPath(Path.Combine(o.Dir, e.FullName));
                        if (!dest.StartsWith(Path.GetFullPath(o.Dir), StringComparison.OrdinalIgnoreCase)) continue;
                        if (e.FullName.EndsWith("/")) { Directory.CreateDirectory(dest); continue; }
                        Directory.CreateDirectory(Path.GetDirectoryName(dest));
                        for (int attempt = 0; ; attempt++)
                        {
                            try
                            {
                                using (var src = e.Open())
                                using (var fs = File.Create(dest))
                                {
                                    var buf = new byte[1 << 20];
                                    int n;
                                    while ((n = src.Read(buf, 0, buf.Length)) > 0)
                                    {
                                        fs.Write(buf, 0, n);
                                        done += n;
                                        progress(0.06 + 0.8 * done / total, $"Copying {e.Name}…");
                                    }
                                }
                                break;
                            }
                            catch (IOException) when (attempt < 5) { System.Threading.Thread.Sleep(600); }
                        }
                    }
                }
            }

            string exe = Path.Combine(o.Dir, ExeName);
            string uninst = Path.Combine(o.Dir, UninstallExeName);

            progress(0.88, "Creating shortcuts…");
            if (o.StartMenuShortcut) CreateShortcut(StartMenuLnk, exe, "Edit photos with Sky Photo");
            if (o.DesktopShortcut) CreateShortcut(DesktopLnk, exe, "Edit photos with Sky Photo");

            progress(0.93, "Registering…");
            using (var k = Registry.CurrentUser.CreateSubKey(UninstallKey))
            {
                k.SetValue("DisplayName", AppName);
                k.SetValue("DisplayVersion", Version);
                k.SetValue("Publisher", Publisher);
                k.SetValue("DisplayIcon", exe + ",0");
                k.SetValue("InstallLocation", o.Dir);
                k.SetValue("UninstallString", $"\"{uninst}\"");
                k.SetValue("QuietUninstallString", $"\"{uninst}\" /S");
                k.SetValue("NoModify", 1, RegistryValueKind.DWord);
                k.SetValue("NoRepair", 1, RegistryValueKind.DWord);
                k.SetValue("InstallDate", DateTime.Now.ToString("yyyyMMdd"));
                long size = Directory.GetFiles(o.Dir, "*", SearchOption.AllDirectories).Sum(f => new FileInfo(f).Length) / 1024;
                k.SetValue("EstimatedSize", (int)size, RegistryValueKind.DWord);
            }

            // registered app (shows in "Open with" lists)
            using (var k = Registry.CurrentUser.CreateSubKey($@"Software\Classes\Applications\{ExeName}"))
            {
                k.SetValue("FriendlyAppName", AppName);
                using (var c = k.CreateSubKey(@"shell\open\command")) c.SetValue("", $"\"{exe}\" \"%1\"");
                using (var st = k.CreateSubKey("SupportedTypes"))
                {
                    st.SetValue(".skyphoto", "");
                    foreach (var e in ImageExts) st.SetValue(e, "");
                }
            }
            using (var k = Registry.CurrentUser.CreateSubKey($@"Software\Microsoft\Windows\CurrentVersion\App Paths\{ExeName}"))
            {
                k.SetValue("", exe);
                k.SetValue("Path", o.Dir);
            }

            if (o.AssociateProject)
            {
                using (var k = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{ProjectProgId}"))
                {
                    k.SetValue("", "Sky Photo Project");
                    using (var i = k.CreateSubKey("DefaultIcon")) i.SetValue("", exe + ",0");
                    using (var c = k.CreateSubKey(@"shell\open\command")) c.SetValue("", $"\"{exe}\" \"%1\"");
                }
                using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\.skyphoto"))
                {
                    k.SetValue("", ProjectProgId);
                    using (var ow = k.CreateSubKey("OpenWithProgids")) ow.SetValue(ProjectProgId, new byte[0], RegistryValueKind.None);
                }
            }
            if (o.OpenWithImages)
            {
                using (var k = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{ImageProgId}"))
                {
                    k.SetValue("", "Image (Sky Master Photos)");
                    using (var i = k.CreateSubKey("DefaultIcon")) i.SetValue("", exe + ",0");
                    using (var c = k.CreateSubKey(@"shell\open\command")) c.SetValue("", $"\"{exe}\" \"%1\"");
                }
                foreach (var e in ImageExts)
                    using (var k = Registry.CurrentUser.CreateSubKey($@"Software\Classes\{e}\OpenWithProgids"))
                        k.SetValue(ImageProgId, new byte[0], RegistryValueKind.None);
                // "Edit with Sky Master Photos" on image right-click menus
                using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Classes\SystemFileAssociations\image\shell\SkyMasterPhotos.Edit"))
                {
                    k.SetValue("", "Edit with Sky Master Photos");
                    k.SetValue("Icon", exe + ",0");
                    using (var c = k.CreateSubKey("command")) c.SetValue("", $"\"{exe}\" \"%1\"");
                }
            }
            SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);
            progress(1, "Done");
        }

        public static void Uninstall(Action<double, string> progress)
        {
            string dir = InstalledDir() ?? Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            progress(0.05, "Closing Sky Master Photos…");
            CloseRunning();
            progress(0.2, "Removing shortcuts…");
            TryDelete(DesktopLnk);
            TryDelete(StartMenuLnk);
            progress(0.4, "Removing registry entries…");
            var cu = Registry.CurrentUser;
            TryDeleteKey(cu, UninstallKey);
            TryDeleteKey(cu, $@"Software\Classes\{ProjectProgId}");
            TryDeleteKey(cu, $@"Software\Classes\{ImageProgId}");
            TryDeleteKey(cu, $@"Software\Classes\Applications\{ExeName}");
            TryDeleteKey(cu, $@"Software\Microsoft\Windows\CurrentVersion\App Paths\{ExeName}");
            TryDeleteKey(cu, @"Software\Classes\SystemFileAssociations\image\shell\SkyMasterPhotos.Edit");
            try
            {
                using (var k = cu.OpenSubKey(@"Software\Classes\.skyphoto", true))
                    if (k != null && (k.GetValue("") as string) == ProjectProgId) { cu.DeleteSubKeyTree(@"Software\Classes\.skyphoto", false); }
            }
            catch { }
            foreach (var e in ImageExts)
                try { using (var k = cu.OpenSubKey($@"Software\Classes\{e}\OpenWithProgids", true)) k?.DeleteValue(ImageProgId, false); } catch { }
            SHChangeNotify(0x08000000, 0, IntPtr.Zero, IntPtr.Zero);

            progress(0.7, "Removing files…");
            if (dir != null && Directory.Exists(dir))
            {
                string self = Assembly.GetExecutingAssembly().Location;
                foreach (var f in Directory.GetFiles(dir, "*", SearchOption.AllDirectories))
                    if (!string.Equals(f, self, StringComparison.OrdinalIgnoreCase)) TryDelete(f);
                // the running uninstaller (and the folder) are removed after this process exits
                var psi = new ProcessStartInfo("cmd.exe", $"/c ping 127.0.0.1 -n 3 > nul & rmdir /s /q \"{dir}\"")
                {
                    CreateNoWindow = true,
                    UseShellExecute = false,
                    WorkingDirectory = Path.GetTempPath(),
                };
                try { Process.Start(psi); } catch { }
            }
            progress(1, "Done");
        }

        static void TryDelete(string f) { try { if (File.Exists(f)) File.Delete(f); } catch { } }
        static void TryDeleteKey(RegistryKey root, string path) { try { root.DeleteSubKeyTree(path, false); } catch { } }

        static void CreateShortcut(string lnk, string target, string description)
        {
            var t = Type.GetTypeFromProgID("WScript.Shell");
            object shell = Activator.CreateInstance(t);
            try
            {
                object sc = t.InvokeMember("CreateShortcut", BindingFlags.InvokeMethod, null, shell, new object[] { lnk });
                var st = sc.GetType();
                st.InvokeMember("TargetPath", BindingFlags.SetProperty, null, sc, new object[] { target });
                st.InvokeMember("WorkingDirectory", BindingFlags.SetProperty, null, sc, new object[] { Path.GetDirectoryName(target) });
                st.InvokeMember("IconLocation", BindingFlags.SetProperty, null, sc, new object[] { target + ",0" });
                st.InvokeMember("Description", BindingFlags.SetProperty, null, sc, new object[] { description });
                st.InvokeMember("Save", BindingFlags.InvokeMethod, null, sc, null);
                Marshal.FinalReleaseComObject(sc);
            }
            finally { Marshal.FinalReleaseComObject(shell); }
        }

        [DllImport("shell32.dll")]
        static extern void SHChangeNotify(int eventId, int flags, IntPtr item1, IntPtr item2);
    }
}

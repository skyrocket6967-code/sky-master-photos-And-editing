# Builds Sky Master Photos for Windows and Linux.
#   Output\Sky Master Photos Setup.exe                   – Windows installer to run / share
#   Output\App\Sky Master Photos.exe                     – Windows standalone app (no install needed)
#   Output\Linux\sky-master-photos-<ver>-linux-x64.tar.gz – Linux (Arch / CachyOS: makepkg -si, others: install.sh)
#   -SkipLinux skips the Linux package
param([switch]$SkipLinux)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$src = Join-Path $root 'src'
$out = Join-Path $root 'Output'
$stage = Join-Path $root 'build\stage'
$pub = Join-Path $root 'build\publish'

function Step($t) { Write-Host "`n==> $t" -ForegroundColor Cyan }

if (-not (Test-Path "$src\Shared\app.ico")) { Step 'Generating icon'; & "$root\tools\make-icon.ps1" }

Step 'Publishing Sky Master Photos (self-contained, single file)'
Remove-Item $pub -Recurse -Force -ErrorAction SilentlyContinue
dotnet publish "$src\SkyMasterPhotos\SkyMasterPhotos.csproj" -c Release -r win-x64 --self-contained true `
    -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
    -p:DebugType=none -p:PublishReadyToRun=false -o $pub
if ($LASTEXITCODE -ne 0) { throw 'publish failed' }

Step 'Building uninstaller'
dotnet build "$src\SkySetup\SkySetup.csproj" -c Release -p:Uninstaller=true
if ($LASTEXITCODE -ne 0) { throw 'uninstaller build failed' }

Step 'Packing payload'
Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force $stage | Out-Null
Copy-Item "$pub\SkyMasterPhotos.exe" "$stage\Sky Master Photos.exe"
Copy-Item "$src\SkySetup\bin\uninstall\net48\SkyUninstall.exe" "$stage\Uninstall Sky Master Photos.exe"
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = "$src\SkySetup\payload.zip"
Remove-Item $zip -ErrorAction SilentlyContinue
[System.IO.Compression.ZipFile]::CreateFromDirectory($stage, $zip, [System.IO.Compression.CompressionLevel]::Optimal, $false)

Step 'Building installer'
dotnet build "$src\SkySetup\SkySetup.csproj" -c Release
if ($LASTEXITCODE -ne 0) { throw 'installer build failed' }

if (-not $SkipLinux) {
    Step 'Publishing for Linux (linux-x64, self-contained, single file)'
    $lpub = Join-Path $root 'build\publish-linux'
    Remove-Item $lpub -Recurse -Force -ErrorAction SilentlyContinue
    dotnet publish "$src\SkyMasterPhotos\SkyMasterPhotos.csproj" -c Release -r linux-x64 --self-contained true `
        -p:PublishSingleFile=true -p:EnableCompressionInSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true `
        -p:DebugType=none -p:PublishReadyToRun=false -o $lpub
    if ($LASTEXITCODE -ne 0) { throw 'linux publish failed' }

    Step 'Packing Linux tarball'
    $ver = ([xml](Get-Content "$src\SkyMasterPhotos\SkyMasterPhotos.csproj")).Project.PropertyGroup.Version | Where-Object { $_ } | Select-Object -First 1
    $name = "sky-master-photos-$ver-linux-x64"
    $lstage = Join-Path $root "build\linux\$name"
    Remove-Item (Join-Path $root 'build\linux') -Recurse -Force -ErrorAction SilentlyContinue
    New-Item -ItemType Directory -Force $lstage | Out-Null
    Copy-Item "$lpub\SkyMasterPhotos" $lstage
    Copy-Item "$root\packaging\linux\*" $lstage
    Copy-Item "$src\Shared\logo.png" "$lstage\sky-master-photos.png"
    (Get-Content "$lstage\PKGBUILD" -Raw) -replace 'pkgver=[\d.]+', "pkgver=$ver" | Set-Content "$lstage\PKGBUILD" -NoNewline
    New-Item -ItemType Directory -Force "$out\Linux" | Out-Null
    $tgz = "$out\Linux\$name.tar.gz"
    Remove-Item $tgz -ErrorAction SilentlyContinue
    $wsl = Get-Command wsl.exe -ErrorAction SilentlyContinue
    if ($wsl -and (wsl.exe -l -q 2>$null)) {
        # WSL keeps the executable bits and LF line endings intact
        $toWsl = { param($p) '/mnt/' + $p.Substring(0, 1).ToLower() + $p.Substring(2).Replace('\', '/') }
        $ls = & $toWsl (Split-Path $lstage); $lt = & $toWsl $tgz
        wsl.exe -e sh -c "cd '$ls' && sed -i 's/\r`$//' $name/*.sh $name/PKGBUILD $name/*.desktop $name/*.xml $name/*.txt && chmod 644 $name/* && chmod 755 $name/SkyMasterPhotos $name/*.sh && tar czf '$lt' --owner=0 --group=0 $name"
    } else {
        tar.exe -czf $tgz -C (Split-Path $lstage) $name
    }
    if (-not (Test-Path $tgz)) { throw 'tarball failed' }
}

Step 'Collecting output'
New-Item -ItemType Directory -Force "$out\App" | Out-Null
Copy-Item "$src\SkySetup\bin\Release\net48\SkySetup.exe" "$out\Sky Master Photos Setup.exe" -Force
Copy-Item "$stage\Sky Master Photos.exe" "$out\App\Sky Master Photos.exe" -Force
Get-ChildItem $out -Recurse -File | ForEach-Object { '{0,-40} {1,8:N1} MB' -f $_.FullName.Substring($out.Length + 1), ($_.Length / 1MB) }
Write-Host "`nDone." -ForegroundColor Green

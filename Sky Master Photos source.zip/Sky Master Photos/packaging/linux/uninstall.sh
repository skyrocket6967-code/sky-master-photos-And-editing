#!/bin/sh
# removes what install.sh installed (your settings in ~/.config/Sky Master Photos are kept)
if [ "$(id -u)" -eq 0 ]; then
  app=/opt/sky-master-photos; bin=/usr/local/bin; share=/usr/local/share
else
  app="$HOME/.local/share/sky-master-photos"; bin="$HOME/.local/bin"; share="$HOME/.local/share"
fi
rm -rf "$app"
rm -f "$bin/sky-master-photos" "$share/applications/sky-master-photos.desktop" \
      "$share/icons/hicolor/512x512/apps/sky-master-photos.png" "$share/mime/packages/sky-master-photos.xml"
command -v update-mime-database >/dev/null && update-mime-database "$share/mime" >/dev/null 2>&1 || true
command -v update-desktop-database >/dev/null && update-desktop-database "$share/applications" >/dev/null 2>&1 || true
echo "Sky Master Photos removed."

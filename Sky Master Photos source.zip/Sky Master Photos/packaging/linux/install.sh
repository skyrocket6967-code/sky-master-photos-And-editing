#!/bin/sh
# Sky Master Photos — Linux installer (any distro: Arch / CachyOS, Fedora, Ubuntu, …)
#   ./install.sh            install for your user   (~/.local)
#   sudo ./install.sh       install for everyone    (/opt + /usr/local)
# On Arch / CachyOS you can instead build a real package:   makepkg -si
set -e
here="$(cd "$(dirname "$0")" && pwd)"
if [ "$(id -u)" -eq 0 ]; then
  app=/opt/sky-master-photos; bin=/usr/local/bin; share=/usr/local/share
else
  app="$HOME/.local/share/sky-master-photos"; bin="$HOME/.local/bin"; share="$HOME/.local/share"
fi
mkdir -p "$app" "$bin" "$share/applications" "$share/icons/hicolor/512x512/apps" "$share/mime/packages"
install -m755 "$here/SkyMasterPhotos" "$app/SkyMasterPhotos"
ln -sf "$app/SkyMasterPhotos" "$bin/sky-master-photos"
install -m644 "$here/sky-master-photos.png" "$share/icons/hicolor/512x512/apps/sky-master-photos.png"
install -m644 "$here/sky-master-photos.xml" "$share/mime/packages/sky-master-photos.xml"
sed "s|^Exec=sky-master-photos|Exec=$bin/sky-master-photos|" "$here/sky-master-photos.desktop" > "$share/applications/sky-master-photos.desktop"
chmod 644 "$share/applications/sky-master-photos.desktop"
command -v update-mime-database >/dev/null && update-mime-database "$share/mime" >/dev/null 2>&1 || true
command -v update-desktop-database >/dev/null && update-desktop-database "$share/applications" >/dev/null 2>&1 || true
command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q -t "$share/icons/hicolor" >/dev/null 2>&1 || true
echo "Sky Master Photos installed — find it in your app menu, or run: sky-master-photos"
case ":$PATH:" in *":$bin:"*) ;; *) echo "(note: $bin is not on your PATH; the menu entry works anyway)";; esac

Sky Master Photos 2.0 for Linux
===============================

Arch Linux / CachyOS / Manjaro / EndeavourOS (recommended)
    tar xf sky-master-photos-2.0.0-linux-x64.tar.gz
    cd sky-master-photos-2.0.0-linux-x64
    makepkg -si
  It's then a normal pacman package:   sudo pacman -R sky-master-photos   removes it.

Any other distro (or no root)
    ./install.sh            (just you, into ~/.local)
    sudo ./install.sh       (everyone, into /opt)
    ./uninstall.sh          removes it again

Or just run it straight from this folder:   ./SkyMasterPhotos

Notes
  * Everything is bundled (no .NET install needed). It needs X11 or XWayland,
    which KDE Plasma and GNOME include by default on Wayland.
  * In virtual machines (VirtualBox, VMware, QEMU) it renders on the CPU
    automatically, because VM 3D drivers often draw black windows.
      SKY_SOFTWARE_RENDER=1 sky-master-photos   force CPU rendering
      SKY_SOFTWARE_RENDER=0 sky-master-photos   force OpenGL
  * Settings and recent files live in ~/.config/Sky Master Photos
  * Crash details go to ~/.config/Sky Master Photos/crash.log

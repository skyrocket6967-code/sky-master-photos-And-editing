# Generates the Sky Master Photos app icon (multi-size PNG-in-ICO) and a 512px logo PNG.
param([string]$OutDir = (Join-Path $PSScriptRoot "..\src\Shared"))

Add-Type -AssemblyName System.Drawing
New-Item -ItemType Directory -Force $OutDir | Out-Null

function New-RoundRect([float]$x, [float]$y, [float]$w, [float]$h, [float]$r) {
    $p = New-Object System.Drawing.Drawing2D.GraphicsPath
    $d = $r * 2
    $p.AddArc($x, $y, $d, $d, 180, 90)
    $p.AddArc($x + $w - $d, $y, $d, $d, 270, 90)
    $p.AddArc($x + $w - $d, $y + $h - $d, $d, $d, 0, 90)
    $p.AddArc($x, $y + $h - $d, $d, $d, 90, 90)
    $p.CloseFigure()
    return $p
}

function Draw-Icon([int]$s) {
    $bmp = New-Object System.Drawing.Bitmap $s, $s, ([System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.PixelOffsetMode = 'HighQuality'
    $g.Clear([System.Drawing.Color]::Transparent)
    $pad = [Math]::Max(0.5, $s * 0.04)
    $rect = New-Object System.Drawing.RectangleF $pad, $pad, ($s - 2 * $pad), ($s - 2 * $pad)
    $path = New-RoundRect $rect.X $rect.Y $rect.Width $rect.Height ($s * 0.23)
    $c1 = [System.Drawing.Color]::FromArgb(255, 56, 189, 248)
    $c2 = [System.Drawing.Color]::FromArgb(255, 99, 102, 241)
    $c3 = [System.Drawing.Color]::FromArgb(255, 168, 85, 247)
    $br = New-Object System.Drawing.Drawing2D.LinearGradientBrush $rect, $c1, $c3, 45.0
    $blend = New-Object System.Drawing.Drawing2D.ColorBlend 3
    $blend.Colors = @($c1, $c2, $c3)
    $blend.Positions = @(0.0, 0.5, 1.0)
    $br.InterpolationColors = $blend
    $g.FillPath($br, $path)

    # soft top highlight
    $hl = New-Object System.Drawing.Drawing2D.LinearGradientBrush $rect, ([System.Drawing.Color]::FromArgb(70, 255, 255, 255)), ([System.Drawing.Color]::FromArgb(0, 255, 255, 255)), 90.0
    $g.FillPath($hl, $path)

    # sun
    $white = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(255, 255, 255, 255))
    $sr = $s * 0.115
    $g.FillEllipse($white, ($s * 0.66 - $sr), ($s * 0.32 - $sr), ($sr * 2), ($sr * 2))

    # mountains
    $m = New-Object System.Drawing.Drawing2D.GraphicsPath
    $pts = @(
        (New-Object System.Drawing.PointF ($s * 0.16), ($s * 0.76)),
        (New-Object System.Drawing.PointF ($s * 0.40), ($s * 0.40)),
        (New-Object System.Drawing.PointF ($s * 0.55), ($s * 0.60)),
        (New-Object System.Drawing.PointF ($s * 0.64), ($s * 0.50)),
        (New-Object System.Drawing.PointF ($s * 0.84), ($s * 0.76))
    )
    $m.AddPolygon($pts)
    $g.FillPath($white, $m)
    $g.Dispose()
    return $bmp
}

$sizes = 16, 24, 32, 48, 64, 128, 256
$pngs = @()
foreach ($s in $sizes) {
    $b = Draw-Icon $s
    $ms = New-Object System.IO.MemoryStream
    $b.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png)
    $pngs += , $ms.ToArray()
    $b.Dispose()
}

$icoPath = Join-Path $OutDir "app.ico"
$fs = [System.IO.File]::Create($icoPath)
$bw = New-Object System.IO.BinaryWriter $fs
$bw.Write([UInt16]0); $bw.Write([UInt16]1); $bw.Write([UInt16]$sizes.Count)
$offset = 6 + 16 * $sizes.Count
for ($i = 0; $i -lt $sizes.Count; $i++) {
    $s = $sizes[$i]
    $dim = if ($s -ge 256) { 0 } else { $s }
    $bw.Write([byte]$dim); $bw.Write([byte]$dim); $bw.Write([byte]0); $bw.Write([byte]0)
    $bw.Write([UInt16]1); $bw.Write([UInt16]32)
    $bw.Write([UInt32]$pngs[$i].Length); $bw.Write([UInt32]$offset)
    $offset += $pngs[$i].Length
}
foreach ($p in $pngs) { $bw.Write($p) }
$bw.Flush(); $fs.Close()

$big = Draw-Icon 512
$big.Save((Join-Path $OutDir "logo.png"), [System.Drawing.Imaging.ImageFormat]::Png)
$big.Dispose()
Write-Host "Icon written to $icoPath"

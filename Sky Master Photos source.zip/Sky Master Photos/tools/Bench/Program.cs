using System.Diagnostics;
using Avalonia;
using Avalonia.Media;
using SkyMasterPhotos.Core;
using Transforms = SkyMasterPhotos.Core.Transforms;

// Times the engine operations that decide how the editor feels on big photos.
int W = 6000, H = 4000;
if (args.Length >= 2) { W = int.Parse(args[0]); H = int.Parse(args[1]); }
Console.WriteLine($"Sky Master Photos engine benchmark — {W}×{H} ({W * H / 1e6:F0} MP), {Environment.ProcessorCount} threads");

var rnd = new Random(1);
uint[] Photo()
{
    var p = new uint[W * H];
    Parallel.For(0, H, y =>
    {
        for (int x = 0; x < W; x++)
        {
            int r = (x * 255 / W + y / 7) & 255, g = (y * 255 / H) & 255, b = ((x ^ y) * 3) & 255;
            p[y * W + x] = 0xFF000000u | (uint)(r << 16) | (uint)(g << 8) | (uint)b;
        }
    });
    return p;
}

var results = new List<(string, double)>();
void T(string name, Action a, int reps = 3)
{
    a(); // warm-up
    var best = double.MaxValue;
    for (int i = 0; i < reps; i++) { var sw = Stopwatch.StartNew(); a(); best = Math.Min(best, sw.Elapsed.TotalMilliseconds); }
    results.Add((name, best));
    Console.WriteLine($"  {name,-44} {best,9:F1} ms");
}

var doc = Document.CreateBlank(W, H, "bench", Colors.White);
doc.Layers[0].SetPixels(Photo(), W, H);
var top = new Layer("Paint", W, H, new uint[W * H]);
for (int y = 0; y < H; y += 3) for (int x = 0; x < W / 2; x++) top.Pixels[y * W + x] = 0x80FF2040;
top.Blend = BlendMode.Multiply;
doc.Layers.Insert(0, top);
var masked = new Layer("Masked", W, H, Photo()) { Opacity = 0.6 };
doc.Layers.Insert(0, masked);
doc.ActiveLayer = doc.Layers[0];
var flat = new uint[W * H];

if (args.Contains("--style"))
{
    var st = new LayerStyle { Shadow = true, Stroke = true, OuterGlow = true, Size = 12, Distance = 10 };
    var lp = doc.Layers[0].Pixels;
    T("layer style render (full layer)", () => st.Render(lp, null, W, H, 1), 2);
    var styled = doc.Layers[0]; styled.Style = st;
    T("composite 256x256 rect, styled layer", () => Compositor.Composite(doc.Layers, W, H, new Int32Rect(1000, 1000, 256, 256), flat), 3);
    return;
}
Console.WriteLine("Compositing");
T("composite 3 layers (multiply, opacity)", () => Compositor.Composite(doc.Layers, W, H, new Int32Rect(0, 0, W, H), flat));
T("composite 256×256 dirty rect", () => Compositor.Composite(doc.Layers, W, H, new Int32Rect(1000, 1000, 256, 256), flat), 20);
var screen = new uint[W * H];
var pin = System.Runtime.InteropServices.GCHandle.Alloc(screen, System.Runtime.InteropServices.GCHandleType.Pinned);
T("premultiply full frame for display", () => Compositor.WritePremul(flat, W, new Int32Rect(0, 0, W, H), pin.AddrOfPinnedObject(), W * 4));
pin.Free();

Console.WriteLine("Brush");
var b = new BrushSettings { Size = 80, Hardness = 0.7 };
T("stroke start (backup + coverage)", () => { var s = new StrokeSession(doc, doc.ActiveLayer, StrokeKind.Paint, b, 0xFF3366FF, new Vector()); });
T("stroke 300 px, size 80, incl. render", () =>
{
    var s = new StrokeSession(doc, doc.ActiveLayer, StrokeKind.Paint, b, 0xFF3366FF, new Vector());
    for (int i = 0; i <= 60; i++) { var r = s.MoveTo(new Point(500 + i * 5, 500 + i * 3)); if (!RectUtil.IsEmptyRect(r)) doc.Render(r); }
});
var big = new BrushSettings { Size = 500, Hardness = 0.3 };
T("stroke size 500, 20 moves, incl. render", () =>
{
    var s = new StrokeSession(doc, doc.ActiveLayer, StrokeKind.Paint, big, 0xFF3366FF, new Vector());
    for (int i = 0; i <= 20; i++) { var r = s.MoveTo(new Point(1500 + i * 40, 1500)); if (!RectUtil.IsEmptyRect(r)) doc.Render(r); }
});
T("history capture", () => doc.Capture());

Console.WriteLine("Filters & adjustments (full image)");
var px = doc.Layers[^1].Pixels;
T("gaussian blur r=20", () => Filters.GaussianBlur(px, W, H, 20), 2);
T("box blur r=10", () => Filters.BoxBlur(px, W, H, 10), 2);
T("motion blur 30px", () => Filters.MotionBlur(px, W, H, 20, 30), 1);
T("unsharp mask", () => Filters.UnsharpMask(px, W, H, 120, 2, 0), 2);
T("median r=2", () => Filters.Median(px, W, H, 2), 1);
T("hue / saturation", () => Adjustments.HueSaturation(px, 30, 20, 0, false), 2);
T("levels", () => Adjustments.Levels(px, 10, 240, 1.2, 0, 255), 2);
T("shadows / highlights", () => Adjustments.ShadowsHighlights(px, W, H, 40, 20), 1);
T("resize to 50%", () => Transforms.Resize(px, W, H, W / 2, H / 2), 2);
T("thumbnail 300px", () => ImageIO.MakeThumbPixels(px, W, H, 300, out _, out _), 3);

Console.WriteLine("Files");
var tmp = Path.Combine(Path.GetTempPath(), "smp-bench"); Directory.CreateDirectory(tmp);
T("save PNG", () => ImageIO.SaveImage(Path.Combine(tmp, "a.png"), flat, W, H), 1);
T("save JPEG", () => ImageIO.SaveImage(Path.Combine(tmp, "a.jpg"), flat, W, H), 1);
T("load JPEG", () => ImageIO.LoadPixels(Path.Combine(tmp, "a.jpg")), 1);
T("save project (.skyphoto)", () => ImageIO.SaveProject(doc, Path.Combine(tmp, "a.skyphoto")), 1);
T("load project", () => ImageIO.LoadProject(Path.Combine(tmp, "a.skyphoto")), 1);
T("save PSD", () => SkyMasterPhotos.Core.Psd.PsdWriter.Save(doc, Path.Combine(tmp, "a.psd")), 1);
T("load PSD", () => SkyMasterPhotos.Core.Psd.PsdReader.Read(Path.Combine(tmp, "a.psd")), 1);

if (args.Contains("--csv")) File.WriteAllLines(args[^1], results.Select(r => $"{r.Item1},{r.Item2:F1}"));
